﻿using System;
using System.Runtime.CompilerServices;
using A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002048 File Offset: 0x00000248
	[MethodImpl(MethodImplOptions.NoInlining)]
	internal static void m8DE2BAC152255AE()
	{
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00002054 File Offset: 0x00000254
	[MethodImpl(MethodImplOptions.NoInlining)]
	static <Module>()
	{
		A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
		<Module>.m8DE2BAC152255AE();
	}
}
