﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyVersion("6.0.0.0")]
[assembly: SuppressIldasm]
[assembly: SupportedOSPlatform("Windows7.0")]
[assembly: TargetPlatform("Windows7.0")]
[assembly: AssemblyProduct("燕云琴仙")]
[assembly: AssemblyInformationalVersion("6.0.0+4ea1a38e3a6caac3d64a3433c0ff5deb722dc8cf")]
[assembly: AssemblyTitle("YYQinXianBot")]
[assembly: AssemblyDescription("燕云十六声音乐软件")]
[assembly: AssemblyCopyright("Copyright © 2025")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyCompany("YYQinXian")]
[assembly: AssemblyFileVersion("6.0.0.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
[module: RefSafetyRules(11)]
