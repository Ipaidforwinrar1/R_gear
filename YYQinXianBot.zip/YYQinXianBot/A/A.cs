﻿using System;
using System.Collections.Concurrent;
using System.Runtime.CompilerServices;
using System.Threading;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000035 RID: 53
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088
	{
		// Token: 0x0600016B RID: 363 RVA: 0x0000E838 File Offset: 0x0000CA38
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088 A\u008D\u008C\u009A\u0090\u008B\u0093\u0091\u008B\u0090\u0089()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				object a_u0094_u009C_u008E_u0091_u008A_u0097_u009B_u0092_u0086_u;
				switch (num2)
				{
				case 1:
					if (A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u009B\u009A\u0086\u0097\u009A\u0094\u0095\u0090\u0090\u0098 != null)
					{
						goto IL_0044;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
				{
					bool flag = false;
					num2 = 3;
					continue;
				}
				case 3:
					try
					{
						bool flag;
						Monitor.Enter(a_u0094_u009C_u008E_u0091_u008A_u0097_u009B_u0092_u0086_u, ref flag);
						int num3 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0 == 0)
						{
							num3 = 0;
						}
						for (;;)
						{
							switch (num3)
							{
							case 1:
								goto IL_011B;
							case 2:
								if (A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u009B\u009A\u0086\u0097\u009A\u0094\u0095\u0090\u0090\u0098 != null)
								{
									num3 = 3;
									continue;
								}
								break;
							case 3:
								goto IL_00CE;
							}
							A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u009B\u009A\u0086\u0097\u009A\u0094\u0095\u0090\u0090\u0098 = new A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088();
							num3 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 == 0)
							{
								num3 = 0;
							}
						}
						IL_00CE:
						IL_011B:
						goto IL_0044;
					}
					finally
					{
						bool flag;
						if (flag)
						{
							goto IL_0184;
						}
						int num4 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 != 0)
						{
							num4 = 0;
						}
						IL_014A:
						switch (num4)
						{
						case 2:
							IL_0184:
							Monitor.Exit(a_u0094_u009C_u008E_u0091_u008A_u0097_u009B_u0092_u0086_u);
							num4 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 == 0)
							{
								num4 = 0;
								goto IL_014A;
							}
							goto IL_014A;
						}
					}
					break;
				case 4:
					goto IL_0044;
				}
				a_u0094_u009C_u008E_u0091_u008A_u0097_u009B_u0092_u0086_u = A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u0094\u009C\u008E\u0091\u008A\u0097\u009B\u0092\u0086\u0099;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 == 0)
				{
					num2 = 2;
				}
			}
			IL_0044:
			return A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u009B\u009A\u0086\u0097\u009A\u0094\u0095\u0090\u0090\u0098;
		}

		// Token: 0x0600016C RID: 364 RVA: 0x0000EA44 File Offset: 0x0000CC44
		[MethodImpl(MethodImplOptions.NoInlining)]
		private A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc == 0)
			{
				num = 0;
			}
			for (;;)
			{
				switch (num)
				{
				default:
					this.A\u0086\u0098\u0086\u0087\u008B\u008C\u008D\u0094\u0089\u008F = new ConcurrentDictionary<string, DateTime>();
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1803988e08d94458a1484838316ae19f != 0)
					{
						num = 1;
					}
					break;
				case 1:
					return;
				}
			}
		}

		// Token: 0x0600016D RID: 365 RVA: 0x0000EAD8 File Offset: 0x0000CCD8
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u008A\u009D\u0099\u0095\u009D\u0092\u009B\u009E\u009A\u0089(string \u0020)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				switch (num2)
				{
				default:
				{
					object[] array;
					array[0] = \u0020;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 == 0)
					{
						num2 = 2;
					}
					break;
				}
				case 1:
				{
					object[] array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c83fdfd7feb346bcbdc0a4168723b361 != 0)
					{
						num2 = 0;
					}
					break;
				}
				case 2:
				{
					object[] array;
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(4, array, this);
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_aeecb0ba81724219b3aab6c572f13b3f == 0)
					{
						num2 = 3;
					}
					break;
				}
				case 3:
					goto IL_005E;
				}
			}
			IL_005E:
			return (bool)array2[0];
		}

		// Token: 0x0600016E RID: 366 RVA: 0x0000EBA8 File Offset: 0x0000CDA8
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009C\u008D\u0099\u0096\u0091\u0093\u0097\u009E\u0090\u009E()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0086\u0098\u0086\u0087\u008B\u008C\u008D\u0094\u0089\u008F.Clear();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000EC0C File Offset: 0x0000CE0C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int A\u0086\u0089\u008E\u0090\u0086\u0092\u008E\u008B\u008F\u0092()
		{
			return this.A\u0086\u0098\u0086\u0087\u008B\u008C\u008D\u0094\u0089\u008F.Count;
		}

		// Token: 0x06000170 RID: 368 RVA: 0x0000EC20 File Offset: 0x0000CE20
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
					num2 = 3;
					continue;
				case 2:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u0094\u009C\u008E\u0091\u008A\u0097\u009B\u0092\u0086\u0099 = new object();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000171 RID: 369 RVA: 0x0000ECBC File Offset: 0x0000CEBC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0099\u009A\u008C\u0086\u0095\u0099\u0092\u009E\u0090\u0089()
		{
			return A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u0098\u0096\u0098\u008A\u008F\u0096\u008B\u0092\u0091\u008C == null;
		}

		// Token: 0x06000172 RID: 370 RVA: 0x0000ECD0 File Offset: 0x0000CED0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088 A\u0090\u0088\u0090\u009B\u009A\u0093\u0092\u0092\u009B\u0090()
		{
			return A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088.A\u0098\u0096\u0098\u008A\u008F\u0096\u008B\u0092\u0091\u008C;
		}

		// Token: 0x0400012B RID: 299
		[Nullable(2)]
		private static A\u008D\u008D\u0098\u009E\u008E\u0092\u009A\u008B\u0095\u0088 A\u009B\u009A\u0086\u0097\u009A\u0094\u0095\u0090\u0090\u0098;

		// Token: 0x0400012C RID: 300
		private static readonly object A\u0094\u009C\u008E\u0091\u008A\u0097\u009B\u0092\u0086\u0099;

		// Token: 0x0400012D RID: 301
		private readonly ConcurrentDictionary<string, DateTime> A\u0086\u0098\u0086\u0087\u008B\u008C\u008D\u0094\u0089\u008F;

		// Token: 0x0400012E RID: 302
		private static object A\u0098\u0096\u0098\u008A\u008F\u0096\u008B\u0092\u0091\u008C;
	}
}
