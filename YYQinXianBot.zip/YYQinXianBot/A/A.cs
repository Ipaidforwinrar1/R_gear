﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000059 RID: 89
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C
	{
		// Token: 0x060002AB RID: 683
		[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "FindWindow", SetLastError = true)]
		private static extern IntPtr AA\u008C\u008D\u0089\u008C\u009A\u008E\u008E\u008B\u008A([Nullable(2)] string lpClassName, string \u0020);

		// Token: 0x060002AC RID: 684
		[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "SendMessage")]
		private static extern IntPtr AA\u0096\u009A\u008A\u0086\u008C\u0090\u0095\u0090\u009B(IntPtr \u0020, uint \u0020, IntPtr \u0020, IntPtr \u0020);

		// Token: 0x060002AD RID: 685
		[DllImport("user32.dll", CharSet = CharSet.Auto, EntryPoint = "PostMessage")]
		private static extern bool A\u0093\u008E\u008F\u008A\u0094\u008A\u0096\u0092\u008C\u008F(IntPtr \u0020, uint \u0020, IntPtr \u0020, IntPtr \u0020);

		// Token: 0x060002AE RID: 686
		[DllImport("user32.dll", EntryPoint = "MapVirtualKey")]
		private static extern uint AA\u0090\u0099\u0099\u0098\u0093\u0097\u0097\u0091\u009D(uint \u0020, uint \u0020);

		// Token: 0x060002AF RID: 687 RVA: 0x0001671C File Offset: 0x0001491C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public IntPtr A\u0088\u008D\u0097\u0099\u0090\u008C\u008A\u0094\u009B\u008E(string \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					goto IL_0028;
				case 1:
					if (\u0020 == A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-242410958 + -2074834086) ^ 1356567961 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce))
					{
						goto IL_0097;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 == 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					goto IL_0097;
				}
			}
			IL_0028:
			return A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.AA\u008C\u008D\u0089\u008C\u009A\u008E\u008E\u008B\u008A(null, \u0020);
			IL_0097:
			return A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.AA\u008C\u008D\u0089\u008C\u009A\u008E\u008E\u008B\u008A(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1881530452 ^ 496377959 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754), \u0020);
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x000167EC File Offset: 0x000149EC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u0093\u0095\u0098\u009E\u0092\u0091\u008B\u0090\u0087\u009B(IntPtr \u0020, int \u0020)
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				int num5;
				switch (num2)
				{
				case 1:
				{
					int num3;
					A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.A\u0093\u008E\u008F\u008A\u0094\u008A\u0096\u0092\u008C\u008F(\u0020, 257U, (IntPtr)\u0020, (IntPtr)num3);
					num2 = 3;
					continue;
				}
				case 2:
					A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.A\u0093\u008E\u008F\u008A\u0094\u008A\u0096\u0092\u008C\u008F(\u0020, 258U, (IntPtr)\u0020, IntPtr.Zero);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					return true;
				case 4:
					return false;
				case 5:
				{
					if (\u0020 == IntPtr.Zero)
					{
						num2 = 4;
						continue;
					}
					uint num4 = A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.AA\u0090\u0099\u0099\u0098\u0093\u0097\u0097\u0091\u009D((uint)\u0020, 0U);
					num2 = 7;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd != 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				}
				case 6:
				{
					uint num4;
					int num3 = (int)((ulong)(1U | (num4 << 16) | 1073741824U) | 18446744071562067968UL);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 7:
				{
					uint num4;
					num5 = (int)(1U | (num4 << 16));
					num2 = 6;
					continue;
				}
				}
				A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.A\u0093\u008E\u008F\u008A\u0094\u008A\u0096\u0092\u008C\u008F(\u0020, 256U, (IntPtr)\u0020, (IntPtr)num5);
				num2 = 2;
			}
			return true;
		}

		// Token: 0x060002B1 RID: 689 RVA: 0x00016928 File Offset: 0x00014B28
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060002B2 RID: 690 RVA: 0x00016988 File Offset: 0x00014B88
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0087\u008E\u0088\u008D\u0097\u009C\u008D\u0092\u008B\u009A()
		{
			return A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.A\u0096\u0099\u0092\u0086\u009A\u0095\u009D\u0094\u0089\u0097 == null;
		}

		// Token: 0x060002B3 RID: 691 RVA: 0x00016994 File Offset: 0x00014B94
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C A\u0096\u0091\u0093\u009A\u0095\u008E\u0094\u0094\u008D\u0097()
		{
			return A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C.A\u0096\u0099\u0092\u0086\u009A\u0095\u009D\u0094\u0089\u0097;
		}

		// Token: 0x060002B4 RID: 692 RVA: 0x0001699C File Offset: 0x00014B9C
		static A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x040001AF RID: 431
		internal static object A\u0096\u0099\u0092\u0086\u009A\u0095\u009D\u0094\u0089\u0097;
	}
}
