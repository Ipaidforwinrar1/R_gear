﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000038 RID: 56
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u0094\u0087\u0086\u008A\u0091\u0095\u0087\u0094\u0090\u0098
	{
		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600017F RID: 383 RVA: 0x0000F87C File Offset: 0x0000DA7C
		// (set) Token: 0x06000180 RID: 384 RVA: 0x0000F88C File Offset: 0x0000DA8C
		[JsonPropertyName("ciphertext")]
		public string A\u0086\u0090\u0087\u008B\u0097\u009E\u0094\u0094\u0088\u0092
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u008B\u008C\u009A\u0093\u008E\u0089\u0092\u0094\u0092\u009C;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u008B\u008C\u009A\u0093\u008E\u0089\u0092\u0094\u0092\u009C = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3e7119b219884fb89fd2909088fcea1c == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000181 RID: 385 RVA: 0x0000F8EC File Offset: 0x0000DAEC
		// (set) Token: 0x06000182 RID: 386 RVA: 0x0000F8FC File Offset: 0x0000DAFC
		[JsonPropertyName("sign")]
		public string AA\u008E\u0092\u008A\u008B\u009D\u009E\u0099\u0090\u0094
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u009E\u009D\u0092\u0091\u0097\u0094\u009C\u0090\u0094\u009D;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u009E\u009D\u0092\u0091\u0097\u0094\u009C\u0090\u0094\u009D = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x06000183 RID: 387 RVA: 0x0000F95C File Offset: 0x0000DB5C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0094\u0087\u0086\u008A\u0091\u0095\u0087\u0094\u0090\u0098()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u008B\u008C\u009A\u0093\u008E\u0089\u0092\u0094\u0092\u009C = string.Empty;
			this.A\u009E\u009D\u0092\u0091\u0097\u0094\u009C\u0090\u0094\u009D = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6671b6ee6ac14cdc851c5f6ed0a20229 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000184 RID: 388 RVA: 0x0000F9E0 File Offset: 0x0000DBE0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0099\u008F\u009E\u0087\u008E\u0093\u0089\u009E\u0090\u0091()
		{
			return A\u0094\u0087\u0086\u008A\u0091\u0095\u0087\u0094\u0090\u0098.AA\u0099\u009C\u0087\u009E\u0094\u0090\u008A\u008C\u0089 == null;
		}

		// Token: 0x06000185 RID: 389 RVA: 0x0000F9F4 File Offset: 0x0000DBF4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0094\u0087\u0086\u008A\u0091\u0095\u0087\u0094\u0090\u0098 A\u008F\u0094\u0086\u008F\u0091\u0090\u0093\u008B\u009D\u009B()
		{
			return A\u0094\u0087\u0086\u008A\u0091\u0095\u0087\u0094\u0090\u0098.AA\u0099\u009C\u0087\u009E\u0094\u0090\u008A\u008C\u0089;
		}

		// Token: 0x06000186 RID: 390 RVA: 0x0000FA04 File Offset: 0x0000DC04
		static A\u0094\u0087\u0086\u008A\u0091\u0095\u0087\u0094\u0090\u0098()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000132 RID: 306
		[CompilerGenerated]
		private string A\u008B\u008C\u009A\u0093\u008E\u0089\u0092\u0094\u0092\u009C;

		// Token: 0x04000133 RID: 307
		[CompilerGenerated]
		private string A\u009E\u009D\u0092\u0091\u0097\u0094\u009C\u0090\u0094\u009D;

		// Token: 0x04000134 RID: 308
		private static object AA\u0099\u009C\u0087\u009E\u0094\u0090\u008A\u008C\u0089;
	}
}
