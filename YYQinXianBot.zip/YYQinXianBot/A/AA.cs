﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000031 RID: 49
	[Nullable(0)]
	[NullableContext(1)]
	public class AA\u009B\u008C\u0087\u008F\u009E\u008A\u0093\u0092\u008F
	{
		// Token: 0x0600014E RID: 334 RVA: 0x0000C7E0 File Offset: 0x0000A9E0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public AA\u009B\u008C\u0087\u008F\u009E\u008A\u0093\u0092\u008F(string \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 1;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 != 0)
			{
				num = 1;
			}
			for (;;)
			{
				switch (num)
				{
				default:
					return;
				case 1:
					if (\u0020 == null)
					{
						goto Block_2;
					}
					this.A\u009E\u0097\u009E\u008A\u0088\u0095\u0095\u008B\u0090\u0093 = \u0020;
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 != 0)
					{
						num = 0;
					}
					break;
				}
			}
			return;
			Block_2:
			throw new ArgumentNullException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-149166022 >> 3) ^ -1633575170 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0));
		}

		// Token: 0x0600014F RID: 335 RVA: 0x0000C89C File Offset: 0x0000AA9C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u009C\u0090\u0091\u009A\u008B\u0091\u009E\u009E\u0093\u0086(string \u0020)
		{
			int num = 2;
			int num2 = num;
			string text;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_0602;
				case 2:
					if (string.IsNullOrEmpty(\u0020))
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					else
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				case 3:
					return text;
				}
				break;
			}
			try
			{
				byte[] array = SHA256.HashData(Encoding.UTF8.GetBytes(this.A\u009E\u0097\u009E\u008A\u0088\u0095\u0095\u008B\u0090\u0093));
				int num3 = 8;
				for (;;)
				{
					byte[] array2;
					byte[] bytes;
					byte[] bytes2;
					byte[] array3;
					switch (num3)
					{
					case 0:
						goto IL_0553;
					case 1:
						text = Convert.ToBase64String(array2);
						num3 = 7;
						continue;
					case 2:
						break;
					case 3:
						Buffer.BlockCopy(bytes, 0, array2, 0, bytes.Length);
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_be5da1cd750e495490bb42f04b10e65d != 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					case 4:
					{
						Aes aes = Aes.Create();
						num3 = 5;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f == 0)
						{
							num3 = 3;
							continue;
						}
						continue;
					}
					case 5:
						try
						{
							Aes aes;
							aes.Key = array;
							int num4 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b != 0)
							{
								num4 = 1;
							}
							for (;;)
							{
								ICryptoTransform cryptoTransform;
								switch (num4)
								{
								case 0:
									goto IL_044C;
								case 1:
									aes.IV = bytes;
									num4 = 2;
									continue;
								case 2:
									aes.Mode = CipherMode.CBC;
									num4 = 5;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d != 0)
									{
										num4 = 2;
										continue;
									}
									continue;
								case 3:
									try
									{
										MemoryStream memoryStream = new MemoryStream();
										int num5 = 1;
										if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
										{
											num5 = 1;
										}
										switch (num5)
										{
										case 1:
											try
											{
												CryptoStream cryptoStream = new CryptoStream(memoryStream, cryptoTransform, CryptoStreamMode.Write);
												int num6 = 2;
												if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 != 0)
												{
													num6 = 1;
												}
												for (;;)
												{
													switch (num6)
													{
													case 1:
														goto IL_01C3;
													case 2:
														try
														{
															cryptoStream.Write(bytes2, 0, bytes2.Length);
															int num7 = 0;
															if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 != 0)
															{
																num7 = 1;
															}
															for (;;)
															{
																switch (num7)
																{
																case 1:
																	cryptoStream.FlushFinalBlock();
																	num7 = 0;
																	if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
																	{
																		num7 = 0;
																		continue;
																	}
																	continue;
																}
																break;
															}
															goto IL_01C3;
														}
														finally
														{
															if (cryptoStream != null)
															{
																goto IL_02BE;
															}
															int num8 = 0;
															if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590 == 0)
															{
																num8 = 0;
															}
															IL_0284:
															switch (num8)
															{
															case 2:
																IL_02BE:
																((IDisposable)cryptoStream).Dispose();
																num8 = 0;
																if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0 != 0)
																{
																	num8 = 1;
																	goto IL_0284;
																}
																goto IL_0284;
															}
														}
														break;
													}
													break;
													IL_01C3:
													array3 = memoryStream.ToArray();
													num6 = 0;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 == 0)
													{
														num6 = 0;
													}
												}
											}
											finally
											{
												if (memoryStream != null)
												{
													int num9 = 1;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b == 0)
													{
														num9 = 1;
													}
													for (;;)
													{
														switch (num9)
														{
														case 1:
															((IDisposable)memoryStream).Dispose();
															num9 = 0;
															if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 != 0)
															{
																num9 = 0;
																continue;
															}
															continue;
														}
														break;
													}
												}
											}
											break;
										}
										goto IL_0472;
									}
									finally
									{
										if (cryptoTransform != null)
										{
											goto IL_03F4;
										}
										int num10 = 0;
										if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 == 0)
										{
											num10 = 0;
										}
										IL_03BA:
										switch (num10)
										{
										case 2:
											IL_03F4:
											cryptoTransform.Dispose();
											num10 = 0;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c5518c15345b4b68b42acb503192f55c == 0)
											{
												num10 = 1;
												goto IL_03BA;
											}
											goto IL_03BA;
										}
									}
									break;
								case 4:
									goto IL_0472;
								case 5:
									break;
								default:
									goto IL_044C;
								}
								aes.Padding = PaddingMode.PKCS7;
								num4 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca != 0)
								{
									num4 = 0;
									continue;
								}
								continue;
								IL_044C:
								cryptoTransform = aes.CreateEncryptor();
								num4 = 3;
							}
							IL_0472:
							break;
						}
						finally
						{
							Aes aes;
							if (aes != null)
							{
								goto IL_04CA;
							}
							int num11 = 2;
							int num12 = num11;
							IL_0490:
							switch (num12)
							{
							case 1:
								IL_04CA:
								((IDisposable)aes).Dispose();
								num12 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330 != 0)
								{
									num12 = 0;
									goto IL_0490;
								}
								goto IL_0490;
							}
						}
						goto IL_04FB;
					case 6:
						goto IL_04FB;
					case 7:
						goto IL_0597;
					case 8:
						bytes = RandomNumberGenerator.GetBytes(16);
						num3 = 6;
						continue;
					default:
						goto IL_0553;
					}
					array2 = new byte[bytes.Length + array3.Length];
					num3 = 3;
					continue;
					IL_04FB:
					bytes2 = Encoding.UTF8.GetBytes(\u0020);
					num3 = 4;
					continue;
					IL_0553:
					Buffer.BlockCopy(array3, 0, array2, bytes.Length, array3.Length);
					num3 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b != 0)
					{
						num3 = 1;
					}
				}
				IL_0597:
				return text;
			}
			catch (Exception ex)
			{
				int num13 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7374b39cd1dd42699e43c77815e1074b != 0)
				{
					num13 = 0;
				}
				switch (num13)
				{
				default:
					throw new InvalidOperationException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1609698565 >> 2) ^ 36454380 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c83fdfd7feb346bcbdc0a4168723b361), ex);
				}
			}
			IL_0602:
			throw new ArgumentException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((28686127 >> 6) ^ 924173165 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1342393391 ^ 680498067 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889));
		}

		// Token: 0x06000150 RID: 336 RVA: 0x0000CFB4 File Offset: 0x0000B1B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u008A\u008C\u008B\u009D\u0089\u009B\u0097\u009E\u009E\u0091(string \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (string.IsNullOrEmpty(\u0020))
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a470257873ee4efe9970265367c819a3 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					else
					{
						HMACSHA256 hmacsha = new HMACSHA256(Encoding.UTF8.GetBytes(this.A\u009E\u0097\u009E\u008A\u0088\u0095\u0095\u008B\u0090\u0093));
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 != 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					break;
				case 2:
					goto IL_0060;
				case 3:
				{
					string text;
					return text;
				}
				}
				break;
			}
			goto IL_018B;
			IL_0060:
			try
			{
				byte[] bytes = Encoding.UTF8.GetBytes(\u0020);
				int num3 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_86e848c6696044348a77d8429afaaa88 != 0)
				{
					num3 = 0;
				}
				string text;
				for (;;)
				{
					switch (num3)
					{
					case 1:
					{
						HMACSHA256 hmacsha;
						text = BitConverter.ToString(hmacsha.ComputeHash(bytes)).Replace(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1186520438 - -1314777313) ^ 221125002 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4), "").ToLowerInvariant();
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef != 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					}
					}
					break;
				}
				return text;
			}
			finally
			{
				HMACSHA256 hmacsha;
				if (hmacsha != null)
				{
					goto IL_0132;
				}
				int num4 = 2;
				IL_011C:
				switch (num4)
				{
				default:
					IL_0132:
					((IDisposable)hmacsha).Dispose();
					num4 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2263b4ae313f4ba5ab3effe79a3ad3f1 == 0)
					{
						num4 = 1;
						goto IL_011C;
					}
					goto IL_011C;
				case 1:
					break;
				case 2:
					break;
				}
			}
			IL_018B:
			throw new ArgumentException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((845338078 - -606829882) ^ 866023322 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-452330619 - -634177689) ^ 6149849 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4));
		}

		// Token: 0x06000151 RID: 337 RVA: 0x0000D1DC File Offset: 0x0000B3DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool AA\u008C\u0092\u0091\u0087\u009D\u0097\u009B\u009D\u008C(string \u0020, string \u0020)
		{
			int num = 4;
			int num2 = num;
			bool flag;
			for (;;)
			{
				switch (num2)
				{
				case 0:
					goto IL_004F;
				case 1:
					return false;
				case 2:
					return flag;
				case 3:
					break;
				case 4:
					if (!string.IsNullOrEmpty(\u0020))
					{
						num2 = 3;
						continue;
					}
					return false;
				default:
					goto IL_004F;
				}
				IL_014A:
				if (string.IsNullOrEmpty(\u0020))
				{
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				else
				{
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				IL_004F:
				try
				{
					string text = this.A\u008A\u008C\u008B\u009D\u0089\u009B\u0097\u009E\u009E\u0091(\u0020);
					int num3 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 != 0)
					{
						num3 = 1;
					}
					for (;;)
					{
						switch (num3)
						{
						case 1:
							flag = CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(text), Encoding.UTF8.GetBytes(\u0020.ToLowerInvariant()));
							num3 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a != 0)
							{
								num3 = 0;
								continue;
							}
							continue;
						}
						break;
					}
					break;
				}
				catch
				{
					int num4 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a38905b424c9477eb3c3d2ef4ad1502c != 0)
					{
						num4 = 0;
					}
					for (;;)
					{
						switch (num4)
						{
						case 1:
							flag = false;
							num4 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c == 0)
							{
								num4 = 0;
								continue;
							}
							continue;
						}
						break;
					}
					break;
				}
				goto IL_014A;
			}
			return flag;
		}

		// Token: 0x06000152 RID: 338 RVA: 0x0000D390 File Offset: 0x0000B590
		[MethodImpl(MethodImplOptions.NoInlining)]
		[return: Nullable(2)]
		public string A\u008C\u008E\u0090\u008B\u0093\u008B\u0092\u008B\u0094\u0098(string \u0020, string \u0020)
		{
			int num = 1;
			int num2 = num;
			string text;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (!this.AA\u008C\u0092\u0091\u0087\u009D\u0097\u009B\u009D\u008C(\u0020, \u0020))
					{
						goto IL_0083;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a38905b424c9477eb3c3d2ef4ad1502c != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_003B;
				case 3:
					return text;
				case 4:
					goto IL_0083;
				case 5:
					goto IL_00CE;
				}
				if (string.IsNullOrEmpty(\u0020))
				{
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330 == 0)
					{
						num2 = 2;
					}
				}
				else
				{
					num2 = 5;
				}
			}
			IL_003B:
			return null;
			IL_0083:
			throw new CryptographicException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1712058326 ^ -1059192055 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904));
			IL_00CE:
			try
			{
				byte[] array = SHA256.HashData(Encoding.UTF8.GetBytes(this.A\u009E\u0097\u009E\u008A\u0088\u0095\u0095\u008B\u0090\u0093));
				int num3 = 3;
				for (;;)
				{
					byte[] array2;
					byte[] array4;
					byte[] array5;
					switch (num3)
					{
					case 0:
						goto IL_0632;
					case 1:
					{
						Aes aes = Aes.Create();
						num3 = 2;
						continue;
					}
					case 2:
						try
						{
							Aes aes;
							aes.Key = array;
							int num4 = 2;
							ICryptoTransform cryptoTransform;
							for (;;)
							{
								switch (num4)
								{
								case 1:
									aes.Padding = PaddingMode.PKCS7;
									num4 = 3;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7374b39cd1dd42699e43c77815e1074b == 0)
									{
										num4 = 5;
										continue;
									}
									continue;
								case 2:
									aes.IV = array2;
									num4 = 0;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c9177097f6d4245975a6f4f2351fc33 != 0)
									{
										num4 = 0;
										continue;
									}
									continue;
								case 3:
									goto IL_058A;
								case 4:
									goto IL_0238;
								case 5:
									cryptoTransform = aes.CreateDecryptor();
									num4 = 4;
									continue;
								}
								aes.Mode = CipherMode.CBC;
								num4 = 1;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 == 0)
								{
									num4 = 1;
								}
							}
							IL_0238:
							try
							{
								byte[] array3;
								MemoryStream memoryStream = new MemoryStream(array3);
								int num5 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 == 0)
								{
									num5 = 0;
								}
								switch (num5)
								{
								default:
									try
									{
										CryptoStream cryptoStream = new CryptoStream(memoryStream, cryptoTransform, CryptoStreamMode.Read);
										int num6 = 1;
										if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd != 0)
										{
											num6 = 1;
										}
										switch (num6)
										{
										case 1:
											try
											{
												MemoryStream memoryStream2 = new MemoryStream();
												int num7 = 0;
												if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_732282d3a2ef416a9e85867f5ef3f928 == 0)
												{
													num7 = 0;
												}
												switch (num7)
												{
												default:
													try
													{
														cryptoStream.CopyTo(memoryStream2);
														int num8 = 0;
														if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a73c42054dcb4c649e3326c08dd43fc3 != 0)
														{
															num8 = 0;
														}
														for (;;)
														{
															switch (num8)
															{
															default:
																array4 = memoryStream2.ToArray();
																num8 = 1;
																if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1803988e08d94458a1484838316ae19f != 0)
																{
																	num8 = 1;
																}
																break;
															case 1:
																goto IL_035D;
															}
														}
														IL_035D:;
													}
													finally
													{
														if (memoryStream2 != null)
														{
															goto IL_03C6;
														}
														int num9 = 0;
														if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 != 0)
														{
															num9 = 0;
														}
														IL_038C:
														switch (num9)
														{
														case 1:
															IL_03C6:
															((IDisposable)memoryStream2).Dispose();
															num9 = 2;
															goto IL_038C;
														}
													}
													break;
												case 1:
													break;
												}
											}
											finally
											{
												if (cryptoStream != null)
												{
													int num10 = 0;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 != 0)
													{
														num10 = 1;
													}
													for (;;)
													{
														switch (num10)
														{
														case 1:
															((IDisposable)cryptoStream).Dispose();
															num10 = 0;
															if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
															{
																num10 = 0;
																continue;
															}
															continue;
														}
														break;
													}
												}
											}
											break;
										}
									}
									finally
									{
										if (memoryStream != null)
										{
											goto IL_04D2;
										}
										int num11 = 1;
										if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 == 0)
										{
											num11 = 0;
										}
										IL_04AD:
										switch (num11)
										{
										case 2:
											IL_04D2:
											((IDisposable)memoryStream).Dispose();
											num11 = 0;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_37d4c0ccbd094f76a7cf8f93864def2a != 0)
											{
												num11 = 0;
												goto IL_04AD;
											}
											goto IL_04AD;
										}
									}
									break;
								case 1:
									break;
								}
							}
							finally
							{
								if (cryptoTransform != null)
								{
									int num12 = 1;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6 != 0)
									{
										num12 = 1;
									}
									for (;;)
									{
										switch (num12)
										{
										case 1:
											cryptoTransform.Dispose();
											num12 = 0;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 == 0)
											{
												num12 = 0;
												continue;
											}
											continue;
										}
										break;
									}
								}
							}
							IL_058A:
							break;
						}
						finally
						{
							Aes aes;
							if (aes != null)
							{
								int num13 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66 != 0)
								{
									num13 = 1;
								}
								for (;;)
								{
									switch (num13)
									{
									case 1:
										((IDisposable)aes).Dispose();
										num13 = 0;
										if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 == 0)
										{
											num13 = 0;
											continue;
										}
										continue;
									}
									break;
								}
							}
						}
						goto IL_05FC;
					case 3:
						array5 = Convert.FromBase64String(\u0020);
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 == 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					case 4:
						goto IL_05FC;
					case 5:
						break;
					case 6:
					{
						byte[] array3 = new byte[array5.Length - 16];
						num3 = 8;
						continue;
					}
					case 7:
						goto IL_06D1;
					case 8:
						Buffer.BlockCopy(array5, 0, array2, 0, 16);
						num3 = 6;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2 != 0)
						{
							num3 = 10;
							continue;
						}
						continue;
					case 9:
						text = null;
						num3 = 4;
						continue;
					case 10:
					{
						byte[] array3;
						Buffer.BlockCopy(array5, 16, array3, 0, array3.Length);
						num3 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a38905b424c9477eb3c3d2ef4ad1502c != 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					}
					case 11:
						goto IL_067D;
					default:
						goto IL_0632;
					}
					text = Encoding.UTF8.GetString(array4);
					num3 = 7;
					continue;
					IL_0632:
					if (array5.Length < 16)
					{
						num3 = 9;
						continue;
					}
					IL_067D:
					array2 = new byte[16];
					num3 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6671b6ee6ac14cdc851c5f6ed0a20229 == 0)
					{
						num3 = 6;
					}
				}
				IL_05FC:
				IL_06D1:;
			}
			catch (Exception)
			{
				int num14 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c == 0)
				{
					num14 = 0;
				}
				for (;;)
				{
					switch (num14)
					{
					default:
						text = null;
						num14 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 != 0)
						{
							num14 = 1;
						}
						break;
					case 1:
						goto IL_072E;
					}
				}
				IL_072E:;
			}
			return text;
		}

		// Token: 0x06000153 RID: 339 RVA: 0x0000DB88 File Offset: 0x0000BD88
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0089\u008C\u009B\u0092\u008A\u009A\u0087\u008B\u008C\u0090()
		{
			return AA\u009B\u008C\u0087\u008F\u009E\u008A\u0093\u0092\u008F.A\u0099\u008C\u0095\u0096\u009A\u0087\u009B\u0094\u0088\u008B == null;
		}

		// Token: 0x06000154 RID: 340 RVA: 0x0000DB9C File Offset: 0x0000BD9C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u009B\u008C\u0087\u008F\u009E\u008A\u0093\u0092\u008F A\u0099\u0091\u0086\u0099\u0093\u008A\u0093\u0090\u0096\u0094()
		{
			return AA\u009B\u008C\u0087\u008F\u009E\u008A\u0093\u0092\u008F.A\u0099\u008C\u0095\u0096\u009A\u0087\u009B\u0094\u0088\u008B;
		}

		// Token: 0x06000155 RID: 341 RVA: 0x0000DBAC File Offset: 0x0000BDAC
		static AA\u009B\u008C\u0087\u008F\u009E\u008A\u0093\u0092\u008F()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400011E RID: 286
		private readonly object A\u009E\u0097\u009E\u008A\u0088\u0095\u0095\u008B\u0090\u0093;

		// Token: 0x0400011F RID: 287
		internal static object A\u0099\u008C\u0095\u0096\u009A\u0087\u009B\u0094\u0088\u008B;
	}
}
