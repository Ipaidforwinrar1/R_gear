﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200005A RID: 90
	public partial class AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A : Form
	{
		// Token: 0x060002B5 RID: 693 RVA: 0x000169A4 File Offset: 0x00014BA4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 2;
			for (;;)
			{
				switch (num)
				{
				default:
					return;
				case 1:
					this.A\u008C\u008F\u008F\u0096\u0095\u0099\u008A\u0092\u0096\u0092();
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 != 0)
					{
						num = 0;
					}
					break;
				case 2:
					this.A\u0099\u0097\u009C\u0093\u0087\u0092\u009B\u009E\u0086\u0097();
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b == 0)
					{
						num = 0;
					}
					break;
				}
			}
		}

		// Token: 0x060002B6 RID: 694 RVA: 0x00016A48 File Offset: 0x00014C48
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008C\u008F\u008F\u0096\u0095\u0099\u008A\u0092\u0096\u0092()
		{
			switch (1)
			{
			case 1:
				try
				{
					Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-276687066 ^ -1755535980 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257));
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 == 0)
					{
						num = 0;
					}
					for (;;)
					{
						switch (num)
						{
						case 1:
							base.Icon = new Icon(manifestResourceStream);
							num = 2;
							continue;
						case 2:
							goto IL_00CA;
						}
						if (manifestResourceStream == null)
						{
							break;
						}
						num = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 == 0)
						{
							num = 1;
						}
					}
					IL_00CA:;
				}
				catch
				{
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 == 0)
					{
						num2 = 0;
					}
					switch (num2)
					{
					}
				}
				break;
			}
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x00016B8C File Offset: 0x00014D8C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008E\u008D\u008E\u008A\u008E\u0087\u0099\u0092\u0086\u009D([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
				{
					AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A.<btnConfirm_Click>d__2 <btnConfirm_Click>d__;
					<btnConfirm_Click>d__.<>1__state = -1;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 == 0)
					{
						num2 = 0;
					}
					break;
				}
				case 1:
					return;
				case 2:
				{
					AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A.<btnConfirm_Click>d__2 <btnConfirm_Click>d__;
					<btnConfirm_Click>d__.<>t__builder.Start<AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A.<btnConfirm_Click>d__2>(ref <btnConfirm_Click>d__);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3f1903d0114e4a7ea4b860c994faf9cc != 0)
					{
						num2 = 1;
					}
					break;
				}
				case 3:
				{
					AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A.<btnConfirm_Click>d__2 <btnConfirm_Click>d__;
					<btnConfirm_Click>d__.<>4__this = this;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 != 0)
					{
						num2 = 0;
					}
					break;
				}
				case 4:
				{
					AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A.<btnConfirm_Click>d__2 <btnConfirm_Click>d__;
					<btnConfirm_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
					num2 = 3;
					break;
				}
				}
			}
		}

		// Token: 0x060002B8 RID: 696 RVA: 0x00016C64 File Offset: 0x00014E64
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task A\u0092\u008B\u008F\u0087\u008E\u008F\u0093\u0092\u0092\u009A()
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[0];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_732282d3a2ef416a9e85867f5ef3f928 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_002F;
				}
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(24, array, this);
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_995893e15640499db99898ce289aa393 != 0)
				{
					num2 = 2;
				}
			}
			IL_002F:
			return (Task)array2[0];
		}

		// Token: 0x060002B9 RID: 697 RVA: 0x00016D04 File Offset: 0x00014F04
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0091\u008B\u0099\u008E\u0093\u0097\u0097\u0092\u0096\u0089([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					base.Close();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b == 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					base.DialogResult = DialogResult.Cancel;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363 != 0)
					{
						num2 = 1;
					}
					break;
				}
			}
		}

		// Token: 0x060002BB RID: 699 RVA: 0x00016E98 File Offset: 0x00015098
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0099\u0097\u009C\u0093\u0087\u0092\u009B\u009E\u0086\u0097()
		{
			int num = 45;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099 = new Label();
						num2 = 48;
						continue;
					case 2:
						this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099.Location = new Point(20, 25);
						num2 = 3;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 == 0)
						{
							num2 = 18;
							continue;
						}
						continue;
					case 3:
						base.AutoScaleMode = AutoScaleMode.Font;
						num2 = 35;
						continue;
					case 4:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((29240303 << 1) ^ 2091922731 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094);
						num2 = 26;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca != 0)
						{
							num2 = 14;
							continue;
						}
						continue;
					case 5:
						base.PerformLayout();
						num2 = 21;
						continue;
					case 6:
						base.MinimizeBox = false;
						num2 = 47;
						continue;
					case 7:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.Size = new Size(100, 32);
						num2 = 34;
						continue;
					case 8:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(141962467 ^ 480909968 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad);
						num2 = 31;
						continue;
					case 9:
						goto IL_016D;
					case 10:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089 = new Button();
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3e7119b219884fb89fd2909088fcea1c == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 11:
						this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099.TabIndex = 0;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 12:
						base.ResumeLayout(false);
						num2 = 5;
						continue;
					case 13:
						this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099.Size = new Size(49, 14);
						num2 = 11;
						continue;
					case 14:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.Click += this.A\u0091\u008B\u0099\u008E\u0093\u0097\u0097\u0092\u0096\u0089;
						num2 = 38;
						continue;
					case 15:
						this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-461999399 ^ -1915118383 ^ 1457974375 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db);
						num2 = 19;
						continue;
					case 16:
						this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--214711117 ^ 880107271 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3e7119b219884fb89fd2909088fcea1c), 10f);
						num2 = 40;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 17:
						base.FormBorderStyle = FormBorderStyle.FixedDialog;
						num2 = 4;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b72d53da7b174fadb50590dffdef5348 == 0)
						{
							num2 = 30;
							continue;
						}
						continue;
					case 18:
						this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-358404399 ^ -840590926 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad);
						num2 = 13;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6 == 0)
						{
							num2 = 8;
							continue;
						}
						continue;
					case 19:
						this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098.Size = new Size(220, 23);
						num2 = 27;
						continue;
					case 20:
						base.Controls.Add(this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096);
						num2 = 9;
						continue;
					case 21:
						return;
					case 22:
						goto IL_025D;
					case 23:
						this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098.MaxLength = 30;
						num2 = 15;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510 == 0)
						{
							num2 = 6;
							continue;
						}
						continue;
					case 24:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1699870387 ^ -1234133712 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef);
						num2 = 7;
						continue;
					case 25:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.TabIndex = 2;
						num2 = 6;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 != 0)
						{
							num2 = 29;
							continue;
						}
						continue;
					case 26:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.Size = new Size(100, 32);
						num2 = 25;
						continue;
					case 27:
						this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098.TabIndex = 0;
						num2 = 28;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b2d055de0c54ba08a92e6c6cd750833 != 0)
						{
							num2 = 16;
							continue;
						}
						continue;
					case 28:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(992923615 ^ 589076432 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850), 10f);
						num2 = 39;
						continue;
					case 29:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(649406881 ^ -2075055971 ^ -1649605755 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db);
						num2 = 41;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 == 0)
						{
							num2 = 37;
							continue;
						}
						continue;
					case 30:
						base.MaximizeBox = false;
						num2 = 6;
						continue;
					case 31:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.UseVisualStyleBackColor = true;
						num2 = 43;
						continue;
					case 32:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.Location = new Point(200, 70);
						num2 = 4;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 33:
						goto IL_0679;
					case 34:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.TabIndex = 1;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a != 0)
						{
							num2 = 8;
							continue;
						}
						continue;
					case 35:
						base.ClientSize = new Size(330, 125);
						num2 = 36;
						continue;
					case 36:
						base.Controls.Add(this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089);
						num2 = 20;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4 == 0)
						{
							num2 = 16;
							continue;
						}
						continue;
					case 37:
						base.Controls.Add(this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099);
						num2 = 16;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b != 0)
						{
							num2 = 17;
							continue;
						}
						continue;
					case 38:
						this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099.AutoSize = true;
						num2 = 22;
						continue;
					case 39:
						goto IL_07BF;
					case 40:
						this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098.Location = new Point(80, 22);
						num2 = 23;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_995893e15640499db99898ce289aa393 == 0)
						{
							num2 = 9;
							continue;
						}
						continue;
					case 41:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.UseVisualStyleBackColor = true;
						num2 = 14;
						continue;
					case 42:
						goto IL_05E2;
					case 43:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.Click += this.A\u008E\u008D\u008E\u008A\u008E\u0087\u0099\u0092\u0086\u009D;
						num2 = 46;
						continue;
					case 44:
						this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096 = new Button();
						num2 = 10;
						continue;
					case 45:
						this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098 = new TextBox();
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510 != 0)
						{
							num2 = 44;
							continue;
						}
						continue;
					case 46:
						this.A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-214453972 ^ -11646669 ^ 2127381145 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5), 10f);
						num2 = 32;
						continue;
					case 47:
						base.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-922289810 ^ -667339752 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b);
						num2 = 16;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b == 0)
						{
							num2 = 42;
							continue;
						}
						continue;
					case 48:
						base.SuspendLayout();
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
						{
							num2 = 16;
							continue;
						}
						continue;
					case 49:
						this.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((28686127 >> 6) ^ 91450057 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c);
						num2 = 12;
						continue;
					}
					this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1734807256 ^ -782838284 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a);
					num2 = 33;
				}
				IL_016D:
				base.Controls.Add(this.AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098);
				num = 37;
				continue;
				IL_025D:
				this.A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1505100509 ^ -806680129 ^ 1024483315 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c), 10f);
				num = 2;
				continue;
				IL_05E2:
				base.StartPosition = FormStartPosition.CenterParent;
				num = 49;
				continue;
				IL_0679:
				base.AutoScaleDimensions = new SizeF(7f, 17f);
				num = 3;
				continue;
				IL_07BF:
				this.A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096.Location = new Point(78, 70);
				num = 24;
			}
		}

		// Token: 0x060002BC RID: 700 RVA: 0x00017750 File Offset: 0x00015950
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0094\u0099\u0093\u009E\u0099\u0086\u008C\u008B\u0087\u0088()
		{
			return AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A.A\u009B\u0093\u0095\u008A\u0091\u0089\u0099\u0090\u008B\u0094 == null;
		}

		// Token: 0x060002BD RID: 701 RVA: 0x00017764 File Offset: 0x00015964
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A A\u008D\u0092\u009C\u008A\u0087\u009C\u009B\u009E\u0090\u0090()
		{
			return AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A.A\u009B\u0093\u0095\u008A\u0091\u0089\u0099\u0090\u008B\u0094;
		}

		// Token: 0x060002BE RID: 702 RVA: 0x00017774 File Offset: 0x00015974
		static AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x040001B1 RID: 433
		private object AA\u009B\u0096\u0099\u0089\u0096\u0097\u008E\u0099\u0098;

		// Token: 0x040001B2 RID: 434
		private object A\u009E\u0089\u008E\u0095\u0092\u008B\u009B\u009E\u0089\u0096;

		// Token: 0x040001B3 RID: 435
		private object A\u0092\u0090\u0088\u0088\u0087\u008F\u0090\u008B\u0099\u0089;

		// Token: 0x040001B4 RID: 436
		private object A\u0099\u008E\u0094\u0091\u009B\u009B\u008D\u008B\u009E\u0099;

		// Token: 0x040001B5 RID: 437
		private static object A\u009B\u0093\u0095\u008A\u0091\u0089\u0099\u0090\u008B\u0094;
	}
}
