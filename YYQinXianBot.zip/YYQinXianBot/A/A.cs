﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000043 RID: 67
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088
	{
		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060001D5 RID: 469 RVA: 0x000107BC File Offset: 0x0000E9BC
		// (set) Token: 0x060001D6 RID: 470 RVA: 0x000107CC File Offset: 0x0000E9CC
		[JsonPropertyName("username")]
		public string A\u0091\u0086\u0093\u008C\u009E\u009E\u0093\u008B\u009B\u0094
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0094\u0092\u0089\u0094\u0096\u009D\u0093\u0090\u0091\u0086;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0094\u0092\u0089\u0094\u0096\u009D\u0093\u0090\u0091\u0086 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060001D7 RID: 471 RVA: 0x0001082C File Offset: 0x0000EA2C
		// (set) Token: 0x060001D8 RID: 472 RVA: 0x0001083C File Offset: 0x0000EA3C
		[JsonPropertyName("password")]
		public string A\u009D\u008F\u008D\u0098\u009C\u008E\u009A\u0090\u009E\u0090
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0096\u0093\u009E\u009C\u009C\u0094\u0094\u0092\u0088\u0091;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0096\u0093\u009E\u009C\u009C\u0094\u0094\u0092\u0088\u0091 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8a7706961f2842d0974d2f2cdf994020 == 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0001089C File Offset: 0x0000EA9C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0094\u0092\u0089\u0094\u0096\u009D\u0093\u0090\u0091\u0086 = string.Empty;
			this.A\u0096\u0093\u009E\u009C\u009C\u0094\u0094\u0092\u0088\u0091 = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_be5da1cd750e495490bb42f04b10e65d == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001DA RID: 474 RVA: 0x00010920 File Offset: 0x0000EB20
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0091\u009E\u009B\u0088\u008B\u0094\u009D\u009E\u009E\u009C()
		{
			return A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088.A\u0097\u0090\u0097\u0093\u009A\u008B\u0095\u0092\u008F\u0092 == null;
		}

		// Token: 0x060001DB RID: 475 RVA: 0x00010934 File Offset: 0x0000EB34
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088 A\u0086\u009E\u0090\u009D\u008C\u0087\u008E\u008B\u0087\u008B()
		{
			return A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088.A\u0097\u0090\u0097\u0093\u009A\u008B\u0095\u0092\u008F\u0092;
		}

		// Token: 0x060001DC RID: 476 RVA: 0x00010944 File Offset: 0x0000EB44
		static A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000151 RID: 337
		[CompilerGenerated]
		private string A\u0094\u0092\u0089\u0094\u0096\u009D\u0093\u0090\u0091\u0086;

		// Token: 0x04000152 RID: 338
		[CompilerGenerated]
		private string A\u0096\u0093\u009E\u009C\u009C\u0094\u0094\u0092\u0088\u0091;

		// Token: 0x04000153 RID: 339
		internal static object A\u0097\u0090\u0097\u0093\u009A\u008B\u0095\u0092\u008F\u0092;
	}
}
