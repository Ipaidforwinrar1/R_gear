﻿namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200005A RID: 90
	public partial class AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A : global::System.Windows.Forms.Form
	{
		// Token: 0x060002BA RID: 698 RVA: 0x00016D8C File Offset: 0x00014F8C
		[global::System.Runtime.CompilerServices.MethodImpl(global::System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
		protected override void Dispose(bool \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 0:
					goto IL_0055;
				case 1:
					return;
				case 2:
					break;
				case 3:
					goto IL_0055;
				case 4:
					if (!\u0020)
					{
						num2 = 3;
						continue;
					}
					break;
				case 5:
					goto IL_0055;
				case 6:
					goto IL_00AF;
				default:
					goto IL_0055;
				}
				if (this.A\u0097\u0096\u0093\u0096\u0087\u0092\u0092\u0094\u0094\u008F == null)
				{
					num2 = 5;
					continue;
				}
				goto IL_00AF;
				IL_0055:
				base.Dispose(\u0020);
				num2 = 0;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d == 0)
				{
					num2 = 1;
					continue;
				}
				continue;
				IL_00AF:
				((global::System.IDisposable)this.A\u0097\u0096\u0093\u0096\u0087\u0092\u0092\u0094\u0094\u008F).Dispose();
				num2 = 0;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6671b6ee6ac14cdc851c5f6ed0a20229 == 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x040001B0 RID: 432
		private object A\u0097\u0096\u0093\u0096\u0087\u0092\u0092\u0094\u0094\u008F;
	}
}
