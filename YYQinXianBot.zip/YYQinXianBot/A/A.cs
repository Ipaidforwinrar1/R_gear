﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000046 RID: 70
	[NullableContext(1)]
	[Nullable(0)]
	public static class A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B
	{
		// Token: 0x060001F3 RID: 499 RVA: 0x00010EE4 File Offset: 0x0000F0E4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static void A\u0092\u0087\u0086\u008C\u0087\u0095\u008E\u0092\u0098\u0098()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.AA\u008F\u0091\u0099\u0091\u008C\u008B\u008F\u008D\u009A = Stopwatch.StartNew();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b7fd23e09aa54f94a15e32978d45910b != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				case 3:
					A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u008E\u008B\u008D\u009C\u009B\u008B\u008C\u0092\u008E\u009D = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-588132306 ^ -1945058681 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				}
				A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0098\u009C\u0093\u0088\u0089\u0097\u0092\u0094\u0091\u0098 = 0L;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x00010FB4 File Offset: 0x0000F1B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static void A\u0088\u0088\u0087\u009B\u0098\u0088\u0098\u0092\u0097\u008E(object \u0020, int \u0020)
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					return;
				case 2:
					goto IL_0081;
				case 3:
					A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u008E\u008B\u008D\u009C\u009B\u008B\u008C\u0092\u008E\u009D = \u0020;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 4:
					if (!A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.AA\u008F\u0091\u0099\u0091\u008C\u008B\u008F\u008D\u009A.IsRunning)
					{
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					else
					{
						long elapsedTicks = A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.AA\u008F\u0091\u0099\u0091\u008C\u008B\u008F\u008D\u009A.ElapsedTicks;
						if ((double)(elapsedTicks - A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0098\u009C\u0093\u0088\u0089\u0097\u0092\u0094\u0091\u0098) * 1000.0 / (double)Stopwatch.Frequency > (double)\u0020)
						{
							A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.AA\u009C\u0094\u0091\u008C\u008F\u009B\u008D\u008C\u0098++;
							if (A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.AA\u009C\u0094\u0091\u008C\u008F\u009B\u008D\u008C\u0098 >= 3)
							{
								A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u009A\u0086\u008B\u0087\u0090\u0098\u0086\u0094\u0088\u009C(\u0020);
							}
						}
						A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0098\u009C\u0093\u0088\u0089\u0097\u0092\u0094\u0091\u0098 = elapsedTicks;
						num2 = 5;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 == 0)
						{
							num2 = 6;
							continue;
						}
						continue;
					}
					break;
				case 5:
					if (A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.AA\u008F\u0091\u0099\u0091\u008C\u008B\u008F\u008D\u009A != null)
					{
						num2 = 4;
						continue;
					}
					goto IL_0081;
				case 6:
					A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u008E\u008B\u008D\u009C\u009B\u008B\u008C\u0092\u008E\u009D = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
				IL_0081:
				A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0092\u0087\u0086\u008C\u0087\u0095\u008E\u0092\u0098\u0098();
				num2 = 3;
			}
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x00011108 File Offset: 0x0000F308
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u009A\u0086\u008B\u0087\u0090\u0098\u0086\u0094\u0088\u009C(object \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					Task.Delay(Random.Shared.Next(3000, 8000)).Wait();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				}
				Application.Exit();
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 != 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x000111A8 File Offset: 0x0000F3A8
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 1;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 2:
						goto IL_0039;
					case 3:
						A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.AA\u009C\u0094\u0091\u008C\u008F\u009B\u008D\u008C\u0098 = 0;
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					case 4:
						return;
					case 5:
						A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0098\u009C\u0093\u0088\u0089\u0097\u0092\u0094\u0091\u0098 = 0L;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					}
					A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
					num2 = 5;
				}
				IL_0039:
				A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u008E\u008B\u008D\u009C\u009B\u008B\u008C\u0092\u008E\u009D = "";
				num = 4;
			}
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x00011284 File Offset: 0x0000F484
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool AA\u0090\u009A\u0094\u0086\u008D\u0098\u0088\u0089\u0091()
		{
			return A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u008E\u008A\u0099\u0094\u0086\u0088\u008E\u0094\u0089\u008E == null;
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x00011298 File Offset: 0x0000F498
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B A\u0088\u008B\u0091\u0099\u0097\u008C\u0097\u008B\u0092\u0088()
		{
			return A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u008E\u008A\u0099\u0094\u0086\u0088\u008E\u0094\u0089\u008E;
		}

		// Token: 0x0400015C RID: 348
		[Nullable(2)]
		private static Stopwatch AA\u008F\u0091\u0099\u0091\u008C\u008B\u008F\u008D\u009A;

		// Token: 0x0400015D RID: 349
		private static long A\u0098\u009C\u0093\u0088\u0089\u0097\u0092\u0094\u0091\u0098;

		// Token: 0x0400015E RID: 350
		private static int AA\u009C\u0094\u0091\u008C\u008F\u009B\u008D\u008C\u0098;

		// Token: 0x0400015F RID: 351
		private static object A\u008E\u008B\u008D\u009C\u009B\u008B\u008C\u0092\u008E\u009D;

		// Token: 0x04000160 RID: 352
		internal static object A\u008E\u008A\u0099\u0094\u0086\u0088\u008E\u0094\u0089\u008E;
	}
}
