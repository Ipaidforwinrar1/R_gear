﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200006A RID: 106
	internal class A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089
	{
		// Token: 0x06000331 RID: 817 RVA: 0x0002EA98 File Offset: 0x0002CC98
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089()
		{
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x06000332 RID: 818 RVA: 0x0002EC00 File Offset: 0x0002CE00
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089()
		{
		}

		// Token: 0x06000333 RID: 819 RVA: 0x0002EC08 File Offset: 0x0002CE08
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0090\u008C\u008C\u009B\u0094\u009C\u008E\u008B\u009A\u008C()
		{
		}

		// Token: 0x06000334 RID: 820 RVA: 0x0002EC0C File Offset: 0x0002CE0C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static byte[] A\u009C\u0097\u0098\u0096\u009B\u009A\u0097\u0090\u0091\u008C(object \u0020)
		{
			uint[] array = new uint[16];
			uint num = (uint)((448 - \u0020.Length * 8 % 512 + 512) % 512);
			if (num == 0U)
			{
				num = 512U;
			}
			uint num2 = (uint)((long)\u0020.Length + (long)((ulong)(num / 8U)) + 8L);
			ulong num3 = (ulong)((long)\u0020.Length * 8L);
			byte[] array2 = new byte[num2];
			for (int i = 0; i < \u0020.Length; i++)
			{
				array2[i] = \u0020[i];
			}
			byte[] array3 = array2;
			int num4 = \u0020.Length;
			array3[num4] |= 128;
			for (int j = 8; j > 0; j--)
			{
				array2[(int)(checked((IntPtr)(unchecked((ulong)num2 - (ulong)((long)j)))))] = (byte)((num3 >> (8 - j) * 8) & 255UL);
			}
			uint num5 = (uint)(array2.Length * 8 / 32);
			uint num6 = 1732584193U;
			uint num7 = 4023233417U;
			uint num8 = 2562383102U;
			uint num9 = 271733878U;
			for (uint num10 = 0U; num10 < num5 / 16U; num10 += 1U)
			{
				uint num11 = num10 << 6;
				for (uint num12 = 0U; num12 < 61U; num12 += 4U)
				{
					array[(int)(num12 >> 2)] = (uint)(((int)array2[(int)(num11 + (num12 + 3U))] << 24) | ((int)array2[(int)(num11 + (num12 + 2U))] << 16) | ((int)array2[(int)(num11 + (num12 + 1U))] << 8) | (int)array2[(int)(num11 + num12)]);
				}
				uint num13 = num6;
				uint num14 = num7;
				uint num15 = num8;
				uint num16 = num9;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num6, num7, num8, num9, 0U, 7, 1U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num9, num6, num7, num8, 1U, 12, 2U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num8, num9, num6, num7, 2U, 17, 3U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num7, num8, num9, num6, 3U, 22, 4U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num6, num7, num8, num9, 4U, 7, 5U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num9, num6, num7, num8, 5U, 12, 6U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num8, num9, num6, num7, 6U, 17, 7U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num7, num8, num9, num6, 7U, 22, 8U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num6, num7, num8, num9, 8U, 7, 9U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num9, num6, num7, num8, 9U, 12, 10U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num8, num9, num6, num7, 10U, 17, 11U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num7, num8, num9, num6, 11U, 22, 12U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num6, num7, num8, num9, 12U, 7, 13U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num9, num6, num7, num8, 13U, 12, 14U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num8, num9, num6, num7, 14U, 17, 15U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref num7, num8, num9, num6, 15U, 22, 16U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num6, num7, num8, num9, 1U, 5, 17U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num9, num6, num7, num8, 6U, 9, 18U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num8, num9, num6, num7, 11U, 14, 19U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num7, num8, num9, num6, 0U, 20, 20U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num6, num7, num8, num9, 5U, 5, 21U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num9, num6, num7, num8, 10U, 9, 22U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num8, num9, num6, num7, 15U, 14, 23U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num7, num8, num9, num6, 4U, 20, 24U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num6, num7, num8, num9, 9U, 5, 25U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num9, num6, num7, num8, 14U, 9, 26U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num8, num9, num6, num7, 3U, 14, 27U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num7, num8, num9, num6, 8U, 20, 28U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num6, num7, num8, num9, 13U, 5, 29U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num9, num6, num7, num8, 2U, 9, 30U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num8, num9, num6, num7, 7U, 14, 31U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref num7, num8, num9, num6, 12U, 20, 32U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num6, num7, num8, num9, 5U, 4, 33U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num9, num6, num7, num8, 8U, 11, 34U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num8, num9, num6, num7, 11U, 16, 35U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num7, num8, num9, num6, 14U, 23, 36U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num6, num7, num8, num9, 1U, 4, 37U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num9, num6, num7, num8, 4U, 11, 38U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num8, num9, num6, num7, 7U, 16, 39U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num7, num8, num9, num6, 10U, 23, 40U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num6, num7, num8, num9, 13U, 4, 41U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num9, num6, num7, num8, 0U, 11, 42U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num8, num9, num6, num7, 3U, 16, 43U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num7, num8, num9, num6, 6U, 23, 44U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num6, num7, num8, num9, 9U, 4, 45U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num9, num6, num7, num8, 12U, 11, 46U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num8, num9, num6, num7, 15U, 16, 47U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref num7, num8, num9, num6, 2U, 23, 48U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num6, num7, num8, num9, 0U, 6, 49U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num9, num6, num7, num8, 7U, 10, 50U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num8, num9, num6, num7, 14U, 15, 51U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num7, num8, num9, num6, 5U, 21, 52U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num6, num7, num8, num9, 12U, 6, 53U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num9, num6, num7, num8, 3U, 10, 54U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num8, num9, num6, num7, 10U, 15, 55U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num7, num8, num9, num6, 1U, 21, 56U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num6, num7, num8, num9, 8U, 6, 57U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num9, num6, num7, num8, 15U, 10, 58U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num8, num9, num6, num7, 6U, 15, 59U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num7, num8, num9, num6, 13U, 21, 60U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num6, num7, num8, num9, 4U, 6, 61U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num9, num6, num7, num8, 11U, 10, 62U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num8, num9, num6, num7, 2U, 15, 63U, array);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref num7, num8, num9, num6, 9U, 21, 64U, array);
				num6 += num13;
				num7 += num14;
				num8 += num15;
				num9 += num16;
			}
			byte[] array4 = new byte[16];
			Array.Copy(BitConverter.GetBytes(num6), 0, array4, 0, 4);
			Array.Copy(BitConverter.GetBytes(num7), 0, array4, 4, 4);
			Array.Copy(BitConverter.GetBytes(num8), 0, array4, 8, 4);
			Array.Copy(BitConverter.GetBytes(num9), 0, array4, 12, 4);
			return array4;
		}

		// Token: 0x06000335 RID: 821 RVA: 0x0002F270 File Offset: 0x0002D470
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u008D\u0093\u008D\u009C\u0098\u009A\u0099\u0092\u0094\u009D(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, object \u0020)
		{
			\u0020 += A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008E\u0086\u0096\u008C\u009B\u008A\u0090\u008E\u0093(\u0020 + ((\u0020 & \u0020) | (~\u0020 & \u0020)) + \u0020[(int)\u0020] + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0096\u009C\u008C\u0096\u009D\u0096\u0092\u008D\u0094[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000336 RID: 822 RVA: 0x0002F29C File Offset: 0x0002D49C
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u0097\u008D\u008A\u008F\u0092\u0098\u008E\u008B\u0092\u0089(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, object \u0020)
		{
			\u0020 += A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008E\u0086\u0096\u008C\u009B\u008A\u0090\u008E\u0093(\u0020 + ((\u0020 & \u0020) | (\u0020 & ~\u0020)) + \u0020[(int)\u0020] + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0096\u009C\u008C\u0096\u009D\u0096\u0092\u008D\u0094[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000337 RID: 823 RVA: 0x0002F2C8 File Offset: 0x0002D4C8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void AA\u0089\u0098\u0090\u008D\u0099\u009B\u0091\u008D\u0088(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, object \u0020)
		{
			\u0020 += A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008E\u0086\u0096\u008C\u009B\u008A\u0090\u008E\u0093(\u0020 + (\u0020 ^ \u0020 ^ \u0020) + \u0020[(int)\u0020] + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0096\u009C\u008C\u0096\u009D\u0096\u0092\u008D\u0094[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000338 RID: 824 RVA: 0x0002F2F0 File Offset: 0x0002D4F0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u0088\u0095\u008D\u0089\u008F\u008C\u0097\u0094\u009E\u0097(ref uint \u0020, uint \u0020, uint \u0020, uint \u0020, uint \u0020, ushort \u0020, uint \u0020, object \u0020)
		{
			\u0020 += A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008E\u0086\u0096\u008C\u009B\u008A\u0090\u008E\u0093(\u0020 + (\u0020 ^ (\u0020 | ~\u0020)) + \u0020[(int)\u0020] + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0096\u009C\u008C\u0096\u009D\u0096\u0092\u008D\u0094[(int)(\u0020 - 1U)], \u0020);
		}

		// Token: 0x06000339 RID: 825 RVA: 0x0002F318 File Offset: 0x0002D518
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static uint A\u0099\u008E\u0086\u0096\u008C\u009B\u008A\u0090\u008E\u0093(uint \u0020, ushort \u0020)
		{
			return (\u0020 >> (int)(32 - \u0020)) | (\u0020 << (int)\u0020);
		}

		// Token: 0x0600033A RID: 826 RVA: 0x0002F32C File Offset: 0x0002D52C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static byte[] A\u0091\u0091\u008E\u0096\u009B\u0094\u009A\u0094\u009E\u0086(object \u0020)
		{
			if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u008A\u0090\u008B\u008A\u0092\u0086\u0094\u008B\u008C())
			{
				return new MD5CryptoServiceProvider().ComputeHash(\u0020);
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0097\u0098\u0096\u009B\u009A\u0097\u0090\u0091\u008C(\u0020);
		}

		// Token: 0x0600033B RID: 827 RVA: 0x0002F34C File Offset: 0x0002D54C
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u009B\u009B\u0092\u009B\u008C\u008E\u0095\u008B\u009D\u0090()
		{
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x0600033C RID: 828 RVA: 0x0002F37C File Offset: 0x0002D57C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0088\u008A\u0090\u008B\u008A\u0092\u0086\u0094\u008B\u008C()
		{
			if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008D\u009C\u009B\u0095\u0088\u009A\u008B\u008F\u0090)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u009E\u009A\u009B\u008D\u0089\u0098\u009E\u009E\u0090();
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008D\u009C\u009B\u0095\u0088\u009A\u008B\u008F\u0090 = true;
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0093\u0091\u0089\u008B\u0096\u008B\u0090\u008B;
		}

		// Token: 0x0600033D RID: 829 RVA: 0x0002F398 File Offset: 0x0002D598
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal byte[] A\u0097\u0096\u0087\u008E\u008A\u0091\u0092\u0090\u0094\u0093()
		{
			int length = "reJQQ1nAc9MlrmlZhUTlCV".Length;
			return new byte[] { 1, 2 };
		}

		// Token: 0x0600033E RID: 830 RVA: 0x0002F3B8 File Offset: 0x0002D5B8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal byte[] A\u0092\u0089\u008B\u008D\u0096\u008D\u0099\u0090\u0088\u009B()
		{
			int length = "57rUFGJrvcHAZwGQ".Length;
			return new byte[] { 1, 2 };
		}

		// Token: 0x0600033F RID: 831 RVA: 0x0002F3D8 File Offset: 0x0002D5D8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal byte[] A\u0094\u0091\u008E\u009D\u0093\u0099\u009B\u0094\u008F\u0099()
		{
			int length = "hsWiYJvinSz9V9K20U".Length;
			return new byte[] { 1, 2 };
		}

		// Token: 0x06000340 RID: 832 RVA: 0x0002F3F8 File Offset: 0x0002D5F8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal byte[] A\u009D\u008D\u009C\u0094\u0099\u008D\u008E\u008B\u009A\u0086()
		{
			int length = "ahjSlO3Sz3lSxznuN".Length;
			return new byte[] { 1, 2 };
		}

		// Token: 0x06000341 RID: 833 RVA: 0x0002F418 File Offset: 0x0002D618
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static void A\u0094\u0096\u009C\u008C\u009C\u0089\u008D\u009E\u0099\u008C(RuntimeTypeHandle \u0020)
		{
			try
			{
				Type typeFromHandle = Type.GetTypeFromHandle(\u0020);
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0093\u0091\u0096\u009C\u0092\u008B\u0087\u009E == null)
				{
					object a_u0086_u0099_u0086_u0088_u0091_u0098_u0099_u008B_u0098_u = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u0086\u0088\u0091\u0098\u0099\u008B\u0098\u0099;
					lock (a_u0086_u0099_u0086_u0088_u0091_u0098_u0099_u008B_u0098_u)
					{
						Dictionary<int, int> dictionary = new Dictionary<int, int>();
						BinaryReader binaryReader = new BinaryReader(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).Assembly.GetManifestResourceStream("8b\u008cj\u0097n\u00912\u0092\u008b\u0096\u0091961\u009bi\u0098.\u008bt\u0095\u009ca8\u009223\u0093\u009e\u0095p\u00869\u00994\u0090"));
						binaryReader.BaseStream.Position = 0L;
						byte[] array = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
						binaryReader.Close();
						if (array.Length != 0)
						{
							int num = array.Length % 4;
							int num2 = array.Length / 4;
							byte[] array2 = new byte[array.Length];
							uint num3 = 0U;
							if (num > 0)
							{
								num2++;
							}
							for (int i = 0; i < num2; i++)
							{
								int num4 = i * 4;
								uint num5 = 255U;
								int num6 = 0;
								uint num7;
								if (i == num2 - 1 && num > 0)
								{
									num7 = 0U;
									for (int j = 0; j < num; j++)
									{
										if (j > 0)
										{
											num7 <<= 8;
										}
										num7 |= (uint)array[array.Length - (1 + j)];
									}
								}
								else
								{
									uint num8 = (uint)num4;
									num7 = (uint)(((int)array[(int)(num8 + 3U)] << 24) | ((int)array[(int)(num8 + 2U)] << 16) | ((int)array[(int)(num8 + 1U)] << 8) | (int)array[(int)num8]);
								}
								num3 = num3;
								num3 += A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u0089\u0090\u008C\u0088\u0094\u009D\u008B\u008B\u0098(num3);
								if (i == num2 - 1 && num > 0)
								{
									uint num9 = num3 ^ num7;
									for (int k = 0; k < num; k++)
									{
										if (k > 0)
										{
											num5 <<= 8;
											num6 += 8;
										}
										array2[num4 + k] = (byte)((num9 & num5) >> num6);
									}
								}
								else
								{
									uint num10 = num3 ^ num7;
									array2[num4] = (byte)(num10 & 255U);
									array2[num4 + 1] = (byte)((num10 & 65280U) >> 8);
									array2[num4 + 2] = (byte)((num10 & 16711680U) >> 16);
									array2[num4 + 3] = (byte)((num10 & 4278190080U) >> 24);
								}
							}
							array = array2;
							int num11 = array.Length / 8;
							A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0093\u0091\u0090\u0091\u009B\u0095\u009E\u009A\u0093 a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0093\u0091\u0090\u0091\u009B\u0095\u009E\u009A\u0093(new MemoryStream(array));
							for (int l = 0; l < num11; l++)
							{
								int num12 = a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u.A\u0091\u008F\u0092\u0093\u0098\u009A\u0095\u0092\u0097\u008F();
								int num13 = a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u.A\u0091\u008F\u0092\u0093\u0098\u009A\u0095\u0092\u0097\u008F();
								dictionary.Add(num12, num13);
							}
							a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u.A\u0094\u0094\u0099\u0098\u008C\u009B\u009D\u0094\u0091\u0099();
						}
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0093\u0091\u0096\u009C\u0092\u008B\u0087\u009E = dictionary;
					}
				}
				foreach (FieldInfo fieldInfo in typeFromHandle.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.GetField))
				{
					int metadataToken = fieldInfo.MetadataToken;
					int num14 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0093\u0091\u0096\u009C\u0092\u008B\u0087\u009E[metadataToken];
					bool flag2 = (num14 & 1073741824) > 0;
					num14 &= 1073741823;
					MethodInfo methodInfo = (MethodInfo)typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).Module.ResolveMethod(num14, typeFromHandle.GetGenericArguments(), new Type[0]);
					if (methodInfo.IsStatic)
					{
						fieldInfo.SetValue(null, Delegate.CreateDelegate(fieldInfo.FieldType, methodInfo));
					}
					else
					{
						ParameterInfo[] parameters = methodInfo.GetParameters();
						int num15 = parameters.Length + 1;
						Type[] array3 = new Type[num15];
						if (methodInfo.DeclaringType.IsValueType)
						{
							array3[0] = methodInfo.DeclaringType.MakeByRefType();
						}
						else
						{
							array3[0] = typeof(object);
						}
						for (int n = 0; n < parameters.Length; n++)
						{
							array3[n + 1] = parameters[n].ParameterType;
						}
						DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, methodInfo.ReturnType, array3, typeFromHandle, true);
						ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
						for (int num16 = 0; num16 < num15; num16++)
						{
							switch (num16)
							{
							case 0:
								ilgenerator.Emit(OpCodes.Ldarg_0);
								break;
							case 1:
								ilgenerator.Emit(OpCodes.Ldarg_1);
								break;
							case 2:
								ilgenerator.Emit(OpCodes.Ldarg_2);
								break;
							case 3:
								ilgenerator.Emit(OpCodes.Ldarg_3);
								break;
							default:
								ilgenerator.Emit(OpCodes.Ldarg_S, num16);
								break;
							}
						}
						ilgenerator.Emit(OpCodes.Tailcall);
						ilgenerator.Emit(flag2 ? OpCodes.Callvirt : OpCodes.Call, methodInfo);
						ilgenerator.Emit(OpCodes.Ret);
						fieldInfo.SetValue(null, dynamicMethod.CreateDelegate(typeFromHandle));
					}
				}
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}

		// Token: 0x06000342 RID: 834 RVA: 0x0002F8E0 File Offset: 0x0002DAE0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static uint A\u0090\u0089\u0090\u008C\u0088\u0094\u009D\u008B\u008B\u0098(uint \u0020)
		{
			return 0U;
		}

		// Token: 0x06000343 RID: 835 RVA: 0x0002F8E4 File Offset: 0x0002DAE4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098()
		{
			if (Debugger.IsAttached)
			{
				throw new Exception("Debugger Detected");
			}
		}

		// Token: 0x06000344 RID: 836 RVA: 0x0002F8FC File Offset: 0x0002DAFC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static int A\u0095\u0089\u008C\u0098\u0096\u0086\u008D\u0090\u009C\u008A()
		{
			return 5;
		}

		// Token: 0x06000345 RID: 837 RVA: 0x0002F900 File Offset: 0x0002DB00
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008E\u009E\u009A\u009B\u008D\u0089\u0098\u009E\u009E\u0090()
		{
			try
			{
				new MD5CryptoServiceProvider();
			}
			catch
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0093\u0091\u0089\u008B\u0096\u008B\u0090\u008B = true;
				return;
			}
			try
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0093\u0091\u0089\u008B\u0096\u008B\u0090\u008B = CryptoConfig.AllowOnlyFipsAlgorithms;
			}
			catch
			{
			}
		}

		// Token: 0x06000346 RID: 838 RVA: 0x0002F958 File Offset: 0x0002DB58
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static SymmetricAlgorithm A\u0089\u0088\u008B\u009D\u0094\u0095\u0087\u0090\u009E\u008E()
		{
			SymmetricAlgorithm symmetricAlgorithm = null;
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u008A\u0090\u008B\u008A\u0092\u0086\u0094\u008B\u008C())
			{
				symmetricAlgorithm = new AesCryptoServiceProvider();
			}
			else
			{
				try
				{
					symmetricAlgorithm = new RijndaelManaged();
				}
				catch
				{
					symmetricAlgorithm = new AesCryptoServiceProvider();
				}
			}
			return symmetricAlgorithm;
		}

		// Token: 0x06000347 RID: 839 RVA: 0x0002F9A8 File Offset: 0x0002DBA8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private byte[] A\u008E\u008C\u008F\u009C\u008D\u0086\u008D\u009E\u009A\u009D()
		{
			int length = "xdB3QU4c9JETUGzk8iiH5W".Length;
			return new byte[] { 1, 2 };
		}

		// Token: 0x06000348 RID: 840 RVA: 0x0002F9C8 File Offset: 0x0002DBC8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private byte[] A\u0095\u0095\u008A\u0088\u0089\u008F\u0098\u009E\u0094\u0099()
		{
			int length = "IAuecy6Lvt5i4XxNT6p".Length;
			return new byte[] { 1, 2 };
		}

		// Token: 0x06000349 RID: 841 RVA: 0x0002F9E8 File Offset: 0x0002DBE8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0092\u0091\u0092\u0092\u0098\u009C\u0093\u0092\u0086\u0090(object \u0020, object \u0020, uint \u0020, object \u0020)
		{
			while (\u0020 > 0U)
			{
				int num = ((\u0020 > (uint)\u0020.Length) ? \u0020.Length : ((int)\u0020));
				\u0020.Read(\u0020, 0, num);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0097\u0087\u009A\u0087\u009A\u0089\u008A\u008A\u008C(\u0020, \u0020, 0, num);
				\u0020 -= (uint)num;
			}
		}

		// Token: 0x0600034A RID: 842 RVA: 0x0002FA2C File Offset: 0x0002DC2C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void AA\u0097\u0087\u009A\u0087\u009A\u0089\u008A\u008A\u008C(object \u0020, object \u0020, int \u0020, int \u0020)
		{
			\u0020.TransformBlock(\u0020, \u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x0600034B RID: 843 RVA: 0x0002FA3C File Offset: 0x0002DC3C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static uint A\u0098\u0087\u009D\u008C\u009C\u0098\u0098\u0092\u008C\u0088(uint \u0020, int \u0020, long \u0020, object \u0020)
		{
			for (int i = 0; i < \u0020; i++)
			{
				\u0020.BaseStream.Position = \u0020 + (long)(i * 40 + 8);
				uint num = \u0020.ReadUInt32();
				uint num2 = \u0020.ReadUInt32();
				\u0020.ReadUInt32();
				uint num3 = \u0020.ReadUInt32();
				if (num2 <= \u0020 && \u0020 < num2 + num)
				{
					return num3 + \u0020 - num2;
				}
			}
			return 0U;
		}

		// Token: 0x0600034C RID: 844 RVA: 0x0002FAA4 File Offset: 0x0002DCA4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static Stream A\u0095\u0086\u008E\u0086\u0087\u009D\u009E\u0092\u009A\u009E()
		{
			return new MemoryStream();
		}

		// Token: 0x0600034D RID: 845 RVA: 0x0002FAAC File Offset: 0x0002DCAC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] A\u0099\u0088\u0086\u008B\u008B\u009A\u0096\u0092\u008C\u008B(object \u0020)
		{
			byte[] array;
			using (FileStream fileStream = new FileStream(\u0020, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				int num = 0;
				int i = (int)fileStream.Length;
				array = new byte[i];
				while (i > 0)
				{
					int num2 = fileStream.Read(array, num, i);
					num += num2;
					i -= num2;
				}
			}
			return array;
		}

		// Token: 0x0600034E RID: 846 RVA: 0x0002FB18 File Offset: 0x0002DD18
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0088\u0090\u008C\u009B\u008F\u009E\u0093\u0094\u008A\u0092(object \u0020)
		{
			try
			{
				if (File.Exists(((Assembly)\u0020).Location))
				{
					return ((Assembly)\u0020).Location;
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(((Assembly)\u0020).GetName().CodeBase.ToString().Replace("file:///", "")))
				{
					return ((Assembly)\u0020).GetName().CodeBase.ToString().Replace("file:///", "");
				}
			}
			catch
			{
			}
			try
			{
				if (File.Exists(\u0020.GetType().GetProperty("Location").GetValue(\u0020, new object[0])
					.ToString()))
				{
					return \u0020.GetType().GetProperty("Location").GetValue(\u0020, new object[0])
						.ToString();
				}
			}
			catch
			{
			}
			return "";
		}

		// Token: 0x0600034F RID: 847 RVA: 0x0002FC48 File Offset: 0x0002DE48
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] A\u008B\u0087\u0099\u0086\u0087\u008D\u0094\u009E\u0097\u009E(object \u0020)
		{
			return ((MemoryStream)\u0020).ToArray();
		}

		// Token: 0x06000350 RID: 848 RVA: 0x0002FC58 File Offset: 0x0002DE58
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal byte[] A\u0086\u008E\u008B\u009A\u0095\u008C\u008E\u0094\u008A\u0091()
		{
			return null;
		}

		// Token: 0x06000351 RID: 849 RVA: 0x0002FC68 File Offset: 0x0002DE68
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal byte[] AA\u009B\u008B\u0092\u0091\u0090\u009B\u009D\u0099\u0088()
		{
			return null;
		}

		// Token: 0x06000352 RID: 850 RVA: 0x0002FC78 File Offset: 0x0002DE78
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u009D\u0087\u0097\u0086\u008D\u008F\u0094\u0092\u009C\u008E(object \u0020)
		{
			AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(27, new object[] { \u0020 }, null);
		}

		// Token: 0x06000353 RID: 851 RVA: 0x0002FCA8 File Offset: 0x0002DEA8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static string A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(int \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u0089\u008C\u0096\u008A\u009D\u009E\u0096\u0087.Length == 0)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u008F\u009B\u0093\u0090\u0091\u0092\u008B\u0090\u0095 = new List<string>();
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0092\u0088\u008E\u0091\u008B\u0095\u0090\u0098\u0094 = new List<int>();
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0087\u0097\u0086\u008D\u008F\u0094\u0092\u009C\u008E(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).GetTypeInfo().Assembly.GetManifestResourceStream("p\u009d\u008c9\u009d\u009e\u0087\u0096\u0092\u008ah\u0092e5i\u008b\u0093k.t\u0090\u0097ahl\u0088h\u008b\u0096\u009d5\u009d\u009b5e\u009bj"));
				A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			}
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0092\u0099\u0097\u008E\u0093\u009C\u0092\u008D\u008E < 75)
			{
				MethodBase method = new StackFrame(1).GetMethod();
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0097\u009B\u0098\u008E\u008A\u008A\u009E\u008C\u0093 != method.DeclaringType.Assembly)
				{
					bool flag = false;
					string name = method.DeclaringType.Assembly.GetName().Name;
					foreach (AssemblyName assemblyName in A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0097\u009B\u0098\u008E\u008A\u008A\u009E\u008C\u0093.GetReferencedAssemblies())
					{
						if (name == assemblyName.Name)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						throw new Exception();
					}
				}
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0092\u0099\u0097\u008E\u0093\u009C\u0092\u008D\u008E++;
			}
			object a_u009C_u008D_u008F_u008D_u009E_u0096_u0093_u0090_u008A_u = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u008D\u008F\u008D\u009E\u0096\u0093\u0090\u008A\u0088;
			lock (a_u009C_u008D_u008F_u008D_u009E_u0096_u0093_u0090_u008A_u)
			{
				int num = BitConverter.ToInt32(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u0089\u008C\u0096\u008A\u009D\u009E\u0096\u0087, \u0020);
				if (num < A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0092\u0088\u008E\u0091\u008B\u0095\u0090\u0098\u0094.Count && A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0092\u0088\u008E\u0091\u008B\u0095\u0090\u0098\u0094[num] == \u0020)
				{
					return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u008F\u009B\u0093\u0090\u0091\u0092\u008B\u0090\u0095[num];
				}
				try
				{
					byte[] array = new byte[num];
					Array.Copy(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u0089\u008C\u0096\u008A\u009D\u009E\u0096\u0087, \u0020 + 4, array, 0, num);
					string @string = Encoding.Unicode.GetString(array, 0, array.Length);
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u008F\u009B\u0093\u0090\u0091\u0092\u008B\u0090\u0095.Add(@string);
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0092\u0088\u008E\u0091\u008B\u0095\u0090\u0098\u0094.Add(\u0020);
					Array.Copy(BitConverter.GetBytes(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u008F\u009B\u0093\u0090\u0091\u0092\u008B\u0090\u0095.Count - 1), 0, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u0089\u008C\u0096\u008A\u009D\u009E\u0096\u0087, \u0020, 4);
					return @string;
				}
				catch
				{
				}
			}
			return "";
		}

		// Token: 0x06000354 RID: 852 RVA: 0x0002FE9C File Offset: 0x0002E09C
		[MethodImpl(MethodImplOptions.NoInlining)]
		private A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089(byte[] \u0020, byte[] \u0020)
		{
			this.A\u008D\u0096\u0094\u008B\u0087\u0087\u0087\u009E\u0097\u0088 = \u0020;
			this.A\u009E\u0093\u0098\u0093\u0094\u0093\u009E\u008B\u009E\u008E = \u0020;
		}

		// Token: 0x06000355 RID: 853 RVA: 0x0002FEB4 File Offset: 0x0002E0B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private byte[] A\u009D\u008D\u008E\u0096\u009C\u0086\u0093\u0090\u009A\u0092(byte[] \u0020)
		{
			if (\u0020.Length == 0)
			{
				return new byte[0];
			}
			int num = \u0020.Length % 4;
			int num2 = \u0020.Length / 4;
			byte[] array = new byte[\u0020.Length];
			int num3 = this.A\u008D\u0096\u0094\u008B\u0087\u0087\u0087\u009E\u0097\u0088.Length / 4;
			uint num4 = 0U;
			if (num > 0)
			{
				num2++;
			}
			for (int i = 0; i < num2; i++)
			{
				int num5 = i % num3;
				int num6 = i * 4;
				uint num7 = (uint)(num5 * 4);
				uint num8 = (this.A\u008D\u0096\u0094\u008B\u0087\u0087\u0087\u009E\u0097\u0088[(int)(num7 + 3U)] << 24) | (this.A\u008D\u0096\u0094\u008B\u0087\u0087\u0087\u009E\u0097\u0088[(int)(num7 + 2U)] << 16) | (this.A\u008D\u0096\u0094\u008B\u0087\u0087\u0087\u009E\u0097\u0088[(int)(num7 + 1U)] << 8) | this.A\u008D\u0096\u0094\u008B\u0087\u0087\u0087\u009E\u0097\u0088[(int)num7];
				if (i == num2 - 1 && num > 0)
				{
					uint num9 = 0U;
					uint num10 = 255U;
					int num11 = 0;
					for (int j = 0; j < num; j++)
					{
						if (j > 0)
						{
							num9 <<= 8;
						}
						num9 |= (uint)\u0020[\u0020.Length - (1 + j)];
					}
					num4 += num8;
					num4 += this.A\u0089\u0092\u009A\u0089\u008A\u0096\u009A\u0090\u0089\u008A(num4);
					uint num12 = num4 ^ num9;
					for (int k = 0; k < num; k++)
					{
						if (k > 0)
						{
							num10 <<= 8;
							num11 += 8;
						}
						array[num6 + k] = (byte)((num12 & num10) >> num11);
					}
				}
				else
				{
					num7 = (uint)num6;
					uint num9 = (uint)(((int)\u0020[(int)(num7 + 3U)] << 24) | ((int)\u0020[(int)(num7 + 2U)] << 16) | ((int)\u0020[(int)(num7 + 1U)] << 8) | (int)\u0020[(int)num7]);
					num4 += num8;
					num4 += this.A\u0089\u0092\u009A\u0089\u008A\u0096\u009A\u0090\u0089\u008A(num4);
					uint num13 = num4 ^ num9;
					array[num6] = (byte)(num13 & 255U);
					array[num6 + 1] = (byte)((num13 & 65280U) >> 8);
					array[num6 + 2] = (byte)((num13 & 16711680U) >> 16);
					array[num6 + 3] = (byte)((num13 & 4278190080U) >> 24);
				}
			}
			return array;
		}

		// Token: 0x06000356 RID: 854 RVA: 0x00030098 File Offset: 0x0002E298
		[MethodImpl(MethodImplOptions.NoInlining)]
		private uint A\u0089\u0092\u009A\u0089\u008A\u0096\u009A\u0090\u0089\u008A(uint \u0020)
		{
			int num = 668931134;
			uint num2 = 1582787682U;
			uint num3 = 1577548636U;
			uint num4 = 332884210U;
			ulong num5 = (ulong)(num3 * 1313243236U);
			num5 |= 1UL;
			num2 = (uint)((ulong)(num2 * num2) % num5);
			ulong num6 = (ulong)(1907532890U * num3);
			if (num6 == 0UL)
			{
				num6 -= 1UL;
			}
			ulong num7 = (ulong)(num * num) % num6;
			uint num8 = (uint)(18446744073207225482UL - (ulong)num2);
			ulong num9 = (ulong)(num2 * 183835789U);
			num9 |= 1UL;
			num3 = (uint)((ulong)(num3 * num3) % num9);
			uint num10 = ((num4 >> 6) | (num4 << 26)) ^ num2;
			uint num11 = num10 & 252645135U;
			num4 = ((num10 & 4042322160U) >> 4) | (num11 << 4);
			uint num12 = \u0020 ^ (\u0020 << 3);
			num12 += num8;
			num12 ^= num12 << 11;
			num12 += num3;
			num12 ^= num12 >> 27;
			num12 += num4;
			return (((num8 << 11) - num2) ^ num3) - num12;
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00030174 File Offset: 0x0002E374
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static string A\u0093\u0099\u009E\u0098\u0088\u0088\u0098\u0094\u008A\u0086(object \u0020)
		{
			"Qq7psNqlJWkoNkB".Trim();
			byte[] array = Convert.FromBase64String(\u0020);
			return Encoding.Unicode.GetString(array, 0, array.Length);
		}

		// Token: 0x06000358 RID: 856 RVA: 0x000301A4 File Offset: 0x0002E3A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] A\u009A\u0086\u0099\u009D\u009E\u0097\u009E\u009E\u009B\u008A(object \u0020)
		{
			return new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089(new byte[]
			{
				123, 5, 74, 12, 244, 156, 221, 154, 121, 221,
				183, 41, 121, 65, 9, 43, 67, 81, 23, 43,
				74, 63, 64, 23, 95, 185, 226, 244, 45, 194,
				211, 43
			}, new byte[]
			{
				117, 254, 41, 121, 65, 52, 9, 43, 221, 154,
				12, 54, 68, 241, 68, 66
			}).A\u009D\u008D\u008E\u0096\u009C\u0086\u0093\u0090\u009A\u0092(\u0020);
		}

		// Token: 0x06000359 RID: 857 RVA: 0x000301D8 File Offset: 0x0002E3D8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private byte[] AA\u009C\u0099\u0087\u008F\u0097\u0093\u009E\u0092\u0096()
		{
			return null;
		}

		// Token: 0x0600035A RID: 858 RVA: 0x000301E8 File Offset: 0x0002E3E8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private byte[] A\u008E\u0090\u009E\u008E\u0090\u0093\u0096\u009E\u009C\u008F()
		{
			return null;
		}

		// Token: 0x0600035B RID: 859 RVA: 0x000301F8 File Offset: 0x0002E3F8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static IntPtr VBOpX7B8XB()
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0095\u009C\u008A\u009D\u008D\u0099\u0090\u0090\u0092 == IntPtr.Zero)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0095\u009C\u008A\u009D\u008D\u0099\u0090\u0090\u0092 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0099\u009C\u008F\u0090\u0090\u009A\u0094\u009E\u0098("kernel ".Trim() + "32.dll");
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0095\u009C\u008A\u009D\u008D\u0099\u0090\u0090\u0092;
		}

		// Token: 0x0600035C RID: 860 RVA: 0x0003022C File Offset: 0x0002E42C
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static int A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(IntPtr \u0020, int \u0020, int \u0020, ref int \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0094\u009D\u0099\u0092\u009B\u009B\u0090\u0090\u0093 == null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0094\u009D\u0099\u0092\u009B\u009B\u0090\u0090\u0093 = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u009A\u0091\u0097\u008E\u0098\u0099\u008C\u008B)Marshal.GetDelegateForFunctionPointer(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.VBOpX7B8XB(), "Virtual ".Trim() + "Protect"), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u009A\u0091\u0097\u008E\u0098\u0099\u008C\u008B));
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0094\u009D\u0099\u0092\u009B\u009B\u0090\u0090\u0093(\u0020, \u0020, \u0020, ref \u0020);
		}

		// Token: 0x0600035D RID: 861 RVA: 0x00030288 File Offset: 0x0002E488
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static IntPtr A\u0097\u009D\u009A\u0088\u009C\u008B\u0095\u0092\u008C\u0091(IntPtr \u0020, uint \u0020, uint \u0020, uint \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0096\u009A\u009A\u0098\u0089\u0088\u0098\u0086\u008C == null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0096\u009A\u009A\u0098\u0089\u0088\u0098\u0086\u008C = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0094\u009C\u0090\u0089\u008D\u009B\u0090\u0099\u008B)Marshal.GetDelegateForFunctionPointer(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.VBOpX7B8XB(), "Virtual ".Trim() + "Alloc"), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0094\u009C\u0090\u0089\u008D\u009B\u0090\u0099\u008B));
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0096\u009A\u009A\u0098\u0089\u0088\u0098\u0086\u008C(\u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x0600035E RID: 862 RVA: 0x000302E4 File Offset: 0x0002E4E4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static UIntPtr A\u008A\u009C\u0091\u008F\u0098\u0086\u0092\u008B\u0098\u008D(UIntPtr \u0020, out A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0089\u009A\u0091\u008C\u0097\u0096\u008B\u0088\u0088 \u0020, UIntPtr \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0093\u0096\u008A\u0088\u0095\u009E\u0090\u009D\u0086 == null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0093\u0096\u008A\u0088\u0095\u009E\u0090\u009D\u0086 = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008F\u0097\u009D\u0090\u0087\u0087\u009E\u008E\u008B)Marshal.GetDelegateForFunctionPointer(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.VBOpX7B8XB(), "Virtual ".Trim() + "Query"), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008F\u0097\u009D\u0090\u0087\u0087\u009E\u008E\u008B));
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0093\u0096\u008A\u0088\u0095\u009E\u0090\u009D\u0086(\u0020, out \u0020, \u0020);
		}

		// Token: 0x0600035F RID: 863 RVA: 0x00030340 File Offset: 0x0002E540
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static IntPtr A\u0087\u008E\u008A\u009B\u008D\u0094\u0090\u009E\u009A\u0088(uint \u0020, int \u0020, uint \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u008A\u008E\u009A\u009B\u0088\u008E\u0090\u009B\u008F == null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u008A\u008E\u009A\u009B\u0088\u008E\u0090\u009B\u008F = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0093\u0097\u0091\u008B\u0086\u008C\u0095\u008F\u008E)Marshal.GetDelegateForFunctionPointer(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.VBOpX7B8XB(), "Open ".Trim() + "Process"), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0093\u0097\u0091\u008B\u0086\u008C\u0095\u008F\u008E));
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u008A\u008E\u009A\u009B\u0088\u008E\u0090\u009B\u008F(\u0020, \u0020, \u0020);
		}

		// Token: 0x06000360 RID: 864 RVA: 0x0003039C File Offset: 0x0002E59C
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static int A\u0091\u0091\u0089\u0089\u0086\u0096\u009D\u0092\u0098\u0092(IntPtr \u0020, IntPtr \u0020, [In] [Out] byte[] \u0020, uint \u0020, out IntPtr \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0088\u0098\u009E\u009E\u0089\u008F\u008C\u008C\u008F == null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0088\u0098\u009E\u009E\u0089\u008F\u008C\u008C\u008F = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0097\u0096\u009C\u008E\u0088\u008E\u008B\u008C\u0088)Marshal.GetDelegateForFunctionPointer(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.VBOpX7B8XB(), "Write ".Trim() + "Process ".Trim() + "Memory"), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0097\u0096\u009C\u008E\u0088\u008E\u008B\u008C\u0088));
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0088\u0098\u009E\u009E\u0089\u008F\u008C\u008C\u008F(\u0020, \u0020, \u0020, \u0020, out \u0020);
		}

		// Token: 0x06000361 RID: 865 RVA: 0x00030404 File Offset: 0x0002E604
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static int A\u008E\u0092\u008C\u008B\u008D\u009E\u008E\u0092\u0096\u009E(IntPtr \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0097\u008E\u008F\u009C\u008D\u0088\u008B\u008D\u0086 == null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0097\u008E\u008F\u009C\u008D\u0088\u008B\u008D\u0086 = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0091\u008D\u008F\u0089\u009E\u0097\u0092\u009B\u0095)Marshal.GetDelegateForFunctionPointer(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.VBOpX7B8XB(), "Close ".Trim() + "Handle"), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0091\u008D\u008F\u0089\u009E\u0097\u0092\u009B\u0095));
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0097\u008E\u008F\u009C\u008D\u0088\u008B\u008D\u0086(\u0020);
		}

		// Token: 0x06000362 RID: 866
		[DllImport("kernel32", CharSet = CharSet.Ansi, EntryPoint = "GetProcAddress")]
		public static extern IntPtr A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(IntPtr \u0020, string \u0020);

		// Token: 0x06000363 RID: 867
		[DllImport("kernel32", EntryPoint = "LoadLibrary")]
		public static extern IntPtr A\u0097\u0099\u009C\u008F\u0090\u0090\u009A\u0094\u009E\u0098(string \u0020);

		// Token: 0x06000364 RID: 868
		[DllImport("libclrjit", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "getJit", SetLastError = true)]
		public static extern IntPtr AA\u009C\u009D\u0088\u0096\u0087\u009D\u0087\u0087\u008D();

		// Token: 0x06000365 RID: 869
		[DllImport("libclrjit", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "mmap", SetLastError = true)]
		public static extern IntPtr A\u0091\u0087\u009D\u009C\u0088\u0098\u0092\u009E\u008E\u0089(IntPtr \u0020, IntPtr \u0020, int \u0020, int \u0020, int \u0020, IntPtr \u0020);

		// Token: 0x06000366 RID: 870
		[DllImport("libclrjit", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "mmap", SetLastError = true)]
		public static extern IntPtr AA\u0091\u008B\u009A\u0097\u008B\u0091\u0088\u0092\u009B(IntPtr \u0020, IntPtr \u0020, int \u0020, int \u0020, int \u0020, IntPtr \u0020);

		// Token: 0x06000367 RID: 871
		[DllImport("libclrjit", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "mmap", SetLastError = true)]
		public static extern IntPtr A\u0088\u0091\u009A\u008B\u0095\u009A\u008B\u0092\u0097\u009E(IntPtr \u0020, IntPtr \u0020, int \u0020, int \u0020, int \u0020, IntPtr \u0020);

		// Token: 0x06000368 RID: 872 RVA: 0x00030460 File Offset: 0x0002E660
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static IntPtr A\u0095\u0098\u0097\u009A\u008E\u008B\u0087\u0090\u0099\u0094(IntPtr \u0020, IntPtr \u0020, int \u0020, int \u0020, int \u0020, IntPtr \u0020)
		{
			IntPtr intPtr;
			try
			{
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
				{
					intPtr = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0091\u008B\u009A\u0097\u008B\u0091\u0088\u0092\u009B(\u0020, \u0020, \u0020, \u0020, \u0020, \u0020);
				}
				else
				{
					intPtr = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0091\u009A\u008B\u0095\u009A\u008B\u0092\u0097\u009E(\u0020, \u0020, \u0020, \u0020, \u0020, \u0020);
				}
			}
			catch
			{
				intPtr = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0087\u009D\u009C\u0088\u0098\u0092\u009E\u008E\u0089(\u0020, \u0020, \u0020, \u0020, \u0020, \u0020);
			}
			return intPtr;
		}

		// Token: 0x06000369 RID: 873
		[DllImport("libclrjit", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "mprotect", SetLastError = true)]
		private static extern int A\u0090\u008C\u0098\u0089\u008B\u009D\u009A\u0090\u0092\u0087(IntPtr \u0020, IntPtr \u0020, int \u0020);

		// Token: 0x0600036A RID: 874
		[DllImport("libSystem", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "mprotect", SetLastError = true)]
		private static extern int A\u0098\u0086\u0092\u0094\u0094\u008B\u0093\u009E\u009C\u009D(IntPtr \u0020, IntPtr \u0020, int \u0020);

		// Token: 0x0600036B RID: 875
		[DllImport("libc", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "mprotect", SetLastError = true)]
		private static extern int A\u0094\u008C\u009C\u0089\u009A\u009C\u0098\u009E\u009D\u0086(IntPtr \u0020, IntPtr \u0020, int \u0020);

		// Token: 0x0600036C RID: 876 RVA: 0x000304C4 File Offset: 0x0002E6C4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static int A\u0096\u0087\u0086\u0088\u0094\u008B\u008C\u008B\u008D\u0098(IntPtr \u0020, IntPtr \u0020, int \u0020)
		{
			int num;
			try
			{
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
				{
					num = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0086\u0092\u0094\u0094\u008B\u0093\u009E\u009C\u009D(\u0020, \u0020, \u0020);
				}
				else
				{
					num = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008C\u009C\u0089\u009A\u009C\u0098\u009E\u009D\u0086(\u0020, \u0020, \u0020);
				}
			}
			catch
			{
				num = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u008C\u0098\u0089\u008B\u009D\u009A\u0090\u0092\u0087(\u0020, \u0020, \u0020);
			}
			return num;
		}

		// Token: 0x0600036D RID: 877
		[DllImport("libclrjit", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "getpagesize", SetLastError = true)]
		private static extern int A\u008D\u009E\u0090\u0097\u008B\u0094\u009B\u0090\u0094\u0099();

		// Token: 0x0600036E RID: 878
		[DllImport("libSystem", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "getpagesize", SetLastError = true)]
		private static extern int A\u0088\u009C\u008A\u009C\u008F\u0096\u0097\u0094\u0099\u008B();

		// Token: 0x0600036F RID: 879
		[DllImport("libc", BestFitMapping = true, CallingConvention = CallingConvention.StdCall, EntryPoint = "getpagesize", SetLastError = true)]
		private static extern int A\u0086\u0099\u009C\u0086\u0092\u008E\u009E\u0090\u009E\u008E();

		// Token: 0x06000370 RID: 880
		[DllImport("libSystem", EntryPoint = "mincore")]
		private static extern int A\u0096\u0099\u0087\u008E\u0095\u008D\u008C\u0090\u0091\u0093(IntPtr \u0020, UIntPtr \u0020, byte[] \u0020);

		// Token: 0x06000371 RID: 881
		[DllImport("libc", EntryPoint = "mincore")]
		private static extern int A\u0092\u0097\u0086\u0095\u008C\u0086\u0089\u0090\u0098\u009D(IntPtr \u0020, UIntPtr \u0020, byte[] \u0020);

		// Token: 0x06000372 RID: 882 RVA: 0x00030518 File Offset: 0x0002E718
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static List<IntPtr> A\u0089\u0092\u009D\u0094\u0095\u0086\u009E\u0090\u0088\u0096()
		{
			List<IntPtr> list = new List<IntPtr>();
			foreach (string text in File.ReadAllLines("/proc/self/maps"))
			{
				long num = BitConverter.ToInt64(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C).Assembly.ManifestModule.ModuleVersionId.ToByteArray(), 0);
				long num2 = BitConverter.ToInt64(BitConverter.GetBytes(num).Reverse<byte>().ToArray<byte>(), 0);
				string[] array2 = text.Split(' ', StringSplitOptions.None);
				string text2 = array2[0];
				if (array2[1][0] == 'r')
				{
					long num3 = Convert.ToInt64(text2.Split('-', StringSplitOptions.None)[0], 16);
					if (Convert.ToInt64(text2.Split('-', StringSplitOptions.None)[1], 16) - num3 >= 72L)
					{
						IntPtr intPtr = new IntPtr(num3);
						IntPtr intPtr2 = new IntPtr(num3 + 64L);
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u009C\u0092\u0086\u009A\u0088\u0094\u0089\u0092(intPtr2, 8))
						{
							try
							{
								long num4 = Marshal.ReadInt64(intPtr2);
								if (num4 == num || num4 == num2)
								{
									list.Add(intPtr);
								}
							}
							catch
							{
							}
						}
					}
				}
			}
			return list;
		}

		// Token: 0x06000373 RID: 883 RVA: 0x00030640 File Offset: 0x0002E840
		[MethodImpl(MethodImplOptions.NoInlining)]
		public unsafe static IntPtr[] A\u008B\u0091\u008F\u0099\u0094\u008D\u0093\u008B\u009E\u0094(object \u0020, int \u0020, int \u0020, int \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F && typeof(string).Assembly.GetName().Version.Major >= 8 && \u0020 == 1)
			{
				List<IntPtr> list = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0092\u009D\u0094\u0095\u0086\u009E\u0090\u0088\u0096();
				if (list.Count > 0)
				{
					return list.ToArray();
				}
			}
			bool flag = true;
			if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099 && A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F && typeof(string).Assembly.GetName().Version.Major >= 8 && \u0020 != 1)
			{
				flag = false;
			}
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
			{
				int major = typeof(string).Assembly.GetName().Version.Major;
			}
			if (flag)
			{
				object value = typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C).Assembly.ManifestModule.ModuleHandle.GetType().GetField("m_ptr", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C).Assembly.ManifestModule.ModuleHandle);
				if (value is IntPtr)
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097 = (IntPtr)value;
				}
				if (value.GetType().ToString() == "System.Reflection.RuntimeModule")
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097 = (IntPtr)value.GetType().GetField("m_pData", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(value);
				}
				long num = 0L;
				num = Marshal.GetHINSTANCE(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C).Assembly.GetModules()[0]).ToInt64();
				if (IntPtr.Size == 8)
				{
					if (num == -1L)
					{
						num = 0L;
					}
				}
				else if ((uint)num == 4294967295U)
				{
					num = 0L;
				}
				if (num > 0L)
				{
					return new IntPtr[]
					{
						new IntPtr(num)
					};
				}
				Type type = Type.GetType("System.IRuntimeMethodInfo");
				if (type != null)
				{
					PropertyInfo property = type.GetProperty("Value");
					if (property != null)
					{
						object value2 = property.GetValue(\u0020);
						MethodInfo method = typeof(RuntimeMethodHandle).GetMethod("_GetUtf8Name", BindingFlags.Static | BindingFlags.NonPublic);
						if (value2 != null && method != null)
						{
							Pointer pointer = (Pointer)method.Invoke(null, new object[] { value2 });
							if (pointer != null)
							{
								IntPtr intPtr = new IntPtr(Pointer.Unbox(pointer)) - (IntPtr)\u0020 - (IntPtr)\u0020;
								try
								{
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u009C\u0092\u0086\u009A\u0088\u0094\u0089\u0092(intPtr, 2) && Marshal.ReadInt16(intPtr) == 23117)
									{
										return new IntPtr[] { intPtr };
									}
								}
								catch (Exception)
								{
								}
								intPtr += (IntPtr)\u0020;
								try
								{
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u009C\u0092\u0086\u009A\u0088\u0094\u0089\u0092(intPtr, 2) && Marshal.ReadInt16(intPtr) == 23117)
									{
										return new IntPtr[] { intPtr };
									}
								}
								catch (Exception)
								{
								}
							}
						}
					}
				}
				MethodInfo method2 = typeof(RuntimeTypeHandle).GetMethod("GetMetadataImport", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
				if (method2 != null)
				{
					object obj = method2.Invoke(null, new object[] { typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C) });
					if (obj != null)
					{
						MethodInfo method3 = obj.GetType().GetMethod("GetName", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
						if (method3 != null)
						{
							object obj2 = method3.Invoke(obj, new object[] { \u0020.MetadataToken });
							if (obj2 != null)
							{
								FieldInfo field = obj2.GetType().GetField("m_pStringHeap", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
								if (field != null)
								{
									object value3 = field.GetValue(obj2);
									if (value3 != null)
									{
										IntPtr intPtr2 = new IntPtr(Pointer.Unbox(value3)) - (IntPtr)\u0020 - (IntPtr)\u0020;
										if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u009C\u0092\u0086\u009A\u0088\u0094\u0089\u0092(intPtr2, 2) && Marshal.ReadInt16(intPtr2) == 23117)
										{
											return new IntPtr[] { intPtr2 };
										}
										intPtr2 = intPtr2 - (IntPtr)\u0020 + (IntPtr)\u0020;
										if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0091\u009C\u0092\u0086\u009A\u0088\u0094\u0089\u0092(intPtr2, 2) && Marshal.ReadInt16(intPtr2) == 23117)
										{
											return new IntPtr[] { intPtr2 };
										}
									}
								}
							}
						}
					}
				}
				if (num <= 0L)
				{
					string location = typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C).Assembly.Location;
					if (!string.IsNullOrEmpty(location))
					{
						foreach (object obj3 in Process.GetCurrentProcess().Modules)
						{
							ProcessModule processModule = (ProcessModule)obj3;
							if (processModule.FileName == location)
							{
								num = processModule.BaseAddress.ToInt64();
								break;
							}
						}
					}
				}
				if (IntPtr.Size == 8)
				{
					if (num == -1L)
					{
						num = 0L;
					}
				}
				else if ((uint)num == 4294967295U)
				{
					num = 0L;
				}
				if (num > 0L)
				{
					return new IntPtr[]
					{
						new IntPtr(num)
					};
				}
			}
			IntPtr intPtr3 = IntPtr.Zero;
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
			{
				byte[] array = new byte[] { 99, 108, 114, 106, 105, 116, 46, 100, 108, 108 };
				IntPtr intPtr4 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0099\u009C\u008F\u0090\u0090\u009A\u0094\u009E\u0098(Encoding.UTF8.GetString(array));
				if (intPtr4 == IntPtr.Zero)
				{
					array = new byte[]
					{
						109, 115, 99, 111, 114, 106, 105, 116, 46, 100,
						108, 108
					};
					intPtr4 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0099\u009C\u008F\u0090\u0090\u009A\u0094\u009E\u0098(Encoding.UTF8.GetString(array));
				}
				byte[] array2 = new byte[] { 103, 101, 116, 74, 105, 116 };
				string @string = Encoding.UTF8.GetString(array2);
				intPtr3 = ((A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u009A\u008A\u009B\u0092\u0095\u0097\u0090\u0091\u009E)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0098\u009A\u009D\u0093\u009C\u0098\u008B\u009C\u0088(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(intPtr4, @string), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u009A\u008A\u009B\u0092\u0095\u0097\u0090\u0091\u009E)))();
			}
			else
			{
				intPtr3 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009C\u009D\u0088\u0096\u0087\u009D\u0087\u0087\u008D();
			}
			long num2 = Marshal.ReadIntPtr(intPtr3, 0).ToInt64();
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093 a_u009A_u008E_u0097_u0094_u009A_u0095_u008A_u009E_u009E_u = null;
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A a_u0094_u009A_u0099_u0096_u008F_u009C_u008F_u008B_u0090_u009A = null;
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
			{
				a_u009A_u008E_u0097_u0094_u009A_u0095_u008A_u009E_u009E_u = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u008F\u0086\u0090\u008F\u0099\u0087\u0094\u0091\u009D);
			}
			else
			{
				a_u0094_u009A_u0099_u0096_u008F_u009C_u008F_u008B_u0090_u009A = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u0099\u0099\u0088\u0098\u008B\u0098\u0098\u009D);
			}
			IntPtr intPtr5 = IntPtr.Zero;
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
			{
				intPtr5 = Marshal.GetFunctionPointerForDelegate<A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093>(a_u009A_u008E_u0097_u0094_u009A_u0095_u008A_u009E_u009E_u);
			}
			else
			{
				intPtr5 = Marshal.GetFunctionPointerForDelegate<A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A>(a_u0094_u009A_u0099_u0096_u008F_u009C_u008F_u008B_u0090_u009A);
			}
			long num3 = 0L;
			if (IntPtr.Size == 4)
			{
				num3 = (long)Marshal.ReadInt32(new IntPtr(num2));
			}
			else
			{
				num3 = Marshal.ReadInt64(new IntPtr(num2));
			}
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u0087\u0099\u0095\u009A\u0092\u0094\u0092\u009D = null;
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0087\u0096\u0098\u009D\u0089\u008D\u0090\u0086\u0089 = null;
			try
			{
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u0087\u0099\u0095\u009A\u0092\u0094\u0092\u009D = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0098\u009A\u009D\u0093\u009C\u0098\u008B\u009C\u0088(new IntPtr(num3), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093));
				}
				else
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0087\u0096\u0098\u009D\u0089\u008D\u0090\u0086\u0089 = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0098\u009A\u009D\u0093\u009C\u0098\u008B\u009C\u0088(new IntPtr(num3), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A));
				}
			}
			catch
			{
				try
				{
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
					{
						Delegate @delegate = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0098\u009A\u009D\u0093\u009C\u0098\u008B\u009C\u0088(new IntPtr(num3), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093));
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u0087\u0099\u0095\u009A\u0092\u0094\u0092\u009D = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093)Delegate.CreateDelegate(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093), @delegate.Method);
					}
					else
					{
						Delegate delegate2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0098\u009A\u009D\u0093\u009C\u0098\u008B\u009C\u0088(new IntPtr(num3), typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A));
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0087\u0096\u0098\u009D\u0089\u008D\u0090\u0086\u0089 = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A)Delegate.CreateDelegate(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A), delegate2.Method);
					}
				}
				catch
				{
				}
			}
			byte[] array3 = new byte[32];
			uint num4 = 0U;
			fixed (byte[] array4 = array3)
			{
				byte* ptr;
				if (array3 == null || array4.Length == 0)
				{
					ptr = null;
				}
				else
				{
					ptr = &array4[0];
				}
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u = default(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088);
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
				{
					a_u009A_u008E_u0097_u0094_u009A_u0095_u008A_u009E_u009E_u(new IntPtr((void*)ptr), IntPtr.Zero, ref a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u, 216669565U, new IntPtr((void*)ptr), ref num4);
				}
				else
				{
					a_u0094_u009A_u0099_u0096_u008F_u009C_u008F_u008B_u0090_u009A(new IntPtr((void*)ptr), IntPtr.Zero, ref a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u, 216669565U, new IntPtr((void*)ptr), ref num4);
				}
			}
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
			{
				RuntimeHelpers.PrepareDelegate(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u0087\u0099\u0095\u009A\u0092\u0094\u0092\u009D);
				RuntimeHelpers.PrepareMethod(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u0087\u0099\u0095\u009A\u0092\u0094\u0092\u009D.Method.MethodHandle);
				RuntimeHelpers.PrepareDelegate(a_u009A_u008E_u0097_u0094_u009A_u0095_u008A_u009E_u009E_u);
				RuntimeHelpers.PrepareMethod(a_u009A_u008E_u0097_u0094_u009A_u0095_u008A_u009E_u009E_u.Method.MethodHandle);
			}
			else
			{
				RuntimeHelpers.PrepareDelegate(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0087\u0096\u0098\u009D\u0089\u008D\u0090\u0086\u0089);
				RuntimeHelpers.PrepareMethod(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0087\u0096\u0098\u009D\u0089\u008D\u0090\u0086\u0089.Method.MethodHandle);
				RuntimeHelpers.PrepareDelegate(a_u0094_u009A_u0099_u0096_u008F_u009C_u008F_u008B_u0090_u009A);
				RuntimeHelpers.PrepareMethod(a_u0094_u009A_u0099_u0096_u008F_u009C_u008F_u008B_u0090_u009A.Method.MethodHandle);
			}
			byte[] array5;
			if (IntPtr.Size != 4)
			{
				array5 = new byte[]
				{
					72, 184, 0, 0, 0, 0, 0, 0, 0, 0,
					73, 57, 0, 116, 12, 72, 184, 0, 0, 0,
					0, 0, 0, 0, 0, byte.MaxValue, 224, 72, 184, 0,
					0, 0, 0, 0, 0, 0, 0, byte.MaxValue, 224
				};
			}
			else
			{
				array5 = new byte[]
				{
					85, 139, 236, 139, 69, 16, 129, 56, 0, 0,
					0, 0, 116, 7, 184, 0, 0, 0, 0, 235,
					5, 184, 0, 0, 0, 0, 93, byte.MaxValue, 224
				};
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
				{
					array5[5] = 12;
				}
			}
			IntPtr intPtr6 = IntPtr.Zero;
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
			{
				intPtr6 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u009D\u009A\u0088\u009C\u008B\u0095\u0092\u008C\u0091(IntPtr.Zero, (uint)array5.Length, 4096U, 64U);
			}
			else if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
			{
				intPtr6 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0098\u0097\u009A\u008E\u008B\u0087\u0090\u0099\u0094(IntPtr.Zero, new IntPtr(array5.Length), 6, 33, 0, IntPtr.Zero);
			}
			else
			{
				intPtr6 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0098\u0097\u009A\u008E\u008B\u0087\u0090\u0099\u0094(IntPtr.Zero, new IntPtr(array5.Length), 6, 4097, 0, IntPtr.Zero);
			}
			byte[] array6 = array5;
			IntPtr value4 = \u0020.MethodHandle.Value;
			byte[] array7;
			byte[] array8;
			byte[] array9;
			if (IntPtr.Size == 4)
			{
				array7 = BitConverter.GetBytes(intPtr5.ToInt32());
				array8 = BitConverter.GetBytes(Convert.ToInt32(num3));
				array9 = BitConverter.GetBytes(value4.ToInt32());
			}
			else
			{
				array7 = BitConverter.GetBytes(intPtr5.ToInt64());
				array8 = BitConverter.GetBytes(num3);
				array9 = BitConverter.GetBytes(value4.ToInt64());
			}
			if (IntPtr.Size == 4)
			{
				Array.Copy(array9, 0, array6, 8, 4);
				Array.Copy(array8, 0, array6, 15, 4);
				Array.Copy(array7, 0, array6, 22, 4);
			}
			else
			{
				Array.Copy(array9, 0, array6, 2, 8);
				Array.Copy(array8, 0, array6, 17, 8);
				Array.Copy(array7, 0, array6, 29, 8);
				if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F || A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
				{
					array6[10] = 72;
					array6[12] = 2;
				}
			}
			Marshal.Copy(array6, 0, intPtr6, array6.Length);
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
			{
				int num5 = 0;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(new IntPtr(num2), IntPtr.Size, 64, ref num5);
				Marshal.WriteIntPtr(new IntPtr(num2), intPtr6);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(new IntPtr(num2), IntPtr.Size, num5, ref num5);
			}
			else if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0098\u008D\u0094\u008D\u0089\u0099\u008B\u0091\u0095(new IntPtr(num2), intPtr6);
			}
			else if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0087\u0086\u0088\u0094\u008B\u008C\u008B\u008D\u0098(new IntPtr(num2), new IntPtr(IntPtr.Size), 2);
				Marshal.WriteIntPtr(new IntPtr(num2), intPtr6);
			}
			\u0020.Invoke(null, new object[0]);
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
			{
				intPtr6 = new IntPtr(num3);
				int num6 = 0;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(new IntPtr(num2), IntPtr.Size, 64, ref num6);
				Marshal.WriteIntPtr(new IntPtr(num2), intPtr6);
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(new IntPtr(num2), IntPtr.Size, num6, ref num6);
			}
			else if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0098\u008D\u0094\u008D\u0089\u0099\u008B\u0091\u0095(new IntPtr(num2), intPtr6);
			}
			else if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0087\u0086\u0088\u0094\u008B\u008C\u008B\u008D\u0098(new IntPtr(num2), new IntPtr(IntPtr.Size), 2);
				Marshal.WriteIntPtr(new IntPtr(num2), intPtr6);
			}
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A != IntPtr.Zero)
			{
				if (Marshal.ReadInt16(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A - (IntPtr)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u009E\u009E\u009E\u008F\u0090\u008B\u008B\u0089\u0087) == 23117)
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A -= (IntPtr)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u009E\u009E\u009E\u008F\u0090\u008B\u008B\u0089\u0087;
				}
				else
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A -= (IntPtr)(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u009E\u009E\u009E\u008F\u0090\u008B\u008B\u0089\u0087 + \u0020);
				}
			}
			return new IntPtr[] { A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A };
		}

		// Token: 0x06000374 RID: 884 RVA: 0x000312E8 File Offset: 0x0002F4E8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static bool A\u008C\u0091\u009C\u0092\u0086\u009A\u0088\u0094\u0089\u0092(IntPtr \u0020, int \u0020)
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
			{
				uint num = 257U;
				uint num2 = 238U;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0089\u009A\u0091\u008C\u0097\u0096\u008B\u0088\u0088 a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u = default(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0089\u009A\u0091\u008C\u0097\u0096\u008B\u0088\u0088);
				UIntPtr uintPtr = new UIntPtr((ulong)\u0020.ToInt64());
				UIntPtr uintPtr2 = new UIntPtr(uintPtr.ToUInt64() + (ulong)(\u0020 - 1));
				bool flag;
				do
				{
					a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u = default(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0089\u009A\u0091\u008C\u0097\u0096\u008B\u0088\u0088);
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u009C\u0091\u008F\u0098\u0086\u0092\u008B\u0098\u008D(uintPtr, out a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u, new UIntPtr((ulong)((long)Marshal.SizeOf<A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0089\u009A\u0091\u008C\u0097\u0096\u008B\u0088\u0088>(a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u))));
					flag = (a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u.A\u0086\u008B\u009C\u0098\u009C\u0096\u0096\u0094\u009E\u0095 & 4096U) != 0U && (a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u.A\u008F\u0087\u0090\u008D\u0091\u008B\u009D\u008B\u008F\u0094 & num) == 0U && (a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u.A\u008F\u0087\u0090\u008D\u0091\u008B\u009D\u008B\u008F\u0094 & num2) > 0U;
					uintPtr = new UIntPtr(a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u.A\u009A\u008E\u009A\u008E\u0091\u009C\u0090\u0094\u0092\u008F.ToUInt64() + (ulong)a_u008D_u0089_u009A_u0091_u008C_u0097_u0096_u008B_u0088_u.AA\u009A\u008E\u0092\u0096\u0092\u008F\u008B\u0099\u009E.ToInt64());
				}
				while (flag && uintPtr.ToUInt64() <= uintPtr2.ToUInt64());
				return flag;
			}
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
			{
				for (int i = 0; i < \u0020; i++)
				{
					byte[] array = new byte[1];
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0099\u0087\u008E\u0095\u008D\u008C\u0090\u0091\u0093(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0099\u009B\u0095\u0094\u0095\u008C\u008B\u0094\u0090(\u0020 + (IntPtr)i), new UIntPtr((ulong)((long)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.dGap0CoMM9())), array) != 0)
					{
						return false;
					}
					if ((array[0] & 1) == 0)
					{
						return false;
					}
				}
				return true;
			}
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
			{
				for (int j = 0; j < \u0020; j++)
				{
					byte[] array2 = new byte[1];
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u0097\u0086\u0095\u008C\u0086\u0089\u0090\u0098\u009D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0099\u009B\u0095\u0094\u0095\u008C\u008B\u0094\u0090(\u0020 + (IntPtr)j), new UIntPtr((ulong)((long)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.dGap0CoMM9())), array2) != 0)
					{
						return false;
					}
					if ((array2[0] & 1) == 0)
					{
						return false;
					}
				}
				return true;
			}
			return false;
		}

		// Token: 0x06000375 RID: 885 RVA: 0x00031474 File Offset: 0x0002F674
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static uint AA\u0086\u0099\u0099\u0088\u0098\u008B\u0098\u0098\u009D(IntPtr \u0020, IntPtr \u0020, ref A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 \u0020, [MarshalAs(UnmanagedType.U4)] uint \u0020, IntPtr \u0020, ref uint \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A = \u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092;
			if (\u0020 != IntPtr.Zero)
			{
				return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0087\u0096\u0098\u009D\u0089\u008D\u0090\u0086\u0089(\u0020, \u0020, ref \u0020, \u0020, \u0020, ref \u0020);
			}
			return 0U;
		}

		// Token: 0x06000376 RID: 886 RVA: 0x000314A0 File Offset: 0x0002F6A0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static uint A\u009C\u008F\u0086\u0090\u008F\u0099\u0087\u0094\u0091\u009D(IntPtr \u0020, IntPtr \u0020, ref A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 \u0020, [MarshalAs(UnmanagedType.U4)] uint \u0020, IntPtr \u0020, ref uint \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A = \u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092;
			if (\u0020 != IntPtr.Zero)
			{
				return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u0087\u0099\u0095\u009A\u0092\u0094\u0092\u009D(\u0020, \u0020, ref \u0020, \u0020, \u0020, ref \u0020);
			}
			return 0U;
		}

		// Token: 0x06000377 RID: 887 RVA: 0x000314CC File Offset: 0x0002F6CC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal unsafe static void A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A()
		{
			int num = 85;
			for (;;)
			{
				int num2 = num;
				IntPtr intPtr;
				uint num3;
				int num4;
				long num5;
				byte[] array;
				byte[] array4;
				int num6;
				int num7;
				long num9;
				byte[] array5;
				int num13;
				byte[] array11;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0093\u0091\u0090\u0091\u009B\u0095\u009E\u009A\u0093 a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u;
				byte[] array13;
				long num31;
				long num32;
				int num33;
				int num36;
				long num37;
				IntPtr intPtr3;
				int num39;
				uint num41;
				uint num42;
				long num46;
				byte[] array20;
				IntPtr intPtr6;
				int num50;
				int num52;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E[] array21;
				int num57;
				IntPtr intPtr12;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E2;
				int num60;
				int num62;
				byte[] array24;
				bool flag5;
				uint num78;
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E3;
				byte[] array30;
				int num86;
				int num88;
				int num89;
				IntPtr intPtr16;
				int num90;
				for (;;)
				{
					bool flag;
					byte[] array2;
					byte[] array3;
					List<byte> list;
					int num15;
					long num14;
					byte[] array7;
					int num16;
					byte[] array8;
					IEnumerator enumerator;
					byte[] array10;
					byte[] array12;
					int num27;
					int num28;
					int num29;
					int num30;
					FileStream fileStream;
					IntPtr intPtr2;
					int num35;
					byte[] array18;
					bool flag3;
					uint num40;
					int num43;
					int num44;
					byte[] array19;
					IntPtr intPtr4;
					IntPtr intPtr5;
					IntPtr zero;
					IntPtr intPtr8;
					int num48;
					int num49;
					IntPtr intPtr9;
					int num51;
					uint num53;
					int num56;
					IntPtr[] array22;
					byte[] array23;
					int num58;
					IntPtr intPtr13;
					int num59;
					IntPtr intPtr14;
					int num63;
					int num64;
					int num65;
					int num66;
					IntPtr intPtr15;
					int num67;
					byte[] array25;
					bool flag6;
					int num80;
					bool flag7;
					uint num81;
					FileStream fileStream2;
					int num82;
					int num83;
					int num84;
					switch (num2)
					{
					case 0:
						goto IL_77D4;
					case 1:
						flag = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(intPtr, new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C()), 3) == -1;
						num2 = 513;
						continue;
					case 2:
						goto IL_1E95;
					case 3:
						num3 = 0U;
						num2 = 46;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 74;
							continue;
						}
						continue;
					case 4:
						num4 = 184 - 61;
						num2 = 79;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 18;
							continue;
						}
						continue;
					case 5:
						num5 = 0L;
						num2 = 467;
						continue;
					case 6:
						array[30] = 192 - 64;
						num2 = 48;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 176;
							continue;
						}
						continue;
					case 7:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0088\u008C\u0094\u008F\u009B\u0099\u0092\u0090\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u009A\u0094\u0090\u0088\u0093\u009C\u008B\u0093\u009C());
						num2 = 385;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 371;
							continue;
						}
						continue;
					case 8:
						array2[5] = array3[2];
						num2 = 464;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 88;
							continue;
						}
						continue;
					case 9:
						goto IL_45D4;
					case 10:
						goto IL_6C06;
					case 11:
						array4[14] = 131 - 43;
						num2 = 407;
						continue;
					case 12:
						array2[3] = array3[1];
						num2 = 8;
						continue;
					case 13:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008B\u009B\u008D\u009A\u009C\u0094\u0090\u0097\u0086 = null;
						num2 = 434;
						continue;
					case 14:
						num4 = 227 - 75;
						num2 = 384;
						continue;
					case 15:
						goto IL_51B0;
					case 16:
						num6 = 183 + 17;
						num2 = 0;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 0;
							continue;
						}
						continue;
					case 17:
						array[2] = 92 + 64;
						num2 = 175;
						continue;
					case 18:
						goto IL_4A0B;
					case 19:
						goto IL_2634;
					case 20:
						num6 = 236 - 78;
						num2 = 562;
						continue;
					case 21:
						array[7] = 74 + 79;
						num2 = 495;
						continue;
					case 22:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							num2 = 30;
							continue;
						}
						goto IL_76B5;
					case 23:
						goto IL_2DD1;
					case 24:
						array4[5] = 54 - 6;
						num2 = 543;
						continue;
					case 25:
					{
						bool flag2;
						if (flag2)
						{
							goto IL_346F;
						}
						num2 = 39;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 35;
							continue;
						}
						continue;
					}
					case 26:
						goto IL_679E;
					case 27:
						goto IL_6411;
					case 28:
						num7 = (num7 + 1) * A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C();
						num2 = 684;
						continue;
					case 29:
						goto IL_697D;
					case 30:
						break;
					case 31:
						goto IL_2684;
					case 32:
						try
						{
							if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
							{
								goto IL_72B8;
							}
							int num8 = 3;
							if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
							{
								num8 = 3;
							}
							for (;;)
							{
								IL_7222:
								switch (num8)
								{
								default:
									goto IL_7240;
								case 1:
									goto IL_72B8;
								case 2:
									break;
								case 3:
									break;
								case 4:
									goto IL_72F2;
								}
								A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u009E\u0091\u009C\u0090\u0099\u008C\u0094\u009E(new IntPtr(num9), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A).TypeHandle));
								num8 = 1;
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
								{
									num8 = 4;
								}
							}
							IL_7240:
							IL_72F2:
							goto IL_26F9;
							IL_72B8:
							A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u009E\u0091\u009C\u0090\u0099\u008C\u0094\u009E(new IntPtr(num9), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093).TypeHandle));
							num8 = 0;
							if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
							{
								num8 = 0;
								goto IL_7222;
							}
							goto IL_7222;
						}
						catch
						{
							int num10 = 1;
							if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
							{
								num10 = 1;
							}
							switch (num10)
							{
							case 1:
								try
								{
									if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
									{
										goto IL_7428;
									}
									int num11 = 0;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
									{
										num11 = 5;
									}
									Delegate delegate2;
									for (;;)
									{
										IL_7351:
										switch (num11)
										{
										case 1:
										{
											Delegate @delegate;
											A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0094\u0087\u0089\u0087\u009B\u0099\u0092\u0097\u009B(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093).TypeHandle), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0099\u0098\u0092\u0091\u008C\u0088\u0092\u008C\u0090(@delegate));
											num11 = 4;
											if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
											{
												num11 = 0;
												continue;
											}
											continue;
										}
										case 2:
											goto IL_7428;
										case 3:
											A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0094\u0087\u0089\u0087\u009B\u0099\u0092\u0097\u009B(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A).TypeHandle), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0099\u0098\u0092\u0091\u008C\u0088\u0092\u008C\u0090(delegate2));
											num11 = 0;
											if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
											{
												num11 = 0;
												continue;
											}
											continue;
										case 5:
										{
											Delegate @delegate = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u009E\u0091\u009C\u0090\u0099\u008C\u0094\u009E(new IntPtr(num9), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093).TypeHandle));
											num11 = 1;
											if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
											{
												num11 = 1;
												continue;
											}
											continue;
										}
										}
										break;
									}
									break;
									IL_7428:
									delegate2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u009E\u0091\u009C\u0090\u0099\u008C\u0094\u009E(new IntPtr(num9), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A).TypeHandle));
									num11 = 3;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
									{
										num11 = 3;
										goto IL_7351;
									}
									goto IL_7351;
								}
								catch
								{
									int num12 = 0;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
									{
										num12 = 0;
									}
									switch (num12)
									{
									}
								}
								break;
							}
							goto IL_26F9;
						}
						goto IL_74CA;
					case 33:
						array4[5] = 131 - 43;
						num2 = 169;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 44;
							continue;
						}
						continue;
					case 34:
						goto IL_71E5;
					case 35:
						goto IL_1061;
					case 36:
						goto IL_346F;
					case 37:
					{
						string text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u009E\u0092\u0093\u009A\u009C\u0087\u0090\u008B\u008C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0086\u0093\u008D\u0098\u008D\u009C\u008B\u0089\u009A(), array5);
						num2 = 818;
						continue;
					}
					case 38:
						array4[7] = (byte)num13;
						num2 = 53;
						continue;
					case 39:
					{
						byte[] array6 = new byte[32];
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u0094\u0094\u0089\u0090\u009B\u0097\u0092\u009E\u0092(array6, fieldof(<PrivateImplementationDetails>{1ADEF82B-9094-4B36-BB85-C14C09991B41}.EBA5CF088174B90FE09A19EDB05BB5868B8E51AA3D13DBF7339611DC33F2F056).FieldHandle);
						list = new List<byte>(array6);
						num2 = 329;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 5;
							continue;
						}
						continue;
					}
					case 40:
						num14 = (long)(num15 + 248);
						num2 = 15;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 9;
							continue;
						}
						continue;
					case 41:
						array[9] = (byte)num4;
						num2 = 469;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 554;
							continue;
						}
						continue;
					case 42:
						num4 = 242 - 80;
						num2 = 843;
						continue;
					case 43:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							goto IL_443E;
						}
						num2 = 811;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 145;
							continue;
						}
						continue;
					case 44:
						num16 = array7.Length % 4;
						num2 = 282;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 807;
							continue;
						}
						continue;
					case 45:
						goto IL_38E2;
					case 46:
						goto IL_217E;
					case 47:
						try
						{
							object obj = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u009C\u0089\u008F\u0099\u009C\u009D\u0094\u0095\u0094(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008D\u008B\u0095\u0094\u0098\u009A\u008D\u009C\u008B(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0092\u008A\u0090\u0096\u008D\u009D\u0090\u009B\u009D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0099\u008E\u008B\u009D\u008E\u009E\u0087\u008F\u008E(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).TypeHandle).Assembly))).GetField("m_ptr", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0092\u008A\u0090\u0096\u008D\u009D\u0090\u009B\u009D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0099\u008E\u008B\u009D\u008E\u009E\u0087\u008F\u008E(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C).TypeHandle).Assembly)));
							int num17 = 10;
							if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
							{
								num17 = 10;
							}
							for (;;)
							{
								int num22;
								MemoryStream memoryStream;
								switch (num17)
								{
								case 0:
									goto IL_1CCF;
								case 1:
								{
									uint num18 = 0U;
									num17 = 3;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
									{
										num17 = 3;
										continue;
									}
									continue;
								}
								case 2:
									A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097 = (IntPtr)obj;
									num17 = 8;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
									{
										num17 = 14;
										continue;
									}
									continue;
								case 3:
									try
									{
										byte[] array9;
										if ((array8 = array9) != null)
										{
											goto IL_1AB0;
										}
										int num19 = 3;
										byte* ptr;
										for (;;)
										{
											IL_198A:
											uint num18;
											A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u;
											switch (num19)
											{
											case 0:
												goto IL_19F9;
											case 1:
												break;
											case 2:
												goto IL_1A68;
											case 3:
												break;
											case 4:
												goto IL_1A31;
											case 5:
												A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008B\u009B\u008D\u009A\u009C\u0094\u0090\u0097\u0086(new IntPtr((void*)ptr), new IntPtr((void*)ptr), ref a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u, 216669565U, new IntPtr((void*)ptr), ref num18);
												num19 = 9;
												continue;
											case 6:
												goto IL_1A0F;
											case 7:
												goto IL_1A0F;
											case 8:
												if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
												{
													num19 = 5;
													continue;
												}
												goto IL_1A31;
											case 9:
												goto IL_1AD3;
											case 10:
												goto IL_1AB0;
											case 11:
												goto IL_1AF1;
											default:
												goto IL_19F9;
											}
											ptr = null;
											num19 = 7;
											continue;
											IL_19F9:
											a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u.A\u0099\u0098\u008A\u0094\u009E\u008C\u0098\u0090\u009A\u0096 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097;
											num19 = 8;
											continue;
											IL_1A0F:
											a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u = default(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088);
											num19 = 0;
											if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
											{
												num19 = 0;
												continue;
											}
											continue;
											IL_1A31:
											A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0088\u0088\u009C\u009A\u0098\u009D\u0094\u009A\u0091(new IntPtr((void*)ptr), new IntPtr((void*)ptr), ref a_u008D_u0090_u008B_u0092_u0099_u0094_u0088_u0094_u008E_u, 216669565U, new IntPtr((void*)ptr), ref num18);
											int num20 = 11;
											num19 = num20;
										}
										IL_1AD3:
										IL_1AF1:
										goto IL_1D29;
										IL_1A68:
										ptr = &array8[0];
										num19 = 6;
										goto IL_198A;
										IL_1AB0:
										if (array8.Length != 0)
										{
											goto IL_1A68;
										}
										num19 = 1;
										if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
										{
											num19 = 0;
											goto IL_198A;
										}
										goto IL_198A;
									}
									finally
									{
										array8 = null;
										int num21 = 0;
										if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
										{
											num21 = 0;
										}
										switch (num21)
										{
										}
									}
									goto IL_1B40;
								case 4:
									A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097 = (IntPtr)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u009C\u0089\u008F\u0099\u009C\u009D\u0094\u0095\u0094(obj.GetType().GetField("m_pData", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic), obj);
									num22 = 8;
									break;
								case 5:
									A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(memoryStream, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097.ToInt32()), 0, 4);
									num17 = 9;
									continue;
								case 6:
									A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008E\u0095\u0093\u009D\u0097\u0092\u0090\u0087\u0088(memoryStream, 0L);
									num17 = 15;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
									{
										num17 = 7;
										continue;
									}
									continue;
								case 7:
									goto IL_1939;
								case 8:
									goto IL_1C4C;
								case 9:
									goto IL_1B8E;
								case 10:
									if (obj is IntPtr)
									{
										num17 = 2;
										continue;
									}
									goto IL_1CF4;
								case 11:
									goto IL_1B8E;
								case 12:
									goto IL_1B40;
								case 13:
									goto IL_1D29;
								case 14:
									goto IL_1CF4;
								case 15:
								{
									byte[] array9 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0094\u0097\u0098\u0089\u0099\u0090\u009E\u0099\u0091(memoryStream);
									num17 = 10;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
									{
										num17 = 17;
										continue;
									}
									continue;
								}
								case 16:
									A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(memoryStream, new byte[A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B()], 0, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B());
									num17 = 6;
									if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
									{
										num17 = 0;
										continue;
									}
									continue;
								case 17:
									A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008D\u0089\u008E\u009C\u0088\u0086\u008C\u009A\u0093(memoryStream);
									num17 = 1;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
									{
										num17 = 1;
										continue;
									}
									continue;
								default:
									goto IL_1CCF;
								}
								IL_18BD:
								num17 = num22;
								continue;
								IL_1B8E:
								A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(memoryStream, new byte[A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B()], 0, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B());
								num22 = 16;
								goto IL_18BD;
								IL_1939:
								A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(memoryStream, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097.ToInt64()), 0, 8);
								num17 = 11;
								continue;
								IL_1CCF:
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() != 4)
								{
									goto IL_1939;
								}
								num17 = 0;
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
								{
									num17 = 5;
									continue;
								}
								continue;
								IL_1B40:
								A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(memoryStream, new byte[A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B()], 0, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B());
								num17 = 0;
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
								{
									num17 = 0;
									continue;
								}
								continue;
								IL_1C4C:
								memoryStream = new MemoryStream();
								num17 = 12;
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
								{
									num17 = 4;
									continue;
								}
								continue;
								IL_1CF4:
								if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0096\u0087\u009C\u008F\u0093\u009D\u0094\u0094\u009B(obj.GetType().ToString(), "System.Reflection.RuntimeModule"))
								{
									goto IL_1C4C;
								}
								num17 = 1;
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
								{
									num17 = 4;
								}
							}
							IL_1D29:
							goto IL_418E;
						}
						catch
						{
							int num23 = 0;
							if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
							{
								num23 = 0;
							}
							switch (num23)
							{
							default:
								goto IL_418E;
							}
						}
						goto IL_1D7A;
					case 48:
						try
						{
							for (;;)
							{
								IL_4D36:
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0090\u0092\u009A\u0097\u0099\u0091\u008B\u0099\u009B(enumerator))
								{
									goto IL_4DBA;
								}
								int num24 = 8;
								ProcessModule processModule;
								for (;;)
								{
									IL_4CDC:
									Version version;
									Version version3;
									switch (num24)
									{
									default:
										A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086 = true;
										num24 = 0;
										if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
										{
											num24 = 2;
											continue;
										}
										continue;
									case 1:
									{
										Version version2;
										if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0090\u008C\u0095\u009A\u0097\u0091\u008F\u008C\u008F(version, version2))
										{
											int num25 = 9;
											num24 = num25;
											continue;
										}
										break;
									}
									case 2:
										goto IL_4DFE;
									case 3:
										version3 = new Version(4, 0, 30319, 17921);
										num24 = 1;
										if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
										{
											num24 = 1;
											continue;
										}
										continue;
									case 4:
										goto IL_4DBA;
									case 5:
										break;
									case 6:
										goto IL_4D36;
									case 7:
										version = new Version(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u009E\u0088\u008D\u009B\u0098\u0096\u009E\u0093\u008B(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0087\u0091\u008A\u008B\u0097\u0098\u0097\u008E(processModule)), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u009D\u009C\u008E\u008D\u008F\u0089\u008B\u0091\u0098(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0087\u0091\u008A\u008B\u0097\u0098\u0097\u008E(processModule)), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0095\u0098\u009D\u0089\u0092\u0095\u008B\u0098\u009A(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0087\u0091\u008A\u008B\u0097\u0098\u0097\u008E(processModule)), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0099\u0094\u008E\u0086\u0090\u0087\u0094\u008E\u009B(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0087\u0091\u008A\u008B\u0097\u0098\u0097\u008E(processModule)));
										num24 = 11;
										continue;
									case 8:
										goto IL_4E96;
									case 9:
										goto IL_4DEF;
									case 10:
										if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0096\u0087\u009C\u008F\u0093\u009D\u0094\u0094\u009B(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u008D\u0098\u0094\u009D\u0090\u0089\u008B\u009E\u008D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u008C\u0088\u008D\u0095\u0098\u0090\u008B\u009B(processModule)), "clrjit.dll"))
										{
											goto IL_4D36;
										}
										num24 = 4;
										if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
										{
											num24 = 7;
											continue;
										}
										continue;
									case 11:
									{
										Version version2 = new Version(4, 0, 30319, 17020);
										num24 = 3;
										continue;
									}
									}
									if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009B\u009E\u0093\u0091\u0089\u0093\u008B\u008B\u0089(version, version3))
									{
										break;
									}
									num24 = 0;
									if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
									{
										num24 = 0;
									}
								}
								IL_4DEF:
								continue;
								IL_4DBA:
								processModule = (ProcessModule)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008B\u008B\u008F\u0089\u0098\u009D\u0089\u0090\u009C(enumerator);
								num24 = 10;
								goto IL_4CDC;
							}
							IL_4DFE:
							IL_4E96:
							goto IL_3E46;
						}
						finally
						{
							IDisposable disposable = enumerator as IDisposable;
							int num26 = 0;
							if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
							{
								num26 = 0;
							}
							for (;;)
							{
								switch (num26)
								{
								case 1:
									A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0095\u009B\u008D\u009B\u008E\u0089\u0092\u009E\u0089(disposable);
									num26 = 2;
									if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
									{
										num26 = 0;
										continue;
									}
									continue;
								case 2:
									goto IL_4F1A;
								}
								if (disposable == null)
								{
									break;
								}
								num26 = 1;
								if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
								{
									num26 = 1;
								}
							}
							IL_4F1A:;
						}
						goto IL_4F25;
					case 49:
						num6 = 139 - 119;
						num2 = 580;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 601;
							continue;
						}
						continue;
					case 50:
						goto IL_4F5C;
					case 51:
						goto IL_2F2A;
					case 52:
						goto IL_5A9E;
					case 53:
						num13 = 184 - 61;
						num2 = 93;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 54;
							continue;
						}
						continue;
					case 54:
						num13 = 10 + 0;
						num2 = 626;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 80;
							continue;
						}
						continue;
					case 55:
						array4[6] = 136 - 45;
						num2 = 772;
						continue;
					case 56:
						if (array3.Length == 0)
						{
							num2 = 131;
							continue;
						}
						goto IL_77AF;
					case 57:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0098\u009B\u009E\u0091\u009B\u0086\u0090\u0092\u009E(array10, 0, array11, 23, 4);
						num2 = 302;
						continue;
					case 58:
						array[18] = (byte)num6;
						num2 = 291;
						continue;
					case 59:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008E\u0095\u0093\u009D\u0097\u0092\u0090\u0087\u0088(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u), 0L);
						num2 = 839;
						continue;
					case 60:
						num6 = 78 + 6;
						num2 = 854;
						continue;
					case 61:
						array2[11] = array3[5];
						num2 = 99;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 681;
							continue;
						}
						continue;
					case 62:
						array12[5] = 12;
						num2 = 734;
						continue;
					case 63:
						array13[4] = 114;
						num2 = 113;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 802;
							continue;
						}
						continue;
					case 64:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 688;
						continue;
					case 65:
						array[20] = 158 - 52;
						num2 = 751;
						continue;
					case 66:
						goto IL_77AF;
					case 67:
						goto IL_7783;
					case 68:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() == 4)
						{
							num2 = 161;
							continue;
						}
						goto IL_3051;
					case 69:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009D\u0087\u008C\u0087\u0091\u008B\u0095\u0095\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0088\u0092\u009B\u0092\u008F\u0091\u0090\u009A\u008F(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0099\u0098\u0092\u0091\u008C\u0088\u0092\u008C\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008B\u009B\u008D\u009A\u009C\u0094\u0090\u0097\u0086)));
						num2 = 240;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 21;
							continue;
						}
						continue;
					case 70:
						num4 = 190 - 115;
						num2 = 873;
						continue;
					case 71:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009D\u0087\u008C\u0087\u0091\u008B\u0095\u0095\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0088\u0092\u009B\u0092\u008F\u0091\u0090\u009A\u008F(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0099\u0098\u0092\u0091\u008C\u0088\u0092\u008C\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C)));
						num2 = 427;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 144;
							continue;
						}
						continue;
					case 72:
						goto IL_1061;
					case 73:
						num27 = 0;
						num2 = 480;
						continue;
					case 74:
						goto IL_0F26;
					case 75:
						array[13] = (byte)num4;
						num2 = 304;
						continue;
					case 76:
						array[12] = (byte)num6;
						num2 = 152;
						continue;
					case 77:
						array[23] = 103 + 64;
						num2 = 4;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 4;
							continue;
						}
						continue;
					case 78:
					{
						byte[] array14;
						num28 = array14.Length / 8;
						num2 = 316;
						continue;
					}
					case 79:
						array[23] = (byte)num4;
						num2 = 179;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 387;
							continue;
						}
						continue;
					case 80:
						if (num29 == 1)
						{
							num2 = 747;
							if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
							{
								num2 = 133;
								continue;
							}
							continue;
						}
						else
						{
							if (num30 > 0)
							{
								num2 = 217;
								continue;
							}
							goto IL_2DD1;
						}
						break;
					case 81:
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u0089\u008E\u008C\u009D\u009C\u009D\u009E\u008D\u0088 a_u008F_u0089_u008E_u008C_u009D_u009C_u009D_u009E_u008D_u = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u0089\u008E\u008C\u009D\u009C\u009D\u009E\u008D\u0088)56;
						num2 = 258;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 320;
							continue;
						}
						continue;
					}
					case 82:
						array[3] = (byte)num6;
						num2 = 421;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 817;
							continue;
						}
						continue;
					case 83:
						goto IL_5D30;
					case 84:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0094\u009D\u009D\u0087\u008F\u009E\u0086\u008F = true;
						num2 = 261;
						continue;
					case 85:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0094\u009D\u009D\u0087\u008F\u009E\u0086\u008F)
						{
							goto IL_20AE;
						}
						num2 = 84;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 28;
							continue;
						}
						continue;
					case 86:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0088\u0097\u009C\u008F\u008E\u0092\u009E\u008A\u0088(fileStream, intPtr2.ToInt64(), SeekOrigin.Begin);
						num2 = 438;
						continue;
					case 87:
					{
						MemoryStream memoryStream2 = new MemoryStream();
						num2 = 141;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 381;
							continue;
						}
						continue;
					}
					case 88:
						num6 = 32 + 37;
						num2 = 540;
						continue;
					case 89:
						goto IL_6370;
					case 90:
						num13 = 252 - 84;
						num2 = 270;
						continue;
					case 91:
						array[30] = 44 + 119;
						num2 = 6;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 250;
							continue;
						}
						continue;
					case 92:
						array[27] = 88 + 84;
						num2 = 119;
						continue;
					case 93:
						array4[7] = (byte)num13;
						num2 = 285;
						continue;
					case 94:
						array13[5] = 116;
						num2 = 174;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 197;
							continue;
						}
						continue;
					case 95:
					{
						int num34;
						num5 = (long)(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num32 + 20L)) + num33 - num34);
						num2 = 635;
						continue;
					}
					case 96:
						if (!flag)
						{
							num2 = 524;
							continue;
						}
						goto IL_2FB6;
					case 97:
						array[14] = (byte)num4;
						num2 = 289;
						continue;
					case 98:
						num35++;
						num2 = 633;
						continue;
					case 99:
						goto IL_2085;
					case 100:
						goto IL_13E6;
					case 101:
						array4[2] = 245 - 81;
						num2 = 668;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 193;
							continue;
						}
						continue;
					case 102:
						array[13] = (byte)num6;
						num2 = 618;
						continue;
					case 103:
						array[7] = 218 - 72;
						num2 = 77;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 448;
							continue;
						}
						continue;
					case 104:
						array[21] = 178 - 59;
						num2 = 806;
						continue;
					case 105:
						goto IL_70F7;
					case 106:
						goto IL_13E6;
					case 107:
					{
						MemoryStream memoryStream3 = new MemoryStream();
						ICryptoTransform cryptoTransform;
						CryptoStream cryptoStream = new CryptoStream(memoryStream3, cryptoTransform, CryptoStreamMode.Write);
						byte[] array15;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(cryptoStream, array15, 0, array15.Length);
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u009E\u008A\u0097\u0093\u0097\u0087\u0091\u009D(cryptoStream);
						byte[] array14 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0094\u0097\u0098\u0089\u0099\u0090\u009E\u0099\u0091(memoryStream3);
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0091\u008A\u0087\u0095\u009E\u008B\u0090\u008B\u0096(array2, 0, array2.Length);
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008D\u0089\u008E\u009C\u0088\u0086\u008C\u009A\u0093(memoryStream3);
						num2 = 323;
						continue;
					}
					case 108:
						num27++;
						num2 = 379;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 355;
							continue;
						}
						continue;
					case 109:
						array[23] = (byte)num6;
						num2 = 77;
						continue;
					case 110:
						num5 = (long)(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num32 + 20L)) + num33 - num36);
						num2 = 617;
						continue;
					case 111:
						num37 = 0L;
						num2 = 486;
						continue;
					case 112:
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E;
						byte[] array16;
						a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E.A\u0091\u009C\u008C\u0096\u0095\u009A\u008C\u008B\u008E\u0097 = array16.Length;
						num2 = 861;
						continue;
					}
					case 113:
						goto IL_76B5;
					case 114:
					{
						byte[] array17 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(num9);
						num2 = 609;
						continue;
					}
					case 115:
						goto IL_6F55;
					case 116:
						array13[2] = 114;
						num2 = 787;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 684;
							continue;
						}
						continue;
					case 117:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u008C\u008B\u0092\u0098\u0092\u0099\u0090\u0094\u009C(array18, 0, intPtr3, array18.Length);
						num2 = 284;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 145;
							continue;
						}
						continue;
					case 118:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009D\u0087\u008C\u0087\u0091\u008B\u0095\u0095\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0088\u0092\u009B\u0092\u008F\u0091\u0090\u009A\u008F(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0099\u0098\u0092\u0091\u008C\u0088\u0092\u008C\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C)));
						num2 = 548;
						continue;
					case 119:
						num6 = 90 + 64;
						num2 = 575;
						continue;
					case 120:
						array13[0] = 109;
						num2 = 134;
						continue;
					case 121:
						goto IL_63BD;
					case 122:
						goto IL_5C0C;
					case 123:
						num4 = 234 - 78;
						num2 = 566;
						continue;
					case 124:
						goto IL_3AC6;
					case 125:
						num6 = 124 + 98;
						num2 = 180;
						continue;
					case 126:
						array[29] = (byte)num6;
						num2 = 553;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 316;
							continue;
						}
						continue;
					case 127:
						num13 = 33 + 1;
						num2 = 683;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 591;
							continue;
						}
						continue;
					case 128:
						goto IL_499A;
					case 129:
						array4[7] = (byte)num13;
						num2 = 375;
						continue;
					case 130:
						num13 = 230 - 76;
						num2 = 550;
						continue;
					case 131:
						goto IL_6F55;
					case 132:
						num4 = 119 - 105;
						num2 = 573;
						continue;
					case 133:
					{
						long num38 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0091\u008D\u0089\u0096\u0090\u0087\u009E\u0094\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u));
						num2 = 632;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 70;
							continue;
						}
						continue;
					}
					case 134:
						array13[1] = 115;
						num2 = 259;
						continue;
					case 135:
						num39 = 0;
						num2 = 301;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 581;
							continue;
						}
						continue;
					case 136:
						flag3 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u008B\u0095\u008C\u0092\u008B\u0095\u009E\u008C\u0094() == Architecture.Arm;
						num2 = 372;
						continue;
					case 137:
						goto IL_4067;
					case 138:
						goto IL_33DE;
					case 139:
						goto IL_450C;
					case 140:
						num40 = num41 ^ num42;
						num2 = 512;
						continue;
					case 141:
						array[19] = (byte)num6;
						num2 = 608;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 377;
							continue;
						}
						continue;
					case 142:
						num13 = 199 - 66;
						num2 = 355;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 640;
							continue;
						}
						continue;
					case 143:
						array4[2] = (byte)num13;
						num2 = 101;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 47;
							continue;
						}
						continue;
					case 144:
						num43 = 0;
						num2 = 69;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 713;
							continue;
						}
						continue;
					case 145:
						goto IL_45D4;
					case 146:
						goto IL_6569;
					case 147:
						array[6] = (byte)num4;
						num2 = 103;
						continue;
					case 148:
						num6 = 210 + 6;
						num2 = 399;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 383;
							continue;
						}
						continue;
					case 149:
						goto IL_4373;
					case 150:
						goto IL_50F0;
					case 151:
						num44++;
						num2 = 145;
						continue;
					case 152:
						array[13] = 158 - 52;
						num2 = 868;
						continue;
					case 153:
						array19 = new byte[array7.Length];
						num2 = 474;
						continue;
					case 154:
						array[1] = 106 + 50;
						num2 = 750;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 127;
							continue;
						}
						continue;
					case 155:
					{
						int num45 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 165;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 242;
							continue;
						}
						continue;
					}
					case 156:
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u0089\u008E\u008C\u009D\u009C\u009D\u009E\u008D\u0088 a_u008F_u0089_u008E_u008C_u009D_u009C_u009D_u009E_u008D_u;
						intPtr4 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u008A\u008F\u0095\u0095\u0096\u0098\u008B\u0099\u009B((uint)a_u008F_u0089_u008E_u008C_u009D_u009C_u009D_u009E_u008D_u, 1, (uint)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0087\u009A\u0089\u009C\u0090\u0086\u008B\u0098\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u008F\u0096\u0099\u0094\u008D\u0094\u0090\u008D()));
						num2 = 470;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 255;
							continue;
						}
						continue;
					}
					case 157:
						goto IL_2FB6;
					case 158:
					{
						byte[] array17 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u009D\u0094\u0093\u0093\u0099\u0099\u0092\u0099\u008B(num9));
						num2 = 412;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 70;
							continue;
						}
						continue;
					}
					case 159:
						goto IL_5E56;
					case 160:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0088\u008C\u0094\u008F\u009B\u0099\u0092\u0090\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0086\u008E\u0093\u0097\u008B\u008D\u009E\u0086\u009E());
						num2 = 711;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 316;
							continue;
						}
						continue;
					case 161:
						num46 = (long)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(intPtr5);
						num2 = 677;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 330;
							continue;
						}
						continue;
					case 162:
						goto IL_1E53;
					case 163:
						num4 = 76 + 67;
						num2 = 127;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 234;
							continue;
						}
						continue;
					case 164:
						goto IL_3BD6;
					case 165:
					{
						int num47 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 189;
						continue;
					}
					case 166:
						array4[2] = 171 + 43;
						num2 = 505;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 620;
							continue;
						}
						continue;
					case 167:
						goto IL_31A2;
					case 168:
						goto IL_2FF5;
					case 169:
						goto IL_43A6;
					case 170:
						array4[6] = (byte)num13;
						num2 = 331;
						continue;
					case 171:
						goto IL_2E8F;
					case 172:
						num6 = 88 + 121;
						num2 = 648;
						continue;
					case 173:
						num41 += num3;
						num2 = 602;
						continue;
					case 174:
						goto IL_16FF;
					case 175:
						num4 = 71 + 90;
						num2 = 814;
						continue;
					case 176:
						goto IL_4142;
					case 177:
						list.AddRange(array20);
						num2 = 789;
						continue;
					case 178:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0091\u0089\u0089\u0086\u0096\u009D\u0092\u0098\u0092(intPtr4, intPtr6, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)), 4U, out zero);
						num2 = 414;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 182;
							continue;
						}
						continue;
					case 179:
					{
						IntPtr intPtr7;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(intPtr7, new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C()), 3);
						num2 = 246;
						continue;
					}
					case 180:
						array[26] = (byte)num6;
						num2 = 121;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 172;
							continue;
						}
						continue;
					case 181:
						goto IL_4419;
					case 182:
						array[18] = 145 - 86;
						num2 = 588;
						continue;
					case 183:
						goto IL_1081;
					case 184:
						array4[10] = 173 + 47;
						num2 = 244;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 94;
							continue;
						}
						continue;
					case 185:
						array[13] = (byte)num6;
						num2 = 695;
						continue;
					case 186:
						goto IL_2949;
					case 187:
						array4[10] = (byte)num13;
						num2 = 184;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 62;
							continue;
						}
						continue;
					case 188:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
						{
							goto IL_3BD6;
						}
						num2 = 95;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 299;
							continue;
						}
						continue;
					case 189:
					{
						int num47;
						intPtr8 = new IntPtr(num31 + (long)num47 - (long)num48);
						num2 = 348;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 479;
							continue;
						}
						continue;
					}
					case 190:
						array[30] = (byte)num4;
						num2 = 358;
						continue;
					case 191:
					{
						byte[] array14;
						a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0093\u0091\u0090\u0091\u009B\u0095\u009E\u009A\u0093(new MemoryStream(array14));
						num2 = 59;
						continue;
					}
					case 192:
						array[19] = (byte)num4;
						num2 = 516;
						continue;
					case 193:
						goto IL_38F8;
					case 194:
						goto IL_2DD1;
					case 195:
						goto IL_13E6;
					case 196:
						num36 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num32 + 12L));
						num2 = 359;
						continue;
					case 197:
						array13[6] = 46;
						num2 = 174;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 346;
							continue;
						}
						continue;
					case 198:
						array[29] = (byte)num4;
						num2 = 6;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 4;
							continue;
						}
						continue;
					case 199:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							goto IL_75BE;
						}
						num2 = 81;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 138;
							continue;
						}
						continue;
					case 200:
						goto IL_46D8;
					case 201:
						array[15] = 195 - 65;
						num2 = 226;
						continue;
					case 202:
						array4[8] = (byte)num13;
						num2 = 321;
						continue;
					case 203:
						goto IL_5358;
					case 204:
						array4[14] = 74 + 113;
						num2 = 11;
						continue;
					case 205:
						goto IL_1156;
					case 206:
						goto IL_4067;
					case 207:
						goto IL_6AB5;
					case 208:
						goto IL_21FB;
					case 209:
						goto IL_499A;
					case 210:
						array[0] = (byte)num4;
						num2 = 592;
						continue;
					case 211:
						num6 = 13 + 56;
						num2 = 790;
						continue;
					case 212:
						num49 = 0;
						num2 = 536;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 822;
							continue;
						}
						continue;
					case 213:
						goto IL_4008;
					case 214:
						num4 = 60 + 23;
						num2 = 16;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 41;
							continue;
						}
						continue;
					case 215:
						num13 = 200 - 66;
						num2 = 474;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 780;
							continue;
						}
						continue;
					case 216:
						num13 = 151 - 50;
						num2 = 482;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 586;
							continue;
						}
						continue;
					case 217:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							num2 = 73;
							continue;
						}
						goto IL_1156;
					case 218:
						flag = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(intPtr9, new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C()), 3) == -1;
						num2 = 96;
						continue;
					case 219:
						goto IL_4C9E;
					case 220:
						array[4] = 17 + 72;
						num2 = 41;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 60;
							continue;
						}
						continue;
					case 221:
						goto IL_5A2B;
					case 222:
						array4[3] = 57 + 119;
						num2 = 526;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 597;
							continue;
						}
						continue;
					case 223:
					{
						IntPtr intPtr10;
						if (intPtr10 != intPtr9)
						{
							num2 = 823;
							continue;
						}
						goto IL_4680;
					}
					case 224:
						if (num50 == num51 - 1)
						{
							num2 = 674;
							continue;
						}
						goto IL_675C;
					case 225:
						array5[0] = 103;
						num2 = 272;
						continue;
					case 226:
						num4 = 242 - 80;
						num2 = 694;
						continue;
					case 227:
						goto IL_5D1D;
					case 228:
						array19[num52 + 2] = (byte)((num53 & 16711680U) >> 16);
						num2 = 596;
						continue;
					case 229:
						array4[2] = (byte)num13;
						num2 = 558;
						continue;
					case 230:
					{
						int num55;
						long num54 = num31 + (long)num55;
						num2 = 378;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 838;
							continue;
						}
						continue;
					}
					case 231:
						array4[0] = (byte)num13;
						num2 = 29;
						continue;
					case 232:
						goto IL_2C5C;
					case 233:
						array[13] = (byte)num6;
						num2 = 395;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 538;
							continue;
						}
						continue;
					case 234:
						array[1] = (byte)num4;
						num2 = 154;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 95;
							continue;
						}
						continue;
					case 235:
						num4 = 117 + 65;
						num2 = 97;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 36;
							continue;
						}
						continue;
					case 236:
						goto IL_32B1;
					case 237:
						num6 = 253 - 84;
						num2 = 82;
						continue;
					case 238:
						array4[9] = 173 + 69;
						num2 = 774;
						continue;
					case 239:
						array[7] = (byte)num4;
						num2 = 21;
						continue;
					case 240:
						goto IL_1695;
					case 241:
						goto IL_3516;
					case 242:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u009E\u009E\u009E\u008F\u0090\u008B\u008B\u0089\u0087 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 629;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 598;
							continue;
						}
						continue;
					case 243:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() != 4)
						{
							num2 = 610;
							continue;
						}
						goto IL_1E95;
					case 244:
						array4[11] = 165 - 55;
						num2 = 699;
						continue;
					case 245:
						return;
					case 246:
						goto IL_6667;
					case 247:
						array4[15] = 35 - 5;
						num2 = 107;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 644;
							continue;
						}
						continue;
					case 248:
						goto IL_5ED1;
					case 249:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0094\u0087\u0092\u0090\u0091\u0097\u008B\u0091\u008F(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 805;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 436;
							continue;
						}
						continue;
					case 250:
						num4 = 144 + 19;
						num2 = 190;
						continue;
					case 251:
						intPtr4 = IntPtr.Zero;
						num2 = 687;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 564;
							continue;
						}
						continue;
					case 252:
					{
						IntPtr intPtr11;
						if (intPtr11 != IntPtr.Zero)
						{
							goto IL_38E2;
						}
						num2 = 36;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 582;
							continue;
						}
						continue;
					}
					case 253:
						goto IL_6232;
					case 254:
						array[22] = (byte)num4;
						num2 = 411;
						continue;
					case 255:
						num13 = 175 - 77;
						num2 = 502;
						continue;
					case 256:
						goto IL_5239;
					case 257:
						num29 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 760;
						continue;
					case 258:
						array21 = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E[num56];
						num2 = 87;
						continue;
					case 259:
						goto IL_2793;
					case 260:
					{
						int num45;
						array22 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0086\u008E\u008C\u0086\u008E\u009E\u0092\u0086\u009E(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008E\u0095\u0093\u0099\u0097\u0089\u008B\u008C\u0091(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0099\u008E\u008B\u009D\u008E\u009E\u0087\u008F\u008E(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0097\u009B\u0098\u008E\u008A\u008A\u009E\u008C\u0093), num45), num48, num57, num29);
						num2 = 133;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 18;
							continue;
						}
						continue;
					}
					case 261:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u009C\u008C\u008D\u0087\u009A\u0094\u009C\u0098();
						num2 = 69;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 160;
							continue;
						}
						continue;
					case 262:
						array4[11] = 38 + 88;
						num2 = 130;
						continue;
					case 263:
						array13 = new byte[10];
						num2 = 510;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 32;
							continue;
						}
						continue;
					case 264:
						goto IL_6593;
					case 265:
						array5[4] = 105;
						num2 = 680;
						continue;
					case 266:
						goto IL_3FF7;
					case 267:
						goto IL_1383;
					case 268:
						goto IL_755C;
					case 269:
						array23 = array;
						num2 = 826;
						continue;
					case 270:
						goto IL_706B;
					case 271:
						array4[12] = 90 + 75;
						num2 = 228;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 832;
							continue;
						}
						continue;
					case 272:
						array5[1] = 101;
						num2 = 238;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 297;
							continue;
						}
						continue;
					case 273:
						num13 = 46 + 90;
						num2 = 876;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 316;
							continue;
						}
						continue;
					case 274:
						array10 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(intPtr12.ToInt32());
						num2 = 87;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 158;
							continue;
						}
						continue;
					case 275:
						num6 = 167 + 45;
						num2 = 442;
						continue;
					case 276:
						goto IL_23A5;
					case 277:
						goto IL_5DE7;
					case 278:
					{
						int num34 = 0;
						num2 = 55;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 144;
							continue;
						}
						continue;
					}
					case 279:
						goto IL_4F25;
					case 280:
						goto IL_4975;
					case 281:
						array4[4] = (byte)num13;
						num2 = 52;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 824;
							continue;
						}
						continue;
					case 282:
						num30 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 257;
						continue;
					case 283:
						num6 = 83 + 119;
						num2 = 491;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 482;
							continue;
						}
						continue;
					case 284:
						goto IL_7087;
					case 285:
						num13 = 84 + 73;
						num2 = 129;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 24;
							continue;
						}
						continue;
					case 286:
						num58++;
						num2 = 536;
						continue;
					case 287:
					{
						int num34;
						if (num34 <= num33)
						{
							num2 = 436;
							continue;
						}
						goto IL_505D;
					}
					case 288:
						goto IL_324D;
					case 289:
						goto IL_5CFA;
					case 290:
						goto IL_11A7;
					case 291:
						array[18] = 122 + 0;
						num2 = 182;
						continue;
					case 292:
						goto IL_3C8B;
					case 293:
						num4 = 192 - 64;
						num2 = 568;
						continue;
					case 294:
						goto IL_2EDF;
					case 295:
						array3 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u008B\u008C\u009E\u0091\u008E\u008D\u0092\u0089\u0097(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0091\u0089\u0093\u0097\u008E\u0092\u009C\u008A\u009C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0097\u009B\u0098\u008E\u008A\u008A\u009E\u008C\u0093));
						num2 = 599;
						continue;
					case 296:
						array4[9] = (byte)num13;
						num2 = 238;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 147;
							continue;
						}
						continue;
					case 297:
						array5[2] = 116;
						num2 = 456;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 333;
							continue;
						}
						continue;
					case 298:
						array[4] = 46 + 17;
						num2 = 702;
						continue;
					case 299:
						goto IL_66DE;
					case 300:
						array4[11] = (byte)num13;
						num2 = 262;
						continue;
					case 301:
						array4[1] = (byte)num13;
						num2 = 423;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 412;
							continue;
						}
						continue;
					case 302:
						goto IL_2843;
					case 303:
						num15 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + 60L));
						num2 = 396;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 224;
							continue;
						}
						continue;
					case 304:
						array[14] = 207 - 69;
						num2 = 235;
						continue;
					case 305:
						goto IL_139F;
					case 306:
						num51++;
						num2 = 139;
						continue;
					case 307:
						num36 = 0;
						num2 = 32;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 135;
							continue;
						}
						continue;
					case 308:
						goto IL_2C0F;
					case 309:
						array[28] = 228 - 76;
						num2 = 651;
						continue;
					case 310:
						array4[5] = 246 - 82;
						num2 = 24;
						continue;
					case 311:
						array4[1] = 5 + 93;
						num2 = 308;
						continue;
					case 312:
						num13 = 219 - 73;
						num2 = 318;
						continue;
					case 313:
						goto IL_2843;
					case 314:
						array[29] = (byte)num4;
						num2 = 30;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 211;
							continue;
						}
						continue;
					case 315:
					{
						bool flag4 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num5)) == 1112167234;
						num2 = 350;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 314;
							continue;
						}
						continue;
					}
					case 316:
					{
						byte[] array14;
						if ((array8 = array14) == null)
						{
							goto IL_4165;
						}
						num2 = 765;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 348;
							continue;
						}
						continue;
					}
					case 317:
						num13 = 156 - 52;
						num2 = 229;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 87;
							continue;
						}
						continue;
					case 318:
						array4[9] = (byte)num13;
						num2 = 523;
						continue;
					case 319:
						num6 = 163 - 54;
						num2 = 208;
						continue;
					case 320:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							num2 = 156;
							continue;
						}
						goto IL_31A2;
					case 321:
						num13 = 198 - 66;
						num2 = 523;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 589;
							continue;
						}
						continue;
					case 322:
						goto IL_139F;
					case 323:
					{
						CryptoStream cryptoStream;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008D\u0089\u008E\u009C\u0088\u0086\u008C\u009A\u0093(cryptoStream);
						num2 = 249;
						continue;
					}
					case 324:
						goto IL_36EF;
					case 325:
						goto IL_7087;
					case 326:
					{
						byte[] array14 = array19;
						num2 = 78;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 29;
							continue;
						}
						continue;
					}
					case 327:
						goto IL_5392;
					case 328:
						goto IL_29A4;
					case 329:
						goto IL_70DC;
					case 330:
						array[17] = 232 - 77;
						num2 = 123;
						continue;
					case 331:
						num13 = 231 - 77;
						num2 = 38;
						continue;
					case 332:
						array4[9] = (byte)num13;
						num2 = 312;
						continue;
					case 333:
						array[20] = 238 - 79;
						num2 = 714;
						continue;
					case 334:
						array[16] = (byte)num4;
						num2 = 478;
						continue;
					case 335:
						goto IL_1239;
					case 336:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr13, 4, 8, ref num59);
						num2 = 276;
						continue;
					case 337:
						goto IL_51B0;
					case 338:
						goto IL_2684;
					case 339:
						goto IL_2437;
					case 340:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0096\u0094\u0089\u0093\u008D\u0098\u0090\u009A\u008A(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008B\u0094\u008E\u009D\u0091\u0093\u008B\u008C\u0098(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).TypeHandle).Assembly), null))
						{
							num2 = 288;
							continue;
						}
						goto IL_3C8B;
					case 341:
						num4 = 247 - 82;
						num2 = 345;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 14;
							continue;
						}
						continue;
					case 342:
					{
						IntPtr intPtr7 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0091\u008E\u0097\u0093\u0090\u0090\u009D\u0097\u008B(intPtr2);
						num2 = 786;
						continue;
					}
					case 343:
						array4[12] = (byte)num13;
						num2 = 408;
						continue;
					case 344:
						intPtr5 = IntPtr.Zero;
						num2 = 761;
						continue;
					case 345:
						array[25] = (byte)num4;
						num2 = 42;
						continue;
					case 346:
						array13[7] = 100;
						num2 = 630;
						continue;
					case 347:
						array[16] = (byte)num6;
						num2 = 690;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 125;
							continue;
						}
						continue;
					case 348:
						array[21] = (byte)num4;
						num2 = 3;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 104;
							continue;
						}
						continue;
					case 349:
						array4[4] = (byte)num13;
						num2 = 869;
						continue;
					case 350:
						goto IL_63BD;
					case 351:
						goto IL_4173;
					case 352:
						num4 = 177 - 66;
						num2 = 147;
						continue;
					case 353:
						goto IL_3E46;
					case 354:
						array2[15] = array3[7];
						num2 = 841;
						continue;
					case 355:
						array13[10] = 108;
						num2 = 405;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 525;
							continue;
						}
						continue;
					case 356:
						array[16] = 137 - 45;
						num2 = 417;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 337;
							continue;
						}
						continue;
					case 357:
						goto IL_6CA1;
					case 358:
						num6 = 176 - 58;
						num2 = 403;
						continue;
					case 359:
						if (num36 <= num33)
						{
							num2 = 431;
							continue;
						}
						goto IL_6411;
					case 360:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u008D\u0091\u0087\u0087\u008A\u0086\u0087\u0093 = true;
						num2 = 152;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 759;
							continue;
						}
						continue;
					case 361:
						array4[4] = (byte)num13;
						num2 = 475;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 795;
							continue;
						}
						continue;
					case 362:
						goto IL_71E5;
					case 363:
						num13 = 45 + 2;
						num2 = 187;
						continue;
					case 364:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							goto Block_217;
						}
						goto IL_3DE6;
					case 365:
						goto IL_6618;
					case 366:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008A\u0088\u009A\u008E\u0092\u0093\u0091\u008E\u0091(new IntPtr(num46), intPtr14);
						num2 = 530;
						continue;
					case 367:
						goto IL_75BE;
					case 368:
						array4[13] = (byte)num13;
						num2 = 204;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 133;
							continue;
						}
						continue;
					case 369:
						goto IL_2217;
					case 370:
						array[30] = (byte)num4;
						num2 = 91;
						continue;
					case 371:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(new IntPtr(num46), new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B()), 3) == 0)
						{
							goto Block_347;
						}
						goto IL_5812;
					case 372:
					{
						bool flag2 = false;
						num2 = 455;
						continue;
					}
					case 373:
						array[12] = (byte)num6;
						num2 = 88;
						continue;
					case 374:
						goto IL_1184;
					case 375:
						num13 = 179 + 53;
						num2 = 654;
						continue;
					case 376:
						array4[4] = (byte)num13;
						num2 = 769;
						continue;
					case 377:
						goto IL_2D78;
					case 378:
						goto IL_5812;
					case 379:
						goto IL_6749;
					case 380:
						goto IL_1695;
					case 381:
						a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E2 = default(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E);
						num2 = 219;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 83;
							continue;
						}
						continue;
					case 382:
						array4[9] = (byte)num13;
						num2 = 216;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 34;
							continue;
						}
						continue;
					case 383:
						goto IL_678D;
					case 384:
						array[6] = (byte)num4;
						num2 = 628;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 395;
							continue;
						}
						continue;
					case 385:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							goto IL_3E46;
						}
						num2 = 323;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 842;
							continue;
						}
						continue;
					case 386:
						goto IL_5578;
					case 387:
						array[23] = 171 - 104;
						num2 = 402;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 319;
							continue;
						}
						continue;
					case 388:
						goto IL_5FCB;
					case 389:
						array[18] = (byte)num6;
						num2 = 730;
						continue;
					case 390:
						goto IL_4C5B;
					case 391:
						num60 += 8;
						num2 = 277;
						continue;
					case 392:
						num48 = 0;
						num2 = 105;
						continue;
					case 393:
						num6 = 110 + 39;
						num2 = 337;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 373;
							continue;
						}
						continue;
					case 394:
						array[10] = (byte)num4;
						num2 = 701;
						continue;
					case 395:
						array[24] = 213 - 71;
						num2 = 875;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 811;
							continue;
						}
						continue;
					case 396:
					{
						long num61 = (long)(num15 + 24);
						num2 = 740;
						continue;
					}
					case 397:
						array[5] = (byte)num4;
						num2 = 753;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 631;
							continue;
						}
						continue;
					case 398:
						num62 = 0;
						num2 = 340;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 147;
							continue;
						}
						continue;
					case 399:
						array[0] = (byte)num6;
						num2 = 163;
						continue;
					case 400:
					{
						MemoryStream memoryStream2;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E;
						a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E.A\u0089\u0098\u009E\u0095\u008F\u0086\u008E\u0094\u008B\u008A = new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0091\u008D\u0089\u0096\u0090\u0087\u009E\u0094\u0096(memoryStream2));
						num2 = 855;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 654;
							continue;
						}
						continue;
					}
					case 401:
						goto IL_4008;
					case 402:
						array[24] = 168 - 56;
						num2 = 395;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 279;
							continue;
						}
						continue;
					case 403:
						array[31] = (byte)num6;
						num2 = 796;
						continue;
					case 404:
						goto IL_36EF;
					case 405:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
						{
							goto IL_6167;
						}
						num2 = 18;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 18;
							continue;
						}
						continue;
					case 406:
						goto IL_13CF;
					case 407:
						goto IL_1255;
					case 408:
						array4[13] = 212 - 70;
						num2 = 54;
						continue;
					case 409:
						num6 = 174 - 52;
						num2 = 792;
						continue;
					case 410:
						goto IL_1D7A;
					case 411:
						num4 = 150 - 50;
						num2 = 436;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 482;
							continue;
						}
						continue;
					case 412:
						goto IL_4604;
					case 413:
						array24 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097.ToInt32());
						num2 = 274;
						continue;
					case 414:
						goto IL_28A7;
					case 415:
						num9 = (long)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num46));
						num2 = 171;
						continue;
					case 416:
						array[12] = (byte)num4;
						num2 = 696;
						continue;
					case 417:
						num4 = 96 + 47;
						num2 = 570;
						continue;
					case 418:
						num63 = num48;
						num2 = 429;
						continue;
					case 419:
						goto IL_443E;
					case 420:
						if (num50 == num51 - 1)
						{
							num2 = 627;
							continue;
						}
						goto IL_2F2A;
					case 421:
					{
						byte[] array15;
						array7 = array15;
						num2 = 44;
						continue;
					}
					case 422:
						num13 = 186 - 62;
						num2 = 785;
						continue;
					case 423:
						array4[1] = 96 - 49;
						num2 = 317;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 276;
							continue;
						}
						continue;
					case 424:
					{
						byte[] array15 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008A\u008E\u009E\u008F\u0098\u0086\u008E\u0099(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u, (int)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u008B\u0088\u009A\u0096\u0093\u009E\u0094\u009D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)));
						num2 = 267;
						continue;
					}
					case 425:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr13, 4, num59, ref num59);
						num2 = 28;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 108;
							continue;
						}
						continue;
					case 426:
						num64++;
						num2 = 444;
						continue;
					case 427:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0095\u008D\u008F\u009A\u0098\u008C\u009E\u0094\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008B\u009B\u008D\u009A\u009C\u0094\u0090\u0097\u0086);
						num2 = 69;
						continue;
					case 428:
						goto IL_5358;
					case 429:
						num59 = 0;
						num2 = 260;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 30;
							continue;
						}
						continue;
					case 430:
						goto IL_40A8;
					case 431:
						goto IL_7161;
					case 432:
						array[19] = (byte)num6;
						num2 = 65;
						continue;
					case 433:
						goto IL_24EF;
					case 434:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0088\u0088\u009C\u009A\u0098\u009D\u0094\u009A\u0091 = null;
						num2 = 144;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 188;
							continue;
						}
						continue;
					case 435:
					{
						int num55 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u) - num48;
						num2 = 39;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 64;
							continue;
						}
						continue;
					}
					case 436:
					{
						int num34;
						if (num33 < num34 + num43)
						{
							num2 = 95;
							continue;
						}
						goto IL_505D;
					}
					case 437:
						array4[5] = (byte)num13;
						num2 = 813;
						continue;
					case 438:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(fileStream, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)), 0, 4);
						num2 = 3;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 35;
							continue;
						}
						continue;
					case 439:
						array[10] = (byte)num6;
						num2 = 409;
						continue;
					case 440:
						break;
					case 441:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() == 4)
						{
							num2 = 413;
							continue;
						}
						goto IL_335F;
					case 442:
						array[15] = (byte)num6;
						num2 = 356;
						continue;
					case 443:
						num4 = 227 - 75;
						num2 = 585;
						continue;
					case 444:
						goto IL_5D1D;
					case 445:
						goto IL_6618;
					case 446:
						goto IL_2BEE;
					case 447:
						goto IL_5A9E;
					case 448:
						num4 = 95 + 57;
						num2 = 279;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 91;
							continue;
						}
						continue;
					case 449:
						goto IL_2843;
					case 450:
						array13[9] = 108;
						num2 = 593;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 621;
							continue;
						}
						continue;
					case 451:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr8, num65 * 4, 8, ref num59);
						num2 = 221;
						continue;
					case 452:
						goto IL_2BEE;
					case 453:
						goto IL_32C5;
					case 454:
						array[9] = (byte)num4;
						num2 = 214;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 18;
							continue;
						}
						continue;
					case 455:
						array12 = null;
						num2 = 243;
						continue;
					case 456:
						array5[3] = 74;
						num2 = 265;
						continue;
					case 457:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							goto IL_6AB5;
						}
						num2 = 421;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 670;
							continue;
						}
						continue;
					case 458:
						Array.Reverse<byte>(array2);
						num2 = 295;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 98;
							continue;
						}
						continue;
					case 459:
						goto IL_505D;
					case 460:
						goto IL_66CD;
					case 461:
						goto IL_3EAE;
					case 462:
						goto IL_7760;
					case 463:
						array13[4] = 105;
						num2 = 94;
						continue;
					case 464:
						array2[7] = array3[3];
						num2 = 757;
						continue;
					case 465:
						num6 = 129 - 43;
						num2 = 652;
						continue;
					case 466:
						goto IL_7629;
					case 467:
						flag5 = false;
						num2 = 278;
						continue;
					case 468:
						goto IL_2437;
					case 469:
						array[0] = (byte)num4;
						num2 = 148;
						continue;
					case 470:
						goto IL_2BEE;
					case 471:
						goto IL_34C0;
					case 472:
						num6 = 93 - 9;
						num2 = 432;
						continue;
					case 473:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
						{
							num2 = 294;
							continue;
						}
						goto IL_3C0E;
					case 474:
						num66 = array23.Length / 4;
						num2 = 865;
						continue;
					case 475:
						array13[8] = 46;
						num2 = 526;
						continue;
					case 476:
						goto IL_15DC;
					case 477:
						if (num16 > 0)
						{
							num2 = 306;
							continue;
						}
						goto IL_450C;
					case 478:
						goto IL_0EEA;
					case 479:
						num65 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 503;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 123;
							continue;
						}
						continue;
					case 480:
						goto IL_6749;
					case 481:
						goto IL_36EF;
					case 482:
						array[22] = (byte)num4;
						num2 = 132;
						continue;
					case 483:
						num4 = 97 + 50;
						num2 = 381;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 454;
							continue;
						}
						continue;
					case 484:
					{
						IntPtr intPtr7;
						intPtr15 = intPtr7;
						num2 = 179;
						continue;
					}
					case 485:
						goto IL_54E6;
					case 486:
						if (num33 == 0)
						{
							num2 = 121;
							continue;
						}
						goto IL_1630;
					case 487:
						num13 = 217 - 72;
						num2 = 290;
						continue;
					case 488:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
						{
							goto IL_13E6;
						}
						num2 = 62;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 0;
							continue;
						}
						continue;
					case 489:
						goto IL_3DE6;
					case 490:
						goto IL_418E;
					case 491:
						array[27] = (byte)num6;
						num2 = 309;
						continue;
					case 492:
						num6 = 123 + 28;
						num2 = 126;
						continue;
					case 493:
						goto IL_3435;
					case 494:
						num67++;
						num2 = 819;
						continue;
					case 495:
						array[7] = 43 + 114;
						num2 = 62;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 462;
							continue;
						}
						continue;
					case 496:
						num6 = 115 + 120;
						num2 = 76;
						continue;
					case 497:
						array[11] = 187 - 62;
						num2 = 465;
						continue;
					case 498:
					{
						bool flag4 = false;
						num2 = 303;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 15;
							continue;
						}
						continue;
					}
					case 499:
						num35 = 0;
						num2 = 374;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 721;
							continue;
						}
						continue;
					case 500:
						goto IL_28E3;
					case 501:
						array4[6] = (byte)num13;
						num2 = 21;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 55;
							continue;
						}
						continue;
					case 502:
						array4[8] = (byte)num13;
						num2 = 509;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 830;
							continue;
						}
						continue;
					case 503:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							num2 = 649;
							continue;
						}
						goto IL_29A4;
					case 504:
						goto IL_385C;
					case 505:
						array[10] = 119 + 83;
						num2 = 517;
						continue;
					case 506:
						goto IL_2DF6;
					case 507:
					{
						object obj2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008D\u0088\u008C\u0098\u009D\u008D\u0090\u0088\u008C();
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0091\u0086\u009B\u0090\u008D\u009D\u0092\u0098\u008C(obj2, CipherMode.CBC);
						ICryptoTransform cryptoTransform = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u0097\u009B\u0089\u008E\u009A\u0090\u0092\u009C\u0096(obj2, array23, array2);
						num2 = 634;
						continue;
					}
					case 508:
						goto IL_3051;
					case 509:
					{
						IntPtr intPtr10 = IntPtr.Zero;
						num2 = 773;
						continue;
					}
					case 510:
						array13[0] = 99;
						num2 = 598;
						continue;
					case 511:
						goto IL_3412;
					case 512:
						num58 = 0;
						num2 = 779;
						continue;
					case 513:
						if (!flag)
						{
							num2 = 720;
							continue;
						}
						goto IL_45AA;
					case 514:
						num64 = 0;
						num2 = 227;
						continue;
					case 515:
						num42 <<= 8;
						num2 = 144;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 727;
							continue;
						}
						continue;
					case 516:
						num6 = 147 - 49;
						num2 = 141;
						continue;
					case 517:
						goto IL_3B7F;
					case 518:
						goto IL_782E;
					case 519:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C = null;
						num2 = 23;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 32;
							continue;
						}
						continue;
					case 520:
					{
						IntPtr intPtr10 = intPtr;
						num2 = 1;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					case 521:
					{
						uint num68 = num41;
						uint num69 = 1656006228U;
						uint num70 = 1098729433U;
						uint num71 = 2123735800U;
						uint num72 = 1593074158U;
						ulong num73 = (ulong)(num69 * 2104484525U);
						num73 |= 1UL;
						num71 = (uint)((ulong)(num71 * num71) % num73);
						uint num74 = (1828115309U + num70) ^ num69;
						uint num75 = ((num69 >> 15) | (num69 << 17)) + num71;
						uint num76 = num75 & 252645135U;
						num75 &= 4042322160U;
						num69 = (num75 >> 4) | (num76 << 4);
						num70 = 908656414U ^ num71 ^ num71;
						if (num72 == 0U)
						{
							num72 -= 1U;
						}
						uint num77 = num71 / num72 + num72;
						num72 = (num71 - num71) * num77 + num71;
						num74 ^= num74 >> 6;
						num74 += num69;
						num74 ^= num74 << 1;
						num74 += num70;
						num74 ^= num74 >> 11;
						num74 += num72;
						num74 = (((num74 << 21) - num71) ^ num69) - num74;
						num41 = num68 + (uint)num74;
						num2 = 144;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 224;
							continue;
						}
						continue;
					}
					case 522:
						goto IL_29C1;
					case 523:
						num13 = 176 - 58;
						num2 = 296;
						continue;
					case 524:
						goto IL_4680;
					case 525:
						array13[11] = 108;
						num2 = 676;
						continue;
					case 526:
						array13[9] = 100;
						num2 = 355;
						continue;
					case 527:
						num13 = 250 - 83;
						num2 = 116;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 202;
							continue;
						}
						continue;
					case 528:
						array[28] = (byte)num4;
						num2 = 612;
						continue;
					case 529:
						num6 = 219 - 73;
						num2 = 535;
						continue;
					case 530:
						goto IL_5AAC;
					case 531:
						num59 = 0;
						num2 = 755;
						continue;
					case 532:
						goto IL_1F94;
					case 533:
						goto IL_3412;
					case 534:
						goto IL_12D8;
					case 535:
						array[31] = (byte)num6;
						num2 = 127;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 541;
							continue;
						}
						continue;
					case 536:
						goto IL_7934;
					case 537:
						goto IL_23CD;
					case 538:
						num4 = 60 + 79;
						num2 = 15;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 75;
							continue;
						}
						continue;
					case 539:
						array4[15] = 246 - 82;
						num2 = 327;
						continue;
					case 540:
						array[12] = (byte)num6;
						num2 = 504;
						continue;
					case 541:
						array[31] = 96 + 12;
						num2 = 70;
						continue;
					case 542:
						array[20] = (byte)num4;
						num2 = 558;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 692;
							continue;
						}
						continue;
					case 543:
						num13 = 102 + 81;
						num2 = 501;
						continue;
					case 544:
						num13 = 72 + 91;
						num2 = 231;
						continue;
					case 545:
						goto IL_70DC;
					case 546:
						goto IL_6167;
					case 547:
						goto IL_144B;
					case 548:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0095\u008D\u008F\u009A\u0098\u008C\u009E\u0094\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0088\u0088\u009C\u009A\u0098\u009D\u0094\u009A\u0091);
						num2 = 193;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 35;
							continue;
						}
						continue;
					case 549:
						array11[12] = 66;
						num2 = 449;
						continue;
					case 550:
						goto IL_3F56;
					case 551:
						goto IL_0E36;
					case 552:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008E\u0095\u0093\u009D\u0097\u0092\u0090\u0087\u0088(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u), 0L);
						num2 = 424;
						continue;
					case 553:
						num4 = 138 - 18;
						num2 = 198;
						continue;
					case 554:
						num6 = 123 - 35;
						num2 = 857;
						continue;
					case 555:
						num37 = num32;
						num2 = 2;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 5;
							continue;
						}
						continue;
					case 556:
						goto IL_59B5;
					case 557:
						num13 = 223 - 74;
						num2 = 567;
						continue;
					case 558:
						num13 = 70 + 20;
						num2 = 127;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 143;
							continue;
						}
						continue;
					case 559:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() == 4)
						{
							goto Block_88;
						}
						goto IL_5578;
					case 560:
						goto IL_2F00;
					case 561:
						goto IL_499A;
					case 562:
						array[5] = (byte)num6;
						num2 = 729;
						continue;
					case 563:
						goto IL_680A;
					case 564:
						array4[12] = 133 - 44;
						num2 = 271;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 49;
							continue;
						}
						continue;
					case 565:
						goto IL_324D;
					case 566:
						array[17] = (byte)num4;
						num2 = 443;
						continue;
					case 567:
						array4[13] = (byte)num13;
						num2 = 728;
						continue;
					case 568:
						array[8] = (byte)num4;
						num2 = 812;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 697;
							continue;
						}
						continue;
					case 569:
						goto IL_26F9;
					case 570:
						array[16] = (byte)num4;
						num2 = 304;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 776;
							continue;
						}
						continue;
					case 571:
						goto IL_2EDF;
					case 572:
						goto IL_2843;
					case 573:
						array[22] = (byte)num4;
						num2 = 319;
						continue;
					case 574:
						array[19] = (byte)num6;
						num2 = 613;
						continue;
					case 575:
						array[27] = (byte)num6;
						num2 = 283;
						continue;
					case 576:
						goto IL_678D;
					case 577:
						array4[8] = 65 + 91;
						num2 = 4;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 255;
							continue;
						}
						continue;
					case 578:
						goto IL_4008;
					case 579:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u009D\u008D\u0092\u009D\u009B\u0089\u008B\u0097\u0087();
						num2 = 360;
						continue;
					case 580:
						goto IL_5E56;
					case 581:
						goto IL_5F1E;
					case 582:
						array13 = new byte[12];
						num2 = 120;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 50;
							continue;
						}
						continue;
					case 583:
						num4 = 42 + 74;
						num2 = 314;
						continue;
					case 584:
						goto IL_2F00;
					case 585:
						array[17] = (byte)num4;
						num2 = 344;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 662;
							continue;
						}
						continue;
					case 586:
						array4[9] = (byte)num13;
						num2 = 752;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 182;
							continue;
						}
						continue;
					case 587:
						goto IL_0F37;
					case 588:
						num4 = 106 + 60;
						num2 = 53;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 192;
							continue;
						}
						continue;
					case 589:
						array4[8] = (byte)num13;
						num2 = 577;
						continue;
					case 590:
						goto IL_1332;
					case 591:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr6, 4, 4, ref num59) != 0)
						{
							num2 = 168;
							continue;
						}
						goto IL_755C;
					case 592:
						array[0] = 101 + 53;
						num2 = 710;
						continue;
					case 593:
						list.AddRange(array25);
						num2 = 784;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 453;
							continue;
						}
						continue;
					case 594:
						goto IL_2D78;
					case 595:
						num32 = num14 + 16L;
						num2 = 555;
						continue;
					case 596:
						array19[num52 + 3] = (byte)((num53 & 4278190080U) >> 24);
						num2 = 672;
						continue;
					case 597:
						num13 = 92 + 79;
						num2 = 349;
						continue;
					case 598:
						array13[1] = 108;
						num2 = 116;
						continue;
					case 599:
						if (array3 == null)
						{
							goto IL_6F55;
						}
						num2 = 29;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 56;
							continue;
						}
						continue;
					case 600:
					{
						byte[] array26 = new byte[32];
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u0094\u0094\u0089\u0090\u009B\u0097\u0092\u009E\u0092(array26, fieldof(<PrivateImplementationDetails>{1ADEF82B-9094-4B36-BB85-C14C09991B41}.29DBB090358A524F5AF78560AEE071FCBAF72B250C1471AE3EE4AC1F629F49C0).FieldHandle);
						List<byte> list2 = new List<byte>(array26);
						byte[] array27 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097.ToInt64());
						byte[] array28 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(intPtr12.ToInt64());
						byte[] array29 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(num9);
						list2.AddRange(array27);
						list2.AddRange(array28);
						list2.AddRange(array29);
						array12 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0092\u0091\u0086\u008E\u008A\u008B\u008B\u008C\u0091(list2);
						num2 = 195;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 98;
							continue;
						}
						continue;
					}
					case 601:
						array[5] = (byte)num6;
						num2 = 859;
						continue;
					case 602:
						num42 = (uint)(((int)array7[(int)(num78 + 3U)] << 24) | ((int)array7[(int)(num78 + 2U)] << 16) | ((int)array7[(int)(num78 + 1U)] << 8) | (int)array7[(int)num78]);
						num2 = 837;
						continue;
					case 603:
						array[15] = 29 + 42;
						num2 = 275;
						continue;
					case 604:
						goto IL_335F;
					case 605:
						array[29] = (byte)num6;
						num2 = 492;
						continue;
					case 606:
						goto IL_5B27;
					case 607:
						goto IL_40D6;
					case 608:
						num6 = 172 - 57;
						num2 = 574;
						continue;
					case 609:
						goto IL_4604;
					case 610:
						if (!flag6)
						{
							goto IL_2C5C;
						}
						num2 = 600;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 286;
							continue;
						}
						continue;
					case 611:
						goto IL_3596;
					case 612:
						goto IL_648C;
					case 613:
						num4 = 205 - 68;
						num2 = 521;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 866;
							continue;
						}
						continue;
					case 614:
						goto IL_5B6F;
					case 615:
						num4 = 154 - 51;
						num2 = 416;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 79;
							continue;
						}
						continue;
					case 616:
						num6 = 226 - 75;
						num2 = 389;
						continue;
					case 617:
						goto IL_569C;
					case 618:
						num6 = 19 + 2;
						num2 = 185;
						continue;
					case 619:
						array[14] = (byte)num6;
						num2 = 201;
						continue;
					case 620:
						goto IL_3BF1;
					case 621:
					{
						IntPtr intPtr11 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0099\u009C\u008F\u0090\u0090\u009A\u0094\u009E\u0098(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u009E\u0092\u0093\u009A\u009C\u0087\u0090\u008B\u008C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0086\u0093\u008D\u0098\u008D\u009C\u008B\u0089\u009A(), array13));
						num2 = 228;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 252;
							continue;
						}
						continue;
					}
					case 622:
					{
						MemoryStream memoryStream2;
						byte[] array16;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(memoryStream2, array16, 0, array16.Length);
						num2 = 303;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 339;
							continue;
						}
						continue;
					}
					case 623:
						array[6] = 110 + 40;
						num2 = 352;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 303;
							continue;
						}
						continue;
					case 624:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u009B\u008F\u009A\u0097\u0090\u009A\u0092\u009C\u0091(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0091\u008F\u0089\u0092\u008E\u0089\u0092\u008C\u0091("System.Reflection.ReflectionContext", false), null))
						{
							goto IL_4117;
						}
						num2 = 770;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 745;
							continue;
						}
						continue;
					case 625:
					{
						int num79;
						byte[] array16 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008A\u008E\u009E\u008F\u0098\u0086\u008E\u0099(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u, num79);
						num2 = 230;
						continue;
					}
					case 626:
						array4[13] = (byte)num13;
						num2 = 142;
						continue;
					case 627:
						if (num16 > 0)
						{
							num2 = 708;
							continue;
						}
						goto IL_2F2A;
					case 628:
						array[6] = 81 + 123;
						num2 = 623;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 174;
							continue;
						}
						continue;
					case 629:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 406;
						continue;
					case 630:
						array13[8] = 108;
						num2 = 450;
						continue;
					case 631:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0098\u009B\u009E\u0091\u009B\u0086\u0090\u0092\u009E(array10, 0, array11, 30, 8);
						num2 = 697;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 218;
							continue;
						}
						continue;
					case 632:
						num80 = 0;
						num2 = 421;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 793;
							continue;
						}
						continue;
					case 633:
						goto IL_30DF;
					case 634:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0091\u008A\u0087\u0095\u009E\u008B\u0090\u008B\u0096(array23, 0, array23.Length);
						num2 = 107;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 39;
							continue;
						}
						continue;
					case 635:
						flag5 = true;
						num2 = 367;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 733;
							continue;
						}
						continue;
					case 636:
						array[29] = (byte)num6;
						num2 = 815;
						continue;
					case 637:
						goto IL_3516;
					case 638:
						goto IL_2DD1;
					case 639:
						goto IL_5A9E;
					case 640:
						array4[13] = (byte)num13;
						num2 = 557;
						continue;
					case 641:
						goto IL_3435;
					case 642:
					{
						IntPtr intPtr10;
						if (intPtr10 != intPtr)
						{
							num2 = 520;
							continue;
						}
						goto IL_31C4;
					}
					case 643:
						goto IL_74CA;
					case 644:
						array2 = array4;
						num2 = 458;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 132;
							continue;
						}
						continue;
					case 645:
						array[2] = 207 - 69;
						num2 = 13;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 17;
							continue;
						}
						continue;
					case 646:
						goto IL_5973;
					case 647:
						flag7 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0088\u008C\u0094\u008F\u009B\u0099\u0092\u0090\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0097\u009C\u008E\u008F\u0093\u008E\u009A\u009C\u008D("ANDROID"));
						goto IL_79D7;
					case 648:
						array[26] = (byte)num6;
						num2 = 614;
						continue;
					case 649:
						goto IL_40F9;
					case 650:
						num81 = 255U;
						num2 = 460;
						continue;
					case 651:
						num4 = 120 + 36;
						num2 = 528;
						continue;
					case 652:
						array[11] = (byte)num6;
						num2 = 739;
						continue;
					case 653:
						num6 = 150 - 50;
						num2 = 109;
						continue;
					case 654:
						array4[7] = (byte)num13;
						num2 = 527;
						continue;
					case 655:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C = null;
						num2 = 519;
						continue;
					case 656:
						array4[15] = (byte)num13;
						num2 = 286;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 539;
							continue;
						}
						continue;
					case 657:
						num6 = 69 + 64;
						num2 = 636;
						continue;
					case 658:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(fileStream2, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)), 0, 4);
						num2 = 732;
						continue;
					case 659:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008D\u0093\u008C\u0099\u0091\u009B\u0097\u009A\u009D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0088\u008B\u0096\u0090\u009A\u008C\u009E\u0089\u008D, a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E3.A\u0090\u0090\u0096\u009B\u0097\u009D\u0092\u009E\u0099\u0087.ToInt64(), a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E3);
						num2 = 98;
						continue;
					case 660:
						goto IL_3C0E;
					case 661:
						array4[15] = 161 - 53;
						num2 = 461;
						continue;
					case 662:
						array[17] = 47 + 12;
						num2 = 853;
						continue;
					case 663:
						array[16] = (byte)num4;
						num2 = 584;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 745;
							continue;
						}
						continue;
					case 664:
						array[20] = 85 + 120;
						num2 = 333;
						continue;
					case 665:
						array[3] = 64 + 58;
						num2 = 50;
						continue;
					case 666:
						goto IL_2257;
					case 667:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0088\u0097\u009C\u008F\u008E\u0092\u009E\u008A\u0088(fileStream2, intPtr6.ToInt64(), SeekOrigin.Begin);
						num2 = 193;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 691;
							continue;
						}
						continue;
					case 668:
						array4[2] = 74 + 102;
						num2 = 50;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 90;
							continue;
						}
						continue;
					case 669:
						list = null;
						num2 = 25;
						continue;
					case 670:
						goto IL_6151;
					case 671:
						array19[num52] = (byte)(num53 & 255U);
						num2 = 79;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 731;
							continue;
						}
						continue;
					case 672:
						goto IL_680A;
					case 673:
						array[1] = (byte)num4;
						num2 = 47;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 532;
							continue;
						}
						continue;
					case 674:
						if (num16 > 0)
						{
							num2 = 140;
							continue;
						}
						goto IL_675C;
					case 675:
						num4 = 134 + 26;
						num2 = 673;
						continue;
					case 676:
					{
						IntPtr intPtr11 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u0099\u009C\u008F\u0090\u0090\u009A\u0094\u009E\u0098(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u009E\u0092\u0093\u009A\u009C\u0087\u0090\u008B\u008C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0086\u0093\u008D\u0098\u008D\u009C\u008B\u0089\u009A(), array13));
						num2 = 45;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 11;
							continue;
						}
						continue;
					}
					case 677:
						goto IL_1E53;
					case 678:
						goto IL_694C;
					case 679:
						goto IL_4A0B;
					case 680:
						array5[5] = 116;
						num2 = 37;
						continue;
					case 681:
						array2[13] = array3[6];
						num2 = 354;
						continue;
					case 682:
						num82++;
						num2 = 206;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 91;
							continue;
						}
						continue;
					case 683:
						goto IL_4AB0;
					case 684:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
						{
							goto IL_4C5B;
						}
						num2 = 782;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 525;
							continue;
						}
						continue;
					case 685:
						num4 = 6 + 57;
						num2 = 210;
						continue;
					case 686:
						goto IL_6370;
					case 687:
						fileStream2 = null;
						num2 = 81;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 25;
							continue;
						}
						continue;
					case 688:
					{
						int num79 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 625;
						continue;
					}
					case 689:
						array[6] = (byte)num4;
						num2 = 14;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 7;
							continue;
						}
						continue;
					case 690:
						array[17] = 31 + 99;
						num2 = 330;
						continue;
					case 691:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(fileStream2, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)), 0, 4);
						num2 = 578;
						continue;
					case 692:
						num4 = 140 - 46;
						num2 = 348;
						continue;
					case 693:
					{
						long num38;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u008E\u0095\u0093\u009D\u0097\u0092\u0090\u0087\u0088(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u), num38);
						num2 = 879;
						continue;
					}
					case 694:
						array[15] = (byte)num4;
						num2 = 603;
						continue;
					case 695:
						num6 = 162 - 54;
						num2 = 233;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 107;
							continue;
						}
						continue;
					case 696:
						num6 = 167 - 55;
						num2 = 862;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 806;
							continue;
						}
						continue;
					case 697:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
						{
							num2 = 584;
							continue;
						}
						goto IL_1332;
					case 698:
						array8 = null;
						num2 = 191;
						continue;
					case 699:
						num13 = 232 - 77;
						num2 = 767;
						continue;
					case 700:
						goto IL_1DD0;
					case 701:
						num6 = 172 - 57;
						num2 = 439;
						continue;
					case 702:
						array[4] = 51 + 73;
						num2 = 551;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 438;
							continue;
						}
						continue;
					case 703:
					{
						int num34 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num32 + 12L));
						num2 = 287;
						continue;
					}
					case 704:
						goto IL_6151;
					case 705:
						goto IL_2FF5;
					case 706:
						goto IL_31B6;
					case 707:
						goto IL_363D;
					case 708:
						goto IL_301D;
					case 709:
						num3 = (uint)(((int)array23[(int)(num78 + 3U)] << 24) | ((int)array23[(int)(num78 + 2U)] << 16) | ((int)array23[(int)(num78 + 1U)] << 8) | (int)array23[(int)num78]);
						num2 = 650;
						continue;
					case 710:
						num4 = 160 - 53;
						num2 = 208;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 469;
							continue;
						}
						continue;
					case 711:
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0088\u008C\u0094\u008F\u009B\u0099\u0092\u0090\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u0090\u0099\u0099\u009B\u0098\u0093\u008B\u009C\u008A()))
						{
							num2 = 647;
							continue;
						}
						flag7 = true;
						goto IL_79D7;
					case 712:
						goto IL_4165;
					case 713:
						num83 = 0;
						num2 = 338;
						continue;
					case 714:
						num4 = 179 - 67;
						num2 = 542;
						continue;
					case 715:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0097\u0095\u0095\u0088\u0091\u008F\u0092\u008B\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).TypeHandle).Assembly) == null)
						{
							num2 = 565;
							continue;
						}
						goto IL_2257;
					case 716:
						array13[7] = 116;
						num2 = 475;
						continue;
					case 717:
						array[14] = (byte)num4;
						num2 = 797;
						continue;
					case 718:
						array[8] = 90 + 94;
						num2 = 144;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 293;
							continue;
						}
						continue;
					case 719:
						num84 = 0;
						num2 = 16;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 878;
							continue;
						}
						continue;
					case 720:
						goto IL_31C4;
					case 721:
						goto IL_30DF;
					case 722:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr13, 4, 4, ref num59) != 0)
						{
							goto IL_23A5;
						}
						num2 = 336;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 0;
							continue;
						}
						continue;
					case 723:
						array[11] = 112 - 110;
						num2 = 615;
						continue;
					case 724:
						goto IL_300E;
					case 725:
						goto IL_5C0C;
					case 726:
						array4[15] = 31 + 30;
						num2 = 247;
						continue;
					case 727:
						goto IL_3F14;
					case 728:
						num13 = 120 - 22;
						num2 = 368;
						continue;
					case 729:
						num4 = 246 - 82;
						num2 = 397;
						continue;
					case 730:
						num6 = 36 + 110;
						num2 = 58;
						continue;
					case 731:
						array19[num52 + 1] = (byte)((num53 & 65280U) >> 8);
						num2 = 228;
						continue;
					case 732:
						goto IL_694C;
					case 733:
						goto IL_217E;
					case 734:
						goto IL_13E6;
					case 735:
						goto IL_2E8F;
					case 736:
						goto IL_6CB6;
					case 737:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u008D\u0091\u0087\u0087\u008A\u0086\u0087\u0093 = true;
						num2 = 808;
						continue;
					case 738:
						num42 = 0U;
						num2 = 825;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 73;
							continue;
						}
						continue;
					case 739:
						num4 = 126 - 42;
						num2 = 880;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 293;
							continue;
						}
						continue;
					case 740:
					{
						long num61;
						int num85 = (int)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008F\u009B\u0093\u0092\u009D\u0089\u0094\u0097\u009D(new IntPtr(num31 + num61));
						num14 = 0L;
						if (num85 == 523)
						{
							num2 = 40;
							continue;
						}
						goto IL_4902;
					}
					case 741:
						goto IL_6437;
					case 742:
						goto IL_33DE;
					case 743:
						array13[6] = 105;
						num2 = 716;
						continue;
					case 744:
						array4[0] = (byte)num13;
						num2 = 311;
						continue;
					case 745:
						num6 = 77 + 112;
						num2 = 347;
						continue;
					case 746:
						goto IL_2650;
					case 747:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u009D\u008D\u0092\u009D\u009B\u0089\u008B\u0097\u0087();
						num2 = 737;
						continue;
					case 748:
						goto IL_4975;
					case 749:
					{
						MemoryStream memoryStream2;
						array18 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0094\u0097\u0098\u0089\u0099\u0090\u009E\u0099\u0091(memoryStream2);
						num2 = 457;
						continue;
					}
					case 750:
						array[1] = 148 - 49;
						num2 = 170;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 675;
							continue;
						}
						continue;
					case 751:
						array[20] = 205 - 68;
						num2 = 664;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 434;
							continue;
						}
						continue;
					case 752:
						num13 = 133 - 44;
						num2 = 332;
						continue;
					case 753:
						array[5] = 154 - 51;
						num2 = 12;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 49;
							continue;
						}
						continue;
					case 754:
						goto IL_42A9;
					case 755:
					{
						bool flag4;
						if (flag4)
						{
							goto IL_70F7;
						}
						num2 = 392;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 99;
							continue;
						}
						continue;
					}
					case 756:
						goto IL_5E1D;
					case 757:
						array2[9] = array3[4];
						num2 = 61;
						continue;
					case 758:
						array[0] = 90 + 77;
						num2 = 685;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 1;
							continue;
						}
						continue;
					case 759:
						return;
					case 760:
						if (num29 == 4)
						{
							num2 = 507;
							continue;
						}
						goto IL_5E1D;
					case 761:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
						{
							num2 = 263;
							continue;
						}
						goto IL_16FF;
					case 762:
						array4[3] = (byte)num13;
						num2 = 607;
						continue;
					case 763:
						goto IL_7947;
					case 764:
						a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E2.A\u0090\u0090\u0096\u009B\u0097\u009D\u0092\u009E\u0099\u0087 = new IntPtr(0);
						num2 = 146;
						continue;
					case 765:
						if (array8.Length == 0)
						{
							goto Block_30;
						}
						goto IL_6CA1;
					case 766:
						goto IL_675C;
					case 767:
						array4[11] = (byte)num13;
						num2 = 791;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 829;
							continue;
						}
						continue;
					case 768:
						goto IL_3941;
					case 769:
						num13 = 106 + 36;
						num2 = 361;
						continue;
					case 770:
						goto IL_3E46;
					case 771:
						goto IL_4902;
					case 772:
						array4[6] = 236 - 78;
						num2 = 836;
						continue;
					case 773:
						flag = false;
						num2 = 719;
						continue;
					case 774:
						num13 = 106 + 95;
						num2 = 761;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 777;
							continue;
						}
						continue;
					case 775:
						goto IL_4117;
					case 776:
						num4 = 242 - 80;
						num2 = 250;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 334;
							continue;
						}
						continue;
					case 777:
						array4[10] = (byte)num13;
						num2 = 363;
						continue;
					case 778:
						goto IL_15A0;
					case 779:
						goto IL_7934;
					case 780:
						array4[0] = (byte)num13;
						num2 = 422;
						continue;
					case 781:
						goto IL_3F3F;
					case 782:
						goto IL_5B27;
					case 783:
						goto IL_300E;
					case 784:
						list.AddRange(array30);
						num2 = 126;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 177;
							continue;
						}
						continue;
					case 785:
						array4[0] = (byte)num13;
						num2 = 544;
						continue;
					case 786:
					{
						IntPtr intPtr7;
						if (intPtr15 != intPtr7)
						{
							num2 = 484;
							continue;
						}
						goto IL_6667;
					}
					case 787:
						array13[3] = 106;
						num2 = 463;
						continue;
					case 788:
						num29 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 756;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 541;
							continue;
						}
						continue;
					case 789:
						array12 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0092\u0091\u0086\u008E\u008A\u008B\u008B\u008C\u0091(list);
						num2 = 106;
						continue;
					case 790:
						array[29] = (byte)num6;
						num2 = 61;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 657;
							continue;
						}
						continue;
					case 791:
						goto IL_2697;
					case 792:
						array[10] = (byte)num6;
						num2 = 350;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 388;
							continue;
						}
						continue;
					case 793:
						goto IL_4419;
					case 794:
					{
						byte[] array17;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0098\u009B\u009E\u0091\u009B\u0086\u0090\u0092\u009E(array17, 0, array11, 16, 4);
						num2 = 57;
						continue;
					}
					case 795:
						num13 = 126 + 4;
						num2 = 281;
						continue;
					case 796:
						array[31] = 166 - 55;
						num2 = 529;
						continue;
					case 797:
						num6 = 10 - 2;
						num2 = 267;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 619;
							continue;
						}
						continue;
					case 798:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
						{
							goto IL_1422;
						}
						num2 = 638;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 624;
							continue;
						}
						continue;
					case 799:
						array[3] = (byte)num6;
						num2 = 16;
						continue;
					case 800:
						goto IL_296A;
					case 801:
						goto IL_6232;
					case 802:
						goto IL_5749;
					case 803:
						num13 = 99 + 94;
						num2 = 170;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 113;
							continue;
						}
						continue;
					case 804:
						goto IL_1630;
					case 805:
						num30 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
						num2 = 788;
						continue;
					case 806:
						array[21] = 86 - 24;
						num2 = 846;
						continue;
					case 807:
						num51 = array7.Length / 4;
						num2 = 153;
						continue;
					case 808:
						return;
					case 809:
						if (flag3)
						{
							num2 = 572;
							continue;
						}
						goto IL_32C5;
					case 810:
					{
						MemoryStream memoryStream2;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0092\u0096\u0088\u008C\u0096\u008A\u0092\u0095\u0092(memoryStream2, 42);
						num2 = 221;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 831;
							continue;
						}
						continue;
					}
					case 811:
						goto IL_4373;
					case 812:
						num4 = 109 - 83;
						num2 = 828;
						continue;
					case 813:
						num13 = 38 + 122;
						num2 = 205;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 746;
							continue;
						}
						continue;
					case 814:
						array[3] = (byte)num4;
						num2 = 665;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 495;
							continue;
						}
						continue;
					case 815:
						num6 = 65 + 111;
						num2 = 605;
						continue;
					case 816:
						num83++;
						num2 = 31;
						continue;
					case 817:
						num6 = 68 + 49;
						num2 = 799;
						continue;
					case 818:
					{
						string text;
						IntPtr intPtr11;
						intPtr5 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0090\u0091\u008E\u0092\u008C\u008F\u0090\u0090\u008D((A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u009A\u008A\u009B\u0092\u0095\u0097\u0090\u0091\u009E)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u009E\u0091\u009C\u0090\u0099\u008C\u0094\u009E(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0086\u0095\u0096\u009A\u0089\u0097\u009E\u0088\u0089(intPtr11, text), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u009A\u008A\u009B\u0092\u0095\u0097\u0090\u0091\u009E).TypeHandle)));
						num2 = 47;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 203;
							continue;
						}
						continue;
					}
					case 819:
						goto IL_5239;
					case 820:
						if (flag6)
						{
							goto IL_2843;
						}
						num2 = 324;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 809;
							continue;
						}
						continue;
					case 821:
						array[25] = 150 - 124;
						num2 = 125;
						continue;
					case 822:
						goto IL_6437;
					case 823:
					{
						IntPtr intPtr10 = intPtr9;
						num2 = 218;
						continue;
					}
					case 824:
						num13 = 0 + 19;
						num2 = 437;
						continue;
					case 825:
						num67 = 0;
						num2 = 256;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 253;
							continue;
						}
						continue;
					case 826:
						array4 = new byte[16];
						num2 = 768;
						continue;
					case 827:
						array24 = null;
						num2 = 441;
						continue;
					case 828:
						array[8] = (byte)num4;
						num2 = 281;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 483;
							continue;
						}
						continue;
					case 829:
						num13 = 142 - 47;
						num2 = 300;
						if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 298;
							continue;
						}
						continue;
					case 830:
						goto IL_2617;
					case 831:
						goto IL_1E33;
					case 832:
						num13 = 132 + 2;
						num2 = 343;
						continue;
					case 833:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u0090\u009E\u008F\u0088\u009B\u0094\u0092\u0095\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008B\u0086\u0089\u008B\u0089\u009C\u008E\u0086\u0094(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0091\u0089\u0093\u0097\u008E\u0092\u009C\u008A\u009C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(byte).TypeHandle).Assembly))) >= 6)
						{
							goto Block_270;
						}
						break;
					case 834:
						goto IL_31B6;
					case 835:
						goto IL_337A;
					case 836:
						array4[6] = 229 - 76;
						num2 = 41;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
						{
							num2 = 273;
							continue;
						}
						continue;
					case 837:
						goto IL_1DD0;
					case 838:
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E = default(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E);
						num2 = 400;
						continue;
					}
					case 839:
						goto IL_1410;
					case 840:
						goto IL_66DE;
					case 841:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0091\u008A\u0087\u0095\u009E\u008B\u0090\u008B\u0096(array3, 0, array3.Length);
						num2 = 115;
						continue;
					case 842:
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() == 4)
						{
							num2 = 624;
							continue;
						}
						goto IL_3E46;
					case 843:
						array[25] = (byte)num4;
						num2 = 821;
						continue;
					case 844:
						goto IL_718B;
					case 845:
						num4 = 31 + 6;
						num2 = 239;
						continue;
					case 846:
						num4 = 252 - 84;
						num2 = 254;
						continue;
					case 847:
						num81 <<= 8;
						num2 = 391;
						continue;
					case 848:
					{
						byte[] array17 = null;
						num2 = 419;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 827;
							continue;
						}
						continue;
					}
					case 849:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num14 + 4L));
						num2 = 111;
						continue;
					case 850:
					{
						byte[] array17;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0098\u009B\u009E\u0091\u009B\u0086\u0090\u0092\u009E(array17, 0, array11, 18, 8);
						num2 = 631;
						continue;
					}
					case 851:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr8, num65 * 4, num59, ref num59);
						num2 = 637;
						continue;
					case 852:
						goto IL_3A13;
					case 853:
						array[17] = 95 + 78;
						num2 = 616;
						continue;
					case 854:
						array[4] = (byte)num6;
						num2 = 4;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 10;
							continue;
						}
						continue;
					case 855:
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E;
						long num54;
						a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E.A\u0090\u0090\u0096\u009B\u0097\u009D\u0092\u009E\u0099\u0087 = new IntPtr(num54);
						num2 = 6;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
						{
							num2 = 112;
							continue;
						}
						continue;
					}
					case 856:
						goto IL_28A7;
					case 857:
						array[9] = (byte)num6;
						num2 = 505;
						continue;
					case 858:
						goto IL_29C1;
					case 859:
						num4 = 180 - 60;
						num2 = 689;
						continue;
					case 860:
						goto IL_5376;
					case 861:
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E;
						array21[num86] = a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E;
						num2 = 622;
						continue;
					}
					case 862:
						array[12] = (byte)num6;
						num2 = 393;
						if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
						{
							num2 = 224;
							continue;
						}
						continue;
					case 863:
						num4 = 108 + 23;
						num2 = 717;
						continue;
					case 864:
						goto IL_1422;
					case 865:
						num41 = 0U;
						num2 = 3;
						continue;
					case 866:
						array[19] = (byte)num4;
						num2 = 472;
						continue;
					case 867:
						array4[3] = 138 - 46;
						num2 = 222;
						continue;
					case 868:
						num6 = 3 + 50;
						num2 = 102;
						continue;
					case 869:
						num13 = 60 + 74;
						num2 = 376;
						continue;
					case 870:
						goto IL_20AE;
					case 871:
						array10 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(intPtr12.ToInt64());
						num2 = 114;
						continue;
					case 872:
					{
						MemoryStream memoryStream2;
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008E\u008B\u0095\u009E\u009A\u0088\u0092\u008E\u008C(memoryStream2);
						num2 = 749;
						continue;
					}
					case 873:
						array[31] = (byte)num4;
						num2 = 269;
						continue;
					case 874:
						array13[3] = 111;
						num2 = 63;
						continue;
					case 875:
						goto IL_2BA3;
					case 876:
						goto IL_2EB4;
					case 877:
						goto IL_45AA;
					case 878:
						goto IL_7783;
					case 879:
						num31 = array22[num80].ToInt64();
						num2 = 498;
						continue;
					case 880:
						array[11] = (byte)num4;
						num2 = 723;
						continue;
					default:
						goto IL_77D4;
					}
					IL_0E16:
					a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0093\u0091\u0090\u0091\u009B\u0095\u009E\u009A\u0093(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u009D\u0097\u0095\u0098\u0097\u0090\u0087\u0088(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0097\u009B\u0098\u008E\u008A\u008A\u009E\u008C\u0093, "\u00899\u0098bg\u009f\u008djg\u009fjvum\u009eg\u0094\u0092.r\u0088y\u00902b\u008e\u009egf\u0093\u008atui\u00889r"));
					num2 = 552;
					continue;
					IL_3E46:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() == 4)
					{
						num2 = 833;
						continue;
					}
					goto IL_0E16;
					IL_1061:
					num49++;
					num2 = 605;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
					{
						num2 = 741;
						continue;
					}
					continue;
					IL_1081:
					num39 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num32 + 8L));
					num2 = 49;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 196;
						continue;
					}
					continue;
					IL_5D1D:
					short num87;
					if (num64 >= (int)num87)
					{
						num2 = 576;
						continue;
					}
					goto IL_1081;
					IL_1156:
					fileStream = null;
					num2 = 473;
					continue;
					IL_12D8:
					intPtr14 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0087\u0095\u009E\u009C\u008F\u008A\u0090\u0088\u0086(IntPtr.Zero, new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0097\u0091\u009D\u0094\u0086\u008D\u0092\u009D\u008C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C(), array12.Length)), 3, 33, 0, IntPtr.Zero);
					num2 = 447;
					continue;
					IL_33DE:
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
					{
						num2 = 686;
						continue;
					}
					goto IL_12D8;
					IL_1332:
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
					{
						num2 = 313;
						continue;
					}
					goto IL_2F00;
					IL_139F:
					num44 = 0;
					num2 = 9;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 1;
						continue;
					}
					continue;
					IL_13E6:
					intPtr14 = IntPtr.Zero;
					num2 = 199;
					continue;
					IL_1422:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008D\u0089\u008E\u009C\u0088\u0086\u008C\u009A\u0093(fileStream);
					num2 = 194;
					continue;
					IL_144B:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0095\u008D\u008F\u009A\u0098\u008C\u009E\u0094\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C);
					num2 = 48;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 71;
						continue;
					}
					continue;
					IL_418E:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086)
					{
						goto IL_144B;
					}
					num2 = 335;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 725;
						continue;
					}
					continue;
					IL_15A0:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
					{
						goto IL_6CB6;
					}
					num2 = 641;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 206;
						continue;
					}
					continue;
					IL_3516:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0091\u008D\u0089\u0096\u0090\u0087\u009E\u0094\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)) < A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u008B\u0088\u009A\u0096\u0093\u009E\u0094\u009D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)) - 1L)
					{
						num2 = 165;
						continue;
					}
					goto IL_15A0;
					IL_45AA:
					if (flag)
					{
						num2 = 778;
						continue;
					}
					goto IL_3516;
					IL_1630:
					num87 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u008F\u009B\u0093\u0092\u009D\u0089\u0094\u0097\u009D(new IntPtr(num31 + (long)num15 + 6L));
					num2 = 251;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 595;
						continue;
					}
					continue;
					IL_1695:
					flag6 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u008B\u0095\u008C\u0092\u008B\u0095\u009E\u008C\u0094() == Architecture.Arm64;
					num2 = 136;
					continue;
					IL_16FF:
					intPtr5 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009C\u009D\u0088\u0096\u0087\u009D\u0087\u0087\u008D();
					num2 = 428;
					continue;
					IL_1D7A:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(new IntPtr(num46), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B(), 64, ref num62);
					num2 = 75;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 366;
						continue;
					}
					continue;
					IL_1DD0:
					num41 = num41;
					num2 = 521;
					continue;
					IL_1E53:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0094\u009B\u008D\u0094\u0088\u0092\u008B\u0098\u0089(intPtr5, 0);
					num2 = 13;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 11;
						continue;
					}
					continue;
					IL_1E95:
					byte[] array31 = new byte[30];
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u0094\u0094\u0089\u0090\u009B\u0097\u0092\u009E\u0092(array31, fieldof(<PrivateImplementationDetails>{1ADEF82B-9094-4B36-BB85-C14C09991B41}.D02CF2F7646D8E758A2FAD50E24334919E21747AAC02B017D71EA527A3680A5E).FieldHandle);
					array12 = array31;
					num2 = 400;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 488;
						continue;
					}
					continue;
					IL_2085:
					intPtr3 = IntPtr.Zero;
					num2 = 872;
					continue;
					IL_2437:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0091\u008D\u0089\u0096\u0090\u0087\u009E\u0094\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)) >= A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u008B\u0088\u009A\u0096\u0093\u009E\u0094\u009D(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)) - 1L)
					{
						goto IL_2085;
					}
					num2 = 450;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
					{
						num2 = 646;
						continue;
					}
					continue;
					IL_20AE:
					bool aa_u0086_u008D_u0091_u0087_u0087_u008A_u0086_u0087_u = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u008D\u0091\u0087\u0087\u008A\u0086\u0087\u0093;
					num2 = 724;
					continue;
					IL_217E:
					if (flag5)
					{
						num2 = 754;
						continue;
					}
					goto IL_63BD;
					IL_2217:
					if (num67 > 0)
					{
						num2 = 515;
						continue;
					}
					goto IL_3F14;
					IL_5239:
					if (num67 >= num16)
					{
						num2 = 700;
						continue;
					}
					goto IL_2217;
					IL_2257:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008B\u0098\u0090\u0092\u0099\u008C\u0091\u0090\u0091(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0097\u0095\u0095\u0088\u0091\u008F\u0092\u008B\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).TypeHandle).Assembly)) > 0)
					{
						num2 = 579;
						continue;
					}
					goto IL_324D;
					IL_23A5:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0096\u009E\u0088\u0094\u009B\u0091\u008B\u0096\u0097(intPtr13, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u));
					num2 = 219;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 425;
						continue;
					}
					continue;
					IL_2634:
					byte* ptr2;
					*(long*)(ptr2 + num44 * 8) ^= 1520953273L;
					num2 = 151;
					continue;
					IL_45D4:
					if (num44 >= num28)
					{
						goto Block_193;
					}
					goto IL_2634;
					IL_2684:
					if (num83 >= (int)num87)
					{
						num2 = 46;
						continue;
					}
					goto IL_40A8;
					IL_2697:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0098\u009B\u009E\u0091\u009B\u0086\u0090\u0092\u009E(array24, 0, array11, 2, 8);
					num2 = 10;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 850;
						continue;
					}
					continue;
					IL_4604:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() == 4)
					{
						num2 = 351;
						continue;
					}
					goto IL_2697;
					IL_26F9:
					IntPtr zero2 = IntPtr.Zero;
					num2 = 398;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 185;
						continue;
					}
					continue;
					IL_2843:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u008C\u008B\u0092\u0098\u0092\u0099\u0090\u0094\u009C(array11, 0, intPtr14, array11.Length);
					num2 = 43;
					continue;
					IL_28A7:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr6, 4, num59, ref num59);
					num2 = 213;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 144;
						continue;
					}
					continue;
					IL_28E3:
					fileStream2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008B\u0093\u008C\u0090\u008F\u0096\u009E\u008E\u0095("/proc/self/mem", FileMode.Open, FileAccess.ReadWrite);
					num2 = 37;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 446;
						continue;
					}
					continue;
					IL_31A2:
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
					{
						num2 = 452;
						continue;
					}
					goto IL_28E3;
					IL_2949:
					num88 = num50 % num66;
					num2 = 236;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 138;
						continue;
					}
					continue;
					IL_5E56:
					if (num50 >= num51)
					{
						num2 = 326;
						continue;
					}
					goto IL_2949;
					IL_296A:
					array23[num89] ^= array2[num89];
					num2 = 374;
					continue;
					IL_4975:
					if (num89 < array2.Length)
					{
						goto IL_296A;
					}
					num2 = 421;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 42;
						continue;
					}
					continue;
					IL_29A4:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr8, num65 * 4, 4, ref num59) == 0)
					{
						num2 = 451;
						continue;
					}
					goto IL_5A2B;
					IL_29C1:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u008C\u008B\u0092\u0098\u0092\u0099\u0090\u0094\u009C(array18, 0, intPtr3, array18.Length);
					num2 = 248;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 228;
						continue;
					}
					continue;
					IL_2BEE:
					zero = IntPtr.Zero;
					num2 = 509;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 244;
						continue;
					}
					continue;
					IL_2D78:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008A\u0088\u009A\u008E\u0092\u0093\u0091\u008E\u0091(new IntPtr(num46), intPtr14);
					num2 = 209;
					continue;
					IL_2DD1:
					num56 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u) + 1;
					num2 = 258;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 33;
						continue;
					}
					continue;
					IL_2DF6:
					intPtr16 = new IntPtr(intPtr8.ToInt64() + (long)(num90 * 4));
					num2 = 781;
					continue;
					IL_3412:
					if (num90 < num65)
					{
						goto IL_2DF6;
					}
					num2 = 877;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 318;
						continue;
					}
					continue;
					IL_2E8F:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u008F\u0096\u0099\u0094\u008D\u0094\u0090\u008D();
					num2 = 655;
					continue;
					IL_2EDF:
					intPtr15 = IntPtr.Zero;
					num2 = 212;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 52;
						continue;
					}
					continue;
					IL_2F00:
					array11[10] = 72;
					num2 = 549;
					continue;
					IL_2FB6:
					if (!flag)
					{
						num2 = 241;
						continue;
					}
					goto IL_36EF;
					IL_300E:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0092\u009D\u008D\u0092\u009D\u009B\u0089\u008B\u0097\u0087();
					num2 = 245;
					continue;
					IL_3051:
					num46 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0090\u0097\u0096\u0090\u0099\u008B\u0098\u0087(intPtr5);
					num2 = 162;
					continue;
					IL_30DF:
					if (num35 < array21.Length)
					{
						goto IL_6593;
					}
					num2 = 109;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 344;
						continue;
					}
					continue;
					IL_31B6:
					num9 = 0L;
					num2 = 559;
					continue;
					IL_31C4:
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
					{
						num2 = 365;
						continue;
					}
					goto IL_7629;
					IL_324D:
					num2 = 47;
					continue;
					IL_3C8B:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u0093\u009D\u0090\u009B\u0094\u008D\u009E\u009E\u008C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008B\u0094\u008E\u009D\u0091\u0093\u008B\u008C\u0098(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).TypeHandle).Assembly)).Length != 2)
					{
						goto IL_324D;
					}
					num2 = 318;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 715;
						continue;
					}
					continue;
					IL_32C5:
					array10 = null;
					num2 = 848;
					continue;
					IL_335F:
					array24 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097.ToInt64());
					num2 = 871;
					continue;
					IL_337A:
					if (num58 <= 0)
					{
						goto IL_5DE7;
					}
					num2 = 847;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 352;
						continue;
					}
					continue;
					IL_7934:
					if (num58 >= num16)
					{
						num2 = 563;
						continue;
					}
					goto IL_337A;
					IL_346F:
					byte[] array32 = new byte[28];
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u0094\u0094\u0089\u0090\u009B\u0097\u0092\u009E\u0092(array32, fieldof(<PrivateImplementationDetails>{1ADEF82B-9094-4B36-BB85-C14C09991B41}.8F488678F98CCEA4A7C24154A96A32E1B47266E4D4674893DE24B818CCE2B1D4).FieldHandle);
					list = new List<byte>(array32);
					num2 = 545;
					continue;
					IL_34C0:
					byte[] array33 = new byte[40];
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u0094\u0094\u0089\u0090\u009B\u0097\u0092\u009E\u0092(array33, fieldof(<PrivateImplementationDetails>{1ADEF82B-9094-4B36-BB85-C14C09991B41}.0E448EF5E5E60630BDDB19388CB6378436E3C65D03DD66DA7C6EBFF563BD857A).FieldHandle);
					array12 = array33;
					num2 = 100;
					continue;
					IL_2C5C:
					if (flag3)
					{
						goto Block_91;
					}
					goto IL_34C0;
					IL_3596:
					intPtr6 = new IntPtr(num31 + (long)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u) - (long)num48);
					num2 = 300;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 364;
						continue;
					}
					continue;
					IL_7783:
					if (num84 >= num30)
					{
						num2 = 157;
						continue;
					}
					goto IL_3596;
					IL_36EF:
					num80++;
					num2 = 181;
					continue;
					IL_70F7:
					if (num29 != 1)
					{
						goto IL_36EF;
					}
					num2 = 208;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 251;
						continue;
					}
					continue;
					IL_3BD6:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008B\u009B\u008D\u009A\u009C\u0094\u0090\u0097\u0086 = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0090\u008A\u009C\u008E\u0095\u0091\u008F\u0090\u0099\u009E);
					num2 = 253;
					continue;
					IL_3C0E:
					fileStream = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008B\u0093\u008C\u0090\u008F\u0096\u009E\u008E\u0095("/proc/self/mem", FileMode.Open, FileAccess.ReadWrite);
					num2 = 571;
					continue;
					IL_3DE6:
					intPtr9 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0091\u008E\u0097\u0093\u0090\u0090\u009D\u0097\u008B(intPtr6);
					num2 = 163;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 223;
						continue;
					}
					continue;
					IL_3F14:
					num42 |= (uint)array7[array7.Length - (1 + num67)];
					num2 = 344;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
					{
						num2 = 494;
						continue;
					}
					continue;
					IL_4008:
					num84++;
					num2 = 67;
					continue;
					IL_40A8:
					num43 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num32 + 8L));
					num2 = 420;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 703;
						continue;
					}
					continue;
					IL_4117:
					enumerator = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008A\u0094\u0086\u008C\u0086\u0099\u0093\u0097\u0097(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0088\u0096\u008A\u0090\u0091\u0099\u0094\u008E\u0086(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u008F\u0096\u0099\u0094\u008D\u0094\u0090\u008D()));
					num2 = 48;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 28;
						continue;
					}
					continue;
					IL_4165:
					ptr2 = null;
					num2 = 322;
					continue;
					IL_4373:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099)
					{
						num2 = 410;
						continue;
					}
					goto IL_679E;
					IL_4419:
					if (num80 < array22.Length)
					{
						goto IL_7947;
					}
					num2 = 1;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 80;
						continue;
					}
					continue;
					IL_443E:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(intPtr14, new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0097\u0091\u009D\u0094\u0086\u008D\u0092\u009D\u008C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C(), array12.Length)), 5);
					num2 = 149;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 72;
						continue;
					}
					continue;
					IL_450C:
					num78 = 0U;
					num2 = 266;
					continue;
					IL_4680:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
					{
						num2 = 667;
						continue;
					}
					goto IL_363D;
					IL_4902:
					num14 = (long)(num15 + 232);
					num2 = 337;
					continue;
					IL_499A:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0086\u008D\u0091\u0087\u0087\u008A\u0086\u0087\u0093 = true;
					num2 = 169;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
					{
						num2 = 783;
						continue;
					}
					continue;
					IL_71E5:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
					{
						num2 = 371;
						continue;
					}
					goto IL_499A;
					IL_4A0B:
					intPtr12 = Marshal.GetFunctionPointerForDelegate<A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A>(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0088\u0088\u009C\u009A\u0098\u009D\u0094\u009A\u0091);
					num2 = 834;
					continue;
					IL_4C5B:
					intPtr3 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0087\u0095\u009E\u009C\u008F\u008A\u0090\u0088\u0086(IntPtr.Zero, new IntPtr(num7), 3, 33, 0, IntPtr.Zero);
					num2 = 858;
					continue;
					IL_4F25:
					array[7] = (byte)num4;
					num2 = 845;
					continue;
					IL_505D:
					num32 += 40L;
					num2 = 816;
					continue;
					IL_50F0:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008D\u0089\u008E\u009C\u0088\u0086\u008C\u009A\u0093(fileStream2);
					num2 = 481;
					continue;
					IL_3435:
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
					{
						goto Block_127;
					}
					goto IL_50F0;
					IL_51B0:
					num33 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num14));
					num2 = 849;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 302;
						continue;
					}
					continue;
					IL_5358:
					num46 = 0L;
					num2 = 68;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 52;
						continue;
					}
					continue;
					IL_54E6:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u009D\u008A\u0097\u009C\u0091\u0090\u0090\u0091\u0095(new IntPtr(num46), intPtr14);
					num2 = 128;
					continue;
					IL_679E:
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
					{
						num2 = 362;
						continue;
					}
					goto IL_54E6;
					IL_5578:
					num9 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0090\u0097\u0096\u0090\u0099\u008B\u0098\u0087(new IntPtr(num46));
					num2 = 735;
					continue;
					IL_5812:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0091\u008E\u0097\u0093\u0090\u0090\u009D\u0097\u008B(new IntPtr(num46)), new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C()), 3);
					num2 = 377;
					continue;
					IL_59B5:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0096\u009E\u0088\u0094\u009B\u0091\u008B\u0096\u0097(new IntPtr(intPtr8.ToInt64() + (long)(num82 * 4)), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u));
					num2 = 246;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 682;
						continue;
					}
					continue;
					IL_4067:
					if (num82 >= num65)
					{
						goto Block_168;
					}
					goto IL_59B5;
					IL_5A2B:
					num82 = 0;
					num2 = 137;
					continue;
					IL_5A9E:
					array11 = array12;
					num2 = 820;
					continue;
					IL_5B27:
					intPtr3 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0087\u0095\u009E\u009C\u008F\u008A\u0090\u0088\u0086(IntPtr.Zero, new IntPtr(num7), 3, 4097, 0, IntPtr.Zero);
					num2 = 522;
					continue;
					IL_5C0C:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0095\u008D\u008F\u009A\u0098\u008C\u009E\u0094\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C);
					num2 = 102;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
					{
						num2 = 118;
						continue;
					}
					continue;
					IL_5D30:
					intPtr13 = new IntPtr(num31 + (long)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u) - (long)num48);
					num2 = 722;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 36;
						continue;
					}
					continue;
					IL_6749:
					if (num27 >= num30)
					{
						num2 = 23;
						continue;
					}
					goto IL_5D30;
					IL_5DE7:
					array19[num52 + num58] = (byte)((num40 & num81) >> num60);
					num2 = 286;
					continue;
					IL_5E1D:
					num48 = 7680;
					num2 = 418;
					continue;
					IL_6151:
					num7 = array18.Length / A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C();
					num2 = 28;
					continue;
					IL_6167:
					intPtr12 = Marshal.GetFunctionPointerForDelegate<A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093>(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0099\u008B\u009B\u008D\u009A\u009C\u0094\u0090\u0097\u0086);
					num2 = 706;
					continue;
					IL_6232:
					intPtr12 = IntPtr.Zero;
					num2 = 405;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 386;
						continue;
					}
					continue;
					IL_6370:
					intPtr14 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0087\u0095\u009E\u009C\u008F\u008A\u0090\u0088\u0086(IntPtr.Zero, new IntPtr(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0097\u0091\u009D\u0094\u0086\u008D\u0092\u009D\u008C(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C(), array12.Length)), 3, 6146, -1, IntPtr.Zero);
					num2 = 639;
					continue;
					IL_63BD:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B();
					num2 = 531;
					continue;
					IL_678D:
					if (flag5)
					{
						num2 = 315;
						continue;
					}
					goto IL_63BD;
					IL_6593:
					a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E3 = array21[num35];
					num2 = 433;
					continue;
					IL_6618:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0096\u009E\u0088\u0094\u009B\u0091\u008B\u0096\u0097(intPtr16, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u));
					num2 = 678;
					continue;
					IL_6667:
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F)
					{
						goto IL_718B;
					}
					num2 = 86;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 8;
						continue;
					}
					continue;
					IL_66DE:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0088\u0088\u009C\u009A\u0098\u009D\u0094\u009A\u0091 = new A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0093\u008F\u0098\u009C\u008F\u0087\u008D\u008B\u0088\u009E);
					num2 = 801;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 287;
						continue;
					}
					continue;
					IL_675C:
					num53 = num41 ^ num42;
					num2 = 671;
					continue;
					IL_680A:
					num50++;
					num2 = 159;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 114;
						continue;
					}
					continue;
					IL_694C:
					num90++;
					num2 = 511;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 353;
						continue;
					}
					continue;
					IL_6AB5:
					intPtr3 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0094\u0097\u0091\u0096\u0095\u009A\u0094\u0091\u0094(IntPtr.Zero, (uint)array18.Length, 4096U, 64U);
					num2 = 117;
					continue;
					IL_6CA1:
					ptr2 = &array8[0];
					num2 = 305;
					continue;
					IL_6CB6:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u0088\u009A\u009C\u0090\u0090\u008B\u0092\u0099\u0091(intPtr4);
					num2 = 404;
					continue;
					IL_6F55:
					num89 = 0;
					num2 = 748;
					continue;
					IL_7087:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0088\u008B\u0096\u0090\u009A\u008C\u009E\u0089\u008D = new Hashtable(num56);
					num2 = 499;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 181;
						continue;
					}
					continue;
					IL_70DC:
					array25 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097.ToInt32());
					num2 = 124;
					continue;
					IL_718B:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0096\u009E\u0088\u0094\u009B\u0091\u008B\u0096\u0097(intPtr2, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u));
					num2 = 72;
					continue;
					IL_74CA:
					intPtr2 = new IntPtr(num31 + (long)A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u) - (long)num48);
					num2 = 255;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 342;
						continue;
					}
					continue;
					IL_6437:
					if (num49 >= num30)
					{
						goto Block_296;
					}
					goto IL_74CA;
					IL_755C:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(intPtr6, 4, 8, ref num59);
					num2 = 705;
					continue;
					IL_75BE:
					intPtr14 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0094\u0097\u0091\u0096\u0095\u009A\u0094\u0091\u0094(IntPtr.Zero, (uint)array12.Length, 4096U, 64U);
					num2 = 52;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() != null)
					{
						num2 = 6;
						continue;
					}
					continue;
					IL_7629:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0088\u0097\u009C\u008F\u008E\u0092\u009E\u008A\u0088(fileStream2, intPtr16.ToInt64(), SeekOrigin.Begin);
					num2 = 658;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 61;
						continue;
					}
					continue;
					IL_76B5:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086 = true;
					num2 = 440;
					if (!A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 119;
						continue;
					}
					continue;
					IL_77AF:
					array2[1] = array3[0];
					num2 = 12;
					continue;
					IL_77D4:
					array[3] = (byte)num6;
					num2 = 165;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093())
					{
						num2 = 298;
						continue;
					}
					continue;
					IL_782E:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0091\u0089\u0089\u0086\u0096\u009D\u0092\u0098\u0092(intPtr4, intPtr6, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u)), 4U, out zero);
					num2 = 673;
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E() == null)
					{
						num2 = 856;
						continue;
					}
					continue;
					IL_2FF5:
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B() == 4)
					{
						goto Block_108;
					}
					goto IL_782E;
					IL_7947:
					num48 = num63;
					num2 = 693;
					continue;
					IL_79D7:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F = flag7;
					num2 = 7;
				}
				IL_0E36:
				array[4] = 221 - 73;
				num = 220;
				continue;
				IL_0EEA:
				num4 = 223 - 74;
				num = 663;
				continue;
				IL_0F26:
				num42 = 0U;
				num = 477;
				continue;
				IL_0F37:
				num4 = 249 - 83;
				num = 370;
				continue;
				IL_1184:
				num89++;
				num = 280;
				continue;
				IL_11A7:
				array4[3] = (byte)num13;
				num = 867;
				continue;
				IL_1239:
				array[2] = (byte)num4;
				num = 645;
				continue;
				IL_1255:
				array4[14] = 223 + 25;
				num = 661;
				continue;
				IL_1383:
				array = new byte[32];
				num = 758;
				continue;
				IL_13CF:
				num57 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u);
				num = 282;
				continue;
				IL_1410:
				num31 = 0L;
				num = 155;
				continue;
				IL_15DC:
				array20 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096((int)num9);
				num = 593;
				continue;
				Block_30:
				num = 712;
				continue;
				IL_1E33:
				num86 = 0;
				num = 468;
				continue;
				IL_1F94:
				num4 = 154 - 51;
				num = 335;
				continue;
				IL_21FB:
				array[23] = (byte)num6;
				num = 653;
				continue;
				IL_23CD:
				num78 = (uint)(num88 * 4);
				num = 709;
				continue;
				IL_24EF:
				a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E3.A\u0089\u0098\u009E\u0095\u008F\u0086\u008E\u0094\u008B\u008A = new IntPtr(a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E3.A\u0089\u0098\u009E\u0095\u008F\u0086\u008E\u0094\u008B\u008A.ToInt64() + intPtr3.ToInt64());
				num = 659;
				continue;
				IL_2617:
				num13 = 99 + 33;
				num = 382;
				continue;
				IL_2650:
				array4[5] = (byte)num13;
				num = 33;
				continue;
				IL_2793:
				array13[2] = 99;
				num = 874;
				continue;
				Block_88:
				num = 415;
				continue;
				IL_2BA3:
				array[24] = 170 + 14;
				num = 341;
				continue;
				IL_2C0F:
				num13 = 176 - 58;
				num = 301;
				continue;
				Block_91:
				num = 669;
				continue;
				IL_2EB4:
				array4[6] = (byte)num13;
				num = 803;
				continue;
				IL_2F2A:
				num78 = (uint)num52;
				num = 173;
				continue;
				Block_108:
				num = 178;
				continue;
				IL_301D:
				num41 += num3;
				num = 738;
				continue;
				IL_32B1:
				num52 = num50 * 4;
				num = 537;
				continue;
				Block_127:
				num = 324;
				continue;
				IL_363D:
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u0096\u009E\u0088\u0094\u009B\u0091\u008B\u0096\u0097(intPtr6, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(a_u0095_u0093_u0091_u0090_u0091_u009B_u0095_u009E_u009A_u));
				num = 401;
				continue;
				IL_385C:
				array[12] = 194 - 64;
				num = 496;
				continue;
				IL_38E2:
				array5 = new byte[6];
				num = 225;
				continue;
				IL_38F8:
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u009D\u0087\u008C\u0087\u0091\u008B\u0095\u0095\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0088\u0092\u009B\u0092\u008F\u0091\u0090\u009A\u008F(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0099\u0098\u0092\u0091\u008C\u0088\u0092\u008C\u0090(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009E\u0088\u0088\u009C\u009A\u0098\u009D\u0094\u009A\u0091)));
				num = 380;
				continue;
				IL_3941:
				num13 = 108 + 107;
				num = 860;
				continue;
				IL_3A13:
				num33 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(new IntPtr(num31 + num5 + 8L));
				num = 307;
				continue;
				IL_3AC6:
				array30 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(intPtr12.ToInt32());
				num = 476;
				continue;
				IL_3B7F:
				num4 = 81 + 39;
				num = 394;
				continue;
				IL_3BF1:
				num13 = 135 - 45;
				num = 762;
				continue;
				IL_3EAE:
				num13 = 57 + 30;
				num = 656;
				continue;
				IL_3F3F:
				intPtr = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u0091\u008E\u0097\u0093\u0090\u0090\u009D\u0097\u008B(intPtr16);
				num = 642;
				continue;
				IL_3F56:
				array4[12] = (byte)num13;
				num = 127;
				continue;
				IL_3FF7:
				num50 = 0;
				num = 580;
				continue;
				Block_168:
				num = 851;
				continue;
				IL_40D6:
				array4[3] = 89 + 13;
				num = 487;
				continue;
				IL_4142:
				array[30] = 231 - 77;
				num = 587;
				continue;
				IL_4173:
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0098\u009B\u009E\u0091\u009B\u0086\u0090\u0092\u009E(array24, 0, array11, 9, 4);
				num = 794;
				continue;
				IL_42A9:
				num32 = num37;
				num = 852;
				continue;
				IL_43A6:
				array4[5] = 82 + 48;
				num = 310;
				continue;
				Block_193:
				num = 698;
				continue;
				IL_46D8:
				num90 = 0;
				num = 533;
				continue;
				IL_40F9:
				goto IL_46D8;
				IL_4AB0:
				array4[12] = (byte)num13;
				num = 564;
				continue;
				Block_217:
				num = 591;
				continue;
				IL_4C9E:
				a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E2.A\u0089\u0098\u009E\u0095\u008F\u0086\u008E\u0094\u008B\u008A = IntPtr.Zero;
				num = 764;
				continue;
				IL_4F5C:
				array[3] = 15 + 12;
				num = 237;
				continue;
				IL_5376:
				array4[0] = (byte)num13;
				num = 215;
				continue;
				IL_5392:
				array4[15] = 19 + 75;
				num = 726;
				continue;
				IL_569C:
				flag5 = true;
				num = 383;
				continue;
				IL_5749:
				array13[5] = 106;
				num = 743;
				continue;
				IL_5973:
				num86++;
				num = 435;
				continue;
				IL_5AAC:
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009C\u009C\u009E\u009C\u0091\u009C\u0091\u008B\u009D\u0096(new IntPtr(num46), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B(), num62, ref num62);
				num = 561;
				continue;
				IL_5B6F:
				array[26] = 58 - 26;
				num = 92;
				continue;
				Block_270:
				num = 22;
				continue;
				IL_5CFA:
				array[14] = 246 - 82;
				num = 863;
				continue;
				IL_5ED1:
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(intPtr3, new IntPtr(num7), 5);
				num = 325;
				continue;
				IL_5F1E:
				flag5 = false;
				num = 514;
				continue;
				IL_5FCB:
				array[11] = 25 + 55;
				num = 497;
				continue;
				IL_6411:
				num32 += 40L;
				num = 426;
				continue;
				IL_7161:
				if (num33 < num36 + num39)
				{
					num = 110;
					continue;
				}
				goto IL_6411;
				Block_296:
				num = 798;
				continue;
				IL_648C:
				array[28] = 197 - 73;
				num = 583;
				continue;
				IL_6569:
				array21[0] = a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E2;
				num = 810;
				continue;
				IL_66CD:
				num60 = 0;
				num = 420;
				continue;
				IL_697D:
				num13 = 193 + 5;
				num = 744;
				continue;
				IL_6C06:
				array[4] = 127 + 16;
				num = 20;
				continue;
				Block_347:
				num = 594;
				continue;
				IL_706B:
				array4[2] = (byte)num13;
				num = 166;
				continue;
				IL_7760:
				array[8] = 36 + 109;
				num = 718;
			}
		}

		// Token: 0x06000378 RID: 888 RVA: 0x000390EC File Offset: 0x000372EC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u008A\u0098\u008D\u0094\u008D\u0089\u0099\u008B\u0091\u0095(IntPtr \u0020, IntPtr \u0020)
		{
			byte[] array;
			if (IntPtr.Size == 4)
			{
				array = BitConverter.GetBytes(\u0020.ToInt32());
			}
			else
			{
				array = BitConverter.GetBytes(\u0020.ToInt64());
			}
			FileStream fileStream = File.Open("/proc/self/mem", FileMode.Open, FileAccess.ReadWrite);
			fileStream.Seek(\u0020.ToInt64(), SeekOrigin.Begin);
			fileStream.Write(array, 0, array.Length);
			fileStream.Close();
		}

		// Token: 0x06000379 RID: 889 RVA: 0x00039150 File Offset: 0x00037350
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static IntPtr A\u008C\u0099\u009B\u0095\u0094\u0095\u008C\u008B\u0094\u0090(IntPtr \u0020)
		{
			return new IntPtr(\u0020.ToInt64() & (long)(~(long)(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.dGap0CoMM9() - 1)));
		}

		// Token: 0x0600037A RID: 890 RVA: 0x00039168 File Offset: 0x00037368
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static int dGap0CoMM9()
		{
			if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0087\u009E\u0092\u008E\u0087\u0092\u008B\u0086\u0095 == -2)
			{
				try
				{
					if (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088)
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0087\u009E\u0092\u008E\u0087\u0092\u008B\u0086\u0095 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u009C\u008A\u009C\u008F\u0096\u0097\u0094\u0099\u008B();
					}
					else
					{
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0087\u009E\u0092\u008E\u0087\u0092\u008B\u0086\u0095 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0086\u0099\u009C\u0086\u0092\u008E\u009E\u0090\u009E\u008E();
					}
				}
				catch
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0087\u009E\u0092\u008E\u0087\u0092\u008B\u0086\u0095 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u009E\u0090\u0097\u008B\u0094\u009B\u0090\u0094\u0099();
				}
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0087\u009E\u0092\u008E\u0087\u0092\u008B\u0086\u0095;
		}

		// Token: 0x0600037B RID: 891 RVA: 0x000391D0 File Offset: 0x000373D0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static Delegate A\u008D\u0098\u009A\u009D\u0093\u009C\u0098\u008B\u009C\u0088(IntPtr \u0020, Type \u0020)
		{
			return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[]
			{
				typeof(IntPtr),
				typeof(Type)
			}).Invoke(null, new object[] { \u0020, \u0020 });
		}

		// Token: 0x0600037C RID: 892 RVA: 0x00039230 File Offset: 0x00037430
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static uint A\u0090\u008A\u009C\u008E\u0095\u0091\u008F\u0090\u0099\u009E(IntPtr \u0020, IntPtr \u0020, ref A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 \u0020, [MarshalAs(UnmanagedType.U4)] uint \u0020, IntPtr \u0020, ref uint \u0020)
		{
			long num = \u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092.ToInt64();
			object obj = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0088\u008B\u0096\u0090\u009A\u008C\u009E\u0089\u008D[num];
			if (obj != null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E)obj;
				\u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092 = a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E.A\u0089\u0098\u009E\u0095\u008F\u0086\u008E\u0094\u008B\u008A;
				\u0020.A\u0099\u009E\u0087\u0099\u008F\u009B\u0097\u0092\u009A\u009E = a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E.A\u0091\u009C\u008C\u0096\u0095\u009A\u008C\u008B\u008E\u0097;
				uint num2 = 0U;
				if (\u0020 != 216669565U || A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u009D\u008E\u0087\u009A\u009E\u008E\u008B\u009B\u0095)
				{
					num2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C(\u0020, \u0020, ref \u0020, \u0020, \u0020, ref \u0020);
					\u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092 = IntPtr.Zero;
					\u0020.A\u0099\u009E\u0087\u0099\u008F\u009B\u0097\u0092\u009A\u009E = 0;
				}
				else
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u009D\u008E\u0087\u009A\u009E\u008E\u008B\u009B\u0095 = true;
				}
				return num2;
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C(\u0020, \u0020, ref \u0020, \u0020, \u0020, ref \u0020);
		}

		// Token: 0x0600037D RID: 893 RVA: 0x000392DC File Offset: 0x000374DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static uint A\u0093\u008F\u0098\u009C\u008F\u0087\u008D\u008B\u0088\u009E(IntPtr \u0020, IntPtr \u0020, ref A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 \u0020, [MarshalAs(UnmanagedType.U4)] uint \u0020, IntPtr \u0020, ref uint \u0020)
		{
			long num = \u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092.ToInt64();
			object obj = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0088\u0088\u008B\u0096\u0090\u009A\u008C\u009E\u0089\u008D[num];
			if (obj != null)
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E = (A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E)obj;
				\u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092 = a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E.A\u0089\u0098\u009E\u0095\u008F\u0086\u008E\u0094\u008B\u008A;
				\u0020.A\u0099\u009E\u0087\u0099\u008F\u009B\u0097\u0092\u009A\u009E = a_u0098_u009E_u0092_u009A_u0088_u0095_u0086_u0090_u0087_u009E.A\u0091\u009C\u008C\u0096\u0095\u009A\u008C\u008B\u008E\u0097;
				uint num2 = 0U;
				if (\u0020 != 216669565U || A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u009D\u008E\u0087\u009A\u009E\u008E\u008B\u009B\u0095)
				{
					num2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C(\u0020, \u0020, ref \u0020, \u0020, \u0020, ref \u0020);
					\u0020.A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092 = IntPtr.Zero;
					\u0020.A\u0099\u009E\u0087\u0099\u008F\u009B\u0097\u0092\u009A\u009E = 0;
				}
				else
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u009D\u008E\u0087\u009A\u009E\u008E\u008B\u009B\u0095 = true;
				}
				return num2;
			}
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C(\u0020, \u0020, ref \u0020, \u0020, \u0020, ref \u0020);
		}

		// Token: 0x0600037E RID: 894 RVA: 0x00039388 File Offset: 0x00037588
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u009B\u0090\u009A\u009A\u0087\u0095\u0099\u0099\u0086(object A_0)
		{
			return A_0.BaseStream;
		}

		// Token: 0x0600037F RID: 895 RVA: 0x00039394 File Offset: 0x00037594
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0096\u0095\u0095\u009A\u0090\u0089\u0097\u009E\u0093\u009B(object A_0, long A_1)
		{
			A_0.Position = A_1;
		}

		// Token: 0x06000380 RID: 896 RVA: 0x000393A4 File Offset: 0x000375A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static long AA\u008B\u009B\u009C\u0091\u008D\u009C\u0097\u008A\u0087(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x000393B0 File Offset: 0x000375B0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0094\u008E\u0086\u008C\u0093\u0090\u008F\u0094\u0099\u008A(object A_0, int A_1)
		{
			return A_0.ReadBytes(A_1);
		}

		// Token: 0x06000382 RID: 898 RVA: 0x000393C0 File Offset: 0x000375C0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u0091\u009D\u0096\u009A\u0099\u0095\u0097\u008D\u0089(object A_0)
		{
			return A_0.EntryPoint;
		}

		// Token: 0x06000383 RID: 899 RVA: 0x000393CC File Offset: 0x000375CC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008A\u0087\u0086\u0087\u0097\u0094\u008C\u0090\u0091\u0098(object A_0, object A_1)
		{
			return A_0 == A_1;
		}

		// Token: 0x06000384 RID: 900 RVA: 0x000393DC File Offset: 0x000375DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0088\u009D\u0091\u0091\u008A\u0098\u0096\u0090\u0089\u0098(object A_0)
		{
			((IDisposable)A_0).Dispose();
		}

		// Token: 0x06000385 RID: 901 RVA: 0x000393E8 File Offset: 0x000375E8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0099\u008D\u0094\u009C\u008A\u008E\u009B\u0090\u008F\u008C()
		{
			return null == null;
		}

		// Token: 0x06000386 RID: 902 RVA: 0x000393F0 File Offset: 0x000375F0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0094\u0094\u009A\u008A\u0098\u009A\u0087\u0090\u0097\u0096()
		{
			return null;
		}

		// Token: 0x06000387 RID: 903 RVA: 0x000393F4 File Offset: 0x000375F4
		static int f\u0088\u0097\u009C1f\u000D\u000A5yt\u00998s9n\u009Dh\u0087\u0095q()
		{
			return 1;
		}

		// Token: 0x06000388 RID: 904 RVA: 0x000393F8 File Offset: 0x000375F8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0094\u008B\u009C\u008C\u008D\u0087\u009A\u0094\u009C\u0098()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009B\u009B\u0092\u009B\u008C\u008E\u0095\u008B\u009D\u0090();
		}

		// Token: 0x06000389 RID: 905 RVA: 0x00039400 File Offset: 0x00037600
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static OSPlatform A\u009B\u0086\u008E\u0093\u0097\u008B\u008D\u009E\u0086\u009E()
		{
			return OSPlatform.Windows;
		}

		// Token: 0x0600038A RID: 906 RVA: 0x00039408 File Offset: 0x00037608
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009B\u0088\u008C\u0094\u008F\u009B\u0099\u0092\u0090\u0096(OSPlatform A_0)
		{
			return RuntimeInformation.IsOSPlatform(A_0);
		}

		// Token: 0x0600038B RID: 907 RVA: 0x00039414 File Offset: 0x00037614
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static OSPlatform A\u0090\u0090\u0099\u0099\u009B\u0098\u0093\u008B\u009C\u008A()
		{
			return OSPlatform.Linux;
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0003941C File Offset: 0x0003761C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static OSPlatform AA\u0097\u009C\u008E\u008F\u0093\u008E\u009A\u009C\u008D(object A_0)
		{
			return OSPlatform.Create(A_0);
		}

		// Token: 0x0600038D RID: 909 RVA: 0x00039428 File Offset: 0x00037628
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static OSPlatform A\u0092\u009A\u0094\u0090\u0088\u0093\u009C\u008B\u0093\u009C()
		{
			return OSPlatform.OSX;
		}

		// Token: 0x0600038E RID: 910 RVA: 0x00039430 File Offset: 0x00037630
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u009D\u008E\u009D\u0088\u0088\u009D\u0087\u0090\u0091\u008B()
		{
			return IntPtr.Size;
		}

		// Token: 0x0600038F RID: 911 RVA: 0x00039438 File Offset: 0x00037638
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static Type A\u009D\u0091\u008F\u0089\u0092\u008E\u0089\u0092\u008C\u0091(object A_0, bool A_1)
		{
			return Type.GetType(A_0, A_1);
		}

		// Token: 0x06000390 RID: 912 RVA: 0x00039448 File Offset: 0x00037648
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008B\u009B\u008F\u009A\u0097\u0090\u009A\u0092\u009C\u0091(Type A_0, Type A_1)
		{
			return A_0 != A_1;
		}

		// Token: 0x06000391 RID: 913 RVA: 0x00039458 File Offset: 0x00037658
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u009D\u008E\u008F\u0096\u0099\u0094\u008D\u0094\u0090\u008D()
		{
			return Process.GetCurrentProcess();
		}

		// Token: 0x06000392 RID: 914 RVA: 0x00039460 File Offset: 0x00037660
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0095\u0088\u0096\u008A\u0090\u0091\u0099\u0094\u008E\u0086(object A_0)
		{
			return A_0.Modules;
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0003946C File Offset: 0x0003766C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u008A\u0094\u0086\u008C\u0086\u0099\u0093\u0097\u0097(object A_0)
		{
			return A_0.GetEnumerator();
		}

		// Token: 0x06000394 RID: 916 RVA: 0x00039478 File Offset: 0x00037678
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u008B\u008B\u008F\u0089\u0098\u009D\u0089\u0090\u009C(object A_0)
		{
			return ((IEnumerator)A_0).Current;
		}

		// Token: 0x06000395 RID: 917 RVA: 0x00039484 File Offset: 0x00037684
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u009D\u0086\u008C\u0088\u008D\u0095\u0098\u0090\u008B\u009B(object A_0)
		{
			return A_0.ModuleName;
		}

		// Token: 0x06000396 RID: 918 RVA: 0x00039490 File Offset: 0x00037690
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0088\u008D\u0098\u0094\u009D\u0090\u0089\u008B\u009E\u008D(object A_0)
		{
			return A_0.ToLower();
		}

		// Token: 0x06000397 RID: 919 RVA: 0x0003949C File Offset: 0x0003769C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0098\u0096\u0087\u009C\u008F\u0093\u009D\u0094\u0094\u009B(object A_0, object A_1)
		{
			return A_0 == A_1;
		}

		// Token: 0x06000398 RID: 920 RVA: 0x000394AC File Offset: 0x000376AC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u008E\u0087\u0091\u008A\u008B\u0097\u0098\u0097\u008E(object A_0)
		{
			return A_0.FileVersionInfo;
		}

		// Token: 0x06000399 RID: 921 RVA: 0x000394B8 File Offset: 0x000376B8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u0095\u009E\u0088\u008D\u009B\u0098\u0096\u009E\u0093\u008B(object A_0)
		{
			return A_0.ProductMajorPart;
		}

		// Token: 0x0600039A RID: 922 RVA: 0x000394C4 File Offset: 0x000376C4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u0092\u009D\u009C\u008E\u008D\u008F\u0089\u008B\u0091\u0098(object A_0)
		{
			return A_0.ProductMinorPart;
		}

		// Token: 0x0600039B RID: 923 RVA: 0x000394D0 File Offset: 0x000376D0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u009C\u0095\u0098\u009D\u0089\u0092\u0095\u008B\u0098\u009A(object A_0)
		{
			return A_0.ProductBuildPart;
		}

		// Token: 0x0600039C RID: 924 RVA: 0x000394DC File Offset: 0x000376DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u008E\u0099\u0094\u008E\u0086\u0090\u0087\u0094\u008E\u009B(object A_0)
		{
			return A_0.ProductPrivatePart;
		}

		// Token: 0x0600039D RID: 925 RVA: 0x000394E8 File Offset: 0x000376E8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool AA\u0090\u008C\u0095\u009A\u0097\u0091\u008F\u008C\u008F(object A_0, object A_1)
		{
			return A_0 >= A_1;
		}

		// Token: 0x0600039E RID: 926 RVA: 0x000394F8 File Offset: 0x000376F8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009C\u009B\u009E\u0093\u0091\u0089\u0093\u008B\u008B\u0089(object A_0, object A_1)
		{
			return A_0 < A_1;
		}

		// Token: 0x0600039F RID: 927 RVA: 0x00039508 File Offset: 0x00037708
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009E\u0090\u0092\u009A\u0097\u0099\u0091\u008B\u0099\u009B(object A_0)
		{
			return ((IEnumerator)A_0).MoveNext();
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x00039514 File Offset: 0x00037714
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008A\u0095\u009B\u008D\u009B\u008E\u0089\u0092\u009E\u0089(object A_0)
		{
			((IDisposable)A_0).Dispose();
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x00039520 File Offset: 0x00037720
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static Type A\u009E\u009B\u008A\u008F\u0096\u009E\u009C\u0090\u0091\u0095(RuntimeTypeHandle A_0)
		{
			return Type.GetTypeFromHandle(A_0);
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x0003952C File Offset: 0x0003772C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u0091\u0089\u0093\u0097\u008E\u0092\u009C\u008A\u009C(object A_0)
		{
			return A_0.GetName();
		}

		// Token: 0x060003A3 RID: 931 RVA: 0x00039538 File Offset: 0x00037738
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u008B\u0086\u0089\u008B\u0089\u009C\u008E\u0086\u0094(object A_0)
		{
			return A_0.Version;
		}

		// Token: 0x060003A4 RID: 932 RVA: 0x00039544 File Offset: 0x00037744
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u008F\u0090\u009E\u008F\u0088\u009B\u0094\u0092\u0095\u0090(object A_0)
		{
			return A_0.Major;
		}

		// Token: 0x060003A5 RID: 933 RVA: 0x00039550 File Offset: 0x00037750
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u008F\u009D\u0097\u0095\u0098\u0097\u0090\u0087\u0088(object A_0, object A_1)
		{
			return A_0.GetManifestResourceStream(A_1);
		}

		// Token: 0x060003A6 RID: 934 RVA: 0x00039560 File Offset: 0x00037760
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0087\u0088\u009A\u009E\u0096\u009B\u0090\u009E\u009C\u008C(object A_0)
		{
			return A_0.l6OpUNpGRg();
		}

		// Token: 0x060003A7 RID: 935 RVA: 0x0003956C File Offset: 0x0003776C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0097\u008E\u0095\u0093\u009D\u0097\u0092\u0090\u0087\u0088(object A_0, long A_1)
		{
			A_0.Position = A_1;
		}

		// Token: 0x060003A8 RID: 936 RVA: 0x0003957C File Offset: 0x0003777C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static long A\u008F\u008A\u008B\u0088\u009A\u0096\u0093\u009E\u0094\u009D(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x060003A9 RID: 937 RVA: 0x00039588 File Offset: 0x00037788
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u009E\u008A\u008E\u009E\u008F\u0098\u0086\u008E\u0099(object A_0, int \u0020)
		{
			return A_0.A\u008C\u0094\u0095\u0089\u0095\u0094\u009E\u008B\u0096\u0096(\u0020);
		}

		// Token: 0x060003AA RID: 938 RVA: 0x00039598 File Offset: 0x00037798
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u009E\u008B\u008C\u009E\u0091\u008E\u008D\u0092\u0089\u0097(object A_0)
		{
			return A_0.GetPublicKeyToken();
		}

		// Token: 0x060003AB RID: 939 RVA: 0x000395A4 File Offset: 0x000377A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u009C\u0091\u008A\u0087\u0095\u009E\u008B\u0090\u008B\u0096(object A_0, int A_1, int A_2)
		{
			Array.Clear(A_0, A_1, A_2);
		}

		// Token: 0x060003AC RID: 940 RVA: 0x000395B8 File Offset: 0x000377B8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int AA\u0092\u008F\u008B\u0086\u0097\u008E\u008A\u0095\u0089(object A_0)
		{
			return A_0.A\u0091\u008F\u0092\u0093\u0098\u009A\u0095\u0092\u0097\u008F();
		}

		// Token: 0x060003AD RID: 941 RVA: 0x000395C4 File Offset: 0x000377C4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0099\u008D\u0088\u008C\u0098\u009D\u008D\u0090\u0088\u008C()
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0088\u008B\u009D\u0094\u0095\u0087\u0090\u009E\u008E();
		}

		// Token: 0x060003AE RID: 942 RVA: 0x000395CC File Offset: 0x000377CC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u009D\u0091\u0086\u009B\u0090\u008D\u009D\u0092\u0098\u008C(object A_0, CipherMode A_1)
		{
			A_0.Mode = A_1;
		}

		// Token: 0x060003AF RID: 943 RVA: 0x000395DC File Offset: 0x000377DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0094\u0097\u009B\u0089\u008E\u009A\u0090\u0092\u009C\u0096(object A_0, object A_1, object A_2)
		{
			return A_0.CreateDecryptor(A_1, A_2);
		}

		// Token: 0x060003B0 RID: 944 RVA: 0x000395F0 File Offset: 0x000377F0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0087\u008E\u008E\u008A\u008F\u008F\u009D\u008B\u0093\u0088(object A_0, object A_1, int A_2, int A_3)
		{
			A_0.Write(A_1, A_2, A_3);
		}

		// Token: 0x060003B1 RID: 945 RVA: 0x00039608 File Offset: 0x00037808
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void AA\u0086\u009E\u008A\u0097\u0093\u0097\u0087\u0091\u009D(object A_0)
		{
			A_0.FlushFinalBlock();
		}

		// Token: 0x060003B2 RID: 946 RVA: 0x00039614 File Offset: 0x00037814
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u0094\u0097\u0098\u0089\u0099\u0090\u009E\u0099\u0091(object A_0)
		{
			return A_0.ToArray();
		}

		// Token: 0x060003B3 RID: 947 RVA: 0x00039620 File Offset: 0x00037820
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void AA\u008D\u0089\u008E\u009C\u0088\u0086\u008C\u009A\u0093(object A_0)
		{
			A_0.Close();
		}

		// Token: 0x060003B4 RID: 948 RVA: 0x0003962C File Offset: 0x0003782C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008B\u0094\u0087\u0092\u0090\u0091\u0097\u008B\u0091\u008F(object A_0)
		{
			A_0.A\u0094\u0094\u0099\u0098\u008C\u009B\u009D\u0094\u0091\u0099();
		}

		// Token: 0x060003B5 RID: 949 RVA: 0x00039638 File Offset: 0x00037838
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u0099\u008E\u008B\u009D\u008E\u009E\u0087\u008F\u008E(object A_0)
		{
			return A_0.ManifestModule;
		}

		// Token: 0x060003B6 RID: 950 RVA: 0x00039644 File Offset: 0x00037844
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0089\u008E\u0095\u0093\u0099\u0097\u0089\u008B\u008C\u0091(object A_0, int A_1)
		{
			return A_0.ResolveMethod(A_1);
		}

		// Token: 0x060003B7 RID: 951 RVA: 0x00039654 File Offset: 0x00037854
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u009C\u0086\u008E\u008C\u0086\u008E\u009E\u0092\u0086\u009E(object A_0, int \u0020, int \u0020, int \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008B\u0091\u008F\u0099\u0094\u008D\u0093\u008B\u009E\u0094(A_0, \u0020, \u0020, \u0020);
		}

		// Token: 0x060003B8 RID: 952 RVA: 0x0003966C File Offset: 0x0003786C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static long A\u0086\u0091\u008D\u0089\u0096\u0090\u0087\u009E\u0094\u0096(object A_0)
		{
			return A_0.Position;
		}

		// Token: 0x060003B9 RID: 953 RVA: 0x00039678 File Offset: 0x00037878
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u008E\u008A\u0086\u009C\u008A\u008C\u0094\u0092\u0097\u009E(IntPtr A_0)
		{
			return Marshal.ReadInt32(A_0);
		}

		// Token: 0x060003BA RID: 954 RVA: 0x00039684 File Offset: 0x00037884
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static short A\u0089\u008F\u009B\u0093\u0092\u009D\u0089\u0094\u0097\u009D(IntPtr A_0)
		{
			return Marshal.ReadInt16(A_0);
		}

		// Token: 0x060003BB RID: 955 RVA: 0x00039690 File Offset: 0x00037890
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u0097\u0087\u009A\u0089\u009C\u0090\u0086\u008B\u0098\u0087(object A_0)
		{
			return A_0.Id;
		}

		// Token: 0x060003BC RID: 956 RVA: 0x0003969C File Offset: 0x0003789C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static IntPtr A\u0090\u008A\u008F\u0095\u0095\u0096\u0098\u008B\u0099\u009B(uint \u0020, int \u0020, uint \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0087\u008E\u008A\u009B\u008D\u0094\u0090\u009E\u009A\u0088(\u0020, \u0020, \u0020);
		}

		// Token: 0x060003BD RID: 957 RVA: 0x000396B0 File Offset: 0x000378B0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0096\u008B\u0093\u008C\u0090\u008F\u0096\u009E\u008E\u0095(object A_0, FileMode A_1, FileAccess A_2)
		{
			return File.Open(A_0, A_1, A_2);
		}

		// Token: 0x060003BE RID: 958 RVA: 0x000396C4 File Offset: 0x000378C4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u008A\u0094\u008E\u009A\u0086\u0097\u008D\u009E\u0086\u0096(int A_0)
		{
			return BitConverter.GetBytes(A_0);
		}

		// Token: 0x060003BF RID: 959 RVA: 0x000396D0 File Offset: 0x000378D0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static IntPtr AA\u0091\u008E\u0097\u0093\u0090\u0090\u009D\u0097\u008B(IntPtr \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008C\u0099\u009B\u0095\u0094\u0095\u008C\u008B\u0094\u0090(\u0020);
		}

		// Token: 0x060003C0 RID: 960 RVA: 0x000396DC File Offset: 0x000378DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u0096\u0095\u009B\u008B\u0090\u008D\u008C\u0094\u008C\u009C()
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.dGap0CoMM9();
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x000396E4 File Offset: 0x000378E4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u0088\u0095\u0094\u0087\u0099\u009C\u0086\u009E\u0095\u0091(IntPtr \u0020, IntPtr \u0020, int \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0096\u0087\u0086\u0088\u0094\u008B\u008C\u008B\u008D\u0098(\u0020, \u0020, \u0020);
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x000396F8 File Offset: 0x000378F8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static long A\u008B\u0088\u0097\u009C\u008F\u008E\u0092\u009E\u008A\u0088(object A_0, long A_1, SeekOrigin A_2)
		{
			return A_0.Seek(A_1, A_2);
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x0003970C File Offset: 0x0003790C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u009B\u0096\u009E\u0088\u0094\u009B\u0091\u008B\u0096\u0097(IntPtr A_0, int A_1)
		{
			Marshal.WriteInt32(A_0, A_1);
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x0003971C File Offset: 0x0003791C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u009D\u0088\u009A\u009C\u0090\u0090\u008B\u0092\u0099\u0091(IntPtr \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008E\u0092\u008C\u008B\u008D\u009E\u008E\u0092\u0096\u009E(\u0020);
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x00039728 File Offset: 0x00037928
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0092\u009D\u008D\u0092\u009D\u009B\u0089\u008B\u0097\u0087()
		{
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x00039730 File Offset: 0x00037930
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008C\u0092\u0096\u0088\u008C\u0096\u008A\u0092\u0095\u0092(object A_0, byte A_1)
		{
			A_0.WriteByte(A_1);
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x00039740 File Offset: 0x00037940
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0099\u008E\u008B\u0095\u009E\u009A\u0088\u0092\u008E\u008C(object A_0)
		{
			A_0.Flush();
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x0003974C File Offset: 0x0003794C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static IntPtr A\u0095\u0094\u0097\u0091\u0096\u0095\u009A\u0094\u0091\u0094(IntPtr \u0020, uint \u0020, uint \u0020, uint \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0097\u009D\u009A\u0088\u009C\u008B\u0095\u0092\u008C\u0091(\u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x00039764 File Offset: 0x00037964
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008A\u008C\u008B\u0092\u0098\u0092\u0099\u0090\u0094\u009C(object A_0, int A_1, IntPtr A_2, int A_3)
		{
			Marshal.Copy(A_0, A_1, A_2, A_3);
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0003977C File Offset: 0x0003797C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static IntPtr A\u0089\u0087\u0095\u009E\u009C\u008F\u008A\u0090\u0088\u0086(IntPtr \u0020, IntPtr \u0020, int \u0020, int \u0020, int \u0020, IntPtr \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0095\u0098\u0097\u009A\u008E\u008B\u0087\u0090\u0099\u0094(\u0020, \u0020, \u0020, \u0020, \u0020, \u0020);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x0003979C File Offset: 0x0003799C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void AA\u008D\u0093\u008C\u0099\u0091\u009B\u0097\u009A\u009D(object A_0, object A_1, object A_2)
		{
			A_0.Add(A_1, A_2);
		}

		// Token: 0x060003CC RID: 972 RVA: 0x000397B0 File Offset: 0x000379B0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0086\u0086\u0093\u008D\u0098\u008D\u009C\u008B\u0089\u009A()
		{
			return Encoding.UTF8;
		}

		// Token: 0x060003CD RID: 973 RVA: 0x000397B8 File Offset: 0x000379B8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u008B\u009E\u0092\u0093\u009A\u009C\u0087\u0090\u008B\u008C(object A_0, object A_1)
		{
			return A_0.GetString(A_1);
		}

		// Token: 0x060003CE RID: 974 RVA: 0x000397C8 File Offset: 0x000379C8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u0086\u009E\u0091\u009C\u0090\u0099\u008C\u0094\u009E(IntPtr \u0020, Type \u0020)
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0098\u009A\u009D\u0093\u009C\u0098\u008B\u009C\u0088(\u0020, \u0020);
		}

		// Token: 0x060003CF RID: 975 RVA: 0x000397D8 File Offset: 0x000379D8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static IntPtr A\u009B\u0090\u0091\u008E\u0092\u008C\u008F\u0090\u0090\u008D(object A_0)
		{
			return A_0();
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x000397E4 File Offset: 0x000379E4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static long A\u009A\u008E\u0090\u0097\u0096\u0090\u0099\u008B\u0098\u0087(IntPtr A_0)
		{
			return Marshal.ReadInt64(A_0);
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x000397F0 File Offset: 0x000379F0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static IntPtr A\u0091\u0094\u009B\u008D\u0094\u0088\u0092\u008B\u0098\u0089(IntPtr A_0, int A_1)
		{
			return Marshal.ReadIntPtr(A_0, A_1);
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x00039800 File Offset: 0x00037A00
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0096\u0099\u0098\u0092\u0091\u008C\u0088\u0092\u008C\u0090(object A_0)
		{
			return A_0.Method;
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x0003980C File Offset: 0x00037A0C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u009E\u0094\u0087\u0089\u0087\u009B\u0099\u0092\u0097\u009B(Type A_0, object A_1)
		{
			return Delegate.CreateDelegate(A_0, A_1);
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x0003981C File Offset: 0x00037A1C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u008E\u008B\u0094\u008E\u009D\u0091\u0093\u008B\u008C\u0098(object A_0)
		{
			return A_0.EntryPoint;
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x00039828 File Offset: 0x00037A28
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0097\u0096\u0094\u0089\u0093\u008D\u0098\u0090\u009A\u008A(object A_0, object A_1)
		{
			return A_0 != A_1;
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x00039838 File Offset: 0x00037A38
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0098\u0093\u009D\u0090\u009B\u0094\u008D\u009E\u009E\u008C(object A_0)
		{
			return A_0.GetParameters();
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x00039844 File Offset: 0x00037A44
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u009B\u0097\u0095\u0095\u0088\u0091\u008F\u0092\u008B\u0087(object A_0)
		{
			return A_0.Location;
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x00039850 File Offset: 0x00037A50
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int AA\u008B\u0098\u0090\u0092\u0099\u008C\u0091\u0090\u0091(object A_0)
		{
			return A_0.Length;
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x0003985C File Offset: 0x00037A5C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static ModuleHandle A\u009C\u0092\u008A\u0090\u0096\u008D\u009D\u0090\u009B\u009D(object A_0)
		{
			return A_0.ModuleHandle;
		}

		// Token: 0x060003DA RID: 986 RVA: 0x00039868 File Offset: 0x00037A68
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static Type AA\u008D\u008B\u0095\u0094\u0098\u009A\u008D\u009C\u008B(object A_0)
		{
			return A_0.GetType();
		}

		// Token: 0x060003DB RID: 987 RVA: 0x00039874 File Offset: 0x00037A74
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u008F\u009C\u0089\u008F\u0099\u009C\u009D\u0094\u0095\u0094(object A_0, object A_1)
		{
			return A_0.GetValue(A_1);
		}

		// Token: 0x060003DC RID: 988 RVA: 0x00039884 File Offset: 0x00037A84
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u009D\u0086\u0089\u009C\u0089\u009E\u0091\u0090\u0086\u0094(long A_0)
		{
			return BitConverter.GetBytes(A_0);
		}

		// Token: 0x060003DD RID: 989 RVA: 0x00039890 File Offset: 0x00037A90
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008D\u0095\u008D\u008F\u009A\u0098\u008C\u009E\u0094\u0087(object A_0)
		{
			RuntimeHelpers.PrepareDelegate(A_0);
		}

		// Token: 0x060003DE RID: 990 RVA: 0x0003989C File Offset: 0x00037A9C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static RuntimeMethodHandle A\u0091\u0088\u0092\u009B\u0092\u008F\u0091\u0090\u009A\u008F(object A_0)
		{
			return A_0.MethodHandle;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x000398A8 File Offset: 0x00037AA8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void AA\u009D\u0087\u008C\u0087\u0091\u008B\u0095\u0095\u0090(RuntimeMethodHandle A_0)
		{
			RuntimeHelpers.PrepareMethod(A_0);
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x000398B4 File Offset: 0x00037AB4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static Architecture A\u009E\u008B\u0095\u008C\u0092\u008B\u0095\u009E\u008C\u0094()
		{
			return RuntimeInformation.ProcessArchitecture;
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x000398BC File Offset: 0x00037ABC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0090\u0094\u0094\u0089\u0090\u009B\u0097\u0092\u009E\u0092(object A_0, RuntimeFieldHandle A_1)
		{
			RuntimeHelpers.InitializeArray(A_0, A_1);
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x000398CC File Offset: 0x00037ACC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0087\u0092\u0091\u0086\u008E\u008A\u008B\u008B\u008C\u0091(object A_0)
		{
			return A_0.ToArray();
		}

		// Token: 0x060003E3 RID: 995 RVA: 0x000398D8 File Offset: 0x00037AD8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u0088\u0097\u0091\u009D\u0094\u0086\u008D\u0092\u009D\u008C(int A_0, int A_1)
		{
			return Math.Max(A_0, A_1);
		}

		// Token: 0x060003E4 RID: 996 RVA: 0x000398E8 File Offset: 0x00037AE8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static int A\u008A\u009D\u0094\u0093\u0093\u0099\u0099\u0092\u0099\u008B(long A_0)
		{
			return Convert.ToInt32(A_0);
		}

		// Token: 0x060003E5 RID: 997 RVA: 0x000398F4 File Offset: 0x00037AF4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008C\u0098\u009B\u009E\u0091\u009B\u0086\u0090\u0092\u009E(object A_0, int A_1, object A_2, int A_3, int A_4)
		{
			Array.Copy(A_0, A_1, A_2, A_3, A_4);
		}

		// Token: 0x060003E6 RID: 998 RVA: 0x00039910 File Offset: 0x00037B10
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void AA\u008A\u0088\u009A\u008E\u0092\u0093\u0091\u008E\u0091(IntPtr A_0, IntPtr A_1)
		{
			Marshal.WriteIntPtr(A_0, A_1);
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x00039920 File Offset: 0x00037B20
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u0097\u009D\u008A\u0097\u009C\u0091\u0090\u0090\u0091\u0095(IntPtr \u0020, IntPtr \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008A\u0098\u008D\u0094\u008D\u0089\u0099\u008B\u0091\u0095(\u0020, \u0020);
		}

		// Token: 0x060003E8 RID: 1000 RVA: 0x00039930 File Offset: 0x00037B30
		internal static bool AAA\u0095\u008D\u009D\u009D\u0091\u0099\u009A\u0093()
		{
			return null == null;
		}

		// Token: 0x060003E9 RID: 1001 RVA: 0x00039938 File Offset: 0x00037B38
		internal static object AA\u009E\u008E\u009E\u008B\u008B\u0096\u009E\u008A\u008E()
		{
			return null;
		}

		// Token: 0x04000206 RID: 518
		internal static object A\u0089\u009E\u008F\u009C\u008D\u0093\u009B\u009E\u0094\u009C = null;

		// Token: 0x04000207 RID: 519
		internal static object A\u0088\u0088\u008B\u0096\u0090\u009A\u008C\u009E\u0089\u008D = new Hashtable();

		// Token: 0x04000208 RID: 520
		private static object A\u0092\u008A\u008E\u009A\u009B\u0088\u008E\u0090\u009B\u008F = null;

		// Token: 0x04000209 RID: 521
		private static bool AA\u0086\u008D\u0091\u0087\u0087\u008A\u0086\u0087\u0093 = false;

		// Token: 0x0400020A RID: 522
		private static object A\u008E\u0096\u009C\u008C\u0096\u009D\u0096\u0092\u008D\u0094 = new uint[]
		{
			3614090360U, 3905402710U, 606105819U, 3250441966U, 4118548399U, 1200080426U, 2821735955U, 4249261313U, 1770035416U, 2336552879U,
			4294925233U, 2304563134U, 1804603682U, 4254626195U, 2792965006U, 1236535329U, 4129170786U, 3225465664U, 643717713U, 3921069994U,
			3593408605U, 38016083U, 3634488961U, 3889429448U, 568446438U, 3275163606U, 4107603335U, 1163531501U, 2850285829U, 4243563512U,
			1735328473U, 2368359562U, 4294588738U, 2272392833U, 1839030562U, 4259657740U, 2763975236U, 1272893353U, 4139469664U, 3200236656U,
			681279174U, 3936430074U, 3572445317U, 76029189U, 3654602809U, 3873151461U, 530742520U, 3299628645U, 4096336452U, 1126891415U,
			2878612391U, 4237533241U, 1700485571U, 2399980690U, 4293915773U, 2240044497U, 1873313359U, 4264355552U, 2734768916U, 1309151649U,
			4149444226U, 3174756917U, 718787259U, 3951481745U
		};

		// Token: 0x0400020B RID: 523
		private static IntPtr A\u009D\u0095\u009C\u008A\u009D\u008D\u0099\u0090\u0090\u0092 = IntPtr.Zero;

		// Token: 0x0400020C RID: 524
		private static object A\u009C\u008D\u008F\u008D\u009E\u0096\u0093\u0090\u008A\u0088 = new object();

		// Token: 0x0400020D RID: 525
		private static List<string> A\u0092\u008F\u009B\u0093\u0090\u0091\u0092\u008B\u0090\u0095 = null;

		// Token: 0x0400020E RID: 526
		private static bool AA\u008E\u0089\u0090\u0090\u0096\u0095\u0097\u009B\u0088 = false;

		// Token: 0x0400020F RID: 527
		private static bool A\u008E\u0089\u0097\u009A\u0099\u0087\u009D\u0094\u0089\u0086 = false;

		// Token: 0x04000210 RID: 528
		private static object A\u008F\u0088\u0089\u008A\u0093\u0098\u009D\u0094\u0094\u009E = null;

		// Token: 0x04000211 RID: 529
		private static bool A\u0094\u008D\u009C\u009B\u0095\u0088\u009A\u008B\u008F\u0090 = false;

		// Token: 0x04000212 RID: 530
		private static object A\u0086\u0099\u0087\u0099\u0095\u009A\u0092\u0094\u0092\u009D = null;

		// Token: 0x04000213 RID: 531
		private static bool A\u0086\u009B\u0096\u0091\u009A\u008F\u008A\u0094\u009D\u008F = false;

		// Token: 0x04000214 RID: 532
		private static object A\u008B\u0093\u0096\u008A\u0088\u0095\u009E\u0090\u009D\u0086 = null;

		// Token: 0x04000215 RID: 533
		private object A\u009E\u0093\u0098\u0093\u0094\u0093\u009E\u008B\u009E\u008E;

		// Token: 0x04000216 RID: 534
		private static int A\u009D\u0092\u0099\u0097\u008E\u0093\u009C\u0092\u008D\u008E = 0;

		// Token: 0x04000217 RID: 535
		private static int A\u008D\u0087\u009E\u0092\u008E\u0087\u0092\u008B\u0086\u0095 = -2;

		// Token: 0x04000218 RID: 536
		private static object A\u009C\u0091\u0089\u0087\u009A\u0095\u009C\u008B\u0096\u0091 = null;

		// Token: 0x04000219 RID: 537
		private static bool AA\u008F\u008C\u008F\u009D\u0091\u008E\u009B\u008F\u0099 = false;

		// Token: 0x0400021A RID: 538
		private static IntPtr A\u009C\u0090\u0095\u0095\u008A\u008B\u0088\u009E\u009D\u0097 = IntPtr.Zero;

		// Token: 0x0400021B RID: 539
		private static object A\u0096\u0097\u008E\u008F\u009C\u008D\u0088\u008B\u008D\u0086 = null;

		// Token: 0x0400021C RID: 540
		internal static object A\u0099\u008B\u009B\u008D\u009A\u009C\u0094\u0090\u0097\u0086 = null;

		// Token: 0x0400021D RID: 541
		private static bool A\u009A\u008E\u0093\u0091\u0089\u008B\u0096\u008B\u0090\u008B = false;

		// Token: 0x0400021E RID: 542
		private static object A\u0098\u0087\u0096\u0098\u009D\u0089\u008D\u0090\u0086\u0089 = null;

		// Token: 0x0400021F RID: 543
		private static object A\u009D\u0097\u009B\u0098\u008E\u008A\u008A\u009E\u008C\u0093 = typeof(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089).Assembly;

		// Token: 0x04000220 RID: 544
		private static IntPtr A\u0089\u008A\u0092\u009A\u008C\u009C\u0092\u0094\u0090\u008A = IntPtr.Zero;

		// Token: 0x04000221 RID: 545
		private static object AA\u0090\u0092\u0097\u009E\u0090\u009D\u008C\u009D\u0097 = null;

		// Token: 0x04000222 RID: 546
		private object A\u008D\u0096\u0094\u008B\u0087\u0087\u0087\u009E\u0097\u0088;

		// Token: 0x04000223 RID: 547
		private static bool A\u009D\u0086\u0094\u009D\u009D\u0087\u008F\u009E\u0086\u008F = false;

		// Token: 0x04000224 RID: 548
		internal static object A\u009E\u0088\u0088\u009C\u009A\u0098\u009D\u0094\u009A\u0091 = null;

		// Token: 0x04000225 RID: 549
		private static object AA\u0096\u009A\u009A\u0098\u0089\u0088\u0098\u0086\u008C = null;

		// Token: 0x04000226 RID: 550
		private static object A\u009E\u009E\u008D\u0097\u008E\u009C\u0095\u0090\u0091\u0093 = new byte[0];

		// Token: 0x04000227 RID: 551
		private static List<int> A\u0087\u0092\u0088\u008E\u0091\u008B\u0095\u0090\u0098\u0094 = null;

		// Token: 0x04000228 RID: 552
		private static int A\u008E\u008C\u0096\u0093\u0088\u0093\u0087\u008B\u008B\u0088 = 0;

		// Token: 0x04000229 RID: 553
		private static Dictionary<int, int> A\u0089\u0086\u0093\u0091\u0096\u009C\u0092\u008B\u0087\u009E = null;

		// Token: 0x0400022A RID: 554
		private static object A\u0094\u0094\u009D\u0099\u0092\u009B\u009B\u0090\u0090\u0093 = null;

		// Token: 0x0400022B RID: 555
		private static int A\u0095\u009E\u009E\u009E\u008F\u0090\u008B\u008B\u0089\u0087 = -1;

		// Token: 0x0400022C RID: 556
		private static object AA\u0088\u0098\u009E\u009E\u0089\u008F\u008C\u008C\u008F = null;

		// Token: 0x0400022D RID: 557
		private static object A\u0086\u0099\u0086\u0088\u0091\u0098\u0099\u008B\u0098\u0099 = new object();

		// Token: 0x0400022E RID: 558
		private static bool A\u0087\u009D\u008E\u0087\u009A\u009E\u008E\u008B\u009B\u0095 = false;

		// Token: 0x0400022F RID: 559
		internal static object A\u0096\u008E\u009D\u008F\u0091\u009C\u009A\u0092\u0093\u009C = null;

		// Token: 0x04000230 RID: 560
		private static object A\u008C\u0091\u0089\u008C\u0096\u008A\u009D\u009E\u0096\u0087 = new byte[0];

		// Token: 0x0200006B RID: 107
		private class A\u0094\u0090\u009A\u009E\u008F\u009E\u0099\u0094\u008E\u009C
		{
		}

		// Token: 0x0200006C RID: 108
		internal class A\u0095\u0093\u0091\u0090\u0091\u009B\u0095\u009E\u009A\u0093
		{
			// Token: 0x060003EA RID: 1002 RVA: 0x0003993C File Offset: 0x00037B3C
			[MethodImpl(MethodImplOptions.NoInlining)]
			public A\u0095\u0093\u0091\u0090\u0091\u009B\u0095\u009E\u009A\u0093(Stream \u0020)
			{
				this.AA\u008A\u008D\u008B\u0089\u008F\u009C\u0095\u0089\u0098 = new BinaryReader(\u0020);
			}

			// Token: 0x060003EB RID: 1003 RVA: 0x00039958 File Offset: 0x00037B58
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal Stream l6OpUNpGRg()
			{
				return this.AA\u008A\u008D\u008B\u0089\u008F\u009C\u0095\u0089\u0098.BaseStream;
			}

			// Token: 0x060003EC RID: 1004 RVA: 0x0003996C File Offset: 0x00037B6C
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal byte[] A\u008C\u0094\u0095\u0089\u0095\u0094\u009E\u008B\u0096\u0096(int \u0020)
			{
				return this.AA\u008A\u008D\u008B\u0089\u008F\u009C\u0095\u0089\u0098.ReadBytes(\u0020);
			}

			// Token: 0x060003ED RID: 1005 RVA: 0x00039984 File Offset: 0x00037B84
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal int A\u008A\u0093\u0090\u009D\u009A\u0091\u0090\u008B\u0088\u0093(byte[] \u0020, int \u0020, int \u0020)
			{
				return this.AA\u008A\u008D\u008B\u0089\u008F\u009C\u0095\u0089\u0098.Read(\u0020, \u0020, \u0020);
			}

			// Token: 0x060003EE RID: 1006 RVA: 0x0003999C File Offset: 0x00037B9C
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal int A\u0091\u008F\u0092\u0093\u0098\u009A\u0095\u0092\u0097\u008F()
			{
				return this.AA\u008A\u008D\u008B\u0089\u008F\u009C\u0095\u0089\u0098.ReadInt32();
			}

			// Token: 0x060003EF RID: 1007 RVA: 0x000399B0 File Offset: 0x00037BB0
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal void A\u0094\u0094\u0099\u0098\u008C\u009B\u009D\u0094\u0091\u0099()
			{
				this.AA\u008A\u008D\u008B\u0089\u008F\u009C\u0095\u0089\u0098.Close();
			}

			// Token: 0x04000231 RID: 561
			private object AA\u008A\u008D\u008B\u0089\u008F\u009C\u0095\u0089\u0098;
		}

		// Token: 0x0200006D RID: 109
		// (Invoke) Token: 0x060003F1 RID: 1009
		private delegate void A\u008C\u0094\u0086\u009D\u008F\u0099\u008D\u0090\u0086\u008D(object o);

		// Token: 0x0200006E RID: 110
		internal class AA\u0087\u008C\u009C\u008D\u008D\u0098\u0093\u0089\u0095
		{
			// Token: 0x060003F4 RID: 1012 RVA: 0x000399C4 File Offset: 0x00037BC4
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal static string A\u0093\u0087\u008B\u0092\u0087\u008A\u009A\u0092\u0092\u0088(object \u0020, object \u0020)
			{
				byte[] bytes = Encoding.Unicode.GetBytes(\u0020);
				byte[] array = new byte[]
				{
					82, 102, 104, 110, 32, 77, 24, 34, 118, 181,
					51, 17, 18, 51, 12, 109, 10, 32, 77, 24,
					34, 158, 161, 41, 97, 28, 118, 181, 5, 25,
					1, 88
				};
				byte[] array2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0091\u0091\u008E\u0096\u009B\u0094\u009A\u0094\u009E\u0086(Encoding.Unicode.GetBytes(\u0020));
				MemoryStream memoryStream = new MemoryStream();
				SymmetricAlgorithm symmetricAlgorithm = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0089\u0088\u008B\u009D\u0094\u0095\u0087\u0090\u009E\u008E();
				symmetricAlgorithm.Key = array;
				symmetricAlgorithm.IV = array2;
				CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
				cryptoStream.Write(bytes, 0, bytes.Length);
				cryptoStream.Close();
				return Convert.ToBase64String(memoryStream.ToArray());
			}

			// Token: 0x060003F5 RID: 1013 RVA: 0x00039A48 File Offset: 0x00037C48
			[MethodImpl(MethodImplOptions.NoInlining)]
			public AA\u0087\u008C\u009C\u008D\u008D\u0098\u0093\u0089\u0095()
			{
			}
		}

		// Token: 0x0200006F RID: 111
		internal struct A\u0098\u009E\u0092\u009A\u0088\u0095\u0086\u0090\u0087\u009E
		{
			// Token: 0x04000232 RID: 562
			internal int A\u0091\u009C\u008C\u0096\u0095\u009A\u008C\u008B\u008E\u0097;

			// Token: 0x04000233 RID: 563
			internal IntPtr A\u0089\u0098\u009E\u0095\u008F\u0086\u008E\u0094\u008B\u008A;

			// Token: 0x04000234 RID: 564
			internal IntPtr A\u0090\u0090\u0096\u009B\u0097\u009D\u0092\u009E\u0099\u0087;
		}

		// Token: 0x02000070 RID: 112
		private struct A\u008D\u0089\u009A\u0091\u008C\u0097\u0096\u008B\u0088\u0088
		{
			// Token: 0x04000235 RID: 565
			public UIntPtr A\u009A\u008E\u009A\u008E\u0091\u009C\u0090\u0094\u0092\u008F;

			// Token: 0x04000236 RID: 566
			public UIntPtr A\u0088\u0090\u0097\u0089\u009C\u0098\u008D\u0092\u009A\u0089;

			// Token: 0x04000237 RID: 567
			public uint AA\u009A\u009D\u0096\u0088\u009D\u008C\u009E\u0087\u0095;

			// Token: 0x04000238 RID: 568
			public IntPtr AA\u009A\u008E\u0092\u0096\u0092\u008F\u008B\u0099\u009E;

			// Token: 0x04000239 RID: 569
			public uint A\u0086\u008B\u009C\u0098\u009C\u0096\u0096\u0094\u009E\u0095;

			// Token: 0x0400023A RID: 570
			public uint A\u008F\u0087\u0090\u008D\u0091\u008B\u009D\u008B\u008F\u0094;

			// Token: 0x0400023B RID: 571
			public uint A\u0094\u0099\u008A\u0087\u0086\u008A\u0088\u009E\u008F\u0097;
		}

		// Token: 0x02000071 RID: 113
		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		internal struct A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088
		{
			// Token: 0x0400023C RID: 572
			public IntPtr A\u0087\u009C\u0089\u0097\u008D\u009A\u0093\u0092\u009B\u0099;

			// Token: 0x0400023D RID: 573
			public IntPtr A\u0099\u0098\u008A\u0094\u009E\u008C\u0098\u0090\u009A\u0096;

			// Token: 0x0400023E RID: 574
			public IntPtr A\u0095\u0096\u0092\u0095\u0089\u009B\u009D\u009E\u009C\u0092;

			// Token: 0x0400023F RID: 575
			public int A\u0099\u009E\u0087\u0099\u008F\u009B\u0097\u0092\u009A\u009E;
		}

		// Token: 0x02000072 RID: 114
		// (Invoke) Token: 0x060003F7 RID: 1015
		[UnmanagedFunctionPointer(CallingConvention.ThisCall)]
		internal delegate uint A\u009A\u008E\u0097\u0094\u009A\u0095\u008A\u009E\u009E\u0093(IntPtr classthis, IntPtr comp, ref A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

		// Token: 0x02000073 RID: 115
		// (Invoke) Token: 0x060003FB RID: 1019
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		internal delegate uint A\u0094\u009A\u0099\u0096\u008F\u009C\u008F\u008B\u0090\u009A(IntPtr classthis, IntPtr comp, ref A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0090\u008B\u0092\u0099\u0094\u0088\u0094\u008E\u0088 info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

		// Token: 0x02000074 RID: 116
		// (Invoke) Token: 0x060003FF RID: 1023
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr A\u008C\u009A\u008A\u009B\u0092\u0095\u0097\u0090\u0091\u009E();

		// Token: 0x02000075 RID: 117
		// (Invoke) Token: 0x06000403 RID: 1027
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int AA\u009E\u009A\u0091\u0097\u008E\u0098\u0099\u008C\u008B(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);

		// Token: 0x02000076 RID: 118
		// (Invoke) Token: 0x06000407 RID: 1031
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr A\u0086\u0094\u009C\u0090\u0089\u008D\u009B\u0090\u0099\u008B(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x02000077 RID: 119
		// (Invoke) Token: 0x0600040B RID: 1035
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate UIntPtr A\u009A\u008F\u0097\u009D\u0090\u0087\u0087\u009E\u008E\u008B(UIntPtr lpAddress, out A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008D\u0089\u009A\u0091\u008C\u0097\u0096\u008B\u0088\u0088 mbi, UIntPtr dwLength);

		// Token: 0x02000078 RID: 120
		// (Invoke) Token: 0x0600040F RID: 1039
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr AA\u0093\u0097\u0091\u008B\u0086\u008C\u0095\u008F\u008E(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

		// Token: 0x02000079 RID: 121
		// (Invoke) Token: 0x06000413 RID: 1043
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int A\u008A\u0097\u0096\u009C\u008E\u0088\u008E\u008B\u008C\u0088(IntPtr hProcess, IntPtr lpBaseAddress, [In] [Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

		// Token: 0x0200007A RID: 122
		// (Invoke) Token: 0x06000417 RID: 1047
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int A\u0097\u0091\u008D\u008F\u0089\u009E\u0097\u0092\u009B\u0095(IntPtr ptr);

		// Token: 0x0200007B RID: 123
		// (Invoke) Token: 0x0600041B RID: 1051
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr A\u008C\u0095\u008D\u0086\u008E\u008A\u0091\u009E\u009E\u0094(IntPtr addr, IntPtr length, int prot, int flags, int fd, IntPtr offset);

		// Token: 0x0200007C RID: 124
		// (Invoke) Token: 0x0600041F RID: 1055
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int A\u009C\u0089\u008F\u009E\u008E\u009C\u009B\u0092\u0089\u0093(IntPtr start, IntPtr len, int mprot);

		// Token: 0x0200007D RID: 125
		[Flags]
		private enum A\u008F\u0089\u008E\u008C\u009D\u009C\u009D\u009E\u008D\u0088
		{

		}
	}
}
