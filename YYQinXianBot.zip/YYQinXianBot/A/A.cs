﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Principal;
using System.Windows.Forms;
using YYQinXianBot;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000012 RID: 18
	internal static class A\u0097\u0097\u0087\u0088\u009E\u009A\u009D\u0094\u0092\u008F
	{
		// Token: 0x0600009A RID: 154 RVA: 0x0000A56C File Offset: 0x0000876C
		[STAThread]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static void A\u009B\u0086\u0087\u008E\u009A\u0096\u0092\u0094\u0094\u0092()
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					return;
				case 2:
					goto IL_00D7;
				case 3:
					Application.Run(new AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096());
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 4:
					ApplicationConfiguration.Initialize();
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 5:
					if (!A\u0097\u0097\u0087\u0088\u009E\u009A\u009D\u0094\u0092\u008F.A\u009C\u0090\u008A\u0095\u008F\u0099\u0099\u0090\u009D\u008C())
					{
						goto IL_00D7;
					}
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				}
				break;
				IL_00D7:
				MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-252024401 ^ -696227362 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((28686127 >> 6) ^ 1032635660 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 == 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x0600009B RID: 155 RVA: 0x0000A6B4 File Offset: 0x000088B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static bool A\u009C\u0090\u008A\u0095\u008F\u0099\u0099\u0090\u009D\u008C()
		{
			bool flag;
			switch (1)
			{
			case 1:
				try
				{
					flag = new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a != 0)
					{
						num = 0;
					}
					switch (num)
					{
					}
				}
				catch
				{
					int num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f == 0)
					{
						num2 = 1;
					}
					for (;;)
					{
						switch (num2)
						{
						case 1:
							flag = false;
							num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_be5da1cd750e495490bb42f04b10e65d == 0)
							{
								num2 = 0;
								continue;
							}
							continue;
						}
						break;
					}
				}
				break;
			}
			return flag;
		}

		// Token: 0x0600009C RID: 156 RVA: 0x0000A7C8 File Offset: 0x000089C8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008B\u008C\u0094\u009C\u008B\u0086\u009E\u008B\u009C\u0093()
		{
			return A\u0097\u0097\u0087\u0088\u009E\u009A\u009D\u0094\u0092\u008F.A\u008B\u008D\u008C\u008E\u0096\u0091\u008F\u008B\u0097\u009C == null;
		}

		// Token: 0x0600009D RID: 157 RVA: 0x0000A7DC File Offset: 0x000089DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0097\u0097\u0087\u0088\u009E\u009A\u009D\u0094\u0092\u008F A\u008D\u0088\u0086\u0087\u008C\u0091\u008C\u008B\u009D\u0086()
		{
			return A\u0097\u0097\u0087\u0088\u009E\u009A\u009D\u0094\u0092\u008F.A\u008B\u008D\u008C\u008E\u0096\u0091\u008F\u008B\u0097\u009C;
		}

		// Token: 0x0600009E RID: 158 RVA: 0x0000A7EC File Offset: 0x000089EC
		static A\u0097\u0097\u0087\u0088\u009E\u009A\u009D\u0094\u0092\u008F()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000074 RID: 116
		internal static object A\u008B\u008D\u008C\u008E\u0096\u0091\u008F\u008B\u0097\u009C;
	}
}
