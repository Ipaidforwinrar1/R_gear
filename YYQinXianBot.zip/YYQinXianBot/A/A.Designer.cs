﻿namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200005D RID: 93
	public partial class A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E : global::System.Windows.Forms.Form
	{
		// Token: 0x060002D1 RID: 721 RVA: 0x00017F78 File Offset: 0x00016178
		[global::System.Runtime.CompilerServices.MethodImpl(global::System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
		protected override void Dispose(bool \u0020)
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_00C4;
				case 2:
					return;
				case 3:
					((global::System.IDisposable)this.AA\u009E\u0093\u008D\u0095\u008A\u009A\u0090\u0089\u008D).Dispose();
					num2 = 1;
					if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 4:
					goto IL_00C4;
				case 5:
					if (!\u0020)
					{
						num2 = 4;
						continue;
					}
					break;
				}
				if (this.AA\u009E\u0093\u008D\u0095\u008A\u009A\u0090\u0089\u008D != null)
				{
					num2 = 3;
					if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f == 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				}
				IL_00C4:
				base.Dispose(\u0020);
				num2 = 2;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 != 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x040001C0 RID: 448
		private object AA\u009E\u0093\u008D\u0095\u008A\u009A\u0090\u0089\u008D;
	}
}
