﻿using System;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200004A RID: 74
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098
	{
		// Token: 0x0600021A RID: 538 RVA: 0x000131A4 File Offset: 0x000113A4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u008E\u009A\u008A\u0089\u0087\u0092\u0088\u0090\u008F\u008D()
		{
			return this.A\u0096\u0094\u009D\u009C\u009D\u009E\u008F\u0094\u0096\u0088;
		}

		// Token: 0x0600021B RID: 539 RVA: 0x000131B4 File Offset: 0x000113B4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0097\u009A\u0088\u008F\u009C\u0099\u0094\u009E\u0092\u0095(bool \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0096\u0094\u009D\u009C\u009D\u009E\u008F\u0094\u0096\u0088 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x0600021C RID: 540 RVA: 0x00013214 File Offset: 0x00011414
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string AA\u008C\u008E\u008E\u0087\u0098\u0091\u0097\u0087\u0095()
		{
			return this.A\u0086\u008B\u0096\u008C\u008D\u009D\u0088\u009E\u0090\u0094;
		}

		// Token: 0x0600021D RID: 541 RVA: 0x00013224 File Offset: 0x00011424
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0096\u0097\u0097\u0093\u0099\u008B\u0089\u0090\u009A\u009E(string \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0086\u008B\u0096\u008C\u008D\u009D\u0088\u009E\u0090\u0094 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600021E RID: 542 RVA: 0x00013284 File Offset: 0x00011484
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int A\u008D\u009B\u0090\u0086\u008B\u009A\u008D\u0094\u009E\u0092()
		{
			return this.A\u0095\u0090\u0090\u008F\u008B\u009A\u0088\u009E\u0093\u0090;
		}

		// Token: 0x0600021F RID: 543 RVA: 0x00013294 File Offset: 0x00011494
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0099\u0088\u0089\u0098\u0096\u008B\u009E\u0090\u0087\u0088(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0095\u0090\u0090\u008F\u008B\u009A\u0088\u009E\u0093\u0090 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000220 RID: 544 RVA: 0x000132F4 File Offset: 0x000114F4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public double A\u009A\u008B\u009D\u008A\u0098\u009A\u0086\u0094\u009D\u009E()
		{
			return this.AA\u009B\u009D\u0094\u0097\u008E\u0090\u0086\u0087\u0095;
		}

		// Token: 0x06000221 RID: 545 RVA: 0x00013304 File Offset: 0x00011504
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0094\u009D\u0090\u008D\u009A\u0097\u0086\u0090\u0097\u0088(double \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.AA\u009B\u009D\u0094\u0097\u008E\u0090\u0086\u0087\u0095 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000222 RID: 546 RVA: 0x00013364 File Offset: 0x00011564
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int A\u009A\u0096\u0098\u008A\u0098\u0092\u0095\u0094\u0096\u008D()
		{
			return this.A\u009E\u008A\u009E\u0090\u0089\u009E\u008E\u009E\u008B\u008D;
		}

		// Token: 0x06000223 RID: 547 RVA: 0x00013374 File Offset: 0x00011574
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AA\u008B\u009A\u008A\u0098\u008D\u009C\u008D\u0089\u0087(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u009E\u008A\u009E\u0090\u0089\u009E\u008E\u009E\u008B\u008D = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000224 RID: 548 RVA: 0x000133D4 File Offset: 0x000115D4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int A\u0095\u008F\u008A\u0094\u0087\u009C\u008B\u008B\u008F\u009C()
		{
			return this.A\u008A\u009A\u0094\u008D\u0098\u008C\u008E\u0094\u0091\u009C;
		}

		// Token: 0x06000225 RID: 549 RVA: 0x000133E4 File Offset: 0x000115E4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009C\u0091\u009D\u008B\u0090\u008B\u009D\u0090\u008D\u0095(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u008A\u009A\u0094\u008D\u0098\u008C\u008E\u0094\u0091\u009C = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000226 RID: 550 RVA: 0x00013444 File Offset: 0x00011644
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int A\u009E\u0098\u0086\u008A\u0092\u008D\u008B\u0092\u0090\u009A()
		{
			return this.AA\u0097\u0098\u0088\u0099\u009B\u0090\u0097\u0092\u008C;
		}

		// Token: 0x06000227 RID: 551 RVA: 0x00013454 File Offset: 0x00011654
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008C\u0089\u0098\u0092\u0091\u0091\u009E\u0092\u0096\u009B(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.AA\u0097\u0098\u0088\u0099\u009B\u0090\u0097\u0092\u008C = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000228 RID: 552 RVA: 0x000134B4 File Offset: 0x000116B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0086\u008B\u0096\u008C\u008D\u009D\u0088\u009E\u0090\u0094 = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000229 RID: 553 RVA: 0x00013528 File Offset: 0x00011728
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0090\u0094\u0086\u0086\u008A\u0089\u008B\u0090\u0093\u0096()
		{
			return A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098.A\u0098\u009A\u009D\u008F\u008E\u0095\u009D\u0094\u008B\u009B == null;
		}

		// Token: 0x0600022A RID: 554 RVA: 0x0001353C File Offset: 0x0001173C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098 A\u0086\u009B\u0094\u008C\u0094\u008F\u0089\u0094\u009B\u008F()
		{
			return A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098.A\u0098\u009A\u009D\u008F\u008E\u0095\u009D\u0094\u008B\u009B;
		}

		// Token: 0x0600022B RID: 555 RVA: 0x0001354C File Offset: 0x0001174C
		static A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000165 RID: 357
		[CompilerGenerated]
		private bool A\u0096\u0094\u009D\u009C\u009D\u009E\u008F\u0094\u0096\u0088;

		// Token: 0x04000166 RID: 358
		[CompilerGenerated]
		private string A\u0086\u008B\u0096\u008C\u008D\u009D\u0088\u009E\u0090\u0094;

		// Token: 0x04000167 RID: 359
		[CompilerGenerated]
		private int A\u0095\u0090\u0090\u008F\u008B\u009A\u0088\u009E\u0093\u0090;

		// Token: 0x04000168 RID: 360
		[CompilerGenerated]
		private double AA\u009B\u009D\u0094\u0097\u008E\u0090\u0086\u0087\u0095;

		// Token: 0x04000169 RID: 361
		[CompilerGenerated]
		private int A\u009E\u008A\u009E\u0090\u0089\u009E\u008E\u009E\u008B\u008D;

		// Token: 0x0400016A RID: 362
		[CompilerGenerated]
		private int A\u008A\u009A\u0094\u008D\u0098\u008C\u008E\u0094\u0091\u009C;

		// Token: 0x0400016B RID: 363
		[CompilerGenerated]
		private int AA\u0097\u0098\u0088\u0099\u009B\u0090\u0097\u0092\u008C;

		// Token: 0x0400016C RID: 364
		internal static object A\u0098\u009A\u009D\u008F\u008E\u0095\u009D\u0094\u008B\u009B;
	}
}
