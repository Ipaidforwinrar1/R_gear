﻿using System;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200007F RID: 127
	internal class A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091
	{
		// Token: 0x06000427 RID: 1063 RVA: 0x0003A494 File Offset: 0x00038694
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static void A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094()
		{
		}

		// Token: 0x06000428 RID: 1064 RVA: 0x0003A4A0 File Offset: 0x000386A0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091()
		{
		}

		// Token: 0x04000246 RID: 582
		private static bool AA\u0097\u008A\u0095\u008D\u0099\u008C\u0099\u008A\u008B;
	}
}
