﻿using System;
using System.Collections.Generic;
using System.Management;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000049 RID: 73
	[NullableContext(1)]
	[Nullable(0)]
	public static class A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093
	{
		// Token: 0x06000211 RID: 529 RVA: 0x00011EC0 File Offset: 0x000100C0
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6fdef4c9fb0147c3b3aa646e625fdd4d != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				case 3:
					goto IL_007A;
				}
				A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c != 0)
				{
					num2 = 3;
				}
			}
			return;
			IL_007A:
			try
			{
				A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0098\u008C\u008B\u009B\u0099\u009D\u008A\u0095\u008B = A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0093\u0091\u0089\u0089\u009B\u0097\u0090\u008E\u008E();
				int num3 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f == 0)
				{
					num3 = 0;
				}
				switch (num3)
				{
				default:
					return;
				}
			}
			catch
			{
				int num4 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f != 0)
				{
					num4 = 1;
				}
				for (;;)
				{
					switch (num4)
					{
					case 1:
						A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0098\u008C\u008B\u009B\u0099\u009D\u008A\u0095\u008B = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1219413587 ^ -158550904 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b);
						num4 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
						{
							num4 = 0;
							continue;
						}
						continue;
					}
					break;
				}
				return;
			}
		}

		// Token: 0x06000212 RID: 530 RVA: 0x00012030 File Offset: 0x00010230
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static string AA\u0093\u0091\u0089\u0089\u009B\u0097\u0090\u008E\u008E()
		{
			string text = A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0093\u009D\u0094\u0097\u008B\u008B\u0088\u009B\u0090();
			string text2 = A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.A\u009C\u0096\u008C\u0097\u0094\u008F\u0089\u0090\u0096\u008B();
			string text3 = A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.A\u0093\u0092\u0091\u009D\u008F\u0093\u008F\u008B\u0091\u0098();
			return A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.A\u009C\u0087\u0096\u009B\u009D\u008B\u009B\u009E\u008C\u009A(text + text2 + text3);
		}

		// Token: 0x06000213 RID: 531 RVA: 0x00012068 File Offset: 0x00010268
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static string AA\u0093\u009D\u0094\u0097\u008B\u008B\u0088\u009B\u0090()
		{
			string text;
			switch (1)
			{
			case 1:
				try
				{
					ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((926982431 << 2) ^ -1517402838 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889));
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 != 0)
					{
						num = 0;
					}
					switch (num)
					{
					default:
						try
						{
							ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator();
							int num2 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 == 0)
							{
								num2 = 1;
							}
							for (;;)
							{
								switch (num2)
								{
								case 1:
									try
									{
										for (;;)
										{
											IL_01E6:
											if (enumerator.MoveNext())
											{
												goto IL_0140;
											}
											int num3 = 3;
											string text2;
											for (;;)
											{
												IL_010B:
												switch (num3)
												{
												case 1:
													goto IL_0131;
												case 2:
													goto IL_0140;
												case 3:
													goto IL_0213;
												case 4:
													text = text2.Trim();
													num3 = 0;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_37d4c0ccbd094f76a7cf8f93864def2a == 0)
													{
														num3 = 1;
														continue;
													}
													continue;
												case 5:
													goto IL_01E6;
												case 6:
													if (string.IsNullOrEmpty(text2))
													{
														goto IL_01E6;
													}
													num3 = 4;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b2d055de0c54ba08a92e6c6cd750833 != 0)
													{
														num3 = 4;
														continue;
													}
													continue;
												}
												break;
											}
											IL_01FC:
											string text3 = null;
											goto IL_0207;
											goto IL_01FC;
											IL_0140:
											object obj = ((ManagementObject)enumerator.Current)[A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-20831348 ^ -79800561 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53)];
											if (obj == null)
											{
												num3 = 0;
												if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 != 0)
												{
													num3 = 0;
													goto IL_010B;
												}
												goto IL_010B;
											}
											else
											{
												text3 = obj.ToString();
											}
											IL_0207:
											text2 = text3;
											num3 = 6;
											goto IL_010B;
										}
										IL_0131:
										return text;
										IL_0213:
										break;
									}
									finally
									{
										if (enumerator != null)
										{
											int num4 = 1;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 == 0)
											{
												num4 = 1;
											}
											for (;;)
											{
												switch (num4)
												{
												case 1:
													enumerator.Dispose();
													num4 = 0;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 != 0)
													{
														num4 = 0;
														continue;
													}
													continue;
												}
												break;
											}
										}
									}
									goto IL_029A;
								case 2:
									goto IL_029A;
								}
								text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(707542027 ^ 1291934805 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc);
								num2 = 2;
							}
							IL_029A:;
						}
						finally
						{
							if (managementObjectSearcher != null)
							{
								goto IL_02DF;
							}
							int num5 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 != 0)
							{
								num5 = 0;
							}
							IL_02C9:
							switch (num5)
							{
							case 1:
								IL_02DF:
								managementObjectSearcher.Dispose();
								num5 = 2;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 == 0)
								{
									num5 = 1;
									goto IL_02C9;
								}
								goto IL_02C9;
							}
						}
						break;
					}
				}
				catch
				{
					int num6 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a != 0)
					{
						num6 = 0;
					}
					for (;;)
					{
						switch (num6)
						{
						default:
							text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-595701871 ^ -851344953 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b);
							num6 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
							{
								num6 = 1;
							}
							break;
						case 1:
							goto IL_039D;
						}
					}
					IL_039D:;
				}
				break;
			}
			return text;
		}

		// Token: 0x06000214 RID: 532 RVA: 0x00012484 File Offset: 0x00010684
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static string A\u009C\u0096\u008C\u0097\u0094\u008F\u0089\u0090\u0096\u008B()
		{
			string text2;
			switch (1)
			{
			case 1:
				try
				{
					ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1881530452 ^ 886340833 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b));
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 != 0)
					{
						num = 0;
					}
					switch (num)
					{
					default:
						try
						{
							ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator();
							int num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75 == 0)
							{
								num2 = 0;
							}
							for (;;)
							{
								switch (num2)
								{
								default:
									try
									{
										for (;;)
										{
											IL_0153:
											if (enumerator.MoveNext())
											{
												goto IL_018D;
											}
											int num3 = 5;
											string text;
											for (;;)
											{
												IL_00DC:
												switch (num3)
												{
												default:
													if (string.IsNullOrEmpty(text))
													{
														num3 = 7;
														continue;
													}
													break;
												case 1:
													break;
												case 2:
													goto IL_012F;
												case 3:
													goto IL_01CF;
												case 4:
													goto IL_0153;
												case 5:
													goto IL_01FB;
												case 6:
													goto IL_018D;
												case 7:
													goto IL_0169;
												}
												text2 = text.Trim();
												num3 = 2;
											}
											IL_0169:
											continue;
											IL_01CF:
											string text3 = null;
											goto IL_01DA;
											IL_018D:
											object obj = ((ManagementObject)enumerator.Current)[A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-252024401 ^ -467247630 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad)];
											if (obj == null)
											{
												num3 = 3;
												goto IL_00DC;
											}
											text3 = obj.ToString();
											IL_01DA:
											text = text3;
											num3 = 0;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_732282d3a2ef416a9e85867f5ef3f928 == 0)
											{
												num3 = 0;
												goto IL_00DC;
											}
											goto IL_00DC;
										}
										IL_012F:
										return text2;
										IL_01FB:;
									}
									finally
									{
										if (enumerator != null)
										{
											goto IL_0264;
										}
										int num4 = 1;
										if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 == 0)
										{
											num4 = 1;
										}
										IL_022A:
										switch (num4)
										{
										case 2:
											IL_0264:
											enumerator.Dispose();
											num4 = 0;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce == 0)
											{
												num4 = 0;
												goto IL_022A;
											}
											goto IL_022A;
										}
									}
									break;
								case 1:
									goto IL_02D2;
								case 2:
									break;
								}
								text2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-96990369 ^ 2004048620 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5);
								num2 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3f1903d0114e4a7ea4b860c994faf9cc == 0)
								{
									num2 = 1;
								}
							}
							IL_02D2:;
						}
						finally
						{
							if (managementObjectSearcher != null)
							{
								goto IL_0317;
							}
							int num5 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
							{
								num5 = 0;
							}
							IL_0301:
							switch (num5)
							{
							case 2:
								IL_0317:
								managementObjectSearcher.Dispose();
								num5 = 1;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583 == 0)
								{
									num5 = 0;
									goto IL_0301;
								}
								goto IL_0301;
							}
						}
						break;
					}
				}
				catch
				{
					int num6 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf != 0)
					{
						num6 = 0;
					}
					for (;;)
					{
						switch (num6)
						{
						default:
							text2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1913821498 ^ 405099357 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f);
							num6 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a != 0)
							{
								num6 = 1;
							}
							break;
						case 1:
							goto IL_03BF;
						}
					}
					IL_03BF:;
				}
				break;
			}
			return text2;
		}

		// Token: 0x06000215 RID: 533 RVA: 0x000128C4 File Offset: 0x00010AC4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static string A\u0093\u0092\u0091\u009D\u008F\u0093\u008F\u008B\u0091\u0098()
		{
			string text2;
			switch (1)
			{
			case 1:
				try
				{
					ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-461999399 ^ -1915118383 ^ 2104744589 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad));
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
					{
						num = 0;
					}
					switch (num)
					{
					default:
						try
						{
							ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator();
							int num2 = 2;
							for (;;)
							{
								switch (num2)
								{
								case 1:
									goto IL_041F;
								case 2:
									try
									{
										for (;;)
										{
											IL_0161:
											if (enumerator.MoveNext())
											{
												goto IL_0315;
											}
											int num3 = 8;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b72d53da7b174fadb50590dffdef5348 != 0)
											{
												num3 = 8;
											}
											string text;
											for (;;)
											{
												IL_0123:
												switch (num3)
												{
												case 1:
													goto IL_01D8;
												case 2:
													if (!string.IsNullOrEmpty(text))
													{
														goto IL_0212;
													}
													num3 = 6;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 == 0)
													{
														num3 = 7;
														continue;
													}
													continue;
												case 3:
													goto IL_036C;
												case 4:
													goto IL_0161;
												case 5:
													if (text.Trim() != A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1699870387 ^ -1096664766 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f))
													{
														goto IL_01D8;
													}
													num3 = 9;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b != 0)
													{
														num3 = 9;
														continue;
													}
													continue;
												case 6:
													goto IL_0297;
												case 7:
													goto IL_02BB;
												case 8:
													goto IL_0398;
												case 9:
													goto IL_018C;
												case 10:
													goto IL_01B0;
												case 11:
													goto IL_0248;
												case 12:
													goto IL_0212;
												}
												goto Block_10;
												IL_01B0:
												text2 = text.Trim();
												num3 = 10;
												if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
												{
													num3 = 11;
													continue;
												}
												continue;
												IL_0212:
												if (text.Trim() != A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(247185273 ^ 56774601 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c))
												{
													num3 = 5;
													continue;
												}
												break;
												IL_01D8:
												if (text.Trim() != A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-784492755 ^ -1240402503 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc))
												{
													goto IL_01B0;
												}
												int num4 = 6;
												num3 = num4;
											}
											IL_018C:
											IL_0297:
											IL_02BB:
											continue;
											Block_10:
											goto IL_0315;
											IL_036C:
											string text3 = null;
											goto IL_0377;
											IL_0315:
											object obj = ((ManagementObject)enumerator.Current)[A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1913821498 ^ 1800342389 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f)];
											if (obj != null)
											{
												text3 = obj.ToString();
											}
											else
											{
												num3 = 0;
												if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 == 0)
												{
													num3 = 3;
													goto IL_0123;
												}
												goto IL_0123;
											}
											IL_0377:
											text = text3;
											num3 = 2;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330 != 0)
											{
												num3 = 2;
												goto IL_0123;
											}
											goto IL_0123;
										}
										IL_0248:
										return text2;
										IL_0398:
										break;
									}
									finally
									{
										if (enumerator != null)
										{
											int num5 = 1;
											if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b == 0)
											{
												num5 = 1;
											}
											for (;;)
											{
												switch (num5)
												{
												case 1:
													enumerator.Dispose();
													num5 = 0;
													if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 != 0)
													{
														num5 = 0;
														continue;
													}
													continue;
												}
												break;
											}
										}
									}
									goto IL_041F;
								}
								text2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1109220480 << 2) ^ 1707520815 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754);
								num2 = 1;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 == 0)
								{
									num2 = 1;
								}
							}
							IL_041F:;
						}
						finally
						{
							if (managementObjectSearcher != null)
							{
								goto IL_0464;
							}
							int num6 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4 != 0)
							{
								num6 = 1;
							}
							IL_044E:
							switch (num6)
							{
							default:
							{
								IL_0464:
								managementObjectSearcher.Dispose();
								int num7 = 2;
								num6 = num7;
								goto IL_044E;
							}
							case 1:
								break;
							case 2:
								break;
							}
						}
						break;
					}
				}
				catch
				{
					int num8 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4 != 0)
					{
						num8 = 1;
					}
					for (;;)
					{
						switch (num8)
						{
						case 1:
							text2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1185475502 ^ -1586541029 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca);
							num8 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 != 0)
							{
								num8 = 0;
								continue;
							}
							continue;
						}
						break;
					}
				}
				break;
			}
			return text2;
		}

		// Token: 0x06000216 RID: 534 RVA: 0x00012E54 File Offset: 0x00011054
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static string A\u009C\u0087\u0096\u009B\u009D\u008B\u009B\u009E\u008C\u009A(object \u0020)
		{
			int num = 1;
			int num2 = num;
			SHA256 sha;
			string text;
			for (;;)
			{
				switch (num2)
				{
				default:
					goto IL_002F;
				case 1:
					sha = SHA256.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 == 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					return text;
				}
			}
			IL_002F:
			try
			{
				byte[] bytes = Encoding.UTF8.GetBytes(\u0020);
				int num3 = 7;
				for (;;)
				{
					int num4;
					byte b;
					byte[] array2;
					switch (num3)
					{
					case 1:
					{
						StringBuilder stringBuilder;
						text = stringBuilder.ToString().Substring(0, 32);
						num3 = 5;
						continue;
					}
					case 2:
						num4 = 0;
						num3 = 8;
						continue;
					case 3:
					{
						StringBuilder stringBuilder;
						stringBuilder.Append(b.ToString(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1078648229 ^ -1267438268 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200)));
						num3 = 4;
						continue;
					}
					case 4:
						num4++;
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 == 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					case 5:
						goto IL_01A0;
					case 6:
						goto IL_0152;
					case 7:
					{
						byte[] array = sha.ComputeHash(bytes);
						StringBuilder stringBuilder = new StringBuilder();
						array2 = array;
						num3 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33 != 0)
						{
							num3 = 2;
							continue;
						}
						continue;
					}
					}
					if (num4 >= array2.Length)
					{
						num3 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53 == 0)
						{
							num3 = 1;
							continue;
						}
						continue;
					}
					IL_0152:
					b = array2[num4];
					num3 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 != 0)
					{
						num3 = 2;
					}
				}
				IL_01A0:;
			}
			finally
			{
				if (sha != null)
				{
					int num5 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f == 0)
					{
						num5 = 0;
					}
					for (;;)
					{
						switch (num5)
						{
						default:
							((IDisposable)sha).Dispose();
							num5 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 != 0)
							{
								num5 = 1;
							}
							break;
						case 1:
							goto IL_0207;
						}
					}
				}
				IL_0207:;
			}
			return text;
		}

		// Token: 0x06000217 RID: 535 RVA: 0x000130CC File Offset: 0x000112CC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static Dictionary<string, string> A\u009E\u009E\u0090\u008F\u0099\u009E\u0097\u009E\u0097\u0096()
		{
			return new Dictionary<string, string>
			{
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(561493477 ^ 1236395320 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1),
					A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0093\u009D\u0094\u0097\u008B\u008B\u0088\u009B\u0090()
				},
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1219413587 ^ -1306226234 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c),
					A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.A\u009C\u0096\u008C\u0097\u0094\u008F\u0089\u0090\u0096\u008B()
				},
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-2117712573 ^ -1346654284 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6),
					A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.A\u0093\u0092\u0091\u009D\u008F\u0093\u008F\u008B\u0091\u0098()
				},
				{
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--266838818 ^ 2000224682 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257),
					A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0098\u008C\u008B\u009B\u0099\u009D\u008A\u0095\u008B
				}
			};
		}

		// Token: 0x06000218 RID: 536 RVA: 0x00013180 File Offset: 0x00011380
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0086\u0094\u0091\u0087\u0099\u0089\u008E\u0094\u008C\u008D()
		{
			return A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.A\u0098\u009C\u008F\u0096\u0096\u0089\u0098\u008B\u008E\u009B == null;
		}

		// Token: 0x06000219 RID: 537 RVA: 0x00013194 File Offset: 0x00011394
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093 AA\u0088\u009B\u0094\u0090\u008F\u0088\u0093\u0096\u008A()
		{
			return A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.A\u0098\u009C\u008F\u0096\u0096\u0089\u0098\u008B\u008E\u009B;
		}

		// Token: 0x04000163 RID: 355
		public static readonly object AA\u0098\u008C\u008B\u009B\u0099\u009D\u008A\u0095\u008B;

		// Token: 0x04000164 RID: 356
		private static object A\u0098\u009C\u008F\u0096\u0096\u0089\u0098\u008B\u008E\u009B;
	}
}
