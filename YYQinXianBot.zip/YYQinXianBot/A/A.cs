﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200004E RID: 78
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098
	{
		// Token: 0x06000252 RID: 594 RVA: 0x000145D8 File Offset: 0x000127D8
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int A\u009B\u0090\u0087\u008F\u0098\u009B\u009B\u0094\u0089\u008E()
		{
			return this.A\u0094\u009E\u0099\u009A\u0087\u0087\u008A\u0090\u008C\u0088;
		}

		// Token: 0x06000253 RID: 595 RVA: 0x000145E8 File Offset: 0x000127E8
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008E\u008D\u0087\u0096\u0098\u0088\u0098\u008B\u0092\u008E(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0094\u009E\u0099\u009A\u0087\u0087\u008A\u0090\u008C\u0088 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000254 RID: 596 RVA: 0x00014648 File Offset: 0x00012848
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public double A\u0097\u0087\u0097\u008A\u0094\u009C\u0097\u0090\u0089\u0098()
		{
			return this.A\u009B\u0097\u009B\u0091\u0093\u008D\u0088\u0094\u0099\u0089;
		}

		// Token: 0x06000255 RID: 597 RVA: 0x00014658 File Offset: 0x00012858
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0091\u0099\u0086\u0089\u008F\u0092\u008D\u0094\u0088\u009E(double \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u009B\u0097\u009B\u0091\u0093\u008D\u0088\u0094\u0099\u0089 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000256 RID: 598 RVA: 0x000146B8 File Offset: 0x000128B8
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public List<A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086> A\u0088\u0094\u0096\u0090\u0089\u0086\u008F\u008B\u009A\u0087()
		{
			return this.A\u0088\u0088\u008A\u0098\u009D\u0094\u0093\u008B\u009E\u0099;
		}

		// Token: 0x06000257 RID: 599 RVA: 0x000146C8 File Offset: 0x000128C8
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008A\u009B\u0099\u0094\u008C\u0095\u0086\u0094\u0089\u009A(List<A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086> \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0088\u0088\u008A\u0098\u009D\u0094\u0093\u008B\u009E\u0099 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00014728 File Offset: 0x00012928
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 2;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 != 0)
			{
				num = 3;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					this.A\u0097\u0098\u0092\u0095\u009B\u0092\u0086\u0094\u0093\u009E();
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2263b4ae313f4ba5ab3effe79a3ad3f1 == 0)
					{
						num = 0;
						continue;
					}
					continue;
				case 2:
					this.A\u008A\u009B\u0099\u0094\u008C\u0095\u0086\u0094\u0089\u009A(new List<A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086>());
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c == 0)
					{
						num = 1;
						continue;
					}
					continue;
				case 3:
					this.A\u008E\u008D\u0087\u0096\u0098\u0088\u0098\u008B\u0092\u008E(85);
					num = 2;
					continue;
				}
				break;
			}
		}

		// Token: 0x06000259 RID: 601 RVA: 0x000147FC File Offset: 0x000129FC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0098\u0086\u0093\u0090\u0099\u009C\u0097\u0092\u009C\u0095(string \u0020, [Nullable(2)] string playSign = null)
		{
			int num = 1;
			for (;;)
			{
				int num2 = num;
				object[] array;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						array = new object[2];
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 2:
						goto IL_0063;
					case 3:
						AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(12, array, this);
						num2 = 4;
						continue;
					case 4:
						return;
					}
					array[0] = \u0020;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db != 0)
					{
						num2 = 2;
					}
				}
				IL_0063:
				array[1] = playSign;
				num = 3;
			}
		}

		// Token: 0x0600025A RID: 602 RVA: 0x000148C8 File Offset: 0x00012AC8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0097\u0098\u0092\u0095\u009B\u0092\u0086\u0094\u0093\u009E()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0091\u0099\u0086\u0089\u008F\u0092\u008D\u0094\u0088\u009E(60000.0 / (double)this.A\u009B\u0090\u0087\u008F\u0098\u009B\u009B\u0094\u0089\u008E());
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00014938 File Offset: 0x00012B38
		[MethodImpl(MethodImplOptions.NoInlining)]
		[return: Nullable(2)]
		private A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086 A\u009B\u008D\u008B\u0089\u0092\u008D\u0086\u0092\u0088\u0091(string \u0020)
		{
			int num = 3;
			int num2 = num;
			object[] array;
			for (;;)
			{
				switch (num2)
				{
				default:
				{
					object[] array2;
					array = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(13, array2, this);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
					{
						num2 = 1;
					}
					break;
				}
				case 1:
					goto IL_0061;
				case 2:
				{
					object[] array2;
					array2[0] = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2263b4ae313f4ba5ab3effe79a3ad3f1 == 0)
					{
						num2 = 0;
					}
					break;
				}
				case 3:
				{
					object[] array2 = new object[1];
					num2 = 2;
					break;
				}
				}
			}
			IL_0061:
			return (A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086)array[0];
		}

		// Token: 0x0600025C RID: 604 RVA: 0x000149F0 File Offset: 0x00012BF0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E> AA\u0091\u009A\u0086\u009E\u008A\u008E\u0092\u009E\u0086(string \u0020)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(14, array, this);
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 == 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 3:
					goto IL_00B7;
				}
				array[0] = \u0020;
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 == 0)
				{
					num2 = 2;
				}
			}
			IL_00B7:
			return (List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E>)array2[0];
		}

		// Token: 0x0600025D RID: 605 RVA: 0x00014AC0 File Offset: 0x00012CC0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private bool A\u0087\u0089\u0087\u008B\u0099\u0097\u0094\u0094\u008E\u009A(char \u0020)
		{
			return char.IsLetterOrDigit(\u0020);
		}

		// Token: 0x0600025E RID: 606 RVA: 0x00014AD0 File Offset: 0x00012CD0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private bool A\u009A\u0093\u008A\u009A\u0093\u008C\u0097\u0090\u009D\u008B(char \u0020)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(15, array, this);
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c != 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 3:
					goto IL_008E;
				}
				array[0] = \u0020;
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292 == 0)
				{
					num2 = 2;
				}
			}
			IL_008E:
			return (bool)array2[0];
		}

		// Token: 0x0600025F RID: 607 RVA: 0x00014BA4 File Offset: 0x00012DA4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private double A\u0098\u009B\u009A\u0094\u0089\u0096\u008C\u009E\u009C\u008F(char \u0020)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_0033;
				case 3:
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(16, array, this);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363 != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				}
				array[0] = \u0020;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc == 0)
				{
					num2 = 0;
				}
			}
			IL_0033:
			return (double)array2[0];
		}

		// Token: 0x06000260 RID: 608 RVA: 0x00014C78 File Offset: 0x00012E78
		[MethodImpl(MethodImplOptions.NoInlining)]
		private bool A\u0086\u0090\u008F\u008B\u009D\u0092\u0092\u008B\u009D\u009D()
		{
			int num = 2;
			int num2 = num;
			object[] array;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					object[] array2;
					array = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(17, array2, this);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 2:
				{
					object[] array2 = new object[0];
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				}
				break;
			}
			return (bool)array[0];
		}

		// Token: 0x06000261 RID: 609 RVA: 0x00014D18 File Offset: 0x00012F18
		[MethodImpl(MethodImplOptions.NoInlining)]
		private string AA\u008C\u0098\u008A\u0087\u008F\u0098\u0099\u0091\u0090(string \u0020)
		{
			int num = 1;
			int num2 = num;
			SHA256 sha;
			string text;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					sha = SHA256.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return text;
				}
				break;
			}
			try
			{
				byte[] bytes = Encoding.UTF8.GetBytes(\u0020);
				int num3 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
				{
					num3 = 1;
				}
				for (;;)
				{
					switch (num3)
					{
					case 1:
						text = BitConverter.ToString(sha.ComputeHash(bytes)).Replace(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-2051710422 ^ -715887061 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590), "").ToLower();
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 == 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
			finally
			{
				if (sha != null)
				{
					int num4 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 == 0)
					{
						num4 = 0;
					}
					for (;;)
					{
						switch (num4)
						{
						default:
							((IDisposable)sha).Dispose();
							num4 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 == 0)
							{
								num4 = 1;
							}
							break;
						case 1:
							goto IL_0158;
						}
					}
				}
				IL_0158:;
			}
			return text;
		}

		// Token: 0x06000262 RID: 610 RVA: 0x00014EB0 File Offset: 0x000130B0
		[MethodImpl(MethodImplOptions.NoInlining)]
		[return: Nullable(new byte[] { 1, 0 })]
		public List<ValueTuple<char?, double, bool, double>> AA\u0094\u009C\u0087\u0098\u008D\u0096\u009B\u008A\u0097()
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[0];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_0088;
				}
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(18, array, this);
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a == 0)
				{
					num2 = 0;
				}
			}
			IL_0088:
			return (List<ValueTuple<char?, double, bool, double>>)array2[0];
		}

		// Token: 0x06000263 RID: 611 RVA: 0x00014F50 File Offset: 0x00013150
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool AA\u0088\u0091\u0091\u008E\u009A\u0092\u0087\u0086\u008E()
		{
			return A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098.A\u0097\u0090\u0090\u0090\u008B\u009C\u0088\u0090\u0096\u0089 == null;
		}

		// Token: 0x06000264 RID: 612 RVA: 0x00014F64 File Offset: 0x00013164
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098 A\u008E\u0094\u0091\u009B\u008F\u0091\u008B\u0094\u009E\u008B()
		{
			return A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098.A\u0097\u0090\u0090\u0090\u008B\u009C\u0088\u0090\u0096\u0089;
		}

		// Token: 0x06000265 RID: 613 RVA: 0x00014F74 File Offset: 0x00013174
		static A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400018E RID: 398
		[CompilerGenerated]
		private int A\u0094\u009E\u0099\u009A\u0087\u0087\u008A\u0090\u008C\u0088;

		// Token: 0x0400018F RID: 399
		[CompilerGenerated]
		private double A\u009B\u0097\u009B\u0091\u0093\u008D\u0088\u0094\u0099\u0089;

		// Token: 0x04000190 RID: 400
		[CompilerGenerated]
		private List<A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086> A\u0088\u0088\u008A\u0098\u009D\u0094\u0093\u008B\u009E\u0099;

		// Token: 0x04000191 RID: 401
		[Nullable(2)]
		private string A\u009A\u008C\u0089\u0091\u0092\u0089\u0096\u0090\u008F\u0086;

		// Token: 0x04000192 RID: 402
		internal static object A\u0097\u0090\u0090\u0090\u008B\u009C\u0088\u0090\u0096\u0089;

		// Token: 0x0200004F RID: 79
		[NullableContext(0)]
		private class A\u009E\u0097\u008A\u0094\u008E\u008E\u009D\u008B\u0090\u009C
		{
			// Token: 0x06000266 RID: 614 RVA: 0x00028AC0 File Offset: 0x00026CC0
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			public double A\u0086\u0087\u008D\u0090\u009C\u0093\u0087\u008B\u008D\u0091()
			{
				return this.A\u0094\u0097\u008F\u0093\u008D\u008C\u0090\u008B\u0087\u0088;
			}

			// Token: 0x06000267 RID: 615 RVA: 0x00028AD0 File Offset: 0x00026CD0
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			public void A\u009A\u008F\u008B\u008E\u009E\u0087\u0091\u0090\u0095\u0087(double \u0020)
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0094\u0097\u008F\u0093\u008D\u008C\u0090\u008B\u0087\u0088 = \u0020;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}

			// Token: 0x06000268 RID: 616 RVA: 0x00028B30 File Offset: 0x00026D30
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			public char A\u0096\u009D\u0091\u0094\u0094\u0086\u0089\u008B\u009D\u008B()
			{
				return this.A\u0088\u0096\u009B\u0087\u008D\u008F\u009C\u008B\u008A\u009A;
			}

			// Token: 0x06000269 RID: 617 RVA: 0x00028B40 File Offset: 0x00026D40
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			public void A\u0087\u009C\u009A\u0095\u008E\u0086\u009B\u009E\u008C\u009A(char \u0020)
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0088\u0096\u009B\u0087\u008D\u008F\u009C\u008B\u008A\u009A = \u0020;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c9177097f6d4245975a6f4f2351fc33 == 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}

			// Token: 0x0600026A RID: 618 RVA: 0x00028BA0 File Offset: 0x00026DA0
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			public bool A\u0089\u008D\u008A\u008D\u0096\u0087\u0092\u008B\u009D\u0086()
			{
				return this.AA\u0090\u009D\u009B\u008D\u0094\u0092\u008D\u009A\u0094;
			}

			// Token: 0x0600026B RID: 619 RVA: 0x00028BB0 File Offset: 0x00026DB0
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			public void A\u009A\u0086\u0097\u009D\u009B\u0090\u0090\u0094\u0099\u0096(bool \u0020)
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.AA\u0090\u009D\u009B\u008D\u0094\u0092\u008D\u009A\u0094 = \u0020;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 == 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}

			// Token: 0x0600026C RID: 620 RVA: 0x00028C10 File Offset: 0x00026E10
			[MethodImpl(MethodImplOptions.NoInlining)]
			public A\u009E\u0097\u008A\u0094\u008E\u008E\u009D\u008B\u0090\u009C()
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
				A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
				base..ctor();
				int num = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b != 0)
				{
					num = 0;
				}
				switch (num)
				{
				default:
					return;
				}
			}

			// Token: 0x0600026D RID: 621 RVA: 0x00028C74 File Offset: 0x00026E74
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal static bool A\u008F\u0086\u0097\u008E\u0096\u0090\u009C\u0094\u009D\u0095()
			{
				return A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098.A\u009E\u0097\u008A\u0094\u008E\u008E\u009D\u008B\u0090\u009C.A\u0087\u009B\u0097\u008F\u009C\u0094\u0094\u0092\u009E\u0090 == null;
			}

			// Token: 0x0600026E RID: 622 RVA: 0x00028C88 File Offset: 0x00026E88
			[MethodImpl(MethodImplOptions.NoInlining)]
			internal static A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098.A\u009E\u0097\u008A\u0094\u008E\u008E\u009D\u008B\u0090\u009C A\u009C\u008F\u0087\u009E\u008F\u0096\u009B\u008B\u0086\u009C()
			{
				return A\u0099\u0087\u0098\u0092\u009A\u0086\u0092\u009E\u008B\u0098.A\u009E\u0097\u008A\u0094\u008E\u008E\u009D\u008B\u0090\u009C.A\u0087\u009B\u0097\u008F\u009C\u0094\u0094\u0092\u009E\u0090;
			}

			// Token: 0x0600026F RID: 623 RVA: 0x00028C98 File Offset: 0x00026E98
			static A\u009E\u0097\u008A\u0094\u008E\u008E\u009D\u008B\u0090\u009C()
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			}

			// Token: 0x04000193 RID: 403
			[CompilerGenerated]
			private double A\u0094\u0097\u008F\u0093\u008D\u008C\u0090\u008B\u0087\u0088;

			// Token: 0x04000194 RID: 404
			[CompilerGenerated]
			private char A\u0088\u0096\u009B\u0087\u008D\u008F\u009C\u008B\u008A\u009A;

			// Token: 0x04000195 RID: 405
			[CompilerGenerated]
			private bool AA\u0090\u009D\u009B\u008D\u0094\u0092\u008D\u009A\u0094;

			// Token: 0x04000196 RID: 406
			private static object A\u0087\u009B\u0097\u008F\u009C\u0094\u0094\u0092\u009E\u0090;
		}
	}
}
