﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000047 RID: 71
	[Nullable(0)]
	[NullableContext(1)]
	public static class A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091
	{
		// Token: 0x060001F9 RID: 505 RVA: 0x000112A8 File Offset: 0x0000F4A8
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u0098\u008B\u008E\u0097\u0099\u009E\u0088\u008B\u0099\u0086()
		{
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-174680055 ^ -226554898 ^ 1887528150 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b);
		}

		// Token: 0x060001FA RID: 506 RVA: 0x000112D4 File Offset: 0x0000F4D4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string AA\u0096\u008F\u009C\u0092\u0095\u0092\u0099\u0095\u0099()
		{
			int num = 6;
			int num2 = num;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler;
			for (;;)
			{
				Version version;
				switch (num2)
				{
				case 1:
					goto IL_0149;
				case 2:
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1342393391 ^ 890468035 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363));
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 3:
					defaultInterpolatedStringHandler.AppendFormatted<int>(version.Build);
					num2 = 7;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
					{
						num2 = 4;
						continue;
					}
					continue;
				case 4:
					defaultInterpolatedStringHandler.AppendFormatted<int>(version.Minor);
					num2 = 8;
					continue;
				case 5:
					if (!(version != null))
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					else
					{
						defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(2, 3);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				case 6:
					version = Assembly.GetExecutingAssembly().GetName().Version;
					num2 = 5;
					continue;
				case 7:
					goto IL_0115;
				case 8:
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1381125682 >> 1) ^ 1740468921 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b));
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				}
				defaultInterpolatedStringHandler.AppendFormatted<int>(version.Major);
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d != 0)
				{
					num2 = 1;
				}
			}
			IL_0115:
			return defaultInterpolatedStringHandler.ToStringAndClear();
			IL_0149:
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((2107586582 - -729554149) ^ -1889448592 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583);
		}

		// Token: 0x060001FB RID: 507 RVA: 0x000114BC File Offset: 0x0000F6BC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string AA\u008B\u0096\u009D\u008B\u0095\u009C\u008B\u009A\u009C()
		{
			int num = 2;
			int num2 = num;
			string text2;
			for (;;)
			{
				string text;
				switch (num2)
				{
				case 1:
					text = null;
					goto IL_006F;
				case 2:
				{
					Version version = Assembly.GetExecutingAssembly().GetName().Version;
					if (version != null)
					{
						text = version.ToString();
						goto IL_006F;
					}
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				}
				break;
				IL_006F:
				if ((text2 = text) != null)
				{
					return text2;
				}
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 != 0)
				{
					num2 = 0;
				}
			}
			text2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1186520438 - -1314777313) ^ 221120256 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4);
			return text2;
		}

		// Token: 0x060001FC RID: 508 RVA: 0x00011580 File Offset: 0x0000F780
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u008C\u0099\u009D\u0087\u0091\u008E\u008F\u0094\u0098\u008C()
		{
			return A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091.A\u0098\u008B\u008E\u0097\u0099\u009E\u0088\u008B\u0099\u0086() + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1482712261 ^ 1405557727 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4) + A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091.AA\u0096\u008F\u009C\u0092\u0095\u0092\u0099\u0095\u0099();
		}

		// Token: 0x060001FD RID: 509 RVA: 0x000115B4 File Offset: 0x0000F7B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string AA\u008C\u0096\u0099\u0097\u008F\u009E\u009A\u0093\u0098()
		{
			return A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091.AA\u0096\u008F\u009C\u0092\u0095\u0092\u0099\u0095\u0099();
		}

		// Token: 0x060001FE RID: 510 RVA: 0x000115C4 File Offset: 0x0000F7C4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u0090\u0087\u009B\u008B\u0087\u008D\u0093\u0094\u0088\u008A()
		{
			int num = 2;
			int num2 = num;
			string text2;
			for (;;)
			{
				string text;
				switch (num2)
				{
				case 1:
					text = null;
					goto IL_006F;
				case 2:
				{
					AssemblyCompanyAttribute customAttribute = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyCompanyAttribute>();
					if (customAttribute != null)
					{
						text = customAttribute.Company;
						goto IL_006F;
					}
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				}
				break;
				IL_006F:
				if ((text2 = text) != null)
				{
					goto Block_4;
				}
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
				{
					num2 = 0;
				}
			}
			goto IL_009A;
			Block_4:
			return text2;
			IL_009A:
			text2 = "";
			return text2;
		}

		// Token: 0x060001FF RID: 511 RVA: 0x00011670 File Offset: 0x0000F870
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u0087\u0091\u0098\u009A\u0093\u0097\u009D\u0090\u008E\u0099()
		{
			int num = 2;
			int num2 = num;
			string text2;
			for (;;)
			{
				string text;
				switch (num2)
				{
				case 1:
					text = null;
					goto IL_006A;
				case 2:
				{
					AssemblyCopyrightAttribute customAttribute = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyCopyrightAttribute>();
					if (customAttribute != null)
					{
						text = customAttribute.Copyright;
						goto IL_006A;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				}
				break;
				IL_006A:
				if ((text2 = text) != null)
				{
					goto Block_4;
				}
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 != 0)
				{
					num2 = 0;
				}
			}
			goto IL_0095;
			Block_4:
			return text2;
			IL_0095:
			text2 = "";
			return text2;
		}

		// Token: 0x06000200 RID: 512 RVA: 0x00011718 File Offset: 0x0000F918
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string AA\u0094\u0099\u008A\u009C\u008F\u0090\u0099\u008C\u008B()
		{
			int num = 2;
			int num2 = num;
			string text2;
			for (;;)
			{
				string text;
				switch (num2)
				{
				case 1:
					text = null;
					goto IL_006A;
				case 2:
				{
					AssemblyDescriptionAttribute customAttribute = Assembly.GetExecutingAssembly().GetCustomAttribute<AssemblyDescriptionAttribute>();
					if (customAttribute != null)
					{
						text = customAttribute.Description;
						goto IL_006A;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_aeecb0ba81724219b3aab6c572f13b3f == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				}
				break;
				IL_006A:
				if ((text2 = text) != null)
				{
					goto Block_4;
				}
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292 == 0)
				{
					num2 = 0;
				}
			}
			goto IL_0095;
			Block_4:
			return text2;
			IL_0095:
			text2 = "";
			return text2;
		}

		// Token: 0x06000201 RID: 513 RVA: 0x000117C0 File Offset: 0x0000F9C0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0087\u0099\u008D\u0088\u008A\u008C\u009C\u0094\u0089\u009C()
		{
			return A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091.A\u0088\u0087\u0095\u0092\u008E\u009B\u0089\u0094\u0087\u009C == null;
		}

		// Token: 0x06000202 RID: 514 RVA: 0x000117D4 File Offset: 0x0000F9D4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091 A\u009B\u0092\u008A\u0092\u0087\u0092\u008A\u0090\u0087\u0094()
		{
			return A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091.A\u0088\u0087\u0095\u0092\u008E\u009B\u0089\u0094\u0087\u009C;
		}

		// Token: 0x06000203 RID: 515 RVA: 0x000117E4 File Offset: 0x0000F9E4
		static A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000161 RID: 353
		internal static object A\u0088\u0087\u0095\u0092\u008E\u009B\u0089\u0094\u0087\u009C;
	}
}
