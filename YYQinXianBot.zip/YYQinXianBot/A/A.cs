﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000065 RID: 101
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B
	{
		// Token: 0x14000003 RID: 3
		// (add) Token: 0x060002F9 RID: 761 RVA: 0x0001A320 File Offset: 0x00018520
		// (remove) Token: 0x060002FA RID: 762 RVA: 0x0001A3FC File Offset: 0x000185FC
		[Nullable(2)]
		public event EventHandler A\u009E\u009D\u0090\u0086\u0089\u009B\u008C\u008B\u008D\u009A
		{
			[NullableContext(2)]
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			add
			{
				int num = 3;
				int num2 = num;
				for (;;)
				{
					EventHandler eventHandler;
					EventHandler eventHandler2;
					switch (num2)
					{
					default:
						if (eventHandler == eventHandler2)
						{
							num2 = 5;
							continue;
						}
						break;
					case 1:
					{
						EventHandler eventHandler3;
						eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.A\u0086\u008E\u0094\u009C\u0086\u0086\u0088\u0092\u008A\u008B, eventHandler3, eventHandler2);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					case 2:
						break;
					case 3:
						eventHandler = this.A\u0086\u008E\u0094\u009C\u0086\u0086\u0088\u0092\u008A\u008B;
						num2 = 2;
						continue;
					case 4:
					{
						EventHandler eventHandler3 = (EventHandler)Delegate.Combine(eventHandler2, value);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					case 5:
						return;
					}
					eventHandler2 = eventHandler;
					num2 = 4;
				}
			}
			[NullableContext(2)]
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			remove
			{
				int num = 4;
				int num2 = num;
				for (;;)
				{
					EventHandler eventHandler3;
					EventHandler eventHandler;
					switch (num2)
					{
					case 1:
					{
						EventHandler eventHandler2;
						eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.A\u0086\u008E\u0094\u009C\u0086\u0086\u0088\u0092\u008A\u008B, eventHandler2, eventHandler3);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 != 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					case 2:
						if (eventHandler != eventHandler3)
						{
							goto IL_0090;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 3:
						goto IL_0090;
					case 4:
						eventHandler = this.A\u0086\u008E\u0094\u009C\u0086\u0086\u0088\u0092\u008A\u008B;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363 != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 5:
					{
						EventHandler eventHandler2 = (EventHandler)Delegate.Remove(eventHandler3, value);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b7fd23e09aa54f94a15e32978d45910b == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					}
					break;
					IL_0090:
					eventHandler3 = eventHandler;
					num2 = 5;
				}
			}
		}

		// Token: 0x060002FB RID: 763 RVA: 0x0001A500 File Offset: 0x00018700
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B(TextBox \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 2;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 != 0)
			{
				num = 0;
			}
			for (;;)
			{
				switch (num)
				{
				default:
					return;
				case 1:
					this.A\u0097\u0090\u0090\u008C\u0097\u009E\u008F\u0092\u008C\u0094();
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd != 0)
					{
						num = 0;
					}
					break;
				case 2:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093 = \u0020;
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 != 0)
					{
						num = 1;
					}
					break;
				}
			}
		}

		// Token: 0x060002FC RID: 764 RVA: 0x0001A5B8 File Offset: 0x000187B8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0097\u0090\u0090\u008C\u0097\u009E\u008F\u0092\u008C\u0094()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-242410958 + -2074834086) ^ 170770433 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.TextChanged += this.A\u009C\u008A\u008B\u008A\u0090\u0089\u008B\u0090\u0097\u0096;
					num2 = 3;
					continue;
				case 3:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.KeyDown += this.A\u009D\u0088\u0089\u0094\u0089\u0088\u0092\u009E\u0096\u0092;
					num2 = 7;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 4:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.LostFocus += this.A\u008F\u0095\u008D\u0089\u008B\u0094\u0093\u008B\u009E\u0093;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 5:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GotFocus += this.AA\u008A\u0097\u0096\u008B\u008D\u0095\u008F\u008C\u0094;
					num2 = 4;
					continue;
				case 6:
					return;
				case 7:
					this.A\u009E\u008A\u0091\u009C\u0091\u0089\u009C\u0090\u0095\u0087();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b != 0)
					{
						num2 = 6;
						continue;
					}
					continue;
				}
				this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor = Color.Gray;
				num2 = 5;
			}
		}

		// Token: 0x060002FD RID: 765 RVA: 0x0001A740 File Offset: 0x00018940
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009E\u008A\u0091\u009C\u0091\u0089\u009C\u0090\u0095\u0087()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097 = new ContextMenuStrip();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
				{
					ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(649406881 ^ -2075055971 ^ -903719741 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1));
					num2 = 6;
					continue;
				}
				case 3:
				{
					ToolStripMenuItem toolStripMenuItem2;
					this.A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097.Items.Add(toolStripMenuItem2);
					num2 = 12;
					continue;
				}
				case 4:
				{
					ToolStripMenuItem toolStripMenuItem2 = new ToolStripMenuItem(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1751143249 ^ -283940131 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889));
					num2 = 10;
					continue;
				}
				case 5:
					this.A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097.Items.Add(this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087);
					num2 = 8;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66 == 0)
					{
						num2 = 8;
						continue;
					}
					continue;
				case 6:
				{
					ToolStripMenuItem toolStripMenuItem;
					toolStripMenuItem.Click += this.A\u0087\u0092\u0087\u0089\u0091\u0095\u009E\u0092\u0096\u0096;
					num2 = 11;
					continue;
				}
				case 7:
					return;
				case 8:
					this.A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097.Items.Add(new ToolStripSeparator());
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 9:
					this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087.Click += this.AA\u0092\u0094\u0092\u0092\u0095\u0092\u008F\u008E\u0087;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c == 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				case 10:
				{
					ToolStripMenuItem toolStripMenuItem2;
					toolStripMenuItem2.Click += this.A\u0094\u0087\u0099\u008A\u0089\u008D\u009B\u009E\u009D\u0097;
					num2 = 3;
					continue;
				}
				case 11:
				{
					ToolStripMenuItem toolStripMenuItem;
					this.A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097.Items.Add(toolStripMenuItem);
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 12:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ContextMenuStrip = this.A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097;
					num2 = 13;
					continue;
				case 13:
					this.A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097.Opening += this.A\u009A\u0088\u009E\u009A\u009B\u0086\u0095\u009E\u009A\u0095;
					num2 = 7;
					continue;
				}
				this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087 = new ToolStripMenuItem(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(561493477 ^ 672877504 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1));
				num2 = 9;
			}
		}

		// Token: 0x060002FE RID: 766 RVA: 0x0001A9C8 File Offset: 0x00018BC8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009A\u0088\u009E\u009A\u009B\u0086\u0095\u009E\u009A\u0095([Nullable(2)] object sender, CancelEventArgs \u0020)
		{
			int num = 4;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					string text;
					switch (num2)
					{
					case 1:
						this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087.Enabled = true;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f == 0)
						{
							num2 = 9;
							continue;
						}
						continue;
					case 2:
					{
						bool flag;
						if (!flag)
						{
							num2 = 5;
							continue;
						}
						goto IL_0199;
					}
					case 3:
						goto IL_0145;
					case 4:
					{
						bool flag = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionLength > 0;
						num2 = 3;
						continue;
					}
					case 5:
						this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-252024401 ^ -2108767795 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5);
						num2 = 6;
						continue;
					case 6:
						this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087.Enabled = false;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 7:
						goto IL_0199;
					case 8:
						this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((953756095 - 1838868129) ^ -1860782781 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1) + text + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1381125682 >> 1) ^ 1545401003 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 9:
						return;
					}
					goto Block_1;
					IL_0199:
					text = this.A\u0097\u0099\u0099\u0098\u0099\u0096\u009D\u0094\u008F\u0089();
					num2 = 8;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d != 0)
					{
						num2 = 0;
					}
				}
				IL_0145:
				if (this.A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087 == null)
				{
					break;
				}
				num = 2;
			}
			Block_1:;
		}

		// Token: 0x060002FF RID: 767 RVA: 0x0001AB94 File Offset: 0x00018D94
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0087\u0089\u0090\u0092\u008C\u009C\u0098\u008B\u0091\u0096(bool \u0020)
		{
			int num = 32;
			for (;;)
			{
				int num2 = num;
				int num3;
				string text2;
				int num6;
				bool flag;
				for (;;)
				{
					int lineFromCharIndex;
					string[] lines;
					string text;
					int num4;
					int firstCharIndexFromLine;
					int num5;
					int num7;
					switch (num2)
					{
					case 0:
						goto IL_0236;
					case 1:
						goto IL_032F;
					case 2:
						goto IL_02F7;
					case 3:
						return;
					case 4:
						if (!\u0020)
						{
							num2 = 29;
							continue;
						}
						goto IL_03EB;
					case 5:
						this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectedText = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1451827733 ^ 715078847 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33);
						num2 = 36;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 != 0)
						{
							num2 = 11;
							continue;
						}
						continue;
					case 6:
						goto IL_02F7;
					case 7:
						goto IL_02F7;
					case 8:
						goto IL_021C;
					case 9:
						goto IL_040B;
					case 10:
					{
						int selectionStart;
						lineFromCharIndex = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetLineFromCharIndex(selectionStart);
						num2 = 11;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 == 0)
						{
							num2 = 26;
							continue;
						}
						continue;
					}
					case 11:
						goto IL_0179;
					case 12:
						goto IL_0263;
					case 13:
						goto IL_021C;
					case 14:
						goto IL_03AD;
					case 15:
						goto IL_0275;
					case 16:
						goto IL_032F;
					case 17:
						goto IL_01AB;
					case 18:
						goto IL_0248;
					case 19:
						goto IL_0394;
					case 20:
						text = lines[num3];
						num2 = 23;
						continue;
					case 21:
						if (text2.StartsWith(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-640960945 ^ -1657131634 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b)))
						{
							num2 = 24;
							continue;
						}
						goto IL_050A;
					case 22:
						goto IL_02F7;
					case 23:
						text2 = text.TrimStart();
						num2 = 11;
						continue;
					case 24:
						this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Select(num4, 2);
						num2 = 9;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 == 0)
						{
							num2 = 13;
							continue;
						}
						continue;
					case 25:
						num4 = firstCharIndexFromLine + num5;
						num2 = 21;
						continue;
					case 26:
						num6 = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetLineFromCharIndex(num7);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 27:
						goto IL_03EB;
					case 28:
						goto IL_0394;
					case 29:
						goto IL_03AD;
					case 30:
					{
						int selectionStart;
						num7 = selectionStart + this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionLength;
						num2 = 7;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
						{
							num2 = 10;
							continue;
						}
						continue;
					}
					case 31:
						return;
					case 32:
					{
						if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionLength == 0)
						{
							num2 = 31;
							continue;
						}
						int selectionStart = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionStart;
						num2 = 15;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53 != 0)
						{
							num2 = 30;
							continue;
						}
						continue;
					}
					case 33:
						break;
					case 34:
						break;
					case 35:
						num6--;
						num2 = 33;
						continue;
					case 36:
						goto IL_02F7;
					case 37:
						goto IL_050A;
					default:
						goto IL_0236;
					}
					IL_014D:
					lines = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Lines;
					num2 = 12;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b != 0)
					{
						num2 = 10;
						continue;
					}
					continue;
					IL_01AB:
					if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetFirstCharIndexFromLine(num6) == num7)
					{
						num2 = 35;
						continue;
					}
					goto IL_014D;
					IL_0236:
					if (num7 <= 0)
					{
						num2 = 34;
						continue;
					}
					goto IL_01AB;
					IL_021C:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectedText = "";
					num2 = 2;
					continue;
					IL_0248:
					num5 = text.Length - text2.Length;
					num2 = 25;
					continue;
					IL_03AD:
					if (!flag)
					{
						num2 = 6;
						continue;
					}
					goto IL_0248;
					IL_0275:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Select(firstCharIndexFromLine, 0);
					num2 = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c == 0)
					{
						num2 = 5;
						continue;
					}
					continue;
					IL_03EB:
					if (flag)
					{
						num2 = 22;
						continue;
					}
					goto IL_0275;
					IL_02F7:
					num3--;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
					IL_032F:
					if (num3 >= lineFromCharIndex)
					{
						num2 = 19;
						continue;
					}
					return;
					IL_040B:
					firstCharIndexFromLine = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetFirstCharIndexFromLine(num3);
					num2 = 20;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a != 0)
					{
						num2 = 9;
						continue;
					}
					continue;
					IL_0394:
					if (num3 >= lines.Length)
					{
						goto Block_14;
					}
					goto IL_040B;
					IL_050A:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Select(num4, 1);
					num2 = 8;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 != 0)
					{
						num2 = 8;
					}
				}
				IL_0179:
				flag = text2.StartsWith(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1755067093 ^ -1835025462 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53));
				num = 4;
				continue;
				IL_0263:
				num3 = num6;
				num = 16;
				continue;
				Block_14:
				num = 7;
			}
		}

		// Token: 0x06000300 RID: 768 RVA: 0x0001B0D8 File Offset: 0x000192D8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private string A\u0097\u0099\u0099\u0098\u0099\u0096\u009D\u0094\u008F\u0089()
		{
			int num = 10;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler;
			for (;;)
			{
				int num2 = num;
				int num3;
				int num4;
				int selectionStart;
				for (;;)
				{
					int lineFromCharIndex;
					switch (num2)
					{
					case 1:
						defaultInterpolatedStringHandler.AppendFormatted<int>(lineFromCharIndex + 1);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 2:
						num3--;
						num2 = 7;
						continue;
					case 3:
						defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1362952674 ^ -1526485551 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200));
						num2 = 13;
						continue;
					case 4:
						if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetFirstCharIndexFromLine(num3) != num4)
						{
							goto IL_00C4;
						}
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 != 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					case 5:
						defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(0, 1);
						num2 = 12;
						continue;
					case 6:
						goto IL_014B;
					case 7:
						goto IL_00C4;
					case 8:
						lineFromCharIndex = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetLineFromCharIndex(selectionStart);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 9:
						num4 = selectionStart + this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionLength;
						num2 = 8;
						continue;
					case 10:
						goto IL_007C;
					case 11:
						if (num4 <= 0)
						{
							goto IL_00C4;
						}
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed == 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					case 12:
						defaultInterpolatedStringHandler.AppendFormatted<int>(lineFromCharIndex + 1);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 == 0)
						{
							num2 = 6;
							continue;
						}
						continue;
					case 13:
						defaultInterpolatedStringHandler.AppendFormatted<int>(num3 + 1);
						num2 = 14;
						continue;
					case 14:
						goto IL_005F;
					}
					goto Block_1;
					IL_00C4:
					if (lineFromCharIndex == num3)
					{
						num2 = 5;
					}
					else
					{
						defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(1, 2);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 != 0)
						{
							num2 = 0;
						}
					}
				}
				IL_007C:
				selectionStart = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionStart;
				num = 9;
				continue;
				IL_0097:
				num3 = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetLineFromCharIndex(num4);
				num = 11;
				continue;
				Block_1:
				goto IL_0097;
			}
			IL_005F:
			return defaultInterpolatedStringHandler.ToStringAndClear();
			IL_014B:
			return defaultInterpolatedStringHandler.ToStringAndClear();
		}

		// Token: 0x06000301 RID: 769 RVA: 0x0001B320 File Offset: 0x00019520
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string AA\u0091\u0089\u0089\u0086\u008A\u0099\u0089\u0088\u008D()
		{
			int num = 11;
			StringBuilder stringBuilder;
			for (;;)
			{
				int num2 = num;
				string text;
				int selectionStart;
				int num4;
				int num5;
				for (;;)
				{
					string text2;
					int num3;
					string[] lines;
					string[] array;
					int lineFromCharIndex;
					string text3;
					switch (num2)
					{
					default:
						goto IL_01A1;
					case 1:
						goto IL_032F;
					case 2:
						goto IL_03A1;
					case 3:
						goto IL_0269;
					case 4:
						text = text2;
						num2 = 18;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 == 0)
						{
							num2 = 24;
							continue;
						}
						continue;
					case 5:
						goto IL_032F;
					case 6:
						goto IL_0359;
					case 7:
						goto IL_00E3;
					case 8:
						num3 = 0;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 9:
						if (text != null)
						{
							goto IL_00E3;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 10:
						goto IL_0383;
					case 11:
						selectionStart = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionStart;
						num2 = 10;
						continue;
					case 12:
						break;
					case 13:
						num4--;
						num2 = 23;
						continue;
					case 14:
						goto IL_0167;
					case 15:
						if (text2.StartsWith(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((953756095 - 1838868129) ^ -881823709 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b), StringComparison.OrdinalIgnoreCase))
						{
							num2 = 4;
							continue;
						}
						break;
					case 16:
						goto IL_027F;
					case 17:
						goto IL_02B6;
					case 18:
						goto IL_027F;
					case 19:
						goto IL_048B;
					case 20:
						goto IL_023D;
					case 21:
						array = lines;
						num2 = 8;
						continue;
					case 22:
						lineFromCharIndex = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetLineFromCharIndex(selectionStart);
						num2 = 28;
						continue;
					case 23:
						goto IL_048B;
					case 24:
						goto IL_0133;
					case 25:
						goto IL_0269;
					case 26:
						goto IL_0426;
					case 27:
						goto IL_01BE;
					case 28:
						goto IL_02DA;
					case 29:
						goto IL_03A1;
					case 30:
						if (num5 > 0)
						{
							goto IL_0426;
						}
						num2 = 13;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca == 0)
						{
							num2 = 19;
							continue;
						}
						continue;
					case 31:
						goto IL_0190;
					case 32:
						goto IL_01A1;
					case 33:
						goto IL_0133;
					case 34:
						if (!text3.Trim().StartsWith(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-146834757 ^ 1611059303 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1), StringComparison.OrdinalIgnoreCase))
						{
							goto IL_0167;
						}
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					num3++;
					num2 = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d == 0)
					{
						num2 = 5;
						continue;
					}
					continue;
					IL_00E3:
					stringBuilder.AppendLine(text);
					num2 = 32;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f == 0)
					{
						num2 = 25;
						continue;
					}
					continue;
					IL_0133:
					stringBuilder = new StringBuilder();
					num2 = 9;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c9177097f6d4245975a6f4f2351fc33 != 0)
					{
						num2 = 6;
						continue;
					}
					continue;
					IL_032F:
					if (num3 >= array.Length)
					{
						goto IL_0133;
					}
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c != 0)
					{
						num2 = 3;
						continue;
					}
					continue;
					IL_0167:
					stringBuilder.AppendLine(text3);
					num2 = 16;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_86e848c6696044348a77d8429afaaa88 == 0)
					{
						num2 = 29;
						continue;
					}
					continue;
					IL_0190:
					int num6;
					text3 = lines[num6];
					num2 = 34;
					continue;
					IL_0359:
					if (num6 < lines.Length)
					{
						goto IL_0190;
					}
					num2 = 20;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a != 0)
					{
						num2 = 20;
						continue;
					}
					continue;
					IL_027F:
					if (num6 <= num4)
					{
						goto IL_0359;
					}
					num2 = 12;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
					{
						num2 = 17;
						continue;
					}
					continue;
					IL_01A1:
					num6 = lineFromCharIndex;
					num2 = 18;
					continue;
					IL_0269:
					text2 = array[num3].Trim();
					num2 = 15;
					continue;
					IL_03A1:
					num6++;
					num2 = 16;
					continue;
					IL_0426:
					if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetFirstCharIndexFromLine(num4) == num5)
					{
						num2 = 13;
						continue;
					}
					IL_048B:
					lines = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Lines;
					num2 = 27;
				}
				IL_01BE:
				text = null;
				num = 21;
				continue;
				IL_02DA:
				num4 = this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.GetLineFromCharIndex(num5);
				num = 30;
				continue;
				IL_0383:
				num5 = selectionStart + this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionLength;
				num = 22;
			}
			IL_023D:
			return stringBuilder.ToString().Trim();
			IL_02B6:
			goto IL_023D;
		}

		// Token: 0x06000302 RID: 770 RVA: 0x0001B7D0 File Offset: 0x000199D0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u008F\u0096\u008D\u0087\u0092\u0092\u0086\u008B\u0098\u0094()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor == Color.Gray)
					{
						goto IL_002F;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_002F;
				}
				break;
			}
			goto IL_007F;
			IL_002F:
			return string.Empty;
			IL_007F:
			return this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text.Trim();
		}

		// Token: 0x06000303 RID: 771 RVA: 0x0001B880 File Offset: 0x00019A80
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool AA\u0092\u0099\u0091\u0098\u0091\u0094\u0087\u0099\u009D()
		{
			return this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionLength > 0;
		}

		// Token: 0x06000304 RID: 772 RVA: 0x0001B898 File Offset: 0x00019A98
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u0092\u008C\u009D\u0094\u0093\u0093\u0093\u0090\u0086\u0093()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor == Color.Gray)
					{
						return true;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cfd07f15044a43fbbfaf4b9aecbd2fd6 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
			return string.IsNullOrWhiteSpace(this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text);
		}

		// Token: 0x06000305 RID: 773 RVA: 0x0001B91C File Offset: 0x00019B1C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u008A\u0097\u0096\u008B\u008D\u0095\u008F\u008C\u0094([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 2;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						goto IL_00BA;
					case 2:
						if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor == Color.Gray)
						{
							goto IL_00DE;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 1;
						}
						break;
					case 3:
						this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor = Color.Black;
						num2 = 4;
						break;
					case 4:
						this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectionStart = 0;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 != 0)
						{
							num2 = 0;
						}
						break;
					case 5:
						goto IL_00DE;
					}
				}
				IL_00DE:
				this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(647845501 ^ 1104172021 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_995893e15640499db99898ce289aa393);
				num = 3;
			}
			return;
			IL_00BA:;
		}

		// Token: 0x06000306 RID: 774 RVA: 0x0001BA3C File Offset: 0x00019C3C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008F\u0095\u008D\u0089\u008B\u0094\u0093\u008B\u009E\u0093([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (string.IsNullOrWhiteSpace(this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text))
					{
						goto IL_0037;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor = Color.Gray;
					num2 = 4;
					continue;
				case 3:
					goto IL_0037;
				}
				break;
				IL_0037:
				this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((640005275 >> 6) ^ 1799295293 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231);
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 == 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x06000307 RID: 775 RVA: 0x0001BB40 File Offset: 0x00019D40
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009C\u008A\u008B\u008A\u0090\u0089\u008B\u0090\u0097\u0096([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					break;
				case 2:
					goto IL_00D7;
				case 3:
					goto IL_008F;
				case 4:
					goto IL_006B;
				case 5:
					if (!(this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor == Color.Gray))
					{
						num2 = 4;
						continue;
					}
					goto IL_00D7;
				}
				IL_003C:
				this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor = Color.Black;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 == 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_00D7:
				if (this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text != A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(963518231 ^ 492972570 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f))
				{
					goto IL_003C;
				}
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6671b6ee6ac14cdc851c5f6ed0a20229 != 0)
				{
					num2 = 2;
				}
			}
			return;
			IL_006B:
			IL_008F:;
		}

		// Token: 0x06000308 RID: 776 RVA: 0x0001BC74 File Offset: 0x00019E74
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009D\u0088\u0089\u0094\u0089\u0088\u0092\u009E\u0096\u0092([Nullable(2)] object sender, KeyEventArgs \u0020)
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				string text;
				switch (num2)
				{
				case 0:
					goto IL_012F;
				case 1:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor = Color.Black;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					\u0020.Handled = true;
					num2 = 10;
					continue;
				case 3:
					goto IL_00D2;
				case 4:
					if (\u0020.KeyCode == Keys.V)
					{
						num2 = 2;
						continue;
					}
					return;
				case 5:
					if (\u0020.Control)
					{
						num2 = 4;
						continue;
					}
					return;
				case 6:
					goto IL_012F;
				case 7:
					this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.SelectedText = text;
					num2 = 12;
					continue;
				case 8:
					if (!(this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.ForeColor == Color.Gray))
					{
						num2 = 6;
						continue;
					}
					break;
				case 9:
					break;
				case 10:
					\u0020.SuppressKeyPress = true;
					num2 = 8;
					continue;
				case 11:
					return;
				case 12:
					return;
				default:
					goto IL_012F;
				}
				this.A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093.Text = "";
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 != 0)
				{
					num2 = 1;
					continue;
				}
				continue;
				IL_00D2:
				text = Clipboard.GetText(TextDataFormat.Text);
				num2 = 7;
				continue;
				IL_012F:
				if (Clipboard.ContainsText())
				{
					goto IL_00D2;
				}
				num2 = 9;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed == 0)
				{
					num2 = 11;
				}
			}
		}

		// Token: 0x06000309 RID: 777 RVA: 0x0001BE30 File Offset: 0x0001A030
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u0092\u0094\u0092\u0092\u0095\u0092\u008F\u008E\u0087([Nullable(2)] object s, EventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					return;
				case 2:
				{
					EventHandler a_u0086_u008E_u0094_u009C_u0086_u0086_u0088_u0092_u008A_u008B = this.A\u0086\u008E\u0094\u009C\u0086\u0086\u0088\u0092\u008A\u008B;
					if (a_u0086_u008E_u0094_u009C_u0086_u0086_u0088_u0092_u008A_u008B == null)
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					else
					{
						a_u0086_u008E_u0094_u009C_u0086_u0086_u0088_u0092_u008A_u008B(this, EventArgs.Empty);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b2d055de0c54ba08a92e6c6cd750833 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
				}
				break;
			}
		}

		// Token: 0x0600030A RID: 778 RVA: 0x0001BEC4 File Offset: 0x0001A0C4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0087\u0092\u0087\u0089\u0091\u0095\u009E\u0092\u0096\u0096([Nullable(2)] object s, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0087\u0089\u0090\u0092\u008C\u009C\u0098\u008B\u0091\u0096(true);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600030B RID: 779 RVA: 0x0001BF24 File Offset: 0x0001A124
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0094\u0087\u0099\u008A\u0089\u008D\u009B\u009E\u009D\u0097([Nullable(2)] object s, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0087\u0089\u0090\u0092\u008C\u009C\u0098\u008B\u0091\u0096(false);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600030C RID: 780 RVA: 0x0001BF84 File Offset: 0x0001A184
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0092\u008E\u0093\u0095\u009C\u0097\u008A\u0094\u0089\u0096()
		{
			return A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B.A\u0094\u008E\u0092\u0090\u0088\u0099\u008A\u0092\u008C\u0096 == null;
		}

		// Token: 0x0600030D RID: 781 RVA: 0x0001BF98 File Offset: 0x0001A198
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B A\u009A\u008D\u0088\u009C\u009B\u0099\u0098\u008B\u0090\u009B()
		{
			return A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B.A\u0094\u008E\u0092\u0090\u0088\u0099\u008A\u0092\u008C\u0096;
		}

		// Token: 0x0600030E RID: 782 RVA: 0x0001BFA8 File Offset: 0x0001A1A8
		static A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x040001EE RID: 494
		private readonly object A\u0099\u009C\u009D\u0096\u008C\u008A\u0087\u0094\u0093\u0093;

		// Token: 0x040001EF RID: 495
		[Nullable(2)]
		private ContextMenuStrip A\u009C\u0086\u0090\u008F\u0091\u0091\u009E\u0094\u008D\u0097;

		// Token: 0x040001F0 RID: 496
		[Nullable(2)]
		private ToolStripMenuItem A\u009D\u0094\u009D\u008B\u008A\u0094\u0091\u0094\u009C\u0087;

		// Token: 0x040001F1 RID: 497
		[Nullable(2)]
		[CompilerGenerated]
		private EventHandler A\u0086\u008E\u0094\u009C\u0086\u0086\u0088\u0092\u008A\u008B;

		// Token: 0x040001F2 RID: 498
		internal static object A\u0094\u008E\u0092\u0090\u0088\u0099\u008A\u0092\u008C\u0096;
	}
}
