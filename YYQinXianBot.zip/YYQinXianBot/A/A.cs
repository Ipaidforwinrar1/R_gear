﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000066 RID: 102
	[NullableContext(2)]
	[Nullable(0)]
	public class A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093
	{
		// Token: 0x0600030F RID: 783 RVA: 0x0001BFB0 File Offset: 0x0001A1B0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool AA\u0093\u009B\u0089\u009D\u009E\u0091\u008D\u0097\u009A()
		{
			return this.A\u0095\u008C\u009A\u0098\u0098\u0090\u0092\u0092\u0096\u008F;
		}

		// Token: 0x06000310 RID: 784 RVA: 0x0001BFC0 File Offset: 0x0001A1C0
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008E\u008E\u0091\u0098\u0089\u0088\u0088\u0094\u0099\u009E(Action<int> \u0020)
		{
			int num = 2;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					Action<int> action;
					Action<int> action2;
					Action<int> action3;
					switch (num2)
					{
					case 1:
						goto IL_00C3;
					case 2:
						action = this.A\u0093\u008E\u009D\u0093\u009C\u0092\u008C\u0092\u0099\u0094;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 3:
						if (action == action2)
						{
							goto Block_2;
						}
						goto IL_00C3;
					case 4:
						action3 = (Action<int>)Delegate.Combine(action2, \u0020);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 5:
						return;
					}
					action = Interlocked.CompareExchange<Action<int>>(ref this.A\u0093\u008E\u009D\u0093\u009C\u0092\u008C\u0092\u0099\u0094, action3, action2);
					num2 = 3;
					continue;
					IL_00C3:
					action2 = action;
					num2 = 4;
				}
				Block_2:
				num = 5;
			}
		}

		// Token: 0x06000311 RID: 785 RVA: 0x0001C0A0 File Offset: 0x0001A2A0
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0095\u008C\u008A\u0091\u0099\u0090\u0095\u0092\u008D\u008A(Action<int> \u0020)
		{
			int num = 4;
			for (;;)
			{
				int num2 = num;
				Action<int> action;
				for (;;)
				{
					Action<int> action2;
					Action<int> action3;
					switch (num2)
					{
					case 0:
						goto IL_005F;
					case 1:
						return;
					case 2:
						if (action == action2)
						{
							num2 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
							{
								num2 = 1;
								continue;
							}
							continue;
						}
						break;
					case 3:
						break;
					case 4:
						goto IL_0078;
					case 5:
						action = Interlocked.CompareExchange<Action<int>>(ref this.A\u0093\u008E\u009D\u0093\u009C\u0092\u008C\u0092\u0099\u0094, action3, action2);
						num2 = 2;
						continue;
					default:
						goto IL_005F;
					}
					action2 = action;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
					IL_005F:
					action3 = (Action<int>)Delegate.Remove(action2, \u0020);
					num2 = 5;
				}
				IL_0078:
				action = this.A\u0093\u008E\u009D\u0093\u009C\u0092\u008C\u0092\u0099\u0094;
				num = 3;
			}
		}

		// Token: 0x06000312 RID: 786 RVA: 0x0001C180 File Offset: 0x0001A380
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0095\u009E\u0091\u0091\u0087\u009A\u0096\u008B\u0099\u0089(Action<bool> \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				Action<bool> action;
				Action<bool> action2;
				switch (num2)
				{
				case 1:
					goto IL_008B;
				case 2:
					action = this.A\u009B\u008B\u008B\u0093\u009A\u0089\u008F\u0094\u009C\u0091;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					if (action != action2)
					{
						goto IL_008B;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 4:
				{
					Action<bool> action3;
					action = Interlocked.CompareExchange<Action<bool>>(ref this.A\u009B\u008B\u008B\u0093\u009A\u0089\u008F\u0094\u009C\u0091, action3, action2);
					num2 = 3;
					continue;
				}
				case 5:
				{
					Action<bool> action3 = (Action<bool>)Delegate.Combine(action2, \u0020);
					num2 = 4;
					continue;
				}
				}
				break;
				IL_008B:
				action2 = action;
				num2 = 5;
			}
		}

		// Token: 0x06000313 RID: 787 RVA: 0x0001C25C File Offset: 0x0001A45C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AA\u0087\u0095\u009E\u0095\u0089\u008C\u0094\u008C\u009C(Action<bool> \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				Action<bool> action;
				Action<bool> action3;
				Action<bool> action2;
				switch (num2)
				{
				case 1:
					goto IL_0085;
				case 2:
					action = this.A\u009B\u008B\u008B\u0093\u009A\u0089\u008F\u0094\u009C\u0091;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					action2 = (Action<bool>)Delegate.Remove(action3, \u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 4:
					if (action != action3)
					{
						goto IL_0085;
					}
					num2 = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c9177097f6d4245975a6f4f2351fc33 != 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				case 5:
					return;
				}
				action = Interlocked.CompareExchange<Action<bool>>(ref this.A\u009B\u008B\u008B\u0093\u009A\u0089\u008F\u0094\u009C\u0091, action2, action3);
				num2 = 4;
				continue;
				IL_0085:
				action3 = action;
				num2 = 3;
			}
		}

		// Token: 0x06000314 RID: 788 RVA: 0x0001C34C File Offset: 0x0001A54C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009B\u0099\u0091\u0087\u008A\u0096\u009E\u0090\u0091\u009C(Action<bool?> \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				Action<bool?> action;
				Action<bool?> action2;
				Action<bool?> action3;
				switch (num2)
				{
				case 0:
					goto IL_00B4;
				case 1:
					return;
				case 2:
					if (action == action2)
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					break;
				case 3:
					break;
				case 4:
					action = this.A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C;
					num2 = 3;
					continue;
				case 5:
					action = Interlocked.CompareExchange<Action<bool?>>(ref this.A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C, action3, action2);
					num2 = 2;
					continue;
				default:
					goto IL_00B4;
				}
				action2 = action;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d == 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_00B4:
				action3 = (Action<bool?>)Delegate.Combine(action2, \u0020);
				num2 = 5;
			}
		}

		// Token: 0x06000315 RID: 789 RVA: 0x0001C428 File Offset: 0x0001A628
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0091\u008A\u009B\u0087\u009C\u009B\u009E\u008B\u009C\u0099(Action<bool?> \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				Action<bool?> action;
				Action<bool?> action2;
				Action<bool?> action3;
				switch (num2)
				{
				case 0:
					goto IL_00C9;
				case 1:
					return;
				case 2:
					if (action == action2)
					{
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				case 3:
					break;
				case 4:
					action = this.A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C;
					num2 = 3;
					continue;
				case 5:
					action = Interlocked.CompareExchange<Action<bool?>>(ref this.A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C, action3, action2);
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				default:
					goto IL_00C9;
				}
				action2 = action;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 == 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_00C9:
				action3 = (Action<bool?>)Delegate.Remove(action2, \u0020);
				num2 = 5;
			}
		}

		// Token: 0x06000316 RID: 790 RVA: 0x0001C518 File Offset: 0x0001A718
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093(A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092 \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 == 0)
			{
				num = 0;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					return;
				case 2:
					this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.A\u009E\u0088\u008A\u0088\u008D\u0095\u0098\u0090\u0088\u0092 += this.AA\u0092\u008A\u0087\u0087\u008B\u009E\u0093\u0088\u008D;
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 != 0)
					{
						num = 1;
						continue;
					}
					continue;
				}
				this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086 = \u0020;
				num = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 == 0)
				{
					num = 2;
				}
			}
		}

		// Token: 0x06000317 RID: 791 RVA: 0x0001C5E0 File Offset: 0x0001A7E0
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098> A\u009D\u0094\u009B\u009C\u0088\u0099\u008B\u008B\u0088\u0095(string \u0020, [Nullable(2)] string playSign = null)
		{
			int num = 3;
			int num2 = num;
			A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093.<PlayAsync>d__14 <PlayAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_009F;
				case 2:
					<PlayAsync>d__.<>4__this = this;
					num2 = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				case 3:
					<PlayAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098>.Create();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 4:
					<PlayAsync>d__.<>1__state = -1;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 5:
					<PlayAsync>d__.musicSequence = \u0020;
					num2 = 6;
					continue;
				case 6:
					<PlayAsync>d__.playSign = playSign;
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				<PlayAsync>d__.<>t__builder.Start<A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093.<PlayAsync>d__14>(ref <PlayAsync>d__);
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 == 0)
				{
					num2 = 1;
				}
			}
			IL_009F:
			return <PlayAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000318 RID: 792 RVA: 0x0001C718 File Offset: 0x0001A918
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0088\u008A\u009A\u0091\u0086\u0096\u008A\u008B\u009C\u0088()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.AA\u0089\u0087\u009B\u0089\u0090\u008C\u0095\u0093\u0089();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				case 3:
					return;
				}
				Action<bool?> a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C = this.A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C;
				if (a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C == null)
				{
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca == 0)
					{
						num2 = 2;
					}
				}
				else
				{
					a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C(new bool?(true));
					num2 = 3;
				}
			}
		}

		// Token: 0x06000319 RID: 793 RVA: 0x0001C7C4 File Offset: 0x0001A9C4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009C\u0099\u009C\u0096\u008F\u008F\u0097\u0094\u008E\u009C()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					Action<bool?> a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C = this.A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C;
					if (a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C == null)
					{
						num2 = 3;
						continue;
					}
					a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C(new bool?(false));
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 2:
					this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.AA\u0099\u008C\u009D\u0087\u0099\u008E\u009E\u008D\u008A();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					return;
				}
				break;
			}
		}

		// Token: 0x0600031A RID: 794 RVA: 0x0001C878 File Offset: 0x0001AA78
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008A\u0095\u0099\u0089\u009E\u0095\u008F\u0092\u009A\u009A()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					this.A\u009C\u0099\u009C\u0096\u008F\u008F\u0097\u0094\u008E\u009C();
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b == 0)
					{
						num2 = 0;
					}
					break;
				case 1:
					if (this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.A\u009E\u009E\u009D\u0087\u009A\u0089\u009B\u0094\u009D\u0092())
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 == 0)
						{
							num2 = 0;
						}
					}
					else
					{
						this.A\u0088\u008A\u009A\u0091\u0086\u0096\u008A\u008B\u009C\u0088();
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd != 0)
						{
							num2 = 2;
						}
					}
					break;
				case 2:
					return;
				case 3:
					return;
				}
			}
		}

		// Token: 0x0600031B RID: 795 RVA: 0x0001C934 File Offset: 0x0001AB34
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008E\u0098\u008F\u008F\u008B\u008F\u0094\u0090\u0097\u008C()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.A\u009C\u0091\u0097\u0098\u008A\u0099\u008D\u0092\u0096\u0092();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600031C RID: 796 RVA: 0x0001C998 File Offset: 0x0001AB98
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AA\u0095\u0098\u009D\u0088\u0087\u0088\u0092\u0087\u009A(double \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.A\u008E\u0094\u0087\u008B\u0093\u009D\u0092\u0094\u008B\u008C(\u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					if (this.A\u0095\u008C\u009A\u0098\u0098\u0090\u0092\u0092\u0096\u008F)
					{
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					break;
				}
				break;
			}
		}

		// Token: 0x0600031D RID: 797 RVA: 0x0001CA2C File Offset: 0x0001AC2C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0097\u009D\u008A\u0088\u008C\u0094\u008F\u0090\u0090\u008C(double \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.A\u0094\u008F\u008E\u008D\u009E\u0099\u009E\u0090\u008C\u0096(\u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600031E RID: 798 RVA: 0x0001CA90 File Offset: 0x0001AC90
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0087\u0099\u009D\u009E\u009E\u0099\u0086\u008B\u0087\u008D(bool \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.A\u008A\u0087\u009D\u0089\u0087\u009B\u0098\u0090\u0093\u0097(\u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600031F RID: 799 RVA: 0x0001CAF4 File Offset: 0x0001ACF4
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u008C\u0091\u0088\u0092\u009D\u0098\u008D\u009E\u0093\u008E(string \u0020)
		{
			return this.A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086.A\u0086\u008F\u0094\u0090\u008E\u009C\u009B\u008B\u0086\u009C(\u0020);
		}

		// Token: 0x06000320 RID: 800 RVA: 0x0001CB0C File Offset: 0x0001AD0C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task A\u009A\u0097\u008C\u0099\u0092\u008F\u008C\u0090\u009D\u0093()
		{
			int num = 1;
			int num2 = num;
			A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093.<InitializePlaybackAsync>d__23 <InitializePlaybackAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<InitializePlaybackAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_0037;
				case 3:
					<InitializePlaybackAsync>d__.<>1__state = -1;
					num2 = 4;
					continue;
				case 4:
					<InitializePlaybackAsync>d__.<>t__builder.Start<A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093.<InitializePlaybackAsync>d__23>(ref <InitializePlaybackAsync>d__);
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				<InitializePlaybackAsync>d__.<>4__this = this;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_995893e15640499db99898ce289aa393 == 0)
				{
					num2 = 0;
				}
			}
			IL_0037:
			return <InitializePlaybackAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000321 RID: 801 RVA: 0x0001CBF0 File Offset: 0x0001ADF0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0088\u0086\u0091\u0099\u009C\u009C\u0086\u0094\u0092\u008B()
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					break;
				case 2:
					return;
				case 3:
				{
					Action<bool> a_u009B_u008B_u008B_u0093_u009A_u0089_u008F_u0094_u009C_u = this.A\u009B\u008B\u008B\u0093\u009A\u0089\u008F\u0094\u009C\u0091;
					if (a_u009B_u008B_u008B_u0093_u009A_u0089_u008F_u0094_u009C_u == null)
					{
						num2 = 5;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75 == 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					}
					else
					{
						a_u009B_u008B_u008B_u0093_u009A_u0089_u008F_u0094_u009C_u(false);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					break;
				}
				case 4:
					this.A\u0095\u008C\u009A\u0098\u0098\u0090\u0092\u0092\u0096\u008F = false;
					num2 = 3;
					continue;
				case 5:
					break;
				case 6:
					goto IL_010F;
				case 7:
					goto IL_010F;
				}
				Action<bool?> a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C = this.A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C;
				if (a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C != null)
				{
					a_u0086_u008B_u0093_u008D_u0094_u0094_u0098_u008B_u009B_u009C(null);
					num2 = 7;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f != 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				}
				else
				{
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b != 0)
					{
						num2 = 6;
						continue;
					}
					continue;
				}
				IL_010F:
				Action<int> a_u0093_u008E_u009D_u0093_u009C_u0092_u008C_u0092_u0099_u = this.A\u0093\u008E\u009D\u0093\u009C\u0092\u008C\u0092\u0099\u0094;
				if (a_u0093_u008E_u009D_u0093_u009C_u0092_u008C_u0092_u0099_u != null)
				{
					a_u0093_u008E_u009D_u0093_u009C_u0092_u008C_u0092_u0099_u(0);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f == 0)
					{
						num2 = 0;
					}
				}
				else
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x06000322 RID: 802 RVA: 0x0001CD50 File Offset: 0x0001AF50
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u0092\u008A\u0087\u0087\u008B\u009E\u0093\u0088\u008D(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					Action<int> a_u0093_u008E_u009D_u0093_u009C_u0092_u008C_u0092_u0099_u = this.A\u0093\u008E\u009D\u0093\u009C\u0092\u008C\u0092\u0099\u0094;
					if (a_u0093_u008E_u009D_u0093_u009C_u0092_u008C_u0092_u0099_u != null)
					{
						a_u0093_u008E_u009D_u0093_u009C_u0092_u008C_u0092_u0099_u(\u0020);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					else
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
				case 2:
					return;
				}
				break;
			}
		}

		// Token: 0x06000323 RID: 803 RVA: 0x0001CDE4 File Offset: 0x0001AFE4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0088\u009E\u009E\u009D\u0086\u009A\u008B\u0090\u008C\u0098()
		{
			return A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093.A\u0099\u008B\u008D\u0096\u008C\u0091\u008F\u009E\u0099\u008B == null;
		}

		// Token: 0x06000324 RID: 804 RVA: 0x0001CDF8 File Offset: 0x0001AFF8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093 A\u0088\u009C\u008A\u0090\u0096\u009C\u0097\u0094\u009A\u0091()
		{
			return A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093.A\u0099\u008B\u008D\u0096\u008C\u0091\u008F\u009E\u0099\u008B;
		}

		// Token: 0x06000325 RID: 805 RVA: 0x0001CE08 File Offset: 0x0001B008
		static A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x040001F3 RID: 499
		[Nullable(1)]
		private readonly A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092 A\u008C\u009A\u0099\u0097\u0087\u0097\u0090\u0094\u009C\u0086;

		// Token: 0x040001F4 RID: 500
		private bool A\u0095\u008C\u009A\u0098\u0098\u0090\u0092\u0092\u0096\u008F;

		// Token: 0x040001F5 RID: 501
		[CompilerGenerated]
		private Action<int> A\u0093\u008E\u009D\u0093\u009C\u0092\u008C\u0092\u0099\u0094;

		// Token: 0x040001F6 RID: 502
		[CompilerGenerated]
		private Action<bool> A\u009B\u008B\u008B\u0093\u009A\u0089\u008F\u0094\u009C\u0091;

		// Token: 0x040001F7 RID: 503
		[CompilerGenerated]
		private Action<bool?> A\u0086\u008B\u0093\u008D\u0094\u0094\u0098\u008B\u009B\u009C;

		// Token: 0x040001F8 RID: 504
		internal static object A\u0099\u008B\u008D\u0096\u008C\u0091\u008F\u009E\u0099\u008B;
	}
}
