﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200003D RID: 61
	[Nullable(0)]
	[NullableContext(1)]
	public class AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E
	{
		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060001A5 RID: 421 RVA: 0x0000FEBC File Offset: 0x0000E0BC
		// (set) Token: 0x060001A6 RID: 422 RVA: 0x0000FECC File Offset: 0x0000E0CC
		[JsonPropertyName("expire_time")]
		public long A\u008B\u009B\u009A\u008D\u009E\u008C\u009D\u008B\u0086\u008C
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u009A\u0094\u0094\u0092\u0089\u009D\u0094\u0094\u0090\u008F;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u009A\u0094\u0094\u0092\u0089\u009D\u0094\u0094\u0090\u008F = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x0000FF2C File Offset: 0x0000E12C
		// (set) Token: 0x060001A8 RID: 424 RVA: 0x0000FF3C File Offset: 0x0000E13C
		[JsonPropertyName("token")]
		public string A\u0097\u009C\u009B\u0094\u009A\u0093\u0090\u008B\u0092\u0098
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.AA\u009A\u0093\u0092\u008C\u008F\u0098\u009B\u0098\u009B;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.AA\u009A\u0093\u0092\u008C\u008F\u0098\u009B\u0098\u009B = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x060001A9 RID: 425 RVA: 0x0000FF9C File Offset: 0x0000E19C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.AA\u009A\u0093\u0092\u008C\u008F\u0098\u009B\u0098\u009B = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001AA RID: 426 RVA: 0x00010010 File Offset: 0x0000E210
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008E\u008A\u008C\u009A\u0099\u0086\u009C\u0094\u008F\u009D()
		{
			return AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E.A\u009C\u0097\u0092\u008D\u0097\u008C\u0087\u008B\u009E\u008D == null;
		}

		// Token: 0x060001AB RID: 427 RVA: 0x00010024 File Offset: 0x0000E224
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E A\u0089\u0090\u0086\u0094\u0086\u008E\u0094\u0090\u009B\u008A()
		{
			return AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E.A\u009C\u0097\u0092\u008D\u0097\u008C\u0087\u008B\u009E\u008D;
		}

		// Token: 0x060001AC RID: 428 RVA: 0x00010034 File Offset: 0x0000E234
		static AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400013F RID: 319
		[CompilerGenerated]
		private long A\u009A\u0094\u0094\u0092\u0089\u009D\u0094\u0094\u0090\u008F;

		// Token: 0x04000140 RID: 320
		[CompilerGenerated]
		private string AA\u009A\u0093\u0092\u008C\u008F\u0098\u009B\u0098\u009B;

		// Token: 0x04000141 RID: 321
		internal static object A\u009C\u0097\u0092\u008D\u0097\u008C\u0087\u008B\u009E\u008D;
	}
}
