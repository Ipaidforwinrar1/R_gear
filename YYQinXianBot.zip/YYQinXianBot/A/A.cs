﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200003E RID: 62
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087
	{
		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060001AD RID: 429 RVA: 0x0001003C File Offset: 0x0000E23C
		// (set) Token: 0x060001AE RID: 430 RVA: 0x0001004C File Offset: 0x0000E24C
		[JsonPropertyName("list")]
		public List<A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099> A\u0098\u008D\u009C\u009C\u0087\u008F\u0089\u008B\u009D\u0091
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u008E\u009B\u009D\u0098\u0090\u0086\u0094\u0092\u0088\u008C;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u008E\u009B\u009D\u0098\u0090\u0086\u0094\u0092\u0088\u008C = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce != 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060001AF RID: 431 RVA: 0x000100AC File Offset: 0x0000E2AC
		// (set) Token: 0x060001B0 RID: 432 RVA: 0x000100BC File Offset: 0x0000E2BC
		[JsonPropertyName("count")]
		public int AA\u008D\u009C\u009A\u009D\u009A\u008F\u0088\u0090\u0093
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0091\u0097\u0095\u008B\u009A\u008E\u009B\u0092\u0091\u0099;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0091\u0097\u0095\u008B\u009A\u008E\u009B\u0092\u0091\u0099 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f == 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x060001B1 RID: 433 RVA: 0x0001011C File Offset: 0x0000E31C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u008E\u009B\u009D\u0098\u0090\u0086\u0094\u0092\u0088\u008C = new List<A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099>();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6fdef4c9fb0147c3b3aa646e625fdd4d == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001B2 RID: 434 RVA: 0x00010190 File Offset: 0x0000E390
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0086\u008F\u0097\u0088\u0094\u0092\u008F\u0094\u0087\u0093()
		{
			return A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087.A\u0087\u009D\u0094\u0086\u0092\u0088\u008D\u0092\u008D\u0098 == null;
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x000101A4 File Offset: 0x0000E3A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087 A\u009D\u0097\u009B\u008E\u0092\u0099\u0086\u009E\u008D\u0095()
		{
			return A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087.A\u0087\u009D\u0094\u0086\u0092\u0088\u008D\u0092\u008D\u0098;
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x000101B4 File Offset: 0x0000E3B4
		static A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000142 RID: 322
		[CompilerGenerated]
		private List<A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099> A\u008E\u009B\u009D\u0098\u0090\u0086\u0094\u0092\u0088\u008C;

		// Token: 0x04000143 RID: 323
		[CompilerGenerated]
		private int A\u0091\u0097\u0095\u008B\u009A\u008E\u009B\u0092\u0091\u0099;

		// Token: 0x04000144 RID: 324
		internal static object A\u0087\u009D\u0094\u0086\u0092\u0088\u008D\u0092\u008D\u0098;
	}
}
