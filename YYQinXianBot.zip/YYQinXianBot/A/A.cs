﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000042 RID: 66
	public class A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D
	{
		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060001CF RID: 463 RVA: 0x000106BC File Offset: 0x0000E8BC
		// (set) Token: 0x060001D0 RID: 464 RVA: 0x000106CC File Offset: 0x0000E8CC
		[JsonPropertyName("days")]
		public int AA\u008C\u008F\u0097\u009E\u0094\u0088\u009A\u0094\u0092
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0097\u0096\u008A\u0094\u0098\u009E\u0089\u008B\u0097\u0089;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0097\u0096\u008A\u0094\u0098\u009E\u0089\u008B\u0097\u0089 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 == 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0001072C File Offset: 0x0000E92C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6123357505a5405392c0339436988b0a == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x00010790 File Offset: 0x0000E990
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0095\u008E\u008F\u0095\u0087\u0086\u0096\u0090\u0086\u0099()
		{
			return A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D.A\u0091\u009E\u0093\u009C\u008D\u0088\u008A\u009E\u0088\u008F == null;
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x000107A4 File Offset: 0x0000E9A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D A\u0090\u009A\u0097\u009A\u0091\u008C\u0087\u008B\u0092\u0092()
		{
			return A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D.A\u0091\u009E\u0093\u009C\u008D\u0088\u008A\u009E\u0088\u008F;
		}

		// Token: 0x060001D4 RID: 468 RVA: 0x000107B4 File Offset: 0x0000E9B4
		static A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400014F RID: 335
		[CompilerGenerated]
		private int A\u0097\u0096\u008A\u0094\u0098\u009E\u0089\u008B\u0097\u0089;

		// Token: 0x04000150 RID: 336
		internal static object A\u0091\u009E\u0093\u009C\u008D\u0088\u008A\u009E\u0088\u008F;
	}
}
