﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000040 RID: 64
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095
	{
		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060001BD RID: 445 RVA: 0x0001033C File Offset: 0x0000E53C
		// (set) Token: 0x060001BE RID: 446 RVA: 0x0001034C File Offset: 0x0000E54C
		[JsonPropertyName("content")]
		public string AA\u0097\u0087\u0099\u0094\u0089\u009E\u0089\u0086\u009D
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0099\u0089\u008D\u008A\u008C\u0095\u009D\u008B\u0094\u009B;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0099\u0089\u008D\u008A\u008C\u0095\u009D\u008B\u0094\u009B = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1803988e08d94458a1484838316ae19f == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060001BF RID: 447 RVA: 0x000103AC File Offset: 0x0000E5AC
		// (set) Token: 0x060001C0 RID: 448 RVA: 0x000103BC File Offset: 0x0000E5BC
		[JsonPropertyName("sign")]
		public string A\u008E\u009A\u009E\u008E\u009D\u0089\u008B\u008B\u0092\u0089
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.AAA\u008A\u0089\u0095\u0091\u0088\u0087\u008B\u008E;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.AAA\u008A\u0089\u0095\u0091\u0088\u0087\u008B\u008E = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a != 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x060001C1 RID: 449 RVA: 0x0001041C File Offset: 0x0000E61C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0099\u0089\u008D\u008A\u008C\u0095\u009D\u008B\u0094\u009B = string.Empty;
			this.AAA\u008A\u0089\u0095\u0091\u0088\u0087\u008B\u008E = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001C2 RID: 450 RVA: 0x000104A0 File Offset: 0x0000E6A0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0090\u008B\u0088\u008C\u008D\u0091\u009D\u0094\u0088\u008F()
		{
			return A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095.A\u0099\u009C\u009A\u008D\u008C\u009C\u0086\u0090\u0095\u008D == null;
		}

		// Token: 0x060001C3 RID: 451 RVA: 0x000104B4 File Offset: 0x0000E6B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095 A\u0093\u0091\u0093\u0098\u0091\u0088\u008A\u009E\u0089\u008D()
		{
			return A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095.A\u0099\u009C\u009A\u008D\u008C\u009C\u0086\u0090\u0095\u008D;
		}

		// Token: 0x060001C4 RID: 452 RVA: 0x000104C4 File Offset: 0x0000E6C4
		static A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000148 RID: 328
		[CompilerGenerated]
		private string A\u0099\u0089\u008D\u008A\u008C\u0095\u009D\u008B\u0094\u009B;

		// Token: 0x04000149 RID: 329
		[CompilerGenerated]
		private string AAA\u008A\u0089\u0095\u0091\u0088\u0087\u008B\u008E;

		// Token: 0x0400014A RID: 330
		private static object A\u0099\u009C\u009A\u008D\u008C\u009C\u0086\u0090\u0095\u008D;
	}
}
