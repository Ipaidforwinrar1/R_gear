﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000041 RID: 65
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089
	{
		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060001C5 RID: 453 RVA: 0x000104CC File Offset: 0x0000E6CC
		// (set) Token: 0x060001C6 RID: 454 RVA: 0x000104DC File Offset: 0x0000E6DC
		[JsonPropertyName("username")]
		public string A\u008F\u008A\u0087\u0097\u0090\u0095\u0099\u0092\u009D\u008F
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0097\u0086\u009E\u0099\u0095\u008D\u008F\u0092\u0098\u009E;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0097\u0086\u009E\u0099\u0095\u008D\u008F\u0092\u0098\u009E = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060001C7 RID: 455 RVA: 0x0001053C File Offset: 0x0000E73C
		// (set) Token: 0x060001C8 RID: 456 RVA: 0x0001054C File Offset: 0x0000E74C
		[JsonPropertyName("type")]
		public int AA\u0095\u008E\u0093\u0088\u008C\u0090\u0090\u0098\u008E
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0095\u0090\u008D\u008D\u0088\u0090\u0090\u0090\u0094\u008E;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0095\u0090\u008D\u008D\u0088\u0090\u0090\u0090\u0094\u008E = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b7fd23e09aa54f94a15e32978d45910b != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060001C9 RID: 457 RVA: 0x000105AC File Offset: 0x0000E7AC
		// (set) Token: 0x060001CA RID: 458 RVA: 0x000105BC File Offset: 0x0000E7BC
		[JsonPropertyName("expire_time")]
		public long AA\u009D\u008E\u0098\u0099\u009E\u0092\u008F\u009D\u0087
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0086\u0094\u009D\u008A\u0094\u0094\u009D\u0090\u0090\u0097;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0086\u0094\u009D\u008A\u0094\u0094\u009D\u0090\u0090\u0097 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 == 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0001061C File Offset: 0x0000E81C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0097\u0086\u009E\u0099\u0095\u008D\u008F\u0092\u0098\u009E = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001CC RID: 460 RVA: 0x00010690 File Offset: 0x0000E890
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008D\u0098\u009C\u0091\u0091\u0091\u0096\u0090\u0094\u0087()
		{
			return A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089.AA\u0096\u0089\u0099\u0096\u0095\u0089\u008E\u008B\u008F == null;
		}

		// Token: 0x060001CD RID: 461 RVA: 0x000106A4 File Offset: 0x0000E8A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089 A\u008B\u0089\u009D\u0089\u0089\u0093\u009D\u008B\u008E\u009B()
		{
			return A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089.AA\u0096\u0089\u0099\u0096\u0095\u0089\u008E\u008B\u008F;
		}

		// Token: 0x060001CE RID: 462 RVA: 0x000106B4 File Offset: 0x0000E8B4
		static A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400014B RID: 331
		[CompilerGenerated]
		private string A\u0097\u0086\u009E\u0099\u0095\u008D\u008F\u0092\u0098\u009E;

		// Token: 0x0400014C RID: 332
		[CompilerGenerated]
		private int A\u0095\u0090\u008D\u008D\u0088\u0090\u0090\u0090\u0094\u008E;

		// Token: 0x0400014D RID: 333
		[CompilerGenerated]
		private long A\u0086\u0094\u009D\u008A\u0094\u0094\u009D\u0090\u0090\u0097;

		// Token: 0x0400014E RID: 334
		internal static object AA\u0096\u0089\u0099\u0096\u0095\u0089\u008E\u008B\u008F;
	}
}
