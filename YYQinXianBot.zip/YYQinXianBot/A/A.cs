﻿using System;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000053 RID: 83
	public enum A\u009E\u0093\u0091\u008A\u0098\u0087\u0097\u0094\u0096\u0090
	{

	}
}
