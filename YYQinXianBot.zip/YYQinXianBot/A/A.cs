﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000061 RID: 97
	public partial class A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092 : Form
	{
		// Token: 0x060002E1 RID: 737 RVA: 0x00018C00 File Offset: 0x00016E00
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 == 0)
			{
				num = 0;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098.TextChanged += this.A\u0086\u0097\u0094\u0096\u008B\u009C\u0095\u008B\u0093\u0091;
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
					{
						num = 6;
						continue;
					}
					continue;
				case 2:
					this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093.KeyPress += this.A\u0092\u0098\u008A\u009B\u008D\u008F\u0092\u009E\u0098\u0093;
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
					{
						num = 5;
						continue;
					}
					continue;
				case 3:
					this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098.KeyPress += this.A\u0092\u0098\u008A\u009B\u008D\u008F\u0092\u009E\u0098\u0093;
					num = 2;
					continue;
				case 4:
					this.A\u0093\u0097\u0099\u0091\u0094\u008B\u0089\u0092\u0098\u0092();
					num = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 != 0)
					{
						num = 8;
						continue;
					}
					continue;
				case 5:
					this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093.TextChanged += this.A\u0086\u0097\u0094\u0096\u008B\u009C\u0095\u008B\u0093\u0091;
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 != 0)
					{
						num = 1;
						continue;
					}
					continue;
				case 6:
					this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093.TextChanged += this.A\u0086\u0097\u0094\u0096\u008B\u009C\u0095\u008B\u0093\u0091;
					num = 7;
					continue;
				case 7:
					return;
				case 8:
				{
					this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093.KeyPress += this.A\u009C\u008D\u0096\u0091\u008C\u0098\u0089\u0090\u008D\u0086;
					int num2 = 3;
					num = num2;
					continue;
				}
				}
				this.A\u008D\u008C\u009B\u009D\u0095\u0094\u0096\u0090\u0089\u0089();
				num = 4;
			}
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x00018DC4 File Offset: 0x00016FC4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0093\u0097\u0099\u0091\u0094\u008B\u0089\u0092\u0098\u0092()
		{
			switch (1)
			{
			case 1:
				try
				{
					Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1648996374 + 313516088) ^ -1776534751 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583));
					int num = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 != 0)
					{
						num = 2;
					}
					for (;;)
					{
						switch (num)
						{
						case 1:
							goto IL_00F8;
						case 2:
							goto IL_0097;
						case 3:
							if (manifestResourceStream == null)
							{
								num = 2;
								continue;
							}
							break;
						}
						base.Icon = new Icon(manifestResourceStream);
						num = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a != 0)
						{
							num = 1;
						}
					}
					IL_0097:
					IL_00F8:;
				}
				catch
				{
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 != 0)
					{
						num2 = 0;
					}
					switch (num2)
					{
					}
				}
				break;
			}
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x00018F34 File Offset: 0x00017134
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009C\u008D\u0096\u0091\u008C\u0098\u0089\u0090\u008D\u0086([Nullable(2)] object sender, KeyPressEventArgs \u0020)
		{
			int num = 3;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						return;
					case 2:
						if (char.IsLetterOrDigit(\u0020.KeyChar))
						{
							return;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 3:
						if (!char.IsControl(\u0020.KeyChar))
						{
							num2 = 2;
							continue;
						}
						return;
					case 4:
						return;
					}
					break;
				}
				IL_0067:
				\u0020.Handled = true;
				num = 4;
				continue;
				goto IL_0067;
			}
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x00018FFC File Offset: 0x000171FC
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0092\u0098\u008A\u009B\u008D\u008F\u0092\u009E\u0098\u0093([Nullable(2)] object sender, KeyPressEventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (char.IsLetterOrDigit(\u0020.KeyChar))
					{
						return;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3e7119b219884fb89fd2909088fcea1c == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					if (char.IsControl(\u0020.KeyChar))
					{
						return;
					}
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_187f5dc9d63847ebb305df4c3a07e8c9 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					return;
				case 4:
					return;
				}
				\u0020.Handled = true;
				num2 = 4;
			}
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x000190C0 File Offset: 0x000172C0
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0086\u0097\u0094\u0096\u008B\u009C\u0095\u008B\u0093\u0091([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 6;
			for (;;)
			{
				int num2 = num;
				TextBox textBox;
				string text;
				int selectionStart;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						goto IL_0148;
					case 2:
						textBox.Text = text;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 3:
						if (text != textBox.Text)
						{
							goto Block_3;
						}
						goto IL_0068;
					case 4:
						text = Regex.Replace(textBox.Text, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((28686127 >> 6) ^ 840323878 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d), "");
						num2 = 3;
						continue;
					case 5:
						if (textBox != null)
						{
							num2 = 7;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 != 0)
							{
								num2 = 0;
								continue;
							}
							continue;
						}
						break;
					case 6:
						textBox = sender as TextBox;
						num2 = 5;
						continue;
					case 7:
						textBox.TextChanged -= this.A\u0086\u0097\u0094\u0096\u008B\u009C\u0095\u008B\u0093\u0091;
						num2 = 9;
						continue;
					case 8:
						goto IL_0068;
					case 9:
						selectionStart = textBox.SelectionStart;
						num2 = 4;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 == 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					}
					return;
					IL_0068:
					textBox.TextChanged += this.A\u0086\u0097\u0094\u0096\u008B\u009C\u0095\u008B\u0093\u0091;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca == 0)
					{
						num2 = 0;
					}
				}
				Block_3:
				num = 2;
				continue;
				IL_0148:
				textBox.SelectionStart = Math.Min(selectionStart, text.Length);
				num = 8;
			}
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x00019274 File Offset: 0x00017474
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0093\u0096\u0086\u009B\u009C\u0096\u0097\u009E\u008F\u008C([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092.<btnRegister_Click>d__5 <btnRegister_Click>d__;
				switch (num2)
				{
				case 1:
					<btnRegister_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7374b39cd1dd42699e43c77815e1074b == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					<btnRegister_Click>d__.<>1__state = -1;
					num2 = 3;
					continue;
				case 3:
					<btnRegister_Click>d__.<>t__builder.Start<A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092.<btnRegister_Click>d__5>(ref <btnRegister_Click>d__);
					num2 = 4;
					continue;
				case 4:
					return;
				}
				<btnRegister_Click>d__.<>4__this = this;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8a7706961f2842d0974d2f2cdf994020 == 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x00019334 File Offset: 0x00017534
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task A\u009C\u0088\u0089\u0090\u009D\u0090\u0093\u0090\u0088\u0099()
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[0];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_0088;
				}
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(26, array, this);
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3f1903d0114e4a7ea4b860c994faf9cc == 0)
				{
					num2 = 2;
				}
			}
			IL_0088:
			return (Task)array2[0];
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x000193D4 File Offset: 0x000175D4
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0086\u0096\u0095\u009E\u008E\u009C\u0086\u0094\u0096\u009B([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					base.DialogResult = DialogResult.Cancel;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				}
				base.Close();
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b == 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x060002EA RID: 746 RVA: 0x00019540 File Offset: 0x00017740
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008D\u008C\u009B\u009D\u0095\u0094\u0096\u0090\u0089\u0089()
		{
			int num = 23;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-364525890 ^ -2140010087 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f);
						num2 = 9;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 2:
						this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D.AutoSize = true;
						num2 = 12;
						continue;
					case 3:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.Click += this.A\u0086\u0096\u0095\u009E\u008E\u009C\u0086\u0094\u0096\u009B;
						num2 = 7;
						continue;
					case 4:
						base.SuspendLayout();
						num2 = 14;
						continue;
					case 5:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-1565293842 ^ 1024361630 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 6:
						this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1241912462 ^ 1403165631 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5);
						num2 = 60;
						continue;
					case 7:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E.AutoSize = true;
						num2 = 43;
						continue;
					case 8:
						this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1851001565 ^ 1407063691 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2), 10f);
						num2 = 57;
						continue;
					case 9:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C.Size = new Size(49, 14);
						num2 = 13;
						continue;
					case 10:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E.Size = new Size(49, 14);
						num2 = 38;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
						{
							num2 = 58;
							continue;
						}
						continue;
					case 11:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1212942792 - -201431463) ^ -2107113128 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
						{
							num2 = 10;
							continue;
						}
						continue;
					case 12:
						goto IL_01E2;
					case 13:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C.TabIndex = 1;
						num2 = 5;
						continue;
					case 14:
						goto IL_0A2E;
					case 15:
						this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093.Location = new Point(100, 22);
						num2 = 26;
						continue;
					case 16:
						this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093.TabIndex = 0;
						num2 = 8;
						continue;
					case 17:
						this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093.Location = new Point(100, 102);
						num2 = 6;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 18:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1588658860 ^ 1822527850 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d);
						num2 = 75;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a != 0)
						{
							num2 = 32;
							continue;
						}
						continue;
					case 19:
						this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098.Size = new Size(220, 23);
						num2 = 25;
						continue;
					case 20:
						this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1537144870 >> 1) ^ -1256331267 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc);
						num2 = 36;
						continue;
					case 21:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.UseVisualStyleBackColor = true;
						num2 = 3;
						continue;
					case 22:
						this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098 = new TextBox();
						num2 = 73;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					case 23:
						this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093 = new TextBox();
						num2 = 22;
						continue;
					case 24:
						base.AutoScaleMode = AutoScaleMode.Font;
						num2 = 64;
						continue;
					case 25:
						this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098.TabIndex = 1;
						num2 = 39;
						continue;
					case 26:
						this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-922289810 ^ -667339832 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b);
						num2 = 30;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 27:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E = new Button();
						num2 = 41;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb == 0)
						{
							num2 = 5;
							continue;
						}
						continue;
					case 28:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.TabIndex = 3;
						num2 = 18;
						continue;
					case 29:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E = new Label();
						num2 = 25;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
						{
							num2 = 35;
							continue;
						}
						continue;
					case 30:
						this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093.Size = new Size(220, 23);
						num2 = 16;
						continue;
					case 31:
						base.FormBorderStyle = FormBorderStyle.FixedDialog;
						num2 = 52;
						continue;
					case 32:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.Size = new Size(100, 32);
						num2 = 28;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 33:
						base.Controls.Add(this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098);
						num2 = 56;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb != 0)
						{
							num2 = 65;
							continue;
						}
						continue;
					case 34:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(4868914 ^ 1499481393 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904);
						num2 = 21;
						continue;
					case 35:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C = new Label();
						num2 = 51;
						continue;
					case 36:
						goto IL_0728;
					case 37:
						this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D.TabIndex = 2;
						num2 = 69;
						continue;
					case 38:
						base.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--266838818 ^ 400555953 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca);
						num2 = 48;
						continue;
					case 39:
						this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1187404492 ^ -646230697 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0), 10f);
						num2 = 17;
						continue;
					case 40:
						base.Controls.Add(this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093);
						num2 = 50;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b2d055de0c54ba08a92e6c6cd750833 != 0)
						{
							num2 = 7;
							continue;
						}
						continue;
					case 41:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D = new Button();
						num2 = 24;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d375a57ab5714e038011351b58752657 == 0)
						{
							num2 = 29;
							continue;
						}
						continue;
					case 42:
						base.Controls.Add(this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093);
						num2 = 62;
						continue;
					case 43:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(647845501 ^ 1987858796 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590), 10f);
						num2 = 78;
						continue;
					case 44:
						return;
					case 45:
						base.Controls.Add(this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E);
						num2 = 40;
						continue;
					case 46:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C.Location = new Point(20, 65);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 47:
						this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D.Location = new Point(6, 105);
						num2 = 20;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 48:
						base.StartPosition = FormStartPosition.CenterParent;
						num2 = 52;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 70;
							continue;
						}
						continue;
					case 49:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1212942792 - -201431463) ^ -831755399 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c);
						num2 = 32;
						continue;
					case 50:
						base.Controls.Add(this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D);
						num2 = 33;
						continue;
					case 51:
						goto IL_04E2;
					case 52:
						base.MaximizeBox = false;
						num2 = 74;
						continue;
					case 53:
						this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1744734314 ^ -1233347655 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6);
						num2 = 19;
						continue;
					case 54:
						base.PerformLayout();
						num2 = 44;
						continue;
					case 55:
						goto IL_061A;
					case 56:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-1029050055 ^ 1943007170 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb), 10f);
						num2 = 72;
						continue;
					case 57:
						this.A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098.Location = new Point(100, 62);
						num2 = 53;
						continue;
					case 58:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E.TabIndex = 0;
						num2 = 63;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f == 0)
						{
							num2 = 59;
							continue;
						}
						continue;
					case 59:
						base.Controls.Add(this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D);
						num2 = 45;
						continue;
					case 60:
						this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093.Size = new Size(220, 23);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 61:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(647845501 ^ 1051659890 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850), 10f);
						num2 = 71;
						continue;
					case 62:
						base.Controls.Add(this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E);
						num2 = 31;
						continue;
					case 63:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(707542027 ^ 406628849 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d);
						num2 = 79;
						continue;
					case 64:
						base.ClientSize = new Size(350, 205);
						num2 = 59;
						continue;
					case 65:
						base.Controls.Add(this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C);
						num2 = 19;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 == 0)
						{
							num2 = 42;
							continue;
						}
						continue;
					case 66:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.TabIndex = 4;
						num2 = 34;
						continue;
					case 67:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.Size = new Size(100, 32);
						num2 = 52;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 != 0)
						{
							num2 = 66;
							continue;
						}
						continue;
					case 68:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.Click += this.A\u0093\u0096\u0086\u009B\u009C\u0096\u0097\u009E\u008F\u008C;
						num2 = 61;
						continue;
					case 69:
						this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(608632954 ^ 1124730498 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_995893e15640499db99898ce289aa393);
						num2 = 80;
						continue;
					case 70:
						this.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-461999399 ^ -1915118383 ^ 1457978057 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db);
						num2 = 55;
						continue;
					case 71:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.Location = new Point(220, 150);
						num2 = 76;
						continue;
					case 72:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.Location = new Point(100, 150);
						num2 = 49;
						continue;
					case 73:
						this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093 = new TextBox();
						num2 = 27;
						continue;
					case 74:
						base.MinimizeBox = false;
						num2 = 38;
						continue;
					case 75:
						this.A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E.UseVisualStyleBackColor = true;
						num2 = 68;
						continue;
					case 76:
						this.A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1482712261 ^ 1958670424 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef);
						num2 = 67;
						continue;
					case 77:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1734173303 ^ 1828325529 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4), 10f);
						num2 = 46;
						continue;
					case 78:
						this.A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E.Location = new Point(20, 25);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 == 0)
						{
							num2 = 11;
							continue;
						}
						continue;
					case 79:
						this.AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C.AutoSize = true;
						num2 = 77;
						continue;
					case 80:
						base.AutoScaleDimensions = new SizeF(7f, 17f);
						num2 = 24;
						continue;
					}
					this.A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093.TabIndex = 2;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 == 0)
					{
						num2 = 56;
					}
				}
				IL_01E2:
				this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-636077321 ^ -1090120313 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363), 10f);
				num = 47;
				continue;
				IL_04E2:
				this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D = new Label();
				num = 4;
				continue;
				IL_061A:
				base.ResumeLayout(false);
				num = 54;
				continue;
				IL_0728:
				this.A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D.Size = new Size(77, 14);
				num = 37;
				continue;
				IL_0A2E:
				this.A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(247185273 ^ 1510544406 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c), 10f);
				num = 15;
			}
		}

		// Token: 0x060002EB RID: 747 RVA: 0x0001A2F4 File Offset: 0x000184F4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008B\u008C\u009A\u0099\u0093\u009C\u0090\u0092\u0096\u008A()
		{
			return A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092.AA\u008A\u008E\u008C\u008B\u008F\u008F\u008F\u0099\u0090 == null;
		}

		// Token: 0x060002EC RID: 748 RVA: 0x0001A308 File Offset: 0x00018508
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092 A\u0099\u0094\u0098\u008A\u0092\u0093\u0098\u0094\u009D\u0090()
		{
			return A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092.AA\u008A\u008E\u008C\u008B\u008F\u008F\u008F\u0099\u0090;
		}

		// Token: 0x060002ED RID: 749 RVA: 0x0001A318 File Offset: 0x00018518
		static A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x040001D7 RID: 471
		private object A\u009B\u0098\u008C\u0093\u008F\u009A\u0099\u009E\u009C\u0093;

		// Token: 0x040001D8 RID: 472
		private object A\u008D\u008B\u0090\u008D\u009D\u0088\u009C\u009E\u009D\u0098;

		// Token: 0x040001D9 RID: 473
		private object A\u0089\u0097\u0093\u0098\u009B\u009A\u0093\u0090\u009A\u0093;

		// Token: 0x040001DA RID: 474
		private object A\u0096\u0092\u009E\u0098\u008E\u0090\u008E\u0090\u009E\u009E;

		// Token: 0x040001DB RID: 475
		private object A\u008D\u0095\u009D\u0091\u0086\u0090\u0098\u0094\u009D\u008D;

		// Token: 0x040001DC RID: 476
		private object A\u0092\u008F\u0094\u009D\u0094\u0087\u008D\u0090\u0097\u009E;

		// Token: 0x040001DD RID: 477
		private object AA\u0086\u008D\u009C\u0088\u008E\u008D\u009B\u008A\u008C;

		// Token: 0x040001DE RID: 478
		private object A\u008C\u0090\u0096\u008B\u009E\u0093\u009C\u009E\u0099\u009D;

		// Token: 0x040001DF RID: 479
		private static object AA\u008A\u008E\u008C\u008B\u008F\u008F\u008F\u0099\u0090;

		// Token: 0x02000062 RID: 98
		[CompilerGenerated]
		private static class <>O
		{
			// Token: 0x060002EE RID: 750 RVA: 0x0002B01C File Offset: 0x0002921C
			static <>O()
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			}

			// Token: 0x040001E0 RID: 480
			public static Func<char, bool> A\u0090\u008D\u0093\u0097\u009A\u0087\u008E\u008B\u008D\u008D;

			// Token: 0x040001E1 RID: 481
			public static Func<char, bool> A\u008E\u009B\u008B\u0090\u0099\u008C\u0097\u0090\u008B\u008A;
		}
	}
}
