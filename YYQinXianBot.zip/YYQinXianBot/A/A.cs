﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000057 RID: 87
	[NullableContext(1)]
	[Nullable(0)]
	public sealed class A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087 : IDisposable
	{
		// Token: 0x0600029A RID: 666 RVA: 0x00015840 File Offset: 0x00013A40
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087(string \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0086\u009E\u009D\u0096\u0096\u0094\u008A\u0090\u0097\u008F = new object();
			base..ctor();
			int num = 6;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ca4cfff71871411997ee2c1fb2f8f95e != 0)
			{
				num = 6;
			}
			byte[] bytes;
			for (;;)
			{
				switch (num)
				{
				case 1:
					goto IL_016E;
				case 2:
					try
					{
						RandomNumberGenerator randomNumberGenerator;
						randomNumberGenerator.GetBytes(this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097);
						int num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca == 0)
						{
							num2 = 0;
						}
						switch (num2)
						{
						}
					}
					finally
					{
						RandomNumberGenerator randomNumberGenerator;
						if (randomNumberGenerator != null)
						{
							int num3 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583 != 0)
							{
								num3 = 0;
							}
							for (;;)
							{
								switch (num3)
								{
								default:
									((IDisposable)randomNumberGenerator).Dispose();
									num3 = 1;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c != 0)
									{
										num3 = 0;
									}
									break;
								case 1:
									goto IL_0137;
								}
							}
						}
						IL_0137:;
					}
					goto IL_0142;
				case 3:
					return;
				case 4:
				{
					RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create();
					num = 2;
					continue;
				}
				case 5:
					goto IL_0142;
				case 6:
					if (!string.IsNullOrEmpty(\u0020))
					{
						this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097 = new byte[32];
						num = 4;
						continue;
					}
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
					{
						num = 1;
						continue;
					}
					continue;
				}
				break;
				IL_0142:
				bytes = Encoding.UTF8.GetBytes(\u0020);
				num = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6123357505a5405392c0339436988b0a != 0)
				{
					num = 0;
				}
			}
			goto IL_01D6;
			IL_016E:
			throw new ArgumentNullException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-380108630 - -1306166139) ^ 988510105 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c));
			IL_01D6:
			try
			{
				this.A\u0087\u008C\u0099\u0089\u0092\u0098\u0097\u0090\u0093\u0089 = ProtectedData.Protect(bytes, this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097, DataProtectionScope.CurrentUser);
				int num4 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
				{
					num4 = 0;
				}
				switch (num4)
				{
				default:
					return;
				}
			}
			finally
			{
				Array.Clear(bytes, 0, bytes.Length);
				int num5 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cfd07f15044a43fbbfaf4b9aecbd2fd6 == 0)
				{
					num5 = 0;
				}
				switch (num5)
				{
				default:
					goto EndFinally_18;
				}
				EndFinally_18:;
			}
		}

		// Token: 0x0600029B RID: 667 RVA: 0x00015AD4 File Offset: 0x00013CD4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u009D\u0090\u0098\u0093\u0098\u0099\u0095\u0090\u009E\u0092()
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_005A;
				case 2:
				{
					bool flag = false;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				case 3:
				{
					object a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F = this.A\u0086\u009E\u009D\u0096\u0096\u0094\u008A\u0090\u0097\u008F;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				}
				}
				break;
			}
			string @string;
			return @string;
			IL_005A:
			try
			{
				bool flag;
				object a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F;
				Monitor.Enter(a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F, ref flag);
				int num3 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d != 0)
				{
					num3 = 1;
				}
				byte[] array;
				for (;;)
				{
					switch (num3)
					{
					case 1:
						this.AA\u008A\u008F\u008C\u008C\u0086\u0090\u0091\u009B\u0091();
						num3 = 2;
						continue;
					case 2:
						array = null;
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cfd07f15044a43fbbfaf4b9aecbd2fd6 != 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					}
					break;
				}
				try
				{
					array = ProtectedData.Unprotect(this.A\u0087\u008C\u0099\u0089\u0092\u0098\u0097\u0090\u0093\u0089, this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097, DataProtectionScope.CurrentUser);
					int num4 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e == 0)
					{
						num4 = 0;
					}
					for (;;)
					{
						switch (num4)
						{
						default:
							@string = Encoding.UTF8.GetString(array);
							num4 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_44c58969999b4bcc8508adab214dff9c == 0)
							{
								num4 = 1;
							}
							break;
						case 1:
							goto IL_0146;
						}
					}
					IL_0146:;
				}
				finally
				{
					if (array != null)
					{
						goto IL_018B;
					}
					int num5 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d == 0)
					{
						num5 = 0;
					}
					IL_0175:
					switch (num5)
					{
					default:
						IL_018B:
						Array.Clear(array, 0, array.Length);
						num5 = 2;
						goto IL_0175;
					case 1:
						break;
					case 2:
						break;
					}
				}
			}
			finally
			{
				bool flag;
				if (flag)
				{
					int num6 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 != 0)
					{
						num6 = 1;
					}
					for (;;)
					{
						switch (num6)
						{
						case 1:
						{
							object a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F;
							Monitor.Exit(a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F);
							num6 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1803988e08d94458a1484838316ae19f == 0)
							{
								num6 = 0;
								continue;
							}
							continue;
						}
						}
						break;
					}
				}
			}
			return @string;
		}

		// Token: 0x0600029C RID: 668 RVA: 0x00015D84 File Offset: 0x00013F84
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008E\u009E\u0090\u0095\u009E\u0090\u0096\u008B\u0095\u0087 A\u0093\u009D\u008F\u008C\u0097\u008E\u0096\u0092\u0088\u0095<[Nullable(2)] A\u008E\u009E\u0090\u0095\u009E\u0090\u0096\u008B\u0095\u0087>(Func<string, A\u008E\u009E\u0090\u0095\u009E\u0090\u0096\u008B\u0095\u0087> \u0020)
		{
			if (\u0020 == null)
			{
				throw new ArgumentNullException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(171047500 ^ 56426945 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1));
			}
			string text = this.A\u009D\u0090\u0098\u0093\u0098\u0099\u0095\u0090\u009E\u0092();
			A\u008E\u009E\u0090\u0095\u009E\u0090\u0096\u008B\u0095\u0087 a_u008E_u009E_u0090_u0095_u009E_u0090_u0096_u008B_u0095_u;
			try
			{
				a_u008E_u009E_u0090_u0095_u009E_u0090_u0096_u008B_u0095_u = \u0020(text);
			}
			finally
			{
				this.A\u0089\u009B\u009C\u0095\u0087\u0095\u008D\u0090\u009C\u009D(ref text);
			}
			return a_u008E_u009E_u0090_u0095_u009E_u0090_u0096_u008B_u0095_u;
		}

		// Token: 0x0600029D RID: 669 RVA: 0x00015DF0 File Offset: 0x00013FF0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009C\u009B\u009C\u0098\u008C\u0091\u009C\u009E\u0088\u0095(Action<string> \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					this.A\u0093\u009D\u008F\u008C\u0097\u008E\u0096\u0092\u0088\u0095<object>(new Func<string, object>(CS$<>8__locals1.A\u0091\u009D\u0096\u0088\u009B\u0095\u0090\u0094\u008C\u009C));
					num2 = 5;
					break;
				case 1:
					goto IL_0060;
				case 2:
					CS$<>8__locals1.A\u0089\u008B\u0094\u008C\u008F\u0095\u0094\u009E\u008D\u008E = \u0020;
					num2 = 4;
					break;
				case 3:
					num2 = 2;
					break;
				case 4:
					if (CS$<>8__locals1.A\u0089\u008B\u0094\u008C\u008F\u0095\u0094\u009E\u008D\u008E == null)
					{
						goto IL_0060;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
					{
						num2 = 0;
					}
					break;
				case 5:
					return;
				}
			}
			return;
			IL_0060:
			throw new ArgumentNullException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-116048754 ^ -708073089 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef));
		}

		// Token: 0x0600029E RID: 670 RVA: 0x00015EEC File Offset: 0x000140EC
		[NullableContext(2)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private unsafe void A\u0089\u009B\u009C\u0095\u0087\u0095\u008D\u0090\u009C\u009D(ref string \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_0261;
				case 2:
					return;
				case 3:
					try
					{
						try
						{
							string text = \u0020;
							int num3;
							if (text != null)
							{
								fixed (char* ptr = text.GetPinnableReference())
								{
									num3 = 6;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510 != 0)
									{
										num3 = 6;
									}
								}
							}
							else
							{
								num3 = 1;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 == 0)
								{
									num3 = 1;
								}
							}
							for (;;)
							{
								char* ptr2;
								int num4;
								switch (num3)
								{
								case 1:
									ptr2 = null;
									goto IL_0159;
								case 2:
									goto IL_00ED;
								case 3:
									num4++;
									num3 = 1;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 != 0)
									{
										num3 = 2;
										continue;
									}
									continue;
								case 4:
									goto IL_00B7;
								case 5:
									num4 = 0;
									num3 = 7;
									continue;
								case 6:
								{
									char* ptr;
									ptr2 = ptr;
									goto IL_0159;
								}
								case 7:
									goto IL_00ED;
								}
								break;
								IL_00B7:
								char* ptr3;
								ptr3[num4] = '\0';
								num3 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_37d4c0ccbd094f76a7cf8f93864def2a == 0)
								{
									num3 = 3;
									continue;
								}
								continue;
								IL_00ED:
								if (num4 < \u0020.Length)
								{
									goto IL_00B7;
								}
								num3 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
								{
									num3 = 0;
									continue;
								}
								continue;
								IL_0159:
								ptr3 = ptr2;
								num3 = 5;
							}
						}
						finally
						{
							char* ptr = null;
							int num5 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b == 0)
							{
								num5 = 0;
							}
							switch (num5)
							{
							}
						}
						return;
					}
					catch
					{
						int num6 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad != 0)
						{
							num6 = 0;
						}
						switch (num6)
						{
						default:
							return;
						}
					}
					finally
					{
						\u0020 = null;
						int num7 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b7fd23e09aa54f94a15e32978d45910b == 0)
						{
							num7 = 0;
						}
						switch (num7)
						{
						}
					}
					goto IL_0261;
				}
				break;
				IL_0261:
				if (\u0020 == null)
				{
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d == 0)
					{
						num2 = 0;
					}
				}
				else
				{
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c != 0)
					{
						num2 = 0;
					}
				}
			}
		}

		// Token: 0x0600029F RID: 671 RVA: 0x000161EC File Offset: 0x000143EC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void Dispose()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					GC.SuppressFinalize(this);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c5518c15345b4b68b42acb503192f55c == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					this.A\u009B\u008E\u008C\u0088\u0088\u0099\u008B\u0094\u008A\u0091(true);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7374b39cd1dd42699e43c77815e1074b == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x00016274 File Offset: 0x00014474
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009B\u008E\u008C\u0088\u0088\u0099\u008B\u0094\u008A\u0091(bool \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				object a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F;
				bool flag;
				switch (num2)
				{
				case 1:
					try
					{
						Monitor.Enter(a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F, ref flag);
						int num3 = 5;
						for (;;)
						{
							switch (num3)
							{
							case 1:
								goto IL_0153;
							case 2:
								Array.Clear(this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097, 0, this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097.Length);
								num3 = 4;
								continue;
							case 3:
								this.A\u0087\u008C\u0099\u0089\u0092\u0098\u0097\u0090\u0093\u0089 = null;
								num3 = 6;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d != 0)
								{
									num3 = 4;
									continue;
								}
								continue;
							case 4:
								this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097 = null;
								num3 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1 == 0)
								{
									num3 = 0;
									continue;
								}
								continue;
							case 5:
								if (this.A\u0087\u008C\u0099\u0089\u0092\u0098\u0097\u0090\u0093\u0089 == null)
								{
									num3 = 7;
									continue;
								}
								goto IL_0153;
							case 6:
								goto IL_00B9;
							case 7:
								goto IL_00B9;
							}
							break;
							IL_00B9:
							if (this.A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097 == null)
							{
								break;
							}
							num3 = 2;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 == 0)
							{
								num3 = 2;
								continue;
							}
							continue;
							IL_0153:
							Array.Clear(this.A\u0087\u008C\u0099\u0089\u0092\u0098\u0097\u0090\u0093\u0089, 0, this.A\u0087\u008C\u0099\u0089\u0092\u0098\u0097\u0090\u0093\u0089.Length);
							num3 = 3;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 == 0)
							{
								num3 = 0;
							}
						}
					}
					finally
					{
						if (flag)
						{
							int num4 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b2d055de0c54ba08a92e6c6cd750833 != 0)
							{
								num4 = 0;
							}
							for (;;)
							{
								switch (num4)
								{
								case 1:
									Monitor.Exit(a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F);
									num4 = 0;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8303e4c6935047879936422b129218be == 0)
									{
										num4 = 0;
										continue;
									}
									continue;
								}
								break;
							}
						}
					}
					goto IL_022B;
				case 2:
					return;
				case 3:
					if (this.A\u009C\u0089\u0093\u0092\u008F\u008F\u0094\u009E\u0099\u008E)
					{
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					else
					{
						if (!\u0020)
						{
							num2 = 7;
							continue;
						}
						goto IL_0275;
					}
					break;
				case 4:
					goto IL_024F;
				case 5:
					return;
				case 6:
					goto IL_0275;
				case 7:
					goto IL_022B;
				}
				flag = false;
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 == 0)
				{
					num2 = 1;
					continue;
				}
				continue;
				IL_024F:
				this.A\u009C\u0089\u0093\u0092\u008F\u008F\u0094\u009E\u0099\u008E = true;
				num2 = 5;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf == 0)
				{
					num2 = 2;
					continue;
				}
				continue;
				IL_022B:
				goto IL_024F;
				IL_0275:
				a_u0086_u009E_u009D_u0096_u0096_u0094_u008A_u0090_u0097_u008F = this.A\u0086\u009E\u009D\u0096\u0096\u0094\u008A\u0090\u0097\u008F;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 == 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x00016564 File Offset: 0x00014764
		[MethodImpl(MethodImplOptions.NoInlining)]
		protected override void Finalize()
		{
			switch (1)
			{
			case 1:
				try
				{
					this.A\u009B\u008E\u008C\u0088\u0088\u0099\u008B\u0094\u008A\u0091(false);
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292 == 0)
					{
						num = 0;
					}
					switch (num)
					{
					}
				}
				finally
				{
					base.Finalize();
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
					{
						num2 = 0;
					}
					switch (num2)
					{
					}
				}
				break;
			}
		}

		// Token: 0x060002A2 RID: 674 RVA: 0x00016644 File Offset: 0x00014844
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u008A\u008F\u008C\u008C\u0086\u0090\u0091\u009B\u0091()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					return;
				case 2:
					if (!this.A\u009C\u0089\u0093\u0092\u008F\u008F\u0094\u009E\u0099\u008E)
					{
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
				break;
			}
			throw new ObjectDisposedException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1063499328 ^ -906972579 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1));
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x000166F0 File Offset: 0x000148F0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009A\u0097\u008A\u0090\u008C\u008C\u009E\u0090\u009E\u0099()
		{
			return A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087.A\u0092\u009D\u008D\u0091\u0094\u0095\u009E\u0092\u008E\u0093 == null;
		}

		// Token: 0x060002A4 RID: 676 RVA: 0x00016704 File Offset: 0x00014904
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087 A\u008C\u009C\u0096\u0092\u0089\u0090\u008F\u0090\u008E\u0092()
		{
			return A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087.A\u0092\u009D\u008D\u0091\u0094\u0095\u009E\u0092\u008E\u0093;
		}

		// Token: 0x060002A5 RID: 677 RVA: 0x00016714 File Offset: 0x00014914
		static A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x040001A8 RID: 424
		[Nullable(2)]
		private byte[] A\u0087\u008C\u0099\u0089\u0092\u0098\u0097\u0090\u0093\u0089;

		// Token: 0x040001A9 RID: 425
		[Nullable(2)]
		private byte[] A\u0089\u009B\u0096\u0096\u0092\u0097\u0086\u0092\u0099\u0097;

		// Token: 0x040001AA RID: 426
		private readonly object A\u0086\u009E\u009D\u0096\u0096\u0094\u008A\u0090\u0097\u008F;

		// Token: 0x040001AB RID: 427
		private bool A\u009C\u0089\u0093\u0092\u008F\u008F\u0094\u009E\u0099\u008E;

		// Token: 0x040001AC RID: 428
		private static object A\u0092\u009D\u008D\u0091\u0094\u0095\u009E\u0092\u008E\u0093;
	}
}
