﻿namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000061 RID: 97
	public partial class A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092 : global::System.Windows.Forms.Form
	{
		// Token: 0x060002E9 RID: 745 RVA: 0x0001945C File Offset: 0x0001765C
		[global::System.Runtime.CompilerServices.MethodImpl(global::System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
		protected override void Dispose(bool \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_0085;
				case 2:
					goto IL_00AB;
				case 3:
					goto IL_0085;
				case 4:
					if (!\u0020)
					{
						num2 = 3;
						continue;
					}
					goto IL_00AB;
				case 5:
					return;
				}
				((global::System.IDisposable)this.A\u009D\u008B\u0099\u0088\u0091\u009E\u009A\u0090\u0094\u008F).Dispose();
				num2 = 1;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 != 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_0085:
				base.Dispose(\u0020);
				num2 = 5;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 != 0)
				{
					num2 = 4;
					continue;
				}
				continue;
				IL_00AB:
				if (this.A\u009D\u008B\u0099\u0088\u0091\u009E\u009A\u0090\u0094\u008F == null)
				{
					goto IL_0085;
				}
				num2 = 0;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f == 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x040001D6 RID: 470
		private object A\u009D\u008B\u0099\u0088\u0091\u009E\u009A\u0090\u0094\u008F;
	}
}
