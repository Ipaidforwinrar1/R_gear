﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000009 RID: 9
	public partial class AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096 : Form
	{
		// Token: 0x06000045 RID: 69 RVA: 0x000032A8 File Offset: 0x000014A8
		[MethodImpl(MethodImplOptions.NoInlining)]
		public AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 12;
			for (;;)
			{
				switch (num)
				{
				case 1:
					A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0088\u0088\u0087\u009B\u0098\u0088\u0098\u0092\u0097\u008E(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~435105394 ^ -1943598850 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f), 100);
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_be5da1cd750e495490bb42f04b10e65d == 0)
					{
						num = 13;
						continue;
					}
					continue;
				case 2:
					this.AA\u008B\u0094\u0086\u0087\u0098\u008C\u0086\u0092\u0097 = new AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099();
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 != 0)
					{
						num = 0;
						continue;
					}
					continue;
				case 3:
					A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0088\u0088\u0087\u009B\u0098\u0088\u0098\u0092\u0097\u008E(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1279729392 << 4) ^ -436001217 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66), 5000);
					num = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 != 0)
					{
						num = 11;
						continue;
					}
					continue;
				case 4:
					this.Text = A\u0090\u0089\u0086\u0096\u008D\u008C\u0096\u009E\u0088\u0091.A\u008C\u0099\u009D\u0087\u0091\u008E\u008F\u0094\u0098\u008C();
					num = 9;
					continue;
				case 5:
					this.AA\u009D\u0088\u008F\u008B\u0086\u009B\u009B\u008F\u0099();
					num = 15;
					continue;
				case 6:
					this.A\u008A\u008E\u0095\u009A\u0087\u009B\u0099\u0092\u008A\u0091 = new AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099();
					num = 2;
					continue;
				case 7:
					return;
				case 8:
					this.A\u008E\u0091\u0094\u0090\u008B\u0096\u008B\u0094\u0095\u008A = new A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B(this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091);
					num = 14;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a == 0)
					{
						num = 3;
						continue;
					}
					continue;
				case 9:
				{
					A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092 a_u008D_u008D_u0094_u0096_u0091_u0089_u008B_u009E_u008A_u = new A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092();
					num = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e != 0)
					{
						num = 16;
						continue;
					}
					continue;
				}
				case 10:
					this.A\u0097\u009A\u009A\u008A\u009D\u0087\u009D\u0094\u0092\u0095();
					num = 4;
					continue;
				case 11:
					this.A\u0089\u0090\u008A\u0093\u008A\u008D\u009E\u009E\u008D\u008D();
					num = 7;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 != 0)
					{
						num = 5;
						continue;
					}
					continue;
				case 12:
					A\u0087\u0096\u0095\u009E\u009B\u009C\u0089\u0092\u0087\u008B.A\u0092\u0087\u0086\u008C\u0087\u0095\u008E\u0092\u0098\u0098();
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 != 0)
					{
						num = 0;
						continue;
					}
					continue;
				case 13:
				{
					this.AA\u009B\u0099\u0096\u0092\u0091\u0091\u009C\u0090\u0087();
					int num2 = 10;
					num = num2;
					continue;
				}
				case 14:
					this.AA\u008A\u009A\u0099\u0097\u0095\u009C\u0088\u0089\u009C = new A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B(this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092, this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C);
					num = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330 == 0)
					{
						num = 3;
						continue;
					}
					continue;
				case 15:
					this.A\u008E\u0086\u0094\u008A\u0094\u0095\u008C\u008B\u0093\u009C();
					num = 3;
					continue;
				case 16:
				{
					A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092 a_u008D_u008D_u0094_u0096_u0091_u0089_u008B_u009E_u008A_u;
					this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094 = new A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093(a_u008D_u008D_u0094_u0096_u0091_u0089_u008B_u009E_u008A_u);
					num = 6;
					continue;
				}
				}
				this.A\u009A\u0086\u0087\u0092\u0093\u0095\u009B\u008B\u0092\u0086 = new AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094();
				num = 8;
			}
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00003560 File Offset: 0x00001760
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0097\u009A\u009A\u008A\u009D\u0087\u009D\u0094\u0092\u0095()
		{
			switch (1)
			{
			case 1:
				try
				{
					Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1362952674 ^ -643169769 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b));
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 == 0)
					{
						num = 1;
					}
					for (;;)
					{
						switch (num)
						{
						case 1:
							if (manifestResourceStream != null)
							{
								int num2 = 2;
								num = num2;
								continue;
							}
							break;
						case 2:
							base.Icon = new Icon(manifestResourceStream);
							num = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 == 0)
							{
								num = 0;
								continue;
							}
							continue;
						}
						break;
					}
				}
				catch
				{
					int num3 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 != 0)
					{
						num3 = 0;
					}
					switch (num3)
					{
					}
				}
				break;
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000036A8 File Offset: 0x000018A8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u009D\u0088\u008F\u008B\u0086\u009B\u009B\u008F\u0099()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094.A\u0095\u009E\u0091\u0091\u0087\u009A\u0096\u008B\u0099\u0089(new Action<bool>(this.A\u0091\u0088\u0098\u0093\u008D\u009D\u009E\u0090\u0087\u0093));
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1803988e08d94458a1484838316ae19f == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094.A\u008E\u008E\u0091\u0098\u0089\u0088\u0088\u0094\u0099\u009E(new Action<int>(this.AA\u0095\u009E\u0091\u008C\u008C\u0092\u009A\u009A\u0092));
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7374b39cd1dd42699e43c77815e1074b != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					this.A\u008E\u0091\u0094\u0090\u008B\u0096\u008B\u0094\u0095\u008A.A\u009E\u009D\u0090\u0086\u0089\u009B\u008C\u008B\u008D\u009A += this.A\u0091\u009C\u0090\u0086\u009E\u0094\u008E\u0094\u008B\u008E;
					num2 = 5;
					continue;
				case 4:
					this.AA\u008A\u009A\u0099\u0097\u0095\u009C\u0088\u0089\u009C.A\u008E\u008E\u008F\u0094\u0090\u008B\u0094\u008B\u0094\u0096 += this.A\u0099\u0093\u0099\u009B\u0087\u0088\u0092\u008B\u0099\u0087;
					num2 = 7;
					continue;
				case 5:
					return;
				case 6:
					this.AA\u008B\u0094\u0086\u0087\u0098\u008C\u0086\u0092\u0097.A\u008B\u008E\u0095\u009A\u0090\u0088\u0086\u0094\u008F\u009A(new Action<int, bool>(this.A\u0094\u008E\u008B\u008F\u008D\u008F\u0087\u008B\u0089\u009E));
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 7:
					this.A\u008A\u008E\u0095\u009A\u0087\u009B\u0099\u0092\u008A\u0091.A\u008B\u008E\u0095\u009A\u0090\u0088\u0086\u0094\u008F\u009A(new Action<int, bool>(this.A\u009B\u0090\u0093\u009C\u008D\u008E\u0099\u0090\u0089\u0097));
					num2 = 6;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b == 0)
					{
						num2 = 6;
						continue;
					}
					continue;
				}
				this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094.A\u009B\u0099\u0091\u0087\u008A\u0096\u009E\u0090\u0091\u009C(new Action<bool?>(this.A\u0087\u008A\u008A\u008B\u0089\u0099\u008D\u0090\u0086\u0092));
				num2 = 4;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf == 0)
				{
					num2 = 3;
				}
			}
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00003848 File Offset: 0x00001A48
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008E\u0086\u0094\u008A\u0094\u0095\u008C\u008B\u0093\u009C()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Enabled = false;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000049 RID: 73 RVA: 0x000038AC File Offset: 0x00001AAC
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task A\u0089\u0090\u008A\u0093\u008A\u008D\u009E\u009E\u008D\u008D()
		{
			int num = 2;
			int num2 = num;
			AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<InitializeAsync>d__12 <InitializeAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<InitializeAsync>d__.<>4__this = this;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					<InitializeAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					goto IL_0085;
				case 4:
					<InitializeAsync>d__.<>t__builder.Start<AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<InitializeAsync>d__12>(ref <InitializeAsync>d__);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53 != 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				}
				<InitializeAsync>d__.<>1__state = -1;
				num2 = 4;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c == 0)
				{
					num2 = 0;
				}
			}
			IL_0085:
			return <InitializeAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x000039A4 File Offset: 0x00001BA4
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task A\u0089\u0092\u0099\u009B\u0096\u0099\u008E\u0090\u009E\u0089()
		{
			int num = 1;
			int num2 = num;
			AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<LoadDataAsync>d__13 <LoadDataAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<LoadDataAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					<LoadDataAsync>d__.<>t__builder.Start<AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<LoadDataAsync>d__13>(ref <LoadDataAsync>d__);
					num2 = 4;
					continue;
				case 3:
					<LoadDataAsync>d__.<>1__state = -1;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_86e848c6696044348a77d8429afaaa88 != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 4:
					goto IL_00C8;
				}
				<LoadDataAsync>d__.<>4__this = this;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 == 0)
				{
					num2 = 0;
				}
			}
			IL_00C8:
			return <LoadDataAsync>d__.<>t__builder.Task;
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00003A88 File Offset: 0x00001C88
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0087\u008A\u008A\u008B\u0089\u0099\u008D\u0090\u0086\u0092(bool? \u0020)
		{
			int num = 4;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-337667488 ^ -755364134 ^ 888960794 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c);
						num2 = 7;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b == 0)
						{
							num2 = 1;
						}
						break;
					case 1:
						goto IL_00D4;
					case 2:
						return;
					case 3:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Enabled = false;
						num2 = 8;
						break;
					case 4:
						if (\u0020 == null)
						{
							num2 = 3;
						}
						else if (\u0020.Value)
						{
							num2 = 5;
						}
						else
						{
							this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Enabled = true;
							num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6fdef4c9fb0147c3b3aa646e625fdd4d != 0)
							{
								num2 = 0;
							}
						}
						break;
					case 5:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Enabled = true;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 != 0)
						{
							num2 = 1;
						}
						break;
					case 6:
						return;
					case 7:
						return;
					case 8:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-922289810 ^ -855990295 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53);
						num2 = 6;
						break;
					}
				}
				IL_00D4:
				this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1451827733 ^ 1608894890 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1);
				num = 2;
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00003C28 File Offset: 0x00001E28
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0086\u0091\u0091\u009B\u0090\u0086\u0089\u0090\u008D\u0093([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
				{
					AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<btnPlayMusic_Click>d__15 <btnPlayMusic_Click>d__;
					<btnPlayMusic_Click>d__.<>4__this = this;
					num2 = 3;
					break;
				}
				case 1:
				{
					AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<btnPlayMusic_Click>d__15 <btnPlayMusic_Click>d__;
					<btnPlayMusic_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8303e4c6935047879936422b129218be != 0)
					{
						num2 = 0;
					}
					break;
				}
				case 2:
					return;
				case 3:
				{
					AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<btnPlayMusic_Click>d__15 <btnPlayMusic_Click>d__;
					<btnPlayMusic_Click>d__.<>1__state = -1;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 != 0)
					{
						num2 = 4;
					}
					break;
				}
				case 4:
				{
					AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<btnPlayMusic_Click>d__15 <btnPlayMusic_Click>d__;
					<btnPlayMusic_Click>d__.<>t__builder.Start<AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<btnPlayMusic_Click>d__15>(ref <btnPlayMusic_Click>d__);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 == 0)
					{
						num2 = 2;
					}
					break;
				}
				}
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x00003D00 File Offset: 0x00001F00
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task AA\u008E\u0098\u0087\u0093\u009D\u008E\u0091\u0096\u008E()
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[0];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_0088;
				}
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(0, array, this);
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b != 0)
				{
					num2 = 2;
				}
			}
			IL_0088:
			return (Task)array2[0];
		}

		// Token: 0x0600004E RID: 78 RVA: 0x00003DA0 File Offset: 0x00001FA0
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private string A\u009E\u008B\u0089\u0093\u0097\u009A\u008E\u009E\u009D\u009E()
		{
			int num = 4;
			string text2;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					int num3;
					string text;
					switch (num2)
					{
					case 0:
						goto IL_01F8;
					case 1:
						goto IL_0053;
					case 2:
						goto IL_00EE;
					case 3:
						if (this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.SelectedItems.Count == 0)
						{
							num2 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 == 0)
							{
								num2 = 5;
								continue;
							}
							continue;
						}
						else
						{
							A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089 a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u = this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.SelectedItems[0].Tag as A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089;
							if (a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u == null)
							{
								num2 = 11;
								continue;
							}
							num3 = a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u.AA\u0092\u009A\u0090\u008B\u009D\u0089\u0086\u009B\u009E();
							num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 == 0)
							{
								num2 = 0;
								continue;
							}
							continue;
						}
						break;
					case 4:
						if (this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SelectedIndex == 0)
						{
							goto Block_5;
						}
						if (this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SelectedIndex == 1)
						{
							num2 = 7;
							continue;
						}
						if (this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SelectedIndex == 2)
						{
							num2 = 8;
							continue;
						}
						goto IL_018F;
					case 5:
						goto IL_0195;
					case 6:
						goto IL_00CA;
					case 7:
						if (this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedItems.Count == 0)
						{
							goto IL_0053;
						}
						num2 = 6;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce == 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 8:
						goto IL_011B;
					case 9:
						goto IL_022A;
					case 10:
						goto IL_016D;
					case 11:
						text = null;
						break;
					default:
						goto IL_01F8;
					}
					IL_01FF:
					if ((text2 = text) != null)
					{
						goto Block_11;
					}
					num2 = 8;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 == 0)
					{
						num2 = 9;
						continue;
					}
					continue;
					IL_01F8:
					text = num3.ToString();
					goto IL_01FF;
				}
				Block_5:
				num = 3;
				continue;
				IL_011B:
				if (this.A\u008E\u0091\u0094\u0090\u008B\u0096\u008B\u0094\u0095\u008A.A\u0092\u008C\u009D\u0094\u0093\u0093\u0093\u0090\u0086\u0093())
				{
					goto IL_016D;
				}
				num = 2;
			}
			IL_0053:
			return string.Empty;
			IL_00CA:
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((640005275 >> 6) ^ 631420725 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce);
			IL_00EE:
			return A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1219413587 ^ -1033569933 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283);
			IL_016D:
			return string.Empty;
			IL_018F:
			return string.Empty;
			IL_0195:
			return string.Empty;
			Block_11:
			return text2;
			IL_022A:
			text2 = string.Empty;
			return text2;
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00003FF8 File Offset: 0x000021F8
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008C\u0099\u008B\u009A\u0087\u0098\u0089\u009E\u0095\u0099([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094.A\u008A\u0095\u0099\u0089\u009E\u0095\u008F\u0092\u009A\u009A();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c83fdfd7feb346bcbdc0a4168723b361 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x0000405C File Offset: 0x0000225C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u008F\u008D\u0086\u0092\u008D\u0096\u009E\u009C\u009E([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_0057;
				case 3:
					if (!this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Enabled)
					{
						num2 = 2;
						continue;
					}
					goto IL_0057;
				}
				break;
				IL_0057:
				this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Cursor = Cursors.Hand;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a != 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x06000051 RID: 81 RVA: 0x0000410C File Offset: 0x0000230C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0088\u0094\u0094\u0088\u009B\u008A\u0092\u008B\u009E\u0092([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Cursor = Cursors.Default;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00004174 File Offset: 0x00002374
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AAA\u0097\u009A\u009C\u0086\u0091\u009A\u0090\u0093([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 3;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					string text;
					switch (num2)
					{
					case 1:
						goto IL_0066;
					case 2:
						if (string.IsNullOrWhiteSpace(text))
						{
							goto IL_0066;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 3:
						text = this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.Text.Trim();
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 != 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					case 4:
						return;
					case 5:
						return;
					}
					this.A\u008A\u008E\u0095\u009A\u0087\u009B\u0099\u0092\u008A\u0091.A\u008D\u0092\u0096\u0090\u0088\u0092\u0093\u0094\u0091\u008B(text, this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Items);
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66 != 0)
					{
						num2 = 4;
					}
				}
				IL_0066:
				MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(561493477 ^ 252333934 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((926982431 << 2) ^ -1663100403 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				num = 5;
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x000042C8 File Offset: 0x000024C8
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0093\u0094\u0091\u009A\u0089\u0091\u009B\u009E\u0090\u009A([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					string text;
					this.AA\u008B\u0094\u0086\u0087\u0098\u008C\u0086\u0092\u0097.A\u008D\u0092\u0096\u0090\u0088\u0092\u0093\u0094\u0091\u008B(text, this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Items);
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 2:
					goto IL_003B;
				case 3:
					return;
				case 4:
				{
					string text;
					if (string.IsNullOrWhiteSpace(text))
					{
						goto IL_003B;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				case 5:
				{
					string text = this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.Text.Trim();
					num2 = 4;
					continue;
				}
				}
				break;
				IL_003B:
				MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1925285482 + 96378623) ^ -2027050928 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c83fdfd7feb346bcbdc0a4168723b361), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-784492755 ^ -929493102 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 != 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x06000054 RID: 84 RVA: 0x00004418 File Offset: 0x00002618
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008F\u008D\u0091\u008C\u0099\u0087\u009A\u0090\u0090\u0091([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_004E;
				case 2:
					if (this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.SelectedItems.Count <= 0)
					{
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					break;
				case 3:
					return;
				}
				this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedItems.Clear();
				num2 = 3;
			}
			return;
			IL_004E:;
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000044CC File Offset: 0x000026CC
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0091\u008B\u009E\u008D\u0091\u0088\u0093\u009E\u0093\u009A([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.SelectedItems.Clear();
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_aeecb0ba81724219b3aab6c572f13b3f != 0)
					{
						num2 = 1;
					}
					break;
				case 1:
					if (this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedItems.Count <= 0)
					{
						return;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 != 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					return;
				}
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x0000456C File Offset: 0x0000276C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u0094\u009C\u0090\u0090\u0091\u0094\u0097\u0090\u009D([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u009A\u0086\u0087\u0092\u0093\u0095\u009B\u008B\u0092\u0086.A\u0094\u0086\u008B\u0098\u0086\u0089\u0096\u0090\u008A\u008D(this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000057 RID: 87 RVA: 0x000045D4 File Offset: 0x000027D4
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0089\u0097\u0091\u0089\u0099\u009A\u0086\u008B\u0087\u009E([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089 a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedItems.Count == 0)
					{
						goto IL_0295;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				case 3:
					goto IL_0295;
				case 4:
					return;
				case 5:
					goto IL_0043;
				case 6:
					return;
				case 7:
					num2 = ((a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u != null) ? 5 : 6);
					continue;
				}
				a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u = this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedItems[0].Tag as A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089;
				num2 = 7;
				continue;
				IL_0295:
				MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-275825843 ^ 302041667 ^ -1787860247 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1637534663 + 1764814831) ^ -390499563 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				num2 = 4;
			}
			IL_0043:
			try
			{
				string text = Path.Combine(this.A\u009A\u0086\u0087\u0092\u0093\u0095\u009B\u008B\u0092\u0086.A\u009E\u0089\u008E\u0086\u0099\u0088\u008E\u008B\u0098\u0099(), a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u.A\u008F\u0096\u008F\u008C\u0095\u0087\u008C\u0090\u008F\u0099() + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((640005275 >> 6) ^ 648687901 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73));
				int num3 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590 == 0)
				{
					num3 = 0;
				}
				for (;;)
				{
					switch (num3)
					{
					default:
						if (!File.Exists(text))
						{
							num3 = 3;
							continue;
						}
						break;
					case 1:
						break;
					case 2:
						goto IL_00DA;
					case 3:
						MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1482712261 ^ 1347235881 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e) + text, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-2051710422 ^ -543326125 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1), MessageBoxButtons.OK, MessageBoxIcon.Hand);
						num3 = 2;
						continue;
					case 4:
						goto IL_0176;
					}
					Process.Start(new ProcessStartInfo
					{
						FileName = text,
						UseShellExecute = true
					});
					int num4 = 4;
					num3 = num4;
				}
				IL_00DA:
				IL_0176:;
			}
			catch (Exception ex)
			{
				int num5 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad != 0)
				{
					num5 = 1;
				}
				for (;;)
				{
					switch (num5)
					{
					case 1:
						MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(67101037 ^ 198358505 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e) + ex.Message, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(141962467 ^ 50148348 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4), MessageBoxButtons.OK, MessageBoxIcon.Hand);
						num5 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d375a57ab5714e038011351b58752657 != 0)
						{
							num5 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x06000058 RID: 88 RVA: 0x0000491C File Offset: 0x00002B1C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0096\u008B\u0091\u008A\u008B\u0098\u0089\u0092\u0095\u0093([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				double num3;
				RadioButton radioButton;
				double num4;
				switch (num2)
				{
				case 1:
					num3 = 1.0;
					goto IL_01CA;
				case 2:
					if (radioButton == null)
					{
						return;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					radioButton = sender as RadioButton;
					num2 = 2;
					continue;
				case 4:
					this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094.A\u0097\u009D\u008A\u0088\u008C\u0094\u008F\u0090\u0090\u008C(num4);
					num2 = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4 == 0)
					{
						num2 = 4;
						continue;
					}
					continue;
				case 5:
					return;
				case 6:
					return;
				case 7:
					if (radioButton != this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091)
					{
						num2 = 8;
						continue;
					}
					num3 = 1.2;
					goto IL_01CA;
				case 8:
					if (radioButton == this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C)
					{
						num3 = 1.5;
						goto IL_01CA;
					}
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 9:
					if (radioButton != this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F)
					{
						num2 = 10;
						continue;
					}
					num3 = 0.8;
					goto IL_01CA;
				case 10:
					if (radioButton != this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C)
					{
						num2 = 7;
						continue;
					}
					num3 = 1.0;
					goto IL_01CA;
				}
				if (!radioButton.Checked)
				{
					break;
				}
				num2 = 8;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 != 0)
				{
					num2 = 9;
					continue;
				}
				continue;
				IL_01CA:
				num4 = num3;
				num2 = 4;
			}
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00004B00 File Offset: 0x00002D00
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009D\u008C\u0095\u009A\u0092\u009C\u009D\u0090\u008F\u008B([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094.A\u0087\u0099\u009D\u009E\u009E\u0099\u0086\u008B\u0087\u008D(this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.Checked);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00004B70 File Offset: 0x00002D70
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u0086\u009E\u009E\u0099\u0091\u0089\u008B\u0090\u0096([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 0:
					goto IL_00EF;
				case 1:
				{
					int selectedIndex;
					switch (selectedIndex)
					{
					case 0:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedIndices.Clear();
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 1:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.SelectedIndices.Clear();
						num2 = 12;
						continue;
					case 2:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.SelectedIndices.Clear();
						num2 = 13;
						continue;
					default:
						num2 = 6;
						continue;
					}
					break;
				}
				case 2:
				{
					int selectedIndex = this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SelectedIndex;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 3:
					goto IL_01D8;
				case 4:
					return;
				case 5:
					return;
				case 6:
					return;
				case 7:
					this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.EnsureVisible(0);
					num2 = 5;
					continue;
				case 8:
					break;
				case 9:
					goto IL_013B;
				case 10:
					return;
				case 11:
					goto IL_0060;
				case 12:
					if (this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Items.Count <= 0)
					{
						num2 = 11;
						continue;
					}
					break;
				case 13:
					this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedIndices.Clear();
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 != 0)
					{
						num2 = 4;
						continue;
					}
					continue;
				case 14:
					this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.EnsureVisible(0);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f != 0)
					{
						num2 = 10;
						continue;
					}
					continue;
				default:
					goto IL_00EF;
				}
				this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Items[0].Selected = true;
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b != 0)
				{
					num2 = 14;
					continue;
				}
				continue;
				IL_00EF:
				if (this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Items.Count <= 0)
				{
					num2 = 9;
					continue;
				}
				IL_01D8:
				this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Items[0].Selected = true;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
				{
					num2 = 7;
				}
			}
			return;
			IL_0060:
			return;
			IL_013B:;
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00004DC8 File Offset: 0x00002FC8
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task AA\u009E\u008D\u008E\u008B\u008F\u008D\u0090\u009C\u0091()
		{
			int num = 2;
			int num2 = num;
			object[] array;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					object[] array2;
					array = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(1, array2, this);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 2:
				{
					object[] array2 = new object[0];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				}
				break;
			}
			return (Task)array[0];
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00004E68 File Offset: 0x00003068
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task A\u0097\u0099\u0096\u0097\u009C\u009D\u008D\u0094\u0096\u0089()
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[0];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_002F;
				}
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(2, array, this);
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 == 0)
				{
					num2 = 2;
				}
			}
			IL_002F:
			return (Task)array2[0];
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00004F08 File Offset: 0x00003108
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u008B\u009B\u0097\u009B\u008A\u0087\u008B\u0096\u0086([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E a_u0088_u008A_u008C_u0089_u0096_u0093_u0098_u0094_u0091_u008E;
				switch (num2)
				{
				case 1:
					try
					{
						a_u0088_u008A_u008C_u0089_u0096_u0093_u0098_u0094_u0091_u008E.TopMost = base.TopMost;
						int num3 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904 != 0)
						{
							num3 = 3;
						}
						for (;;)
						{
							switch (num3)
							{
							case 1:
								MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(561493477 ^ 1947478031 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1612782771 >> 1) ^ -308430587 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
								num3 = 2;
								continue;
							case 2:
								goto IL_0141;
							case 3:
								if (a_u0088_u008A_u008C_u0089_u0096_u0093_u0098_u0094_u0091_u008E.ShowDialog(this) != DialogResult.OK)
								{
									goto IL_0141;
								}
								num3 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_986b8401b4a04c8bbcac3dbaf50e7368 == 0)
								{
									num3 = 0;
									continue;
								}
								continue;
							}
							this.A\u0096\u008E\u0086\u0088\u0089\u0089\u008A\u0090\u009D\u0086();
							num3 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c == 0)
							{
								num3 = 1;
							}
						}
						IL_0141:
						return;
					}
					finally
					{
						if (a_u0088_u008A_u008C_u0089_u0096_u0093_u0098_u0094_u0091_u008E != null)
						{
							int num4 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b72d53da7b174fadb50590dffdef5348 == 0)
							{
								num4 = 1;
							}
							for (;;)
							{
								switch (num4)
								{
								case 1:
									((IDisposable)a_u0088_u008A_u008C_u0089_u0096_u0093_u0098_u0094_u0091_u008E).Dispose();
									num4 = 0;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 == 0)
									{
										num4 = 0;
										continue;
									}
									continue;
								}
								break;
							}
						}
					}
					goto IL_01C8;
				case 2:
					goto IL_01C8;
				case 3:
					if (!A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0090\u009A\u0094\u009C\u009E\u0093\u008D\u0090\u0091\u0086.A\u009B\u009C\u0097\u009D\u008F\u0090\u0090\u009E\u0098\u008A())
					{
						num2 = 2;
						continue;
					}
					goto IL_0213;
				case 4:
					goto IL_0213;
				case 5:
					return;
				}
				break;
				IL_01C8:
				a_u0088_u008A_u008C_u0089_u0096_u0093_u0098_u0094_u0091_u008E = new A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E();
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 == 0)
				{
					num2 = 1;
					continue;
				}
				continue;
				IL_0213:
				MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-2051710422 ^ -260004994 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1505100509 ^ -806680129 ^ 1271938111 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d != 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x0600005E RID: 94 RVA: 0x0000519C File Offset: 0x0000339C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0093\u0094\u009C\u0087\u0094\u0091\u009C\u0092\u008B\u0092([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 0:
					goto IL_0030;
				case 1:
					break;
				case 2:
					return;
				default:
					goto IL_0030;
				}
				IL_018F:
				A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092 a_u0091_u0093_u0087_u009D_u008F_u0099_u008F_u008B_u009B_u = new A\u0091\u0093\u0087\u009D\u008F\u0099\u008F\u008B\u009B\u0092();
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971 != 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_0030:
				try
				{
					a_u0091_u0093_u0087_u009D_u008F_u0099_u008F_u008B_u009B_u.TopMost = base.TopMost;
					int num3 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
					{
						num3 = 1;
					}
					for (;;)
					{
						switch (num3)
						{
						case 1:
							if (a_u0091_u0093_u0087_u009D_u008F_u0099_u008F_u008B_u009B_u.ShowDialog(this) != DialogResult.OK)
							{
								goto IL_0108;
							}
							num3 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971 == 0)
							{
								num3 = 0;
								continue;
							}
							continue;
						case 2:
							MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1442726474 ^ 2013985340 ^ -1255787442 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-146834757 ^ 284351459 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							num3 = 3;
							continue;
						case 3:
							goto IL_0108;
						}
						this.A\u0096\u008E\u0086\u0088\u0089\u0089\u008A\u0090\u009D\u0086();
						num3 = 2;
					}
					IL_0108:
					break;
				}
				finally
				{
					if (a_u0091_u0093_u0087_u009D_u008F_u0099_u008F_u008B_u009B_u != null)
					{
						int num4 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d != 0)
						{
							num4 = 0;
						}
						for (;;)
						{
							switch (num4)
							{
							case 1:
								((IDisposable)a_u0091_u0093_u0087_u009D_u008F_u0099_u008F_u008B_u009B_u).Dispose();
								num4 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f == 0)
								{
									num4 = 0;
									continue;
								}
								continue;
							}
							break;
						}
					}
				}
				goto IL_018F;
			}
		}

		// Token: 0x0600005F RID: 95 RVA: 0x00005370 File Offset: 0x00003570
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008D\u0091\u0087\u009E\u008A\u008C\u0093\u009E\u0093\u0089([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						if (A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0090\u009A\u0094\u009C\u009E\u0093\u008D\u0090\u0091\u0086.A\u009B\u009C\u0097\u009D\u008F\u0090\u0090\u009E\u0098\u008A())
						{
							goto IL_00B5;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_37d4c0ccbd094f76a7cf8f93864def2a == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 2:
						return;
					case 3:
						goto IL_00CB;
					case 4:
						return;
					}
					MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-380108630 - -1306166139) ^ 468451504 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1588658860 ^ 681356863 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427), MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					num2 = 4;
				}
				IL_00B5:
				AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A aa_u009D_u0092_u0086_u0090_u009C_u009C_u009E_u008F_u009A = new AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A();
				num = 3;
			}
			return;
			IL_00CB:
			try
			{
				AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A aa_u009D_u0092_u0086_u0090_u009C_u009C_u009E_u008F_u009A;
				aa_u009D_u0092_u0086_u0090_u009C_u009C_u009E_u008F_u009A.TopMost = base.TopMost;
				int num3 = 2;
				for (;;)
				{
					switch (num3)
					{
					default:
						this.A\u0086\u009B\u009C\u0098\u0093\u008C\u0096\u008B\u009A\u009E();
						num3 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b != 0)
						{
							num3 = 1;
						}
						break;
					case 1:
						goto IL_014F;
					case 2:
						if (aa_u009D_u0092_u0086_u0090_u009C_u009C_u009E_u008F_u009A.ShowDialog(this) != DialogResult.OK)
						{
							goto IL_014F;
						}
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 != 0)
						{
							num3 = 0;
						}
						break;
					}
				}
				IL_014F:
				return;
			}
			finally
			{
				AA\u009D\u0092\u0086\u0090\u009C\u009C\u009E\u008F\u009A aa_u009D_u0092_u0086_u0090_u009C_u009C_u009E_u008F_u009A;
				if (aa_u009D_u0092_u0086_u0090_u009C_u009C_u009E_u008F_u009A != null)
				{
					int num4 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 != 0)
					{
						num4 = 1;
					}
					for (;;)
					{
						switch (num4)
						{
						case 0:
							goto IL_01B6;
						case 1:
							((IDisposable)aa_u009D_u0092_u0086_u0090_u009C_u009C_u009E_u008F_u009A).Dispose();
							num4 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c == 0)
							{
								num4 = 0;
								continue;
							}
							continue;
						}
						goto Block_12;
					}
					Block_12:
					goto IL_01B6;
				}
				goto IL_01B6;
				IL_01B6:;
			}
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00005564 File Offset: 0x00003764
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0095\u0088\u0090\u0096\u009C\u0091\u0098\u0092\u0097\u0098([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					base.TopMost = this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C.Checked;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000061 RID: 97 RVA: 0x000055CC File Offset: 0x000037CC
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0097\u0092\u008C\u009E\u0089\u009A\u0098\u0092\u009A\u008A([Nullable(2)] object sender, EventArgs \u0020)
		{
			switch (1)
			{
			case 1:
				try
				{
					Process.Start(new ProcessStartInfo
					{
						FileName = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1851001565 ^ 1719230099 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e),
						UseShellExecute = true
					});
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 == 0)
					{
						num = 0;
					}
					switch (num)
					{
					}
				}
				catch (Exception ex)
				{
					int num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d != 0)
					{
						num2 = 1;
					}
					for (;;)
					{
						switch (num2)
						{
						case 1:
							MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((695555604 + 228720234) ^ 640190726 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b) + ex.Message, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1480444969 ^ -1074762442 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850), MessageBoxButtons.OK, MessageBoxIcon.Hand);
							num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6fdef4c9fb0147c3b3aa646e625fdd4d == 0)
							{
								num2 = 0;
								continue;
							}
							continue;
						}
						break;
					}
				}
				break;
			}
		}

		// Token: 0x06000062 RID: 98 RVA: 0x0000574C File Offset: 0x0000394C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008E\u0094\u0090\u0086\u009D\u0098\u008C\u0090\u009C\u009B([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<btnForgetAccount_Click>d__37 <btnForgetAccount_Click>d__;
				switch (num2)
				{
				case 1:
					<btnForgetAccount_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					<btnForgetAccount_Click>d__.<>1__state = -1;
					num2 = 4;
					continue;
				case 3:
					return;
				case 4:
					<btnForgetAccount_Click>d__.<>t__builder.Start<AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.<btnForgetAccount_Click>d__37>(ref <btnForgetAccount_Click>d__);
					num2 = 3;
					continue;
				}
				<btnForgetAccount_Click>d__.<>4__this = this;
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef != 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x06000063 RID: 99 RVA: 0x0000580C File Offset: 0x00003A0C
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task AA\u0098\u0097\u0090\u0093\u009B\u009C\u009E\u0093\u009D()
		{
			int num = 2;
			int num2 = num;
			object[] array;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					object[] array2;
					array = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(3, array2, this);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c5518c15345b4b68b42acb503192f55c == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 2:
				{
					object[] array2 = new object[0];
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				}
				break;
			}
			return (Task)array[0];
		}

		// Token: 0x06000064 RID: 100 RVA: 0x000058AC File Offset: 0x00003AAC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0096\u008E\u0086\u0088\u0089\u0089\u008A\u0090\u009D\u0086()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (!A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0090\u009A\u0094\u009C\u009E\u0093\u008D\u0090\u0091\u0086.A\u009B\u009C\u0097\u009D\u008F\u0090\u0090\u009E\u0098\u008A())
					{
						return;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				case 3:
					return;
				}
				this.A\u0086\u009B\u009C\u0098\u0093\u008C\u0096\u008B\u009A\u009E();
				num2 = 3;
			}
		}

		// Token: 0x06000065 RID: 101 RVA: 0x00005950 File Offset: 0x00003B50
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0086\u009B\u009C\u0098\u0093\u008C\u0096\u008B\u009A\u009E()
		{
			int num = 23;
			int num2 = num;
			for (;;)
			{
				string text2;
				string text;
				DateTime localDateTime;
				bool flag;
				A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B;
				string text3;
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler;
				string text4;
				DateTimeOffset dateTimeOffset;
				string aa_u0098_u008C_u008B_u009B_u0099_u009D_u008A_u0095_u008B;
				string text5;
				switch (num2)
				{
				case 1:
					text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1734807256 ^ -1846272923 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1) + text2 + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-242410958 + -2074834086) ^ 63704613 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca == 0)
					{
						num2 = 7;
						continue;
					}
					continue;
				case 2:
					goto IL_0225;
				case 3:
					goto IL_03B8;
				case 4:
					flag = localDateTime < DateTime.Now;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db != 0)
					{
						num2 = 12;
						continue;
					}
					continue;
				case 5:
					if (a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B.A\u0090\u008B\u008E\u0090\u0087\u0097\u008F\u009E\u0087\u008F() == null)
					{
						num2 = 29;
						continue;
					}
					goto IL_025D;
				case 6:
					text3 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(992923615 ^ 1850561883 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3);
					goto IL_0610;
				case 7:
					goto IL_03B8;
				case 8:
					goto IL_024C;
				case 9:
					text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-970983003 ^ 1559242928 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363);
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 10:
					goto IL_03B8;
				case 11:
					text = "";
					num2 = 24;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b7fd23e09aa54f94a15e32978d45910b != 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				case 12:
					if (a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B.A\u0090\u008B\u008E\u0090\u0087\u0097\u008F\u009E\u0087\u008F().AA\u0095\u008E\u0093\u0088\u008C\u0090\u0090\u0098\u008E == 1)
					{
						num2 = 28;
						continue;
					}
					goto IL_024C;
				case 13:
					defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(5, 2);
					num2 = 14;
					continue;
				case 14:
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1186520438 - -1314777313) ^ 175958491 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c));
					num2 = 30;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a != 0)
					{
						num2 = 6;
						continue;
					}
					continue;
				case 15:
					text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-214453972 ^ -11646669 ^ 1815810534 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0);
					num2 = 10;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75 == 0)
					{
						num2 = 6;
						continue;
					}
					continue;
				case 16:
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1876083551 ^ 261107056 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4c22ad8e716e49e8ba8a62ec601d81c0));
					num2 = 19;
					continue;
				case 17:
					goto IL_03B8;
				case 18:
					goto IL_0537;
				case 19:
					defaultInterpolatedStringHandler.AppendFormatted(text4);
					num2 = 32;
					continue;
				case 20:
					dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds(a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B.A\u0090\u008B\u008E\u0090\u0087\u0097\u008F\u009E\u0087\u008F().AA\u009D\u008E\u0098\u0099\u009E\u0092\u008F\u009D\u0087);
					num2 = 31;
					continue;
				case 21:
					if (this.A\u0089\u009D\u0086\u008B\u009A\u0088\u008D\u009E\u0088\u009C <= 0L)
					{
						num2 = 17;
						continue;
					}
					goto IL_0537;
				case 22:
					aa_u0098_u008C_u008B_u009B_u0099_u009D_u008A_u0095_u008B = A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0098\u008C\u008B\u009B\u0099\u009D\u008A\u0095\u008B;
					num2 = 11;
					continue;
				case 23:
					a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B = A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0090\u009A\u0094\u009C\u009E\u0093\u008D\u0090\u0091\u0086;
					num2 = 22;
					continue;
				case 24:
					if (a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B.A\u009B\u009C\u0097\u009D\u008F\u0090\u0090\u009E\u0098\u008A())
					{
						num2 = 5;
						continue;
					}
					goto IL_0225;
				case 25:
					if (dateTimeOffset.LocalDateTime < DateTime.Now)
					{
						num2 = 9;
						continue;
					}
					goto IL_03B8;
				case 26:
					goto IL_025D;
				case 27:
					text5 = defaultInterpolatedStringHandler.ToStringAndClear();
					num2 = 20;
					continue;
				case 28:
					if (flag)
					{
						num2 = 6;
						continue;
					}
					goto IL_04EB;
				case 29:
					goto IL_0225;
				case 30:
					defaultInterpolatedStringHandler.AppendFormatted(a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B.A\u0087\u008C\u0092\u0092\u008C\u0089\u0096\u008B\u0092\u0096());
					num2 = 16;
					continue;
				case 31:
					localDateTime = dateTimeOffset.LocalDateTime;
					num2 = 4;
					continue;
				case 32:
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1837343160 - -715340619) ^ -544444576 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0));
					num2 = 27;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c != 0)
					{
						num2 = 16;
						continue;
					}
					continue;
				case 33:
					goto IL_04EB;
				}
				break;
				IL_0225:
				text5 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1877191572 ^ 1873644397 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b);
				num2 = 21;
				continue;
				IL_024C:
				if (flag)
				{
					num2 = 15;
					continue;
				}
				goto IL_03B8;
				IL_025D:
				text4 = this.A\u009A\u0091\u0099\u009A\u008D\u0092\u009C\u0094\u0089\u0089(a_u0097_u009C_u008E_u0096_u0091_u0086_u0093_u0090_u0090_u008B.A\u0090\u008B\u008E\u0090\u0087\u0097\u008F\u009E\u0087\u008F().AA\u0095\u008E\u0093\u0088\u008C\u0090\u0090\u0098\u008E);
				num2 = 13;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
				{
					num2 = 10;
					continue;
				}
				continue;
				IL_03B8:
				Control a_u0099_u008B_u0090_u009C_u009D_u0093_u0088_u0094_u009A_u = this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086;
				defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(27, 3);
				defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-48810395 ^ -1885106897 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5));
				defaultInterpolatedStringHandler.AppendFormatted(aa_u0098_u008C_u008B_u009B_u0099_u009D_u008A_u0095_u008B);
				defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1126285631 ^ -1222678644 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200));
				defaultInterpolatedStringHandler.AppendFormatted(text5);
				defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((648712696 >> 5) ^ 420288714 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca));
				defaultInterpolatedStringHandler.AppendFormatted(text);
				defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1381125682 >> 1) ^ 1151004792 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754));
				a_u0099_u008B_u0090_u009C_u009D_u0093_u0088_u0094_u009A_u.Text = defaultInterpolatedStringHandler.ToStringAndClear();
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7374b39cd1dd42699e43c77815e1074b == 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_0537:
				dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds(this.A\u0089\u009D\u0086\u008B\u009A\u0088\u008D\u009E\u0088\u009C);
				num2 = 4;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a470257873ee4efe9970265367c819a3 == 0)
				{
					num2 = 25;
					continue;
				}
				continue;
				IL_0610:
				text2 = text3;
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad != 0)
				{
					num2 = 1;
					continue;
				}
				continue;
				IL_04EB:
				text3 = localDateTime.ToString(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1126285631 ^ -139932994 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971));
				goto IL_0610;
			}
		}

		// Token: 0x06000066 RID: 102 RVA: 0x00005F90 File Offset: 0x00004190
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private string A\u009A\u0091\u0099\u009A\u008D\u0092\u009C\u0094\u0089\u0089(int \u0020)
		{
			int num = 4;
			string text;
			for (;;)
			{
				int num2 = num;
				DefaultInterpolatedStringHandler defaultInterpolatedStringHandler;
				for (;;)
				{
					switch (num2)
					{
					case 0:
						goto IL_007E;
					case 1:
						goto IL_01D7;
					case 2:
						defaultInterpolatedStringHandler.AppendFormatted<int>(\u0020);
						num2 = 12;
						continue;
					case 3:
						goto IL_007E;
					case 4:
						if (\u0020 == 0)
						{
							num2 = 3;
							continue;
						}
						goto IL_0188;
					case 5:
						return text;
					case 6:
						break;
					case 7:
						goto IL_0188;
					case 8:
						goto IL_01C0;
					case 9:
						return text;
					case 10:
						goto IL_00FF;
					case 11:
						defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((640005275 >> 6) ^ 2012245197 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b));
						num2 = 2;
						continue;
					case 12:
						defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1588658860 ^ 1531798107 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53));
						num2 = 8;
						continue;
					case 13:
						break;
					default:
						goto IL_007E;
					}
					defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(4, 1);
					num2 = 11;
					continue;
					IL_007E:
					text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1480444969 ^ -819810374 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
					IL_00FF:
					text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1123501873 ^ 683710608 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f);
					num2 = 5;
					continue;
					IL_0188:
					if (\u0020 == 1)
					{
						goto IL_00FF;
					}
					num2 = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 != 0)
					{
						num2 = 6;
					}
				}
				IL_01C0:
				text = defaultInterpolatedStringHandler.ToStringAndClear();
				num = 9;
			}
			return text;
			IL_01D7:
			return text;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00006290 File Offset: 0x00004490
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u009B\u0099\u0096\u0092\u0091\u0091\u009C\u0090\u0087()
		{
			int num = 318;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((953756095 - 1838868129) ^ -1600530189 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231);
						num2 = 20;
						continue;
					case 2:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-784492755 ^ -2074211111 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3);
						num2 = 110;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 != 0)
						{
							num2 = 93;
							continue;
						}
						continue;
					case 3:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Controls.Add(this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A);
						num2 = 87;
						continue;
					case 4:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Location = new Point(9, 106);
						num2 = 32;
						continue;
					case 5:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.ResumeLayout(false);
						num2 = 360;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d375a57ab5714e038011351b58752657 != 0)
						{
							num2 = 157;
							continue;
						}
						continue;
					case 6:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.TabIndex = 1;
						num2 = 215;
						continue;
					case 7:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-281757643 ^ -2016139488 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292);
						num2 = 304;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f == 0)
						{
							num2 = 140;
							continue;
						}
						continue;
					case 8:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.PerformLayout();
						num2 = 106;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
						{
							num2 = 56;
							continue;
						}
						continue;
					case 9:
						base.ClientSize = new Size(418, 712);
						num2 = 109;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971 == 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 10:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1296616224 >> 2) ^ -1026543383 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6);
						num2 = 173;
						continue;
					case 11:
						base.Controls.Add(this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089);
						num2 = 111;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d == 0)
						{
							num2 = 29;
							continue;
						}
						continue;
					case 12:
						this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.TabIndex = 0;
						num2 = 339;
						continue;
					case 13:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.Location = new Point(72, 24);
						num2 = 347;
						continue;
					case 14:
						base.MaximizeBox = false;
						num2 = 90;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0 != 0)
						{
							num2 = 199;
							continue;
						}
						continue;
					case 15:
						goto IL_319B;
					case 16:
						this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092.Style = ProgressBarStyle.Continuous;
						num2 = 42;
						continue;
					case 17:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.AutoSize = true;
						num2 = 321;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a38905b424c9477eb3c3d2ef4ad1502c == 0)
						{
							num2 = 344;
							continue;
						}
						continue;
					case 18:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-96990369 ^ 603280769 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73);
						num2 = 270;
						continue;
					case 19:
						this.A\u009A\u008B\u0088\u009B\u0094\u008B\u008B\u008B\u0094\u008D = new ToolStripSeparator();
						num2 = 315;
						continue;
					case 20:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.UseVisualStyleBackColor = true;
						num2 = 55;
						continue;
					case 21:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Margin = new Padding(2);
						num2 = 95;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f == 0)
						{
							num2 = 29;
							continue;
						}
						continue;
					case 22:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.Multiline = true;
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					case 23:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.ContextMenuStrip = this.A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089;
						num2 = 84;
						continue;
					case 24:
						goto IL_185E;
					case 25:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--266838818 ^ 1456323359 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904), 10f);
						num2 = 310;
						continue;
					case 26:
						this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-2125143238 ^ -320391797 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754), 10f);
						num2 = 187;
						continue;
					case 27:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.Click += this.AAA\u0097\u009A\u009C\u0086\u0091\u009A\u0090\u0093;
						num2 = 210;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b == 0)
						{
							num2 = 268;
							continue;
						}
						continue;
					case 28:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.Location = new Point(111, 70);
						num2 = 203;
						continue;
					case 29:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Size = new Size(392, 402);
						num2 = 309;
						continue;
					case 30:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1212942792 - -201431463) ^ -50555156 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db);
						num2 = 249;
						continue;
					case 31:
						this.A\u0095\u009D\u0090\u008C\u009C\u0092\u0097\u0092\u0092\u0091.Width = 50;
						num2 = 129;
						continue;
					case 32:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Margin = new Padding(2);
						num2 = 133;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 == 0)
						{
							num2 = 24;
							continue;
						}
						continue;
					case 33:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B = new Button();
						num2 = 302;
						continue;
					case 34:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.Multiline = true;
						num2 = 45;
						continue;
					case 35:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C = new GroupBox();
						num2 = 34;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f != 0)
						{
							num2 = 137;
							continue;
						}
						continue;
					case 36:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.MultiSelect = false;
						num2 = 53;
						continue;
					case 37:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1648996374 + 313516088) ^ -1913901964 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2), 9f);
						num2 = 208;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb == 0)
						{
							num2 = 89;
							continue;
						}
						continue;
					case 38:
						return;
					case 39:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.ItemSize = new Size(132, 28);
						num2 = 4;
						continue;
					case 40:
						this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C = new ToolStripMenuItem();
						num2 = 19;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_187f5dc9d63847ebb305df4c3a07e8c9 != 0)
						{
							num2 = 10;
							continue;
						}
						continue;
					case 41:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-784492755 ^ -1504350350 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b);
						num2 = 350;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db == 0)
						{
							num2 = 344;
							continue;
						}
						continue;
					case 42:
						this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092.TabIndex = 0;
						num2 = 65;
						continue;
					case 43:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Padding = new Padding(2);
						num2 = 29;
						continue;
					case 44:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.UseVisualStyleBackColor = true;
						num2 = 214;
						continue;
					case 45:
						goto IL_1878;
					case 46:
						this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092.Size = new Size(380, 8);
						num2 = 16;
						continue;
					case 47:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1212942792 - -201431463) ^ -1591313216 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0);
						num2 = 94;
						continue;
					case 48:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.TabIndex = 0;
						num2 = 125;
						continue;
					case 49:
						this.A\u009A\u008B\u0088\u009B\u0094\u008B\u008B\u008B\u0094\u008D.Size = new Size(121, 6);
						num2 = 362;
						continue;
					case 50:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.CheckedChanged += this.A\u009D\u008C\u0095\u009A\u0092\u009C\u009D\u0090\u008F\u008B;
						num2 = 207;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d == 0)
						{
							num2 = 90;
							continue;
						}
						continue;
					case 51:
						base.FormBorderStyle = FormBorderStyle.FixedSingle;
						num2 = 14;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 == 0)
						{
							num2 = 9;
							continue;
						}
						continue;
					case 52:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Controls.Add(this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091);
						num2 = 330;
						continue;
					case 53:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(68367775 ^ 1990691905 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5);
						num2 = 175;
						continue;
					case 54:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.Size = new Size(396, 56);
						num2 = 119;
						continue;
					case 55:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Controls.Add(this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B);
						num2 = 180;
						continue;
					case 56:
						this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1933286330 ^ -985784660 ^ -142967588 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75);
						num2 = 46;
						continue;
					case 57:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Controls.Add(this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C);
						num2 = 22;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf != 0)
						{
							num2 = 140;
							continue;
						}
						continue;
					case 58:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.Click += this.AA\u008B\u009B\u0097\u009B\u008A\u0087\u008B\u0096\u0086;
						num2 = 338;
						continue;
					case 59:
						goto IL_0633;
					case 60:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Size = new Size(392, 402);
						num2 = 38;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a != 0)
						{
							num2 = 126;
							continue;
						}
						continue;
					case 61:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-276687066 ^ -1230500069 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904), 10f);
						num2 = 164;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 != 0)
						{
							num2 = 156;
							continue;
						}
						continue;
					case 62:
						this.A\u008E\u008D\u0093\u009D\u0093\u008F\u009E\u0094\u0097\u009E = new ColumnHeader();
						num2 = 333;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_44c58969999b4bcc8508adab214dff9c != 0)
						{
							num2 = 332;
							continue;
						}
						continue;
					case 63:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.TabIndex = 2;
						num2 = 141;
						continue;
					case 64:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Location = new Point(216, 663);
						num2 = 78;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 != 0)
						{
							num2 = 58;
							continue;
						}
						continue;
					case 65:
						this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.BorderStyle = BorderStyle.FixedSingle;
						num2 = 26;
						continue;
					case 66:
						this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1699391948 ^ -565911589 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b), 10f);
						num2 = 234;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f == 0)
						{
							num2 = 256;
							continue;
						}
						continue;
					case 67:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.UseVisualStyleBackColor = true;
						num2 = 217;
						continue;
					case 68:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.Size = new Size(90, 30);
						num2 = 334;
						continue;
					case 69:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086 = new Button();
						num2 = 33;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
						{
							num2 = 26;
							continue;
						}
						continue;
					case 70:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Size = new Size(274, 55);
						num2 = 83;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 130;
							continue;
						}
						continue;
					case 71:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-970983003 ^ 1761673547 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590), 10f);
						num2 = 225;
						continue;
					case 72:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.Controls.Add(this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091);
						num2 = 232;
						continue;
					case 73:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Size = new Size(400, 438);
						num2 = 223;
						continue;
					case 74:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Controls.Add(this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F);
						num2 = 285;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363 != 0)
						{
							num2 = 326;
							continue;
						}
						continue;
					case 75:
						this.A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089.SuspendLayout();
						num2 = 237;
						continue;
					case 76:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.UseVisualStyleBackColor = true;
						num2 = 5;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d375a57ab5714e038011351b58752657 == 0)
						{
							num2 = 251;
							continue;
						}
						continue;
					case 77:
						base.Controls.Add(this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092);
						num2 = 83;
						continue;
					case 78:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-149166022 >> 3) ^ -1714549965 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc);
						num2 = 210;
						continue;
					case 79:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Location = new Point(14, 45);
						num2 = 36;
						continue;
					case 80:
						this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.UseVisualStyleBackColor = true;
						num2 = 86;
						continue;
					case 81:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SuspendLayout();
						num2 = 163;
						continue;
					case 82:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.GridLines = true;
						num2 = 130;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 == 0)
						{
							num2 = 341;
							continue;
						}
						continue;
					case 83:
						base.Controls.Add(this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E);
						num2 = 281;
						continue;
					case 84:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(238793986 ^ 1669882701 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754), 9f);
						num2 = 277;
						continue;
					case 85:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.Size = new Size(72, 16);
						num2 = 222;
						continue;
					case 86:
						this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.Click += this.A\u0086\u0091\u0091\u009B\u0090\u0086\u0089\u0090\u008D\u0093;
						num2 = 24;
						continue;
					case 87:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Controls.Add(this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095);
						num2 = 155;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db != 0)
						{
							num2 = 322;
							continue;
						}
						continue;
					case 88:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.TabStop = false;
						num2 = 321;
						continue;
					case 89:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.AutoSize = true;
						num2 = 179;
						continue;
					case 90:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.Padding = new Padding(2);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_187f5dc9d63847ebb305df4c3a07e8c9 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 91:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-146834757 ^ 2141748327 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b);
						num2 = 246;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_fb7b7adb6e6747ef81ebb3c181669ada != 0)
						{
							num2 = 180;
							continue;
						}
						continue;
					case 92:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Location = new Point(135, 548);
						num2 = 260;
						continue;
					case 93:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.Location = new Point(9, 611);
						num2 = 219;
						continue;
					case 94:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.UseVisualStyleBackColor = true;
						num2 = 332;
						continue;
					case 95:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1661698101 - 842196965) ^ 1866332863 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53);
						num2 = 269;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6 == 0)
						{
							num2 = 195;
							continue;
						}
						continue;
					case 96:
						goto IL_354F;
					case 97:
						this.A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089.ResumeLayout(false);
						num2 = 158;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 != 0)
						{
							num2 = 7;
							continue;
						}
						continue;
					case 98:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.View = View.Details;
						num2 = 105;
						continue;
					case 99:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E = new Button();
						num2 = 234;
						continue;
					case 100:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.ResumeLayout(false);
						num2 = 273;
						continue;
					case 101:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F = new RadioButton();
						num2 = 284;
						continue;
					case 102:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.Click += this.A\u0093\u0094\u009C\u0087\u0094\u0091\u009C\u0092\u008B\u0092;
						num2 = 255;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 == 0)
						{
							num2 = 90;
							continue;
						}
						continue;
					case 103:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.Margin = new Padding(2);
						num2 = 211;
						continue;
					case 104:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.Location = new Point(24, 24);
						num2 = 331;
						continue;
					case 105:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.SelectedIndexChanged += this.A\u008F\u008D\u0091\u008C\u0099\u0087\u009A\u0090\u0090\u0091;
						num2 = 355;
						continue;
					case 106:
						base.ResumeLayout(false);
						num2 = 161;
						continue;
					case 107:
						goto IL_08BD;
					case 108:
						this.AA\u0099\u0087\u008A\u008A\u0087\u0092\u0090\u009C\u0096.Size = new Size(124, 22);
						num2 = 354;
						continue;
					case 109:
						base.Controls.Add(this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B);
						num2 = 96;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590 == 0)
						{
							num2 = 65;
							continue;
						}
						continue;
					case 110:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.ReadOnly = true;
						num2 = 54;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
						{
							num2 = 33;
							continue;
						}
						continue;
					case 111:
						base.Controls.Add(this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093);
						num2 = 51;
						continue;
					case 112:
						goto IL_252A;
					case 113:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.UseVisualStyleBackColor = true;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b == 0)
						{
							num2 = 150;
							continue;
						}
						continue;
					case 114:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Size = new Size(365, 350);
						num2 = 63;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_aeecb0ba81724219b3aab6c572f13b3f != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 115:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(707542027 ^ 864592306 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5);
						num2 = 205;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 == 0)
						{
							num2 = 132;
							continue;
						}
						continue;
					case 116:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.Click += this.A\u008E\u0094\u0090\u0086\u009D\u0098\u008C\u0090\u009C\u009B;
						num2 = 132;
						continue;
					case 117:
						this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-55930691 ^ -459748866 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850);
						num2 = 356;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1 == 0)
						{
							num2 = 326;
							continue;
						}
						continue;
					case 118:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.TabIndex = 2;
						num2 = 135;
						continue;
					case 119:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.TabIndex = 6;
						num2 = 131;
						continue;
					case 120:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.CheckState = CheckState.Checked;
						num2 = 278;
						continue;
					case 121:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-364525890 ^ -1335024317 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1);
						num2 = 136;
						continue;
					case 122:
						this.A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089.Size = new Size(125, 54);
						num2 = 329;
						continue;
					case 123:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.ResumeLayout(false);
						num2 = 316;
						continue;
					case 124:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.Location = new Point(263, 11);
						num2 = 292;
						continue;
					case 125:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SelectedIndexChanged += this.AA\u0086\u009E\u009E\u0099\u0091\u0089\u008B\u0090\u0096;
						num2 = 156;
						continue;
					case 126:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.TabIndex = 1;
						num2 = 266;
						continue;
					case 127:
						this.A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1734173303 ^ 1347321172 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330);
						num2 = 122;
						continue;
					case 128:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Location = new Point(4, 32);
						num2 = 166;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 == 0)
						{
							num2 = 156;
							continue;
						}
						continue;
					case 129:
						this.A\u008E\u008D\u0093\u009D\u0093\u008F\u009E\u0094\u0097\u009E.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1185475502 ^ -874271470 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5);
						num2 = 98;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510 != 0)
						{
							num2 = 243;
							continue;
						}
						continue;
					case 130:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.TabIndex = 4;
						num2 = 282;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c9177097f6d4245975a6f4f2351fc33 != 0)
						{
							num2 = 212;
							continue;
						}
						continue;
					case 131:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1158508049 >> 3) ^ -937998702 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db);
						num2 = 71;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f == 0)
						{
							num2 = 69;
							continue;
						}
						continue;
					case 132:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Columns.AddRange(new ColumnHeader[] { this.A\u008D\u0093\u008C\u008D\u008E\u0095\u0087\u0094\u0086\u0095, this.A\u0090\u0086\u008C\u008F\u0090\u009A\u009B\u0094\u0091\u008E });
						num2 = 121;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094 != 0)
						{
							num2 = 279;
							continue;
						}
						continue;
					case 133:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1096520094 >> 2) ^ 363497704 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53);
						num2 = 4;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 == 0)
						{
							num2 = 147;
							continue;
						}
						continue;
					case 134:
						goto IL_1512;
					case 135:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1480444969 ^ -191233867 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf);
						num2 = 67;
						continue;
					case 136:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.UseVisualStyleBackColor = true;
						num2 = 275;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b != 0)
						{
							num2 = 79;
							continue;
						}
						continue;
					case 137:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E = new TabControl();
						num2 = 272;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1803988e08d94458a1484838316ae19f != 0)
						{
							num2 = 230;
							continue;
						}
						continue;
					case 138:
						goto IL_2FC6;
					case 139:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.AutoSize = true;
						num2 = 37;
						continue;
					case 140:
						goto IL_114D;
					case 141:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.UseCompatibleStateImageBehavior = false;
						num2 = 98;
						continue;
					case 142:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.TabIndex = 0;
						num2 = 287;
						continue;
					case 143:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.FullRowSelect = true;
						num2 = 328;
						continue;
					case 144:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.TabIndex = 10;
						num2 = 101;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 == 0)
						{
							num2 = 289;
							continue;
						}
						continue;
					case 145:
						base.SuspendLayout();
						num2 = 197;
						continue;
					case 146:
						goto IL_3C1E;
					case 147:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SelectedIndex = 0;
						num2 = 73;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 148:
						this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((2107586582 - -729554149) ^ -1693727295 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d);
						num2 = 240;
						continue;
					case 149:
						this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.BorderStyle = BorderStyle.FixedSingle;
						num2 = 66;
						continue;
					case 150:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.Click += this.A\u0093\u0094\u0091\u009A\u0089\u0091\u009B\u009E\u0090\u009A;
						num2 = 194;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 == 0)
						{
							num2 = 170;
							continue;
						}
						continue;
					case 151:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.TabIndex = 2;
						num2 = 209;
						continue;
					case 152:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095 = new Button();
						num2 = 283;
						continue;
					case 153:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.Location = new Point(322, 9);
						num2 = 359;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53 == 0)
						{
							num2 = 106;
							continue;
						}
						continue;
					case 154:
						this.A\u009A\u008B\u0088\u009B\u0094\u008B\u008B\u008B\u0094\u008D.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-149345273 ^ -2052221397 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5);
						num2 = 15;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ca4cfff71871411997ee2c1fb2f8f95e == 0)
						{
							num2 = 49;
							continue;
						}
						continue;
					case 155:
						goto IL_09B2;
					case 156:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Controls.Add(this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088);
						num2 = 313;
						continue;
					case 157:
						this.A\u0090\u0086\u008C\u008F\u0090\u009A\u009B\u0094\u0091\u008E.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(247185273 ^ 1418942504 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1);
						num2 = 245;
						continue;
					case 158:
						goto IL_2097;
					case 159:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.Click += this.AA\u0094\u009C\u0090\u0090\u0091\u0094\u0097\u0090\u009D;
						num2 = 21;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33 != 0)
						{
							num2 = 74;
							continue;
						}
						continue;
					case 160:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.BorderStyle = BorderStyle.None;
						num2 = 23;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c == 0)
						{
							num2 = 23;
							continue;
						}
						continue;
					case 161:
						base.PerformLayout();
						num2 = 38;
						continue;
					case 162:
						this.A\u008D\u0093\u008C\u008D\u008E\u0095\u0087\u0094\u0086\u0095 = new ColumnHeader();
						num2 = 185;
						continue;
					case 163:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.SuspendLayout();
						num2 = 307;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 164:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.Location = new Point(316, 70);
						num2 = 104;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 == 0)
						{
							num2 = 115;
							continue;
						}
						continue;
					case 165:
						this.A\u0095\u009D\u0090\u008C\u009C\u0092\u0097\u0092\u0092\u0091.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((821404560 + -1679822156) ^ -1056149136 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c);
						num2 = 31;
						continue;
					case 166:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Margin = new Padding(2);
						num2 = 186;
						continue;
					case 167:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.Checked = true;
						num2 = 294;
						continue;
					case 168:
						base.Controls.Add(this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E);
						num2 = 11;
						continue;
					case 169:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1788212368 ^ 119939617 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754), 10f);
						num2 = 64;
						continue;
					case 170:
						this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092.Location = new Point(10, 21);
						num2 = 56;
						continue;
					case 171:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-970983003 ^ 549293561 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f);
						num2 = 57;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 != 0)
						{
							num2 = 56;
							continue;
						}
						continue;
					case 172:
						this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.Size = new Size(295, 23);
						num2 = 12;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 == 0)
						{
							num2 = 12;
							continue;
						}
						continue;
					case 173:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.Size = new Size(90, 30);
						num2 = 138;
						continue;
					case 174:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.MouseEnter += this.AA\u008F\u008D\u0086\u0092\u008D\u0096\u009E\u009C\u009E;
						num2 = 230;
						continue;
					case 175:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Size = new Size(365, 350);
						num2 = 101;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d == 0)
						{
							num2 = 267;
							continue;
						}
						continue;
					case 176:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.SuspendLayout();
						num2 = 224;
						continue;
					case 177:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094 = new TabPage();
						num2 = 212;
						continue;
					case 178:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091 = new RadioButton();
						num2 = 220;
						continue;
					case 179:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.Checked = true;
						num2 = 120;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 != 0)
						{
							num2 = 78;
							continue;
						}
						continue;
					case 180:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Controls.Add(this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095);
						num2 = 3;
						continue;
					case 181:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.Size = new Size(55, 25);
						num2 = 351;
						continue;
					case 182:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.UseVisualStyleBackColor = true;
						num2 = 116;
						continue;
					case 183:
						goto IL_29AC;
					case 184:
						base.Controls.Add(this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C);
						num2 = 291;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66 == 0)
						{
							num2 = 194;
							continue;
						}
						continue;
					case 185:
						this.A\u0090\u0086\u008C\u008F\u0090\u009A\u009B\u0094\u0091\u008E = new ColumnHeader();
						num2 = 328;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
						{
							num2 = 346;
							continue;
						}
						continue;
					case 186:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1362952674 ^ -875373548 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363);
						num2 = 43;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_fb7b7adb6e6747ef81ebb3c181669ada != 0)
						{
							num2 = 34;
							continue;
						}
						continue;
					case 187:
						this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.Location = new Point(14, 12);
						num2 = 227;
						continue;
					case 188:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1536669816 ^ -1584125095 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53);
						num2 = 353;
						continue;
					case 189:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.TabIndex = 1;
						num2 = 28;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ca4cfff71871411997ee2c1fb2f8f95e == 0)
						{
							num2 = 41;
							continue;
						}
						continue;
					case 190:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1362952674 ^ -135732137 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904);
						num2 = 231;
						continue;
					case 191:
						this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-174680055 ^ -226554898 ^ 905511015 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d), 10f);
						num2 = 111;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 324;
							continue;
						}
						continue;
					case 192:
						this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.Size = new Size(195, 40);
						num2 = 297;
						continue;
					case 193:
						goto IL_3862;
					case 194:
						goto IL_1B10;
					case 195:
						this.A\u0095\u009D\u0090\u008C\u009C\u0092\u0097\u0092\u0092\u0091 = new ColumnHeader();
						num2 = 62;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_37d4c0ccbd094f76a7cf8f93864def2a != 0)
						{
							num2 = 29;
							continue;
						}
						continue;
					case 196:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.UseVisualStyleBackColor = true;
						num2 = 159;
						continue;
					case 197:
						this.A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089.Items.AddRange(new ToolStripItem[] { this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C, this.A\u009A\u008B\u0088\u009B\u0094\u008B\u008B\u008B\u0094\u008D, this.AA\u0099\u0087\u008A\u008A\u0087\u0092\u0090\u009C\u0096 });
						num2 = 127;
						continue;
					case 198:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1881530452 ^ 1968201703 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c), 10f);
						num2 = 39;
						continue;
					case 199:
						base.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-595948928 ^ -1210249195 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231);
						num2 = 274;
						continue;
					case 200:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.Location = new Point(214, 70);
						num2 = 325;
						continue;
					case 201:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.View = View.Details;
						num2 = 236;
						continue;
					case 202:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.TabStop = false;
						num2 = 171;
						continue;
					case 203:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1279729392 << 4) ^ -1056681761 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c);
						num2 = 68;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2 == 0)
						{
							num2 = 32;
							continue;
						}
						continue;
					case 204:
						this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1922313580 ^ 1994518463 ^ -973069645 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2);
						num2 = 78;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 == 0)
						{
							num2 = 192;
							continue;
						}
						continue;
					case 205:
						goto IL_0CD4;
					case 206:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.ResumeLayout(false);
						num2 = 363;
						continue;
					case 207:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.Controls.Add(this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092);
						num2 = 93;
						continue;
					case 208:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.Location = new Point(216, 24);
						num2 = 226;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 == 0)
						{
							num2 = 32;
							continue;
						}
						continue;
					case 209:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-831831707 - 2056861714) ^ 971365120 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f);
						num2 = 19;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 == 0)
						{
							num2 = 44;
							continue;
						}
						continue;
					case 210:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Size = new Size(195, 40);
						num2 = 265;
						continue;
					case 211:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1922313580 ^ 1994518463 ^ -1566561906 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904);
						num2 = 90;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b == 0)
						{
							num2 = 88;
							continue;
						}
						continue;
					case 212:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092 = new TabPage();
						num2 = 335;
						continue;
					case 213:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.Controls.Add(this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090);
						num2 = 258;
						continue;
					case 214:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.AcceptsTab = true;
						num2 = 235;
						continue;
					case 215:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-276687066 ^ -1527454119 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971);
						num2 = 113;
						continue;
					case 216:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.AutoSize = true;
						num2 = 118;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb != 0)
						{
							num2 = 167;
							continue;
						}
						continue;
					case 217:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.CheckedChanged += this.A\u0096\u008B\u0091\u008A\u008B\u0098\u0089\u0092\u0095\u0093;
						num2 = 139;
						continue;
					case 218:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.Size = new Size(400, 40);
						num2 = 229;
						continue;
					case 219:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(963518231 ^ 1914232888 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971);
						num2 = 218;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d375a57ab5714e038011351b58752657 != 0)
						{
							num2 = 158;
							continue;
						}
						continue;
					case 220:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C = new RadioButton();
						num2 = 67;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed == 0)
						{
							num2 = 303;
							continue;
						}
						continue;
					case 221:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1922313580 ^ 1994518463 ^ -1634070075 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363);
						num2 = 114;
						continue;
					case 222:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.TabIndex = 0;
						num2 = 188;
						continue;
					case 223:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.SizeMode = TabSizeMode.Fixed;
						num2 = 48;
						continue;
					case 224:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.SuspendLayout();
						num2 = 39;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 == 0)
						{
							num2 = 81;
							continue;
						}
						continue;
					case 225:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.Location = new Point(8, 70);
						num2 = 10;
						continue;
					case 226:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-970983003 ^ 396228125 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6);
						num2 = 280;
						continue;
					case 227:
						this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1342393391 ^ 90231933 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3);
						num2 = 172;
						continue;
					case 228:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.TabIndex = 5;
						num2 = 88;
						continue;
					case 229:
						this.A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C.TabIndex = 3;
						num2 = 202;
						continue;
					case 230:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.MouseLeave += this.A\u0088\u0094\u0094\u0088\u009B\u008A\u0092\u008B\u009E\u0092;
						num2 = 138;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 == 0)
						{
							num2 = 170;
							continue;
						}
						continue;
					case 231:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.Size = new Size(47, 16);
						num2 = 176;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
						{
							num2 = 290;
							continue;
						}
						continue;
					case 232:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.Location = new Point(4, 32);
						num2 = 103;
						continue;
					case 233:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.ScrollBars = ScrollBars.Both;
						num2 = 276;
						continue;
					case 234:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092 = new Button();
						num2 = 42;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 == 0)
						{
							num2 = 69;
							continue;
						}
						continue;
					case 235:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-784492755 ^ -2107266757 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf), 10f);
						num2 = 293;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc == 0)
						{
							num2 = 140;
							continue;
						}
						continue;
					case 236:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.SelectedIndexChanged += this.A\u0091\u008B\u009E\u008D\u0091\u0088\u0093\u009E\u0093\u009A;
						num2 = 165;
						continue;
					case 237:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.SuspendLayout();
						num2 = 176;
						continue;
					case 238:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095 = new Button();
						num2 = 292;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_be5da1cd750e495490bb42f04b10e65d == 0)
						{
							num2 = 342;
							continue;
						}
						continue;
					case 239:
						this.A\u008D\u0093\u008C\u008D\u008E\u0095\u0087\u0094\u0086\u0095.Width = 50;
						num2 = 157;
						continue;
					case 240:
						this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.Size = new Size(175, 23);
						num2 = 286;
						continue;
					case 241:
						goto IL_3207;
					case 242:
						goto IL_1171;
					case 243:
						this.A\u008E\u008D\u0093\u009D\u0093\u008F\u009E\u0094\u0097\u009E.Width = 285;
						num2 = 149;
						continue;
					case 244:
						this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088 = new TextBox();
						num2 = 152;
						continue;
					case 245:
						goto IL_15DE;
					case 246:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.Size = new Size(55, 25);
						num2 = 103;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 != 0)
						{
							num2 = 352;
							continue;
						}
						continue;
					case 247:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-238694913 ^ -1939626513 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53);
						num2 = 288;
						continue;
					case 248:
						this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C.CheckedChanged += this.A\u0095\u0088\u0090\u0096\u009C\u0091\u0098\u0092\u0097\u0098;
						num2 = 154;
						continue;
					case 249:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.UseVisualStyleBackColor = true;
						num2 = 337;
						continue;
					case 250:
						this.A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092 = new ProgressBar();
						num2 = 244;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1 == 0)
						{
							num2 = 191;
							continue;
						}
						continue;
					case 251:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.Click += this.A\u0089\u0097\u0091\u0089\u0099\u009A\u0086\u008B\u0087\u009E;
						num2 = 305;
						continue;
					case 252:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.Size = new Size(47, 16);
						num2 = 259;
						continue;
					case 253:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Controls.Add(this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092);
						num2 = 198;
						continue;
					case 254:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A = new GroupBox();
						num2 = 101;
						continue;
					case 255:
						goto IL_0FD9;
					case 256:
						this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.Location = new Point(14, 12);
						num2 = 148;
						continue;
					case 257:
						goto IL_0874;
					case 258:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.Location = new Point(9, 548);
						num2 = 94;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
						{
							num2 = 193;
							continue;
						}
						continue;
					case 259:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.TabIndex = 1;
						num2 = 148;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 == 0)
						{
							num2 = 183;
							continue;
						}
						continue;
					case 260:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1315084 << 6) ^ -16261379 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53);
						num2 = 70;
						continue;
					case 261:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.Size = new Size(55, 25);
						num2 = 6;
						continue;
					case 262:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Location = new Point(4, 32);
						num2 = 21;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 263:
						this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(647845501 ^ 1867736667 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a);
						num2 = 261;
						continue;
					case 264:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.CheckedChanged += this.A\u0096\u008B\u0091\u008A\u008B\u0098\u0089\u0092\u0095\u0093;
						num2 = 216;
						continue;
					case 265:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.TabIndex = 2;
						num2 = 107;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d == 0)
						{
							num2 = 121;
							continue;
						}
						continue;
					case 266:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-2051710422 ^ -864330654 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a);
						num2 = 296;
						continue;
					case 267:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.TabIndex = 2;
						num2 = 65;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 == 0)
						{
							num2 = 312;
							continue;
						}
						continue;
					case 268:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Columns.AddRange(new ColumnHeader[] { this.A\u0095\u009D\u0090\u008C\u009C\u0092\u0097\u0092\u0092\u0091, this.A\u008E\u008D\u0093\u009D\u0093\u008F\u009E\u0094\u0097\u009E });
						num2 = 143;
						continue;
					case 269:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Padding = new Padding(2);
						num2 = 35;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 != 0)
						{
							num2 = 60;
							continue;
						}
						continue;
					case 270:
						this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.UseVisualStyleBackColor = true;
						num2 = 58;
						continue;
					case 271:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1699391948 ^ -900443867 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590), 9f);
						num2 = 348;
						continue;
					case 272:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C = new TabPage();
						num2 = 177;
						continue;
					case 273:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.PerformLayout();
						num2 = 301;
						continue;
					case 274:
						this.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-541696120 ^ -632671653 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53);
						num2 = 97;
						continue;
					case 275:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Click += this.A\u008C\u0099\u008B\u009A\u0087\u0098\u0089\u009E\u0095\u0099;
						num2 = 174;
						continue;
					case 276:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.Size = new Size(368, 385);
						num2 = 142;
						continue;
					case 277:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.Location = new Point(9, 8);
						num2 = 22;
						continue;
					case 278:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-275825843 ^ 302041667 ^ -173890692 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e), 9f);
						num2 = 104;
						continue;
					case 279:
						goto IL_1BB1;
					case 280:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.Size = new Size(47, 16);
						num2 = 340;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 != 0)
						{
							num2 = 59;
							continue;
						}
						continue;
					case 281:
						base.Controls.Add(this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086);
						num2 = 184;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b == 0)
						{
							num2 = 118;
							continue;
						}
						continue;
					case 282:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.TabStop = false;
						num2 = 241;
						continue;
					case 283:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E = new ListView();
						num2 = 144;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c != 0)
						{
							num2 = 195;
							continue;
						}
						continue;
					case 284:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C = new RadioButton();
						num2 = 178;
						continue;
					case 285:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1734807256 ^ -1433899172 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d);
						num2 = 320;
						continue;
					case 286:
						this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.TabIndex = 0;
						num2 = 25;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73 == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					case 287:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.WordWrap = false;
						num2 = 149;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce != 0)
						{
							num2 = 295;
							continue;
						}
						continue;
					case 288:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.UseVisualStyleBackColor = true;
						num2 = 102;
						continue;
					case 289:
						this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1482712261 ^ 385099635 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b);
						num2 = 182;
						continue;
					case 290:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.TabIndex = 0;
						num2 = 7;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a38905b424c9477eb3c3d2ef4ad1502c != 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					case 291:
						base.Controls.Add(this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D);
						num2 = 155;
						continue;
					case 292:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-214453972 ^ -11646669 ^ 1690287564 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1);
						num2 = 181;
						continue;
					case 293:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.Location = new Point(13, 10);
						num2 = 34;
						continue;
					case 294:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(992923615 ^ 705762505 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b), 9f);
						num2 = 13;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 == 0)
						{
							num2 = 10;
							continue;
						}
						continue;
					case 295:
						base.AutoScaleDimensions = new SizeF(7f, 17f);
						num2 = 32;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f != 0)
						{
							num2 = 59;
							continue;
						}
						continue;
					case 296:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.UseVisualStyleBackColor = true;
						num2 = 72;
						continue;
					case 297:
						this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.TabIndex = 1;
						num2 = 112;
						continue;
					case 298:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.Size = new Size(90, 30);
						num2 = 41;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a != 0)
						{
							num2 = 349;
							continue;
						}
						continue;
					case 299:
						this.AA\u0099\u0087\u008A\u008A\u0087\u0092\u0090\u009C\u0096.Click += this.A\u0097\u0092\u008C\u009E\u0089\u009A\u0098\u0092\u009A\u008A;
						num2 = 357;
						continue;
					case 300:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1685567939 ^ 1530834784 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db);
						num2 = 76;
						continue;
					case 301:
						this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.ResumeLayout(false);
						num2 = 8;
						continue;
					case 302:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093 = new ListView();
						num2 = 162;
						continue;
					case 303:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D = new GroupBox();
						num2 = 134;
						continue;
					case 304:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.UseVisualStyleBackColor = true;
						num2 = 254;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f != 0)
						{
							num2 = 264;
							continue;
						}
						continue;
					case 305:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1648996374 + 313516088) ^ -1146656515 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200), 10f);
						num2 = 146;
						continue;
					case 306:
						this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-970983003 ^ 1761673709 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590);
						num2 = 248;
						continue;
					case 307:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.SuspendLayout();
						num2 = 242;
						continue;
					case 308:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.AutoSize = true;
						num2 = 271;
						continue;
					case 309:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.TabIndex = 0;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 310:
						goto IL_0707;
					case 311:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Controls.Add(this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093);
						num2 = 6;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db != 0)
						{
							num2 = 128;
							continue;
						}
						continue;
					case 312:
						this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.UseCompatibleStateImageBehavior = false;
						num2 = 201;
						continue;
					case 313:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.Controls.Add(this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095);
						num2 = 73;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 != 0)
						{
							num2 = 311;
							continue;
						}
						continue;
					case 314:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.Size = new Size(47, 16);
						num2 = 68;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 == 0)
						{
							num2 = 118;
							continue;
						}
						continue;
					case 315:
						this.AA\u0099\u0087\u008A\u008A\u0087\u0092\u0090\u009C\u0096 = new ToolStripMenuItem();
						num2 = 257;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca == 0)
						{
							num2 = 43;
							continue;
						}
						continue;
					case 316:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.PerformLayout();
						num2 = 206;
						continue;
					case 317:
						this.A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089 = new ContextMenuStrip(this.AA\u009B\u009A\u0098\u0088\u008D\u0088\u008C\u008B\u0087);
						num2 = 40;
						continue;
					case 318:
						this.AA\u009B\u009A\u0098\u0088\u008D\u0088\u008C\u008B\u0087 = new Container();
						num2 = 317;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
						{
							num2 = 134;
							continue;
						}
						continue;
					case 319:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.PerformLayout();
						num2 = 123;
						continue;
					case 320:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.UseVisualStyleBackColor = true;
						num2 = 88;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 != 0)
						{
							num2 = 358;
							continue;
						}
						continue;
					case 321:
						this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-922289810 ^ -1228242833 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094);
						num2 = 89;
						continue;
					case 322:
						this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094.Controls.Add(this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E);
						num2 = 262;
						continue;
					case 323:
						this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089 = new Button();
						num2 = 250;
						continue;
					case 324:
						this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.Location = new Point(7, 663);
						num2 = 185;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 == 0)
						{
							num2 = 204;
							continue;
						}
						continue;
					case 325:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(561493477 ^ 716631412 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200);
						num2 = 298;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a == 0)
						{
							num2 = 228;
							continue;
						}
						continue;
					case 326:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Controls.Add(this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C);
						num2 = 52;
						continue;
					case 327:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1755067093 ^ -497678589 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283);
						num2 = 314;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 == 0)
						{
							num2 = 113;
							continue;
						}
						continue;
					case 328:
						goto IL_118A;
					case 329:
						this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C.CheckOnClick = true;
						num2 = 117;
						continue;
					case 330:
						this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Controls.Add(this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C);
						num2 = 92;
						continue;
					case 331:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(963518231 ^ 559696580 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850);
						num2 = 85;
						continue;
					case 332:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.Click += this.A\u008D\u0091\u0087\u009E\u008A\u008C\u0093\u009E\u0093\u0089;
						num2 = 24;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 == 0)
						{
							num2 = 61;
							continue;
						}
						continue;
					case 333:
						this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B = new TextBox();
						num2 = 238;
						continue;
					case 334:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.TabIndex = 8;
						num2 = 247;
						continue;
					case 335:
						this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091 = new TextBox();
						num2 = 75;
						continue;
					case 336:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1731321202 << 4) ^ -1986554533 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c);
						num2 = 196;
						continue;
					case 337:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.CheckedChanged += this.A\u0096\u008B\u0091\u008A\u008B\u0098\u0089\u0092\u0095\u0093;
						num2 = 118;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c != 0)
						{
							num2 = 308;
							continue;
						}
						continue;
					case 338:
						this.A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1219413587 ^ -469170363 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf), 10f);
						num2 = 28;
						continue;
					case 339:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-1437012807 ^ 1943871299 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583), 10f);
						num2 = 111;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 == 0)
						{
							num2 = 153;
							continue;
						}
						continue;
					case 340:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.TabIndex = 3;
						num2 = 152;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 != 0)
						{
							num2 = 285;
							continue;
						}
						continue;
					case 341:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Location = new Point(14, 45);
						num2 = 361;
						continue;
					case 342:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A = new Button();
						num2 = 345;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 != 0)
						{
							num2 = 290;
							continue;
						}
						continue;
					case 343:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.Size = new Size(59, 27);
						num2 = 76;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8a7706961f2842d0974d2f2cdf994020 == 0)
						{
							num2 = 189;
							continue;
						}
						continue;
					case 344:
						this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1641633745 ^ -1499476891 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3e7119b219884fb89fd2909088fcea1c), 9f);
						num2 = 107;
						continue;
					case 345:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095 = new Button();
						num2 = 254;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6 == 0)
						{
							num2 = 78;
							continue;
						}
						continue;
					case 346:
						goto IL_157F;
					case 347:
						this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-364525890 ^ -483842007 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1);
						num2 = 252;
						continue;
					case 348:
						this.AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091.Location = new Point(144, 24);
						num2 = 327;
						continue;
					case 349:
						this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.TabIndex = 9;
						num2 = 47;
						continue;
					case 350:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.UseVisualStyleBackColor = true;
						num2 = 27;
						continue;
					case 351:
						this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.TabIndex = 2;
						num2 = 300;
						continue;
					case 352:
						this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.TabIndex = 3;
						num2 = 336;
						continue;
					case 353:
						this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090.UseVisualStyleBackColor = true;
						num2 = 50;
						continue;
					case 354:
						this.AA\u0099\u0087\u008A\u008A\u0087\u0092\u0090\u009C\u0096.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(647845501 ^ 11532242 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_83ec5f9528e04212ae784523bb8c3e73);
						num2 = 299;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef == 0)
						{
							num2 = 54;
							continue;
						}
						continue;
					case 355:
						this.A\u008D\u0093\u008C\u008D\u008E\u0095\u0087\u0094\u0086\u0095.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1637534663 + 1764814831) ^ -146693090 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2);
						num2 = 239;
						continue;
					case 356:
						this.A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C.Size = new Size(124, 22);
						num2 = 306;
						continue;
					case 357:
						this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086.BackColor = SystemColors.Window;
						num2 = 160;
						continue;
					case 358:
						this.A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C.CheckedChanged += this.A\u0096\u008B\u0091\u008A\u008B\u0098\u0089\u0092\u0095\u0093;
						num2 = 213;
						continue;
					case 359:
						this.A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1078648229 ^ -248725467 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb);
						num2 = 343;
						continue;
					case 360:
						this.A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C.PerformLayout();
						num2 = 100;
						continue;
					case 361:
						this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.MultiSelect = false;
						num2 = 221;
						continue;
					case 362:
						this.AA\u0099\u0087\u008A\u008A\u0087\u0092\u0090\u009C\u0096.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-541696120 ^ -1273902665 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231);
						num2 = 18;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
						{
							num2 = 108;
							continue;
						}
						continue;
					case 363:
						this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.ResumeLayout(false);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 == 0)
						{
							num2 = 5;
							continue;
						}
						continue;
					}
					this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.Size = new Size(392, 402);
					num2 = 151;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66 == 0)
					{
						num2 = 11;
					}
				}
				IL_0633:
				base.AutoScaleMode = AutoScaleMode.Font;
				num = 9;
				continue;
				IL_0707:
				this.A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095.Location = new Point(198, 11);
				num = 263;
				continue;
				IL_0874:
				this.A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086 = new TextBox();
				num = 99;
				continue;
				IL_08BD:
				this.A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F.Location = new Point(12, 24);
				num = 190;
				continue;
				IL_09B2:
				base.Controls.Add(this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A);
				num = 168;
				continue;
				IL_0CD4:
				this.A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B.Size = new Size(90, 30);
				num = 144;
				continue;
				IL_0FD9:
				this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(141962467 ^ 95406121 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c), 10f);
				num = 200;
				continue;
				IL_114D:
				this.AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E.Controls.Add(this.A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094);
				num = 253;
				continue;
				IL_1171:
				this.A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092.SuspendLayout();
				num = 145;
				continue;
				IL_118A:
				this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.GridLines = true;
				num = 79;
				continue;
				IL_1512:
				this.A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090 = new CheckBox();
				num = 35;
				continue;
				IL_157F:
				this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093 = new Button();
				num = 323;
				continue;
				IL_15DE:
				this.A\u0090\u0086\u008C\u008F\u0090\u009A\u009B\u0094\u0091\u008E.Width = 285;
				num = 191;
				continue;
				IL_185E:
				this.A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089.Enabled = false;
				num = 169;
				continue;
				IL_1878:
				this.A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1442726474 ^ 2013985340 ^ -535045944 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d);
				num = 233;
				continue;
				IL_1B10:
				this.A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1123501873 ^ 2138921831 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2), 10f);
				num = 124;
				continue;
				IL_1BB1:
				this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.FullRowSelect = true;
				num = 82;
				continue;
				IL_2097:
				this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.ResumeLayout(false);
				num = 319;
				continue;
				IL_252A:
				this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1126285631 ^ -734093132 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292);
				num = 80;
				continue;
				IL_29AC:
				this.A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C.TabStop = true;
				num = 30;
				continue;
				IL_2FC6:
				this.AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E.TabIndex = 7;
				num = 18;
				continue;
				IL_319B:
				this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.Size = new Size(120, 55);
				num = 228;
				continue;
				IL_3207:
				this.A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-146834757 ^ 1871548582 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_995893e15640499db99898ce289aa393);
				num = 17;
				continue;
				IL_354F:
				base.Controls.Add(this.A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086);
				num = 77;
				continue;
				IL_3862:
				this.A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1734173303 ^ 1729318532 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b);
				num = 15;
				continue;
				IL_3C1E:
				this.A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095.Location = new Point(326, 11);
				num = 91;
			}
		}

		// Token: 0x06000069 RID: 105 RVA: 0x0000A060 File Offset: 0x00008260
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u0095\u009E\u0091\u008C\u008C\u0092\u009A\u009A\u0092(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.AA\u008A\u009A\u0099\u0097\u0095\u009C\u0088\u0089\u009C.AA\u008F\u009B\u0094\u008F\u0094\u0098\u0091\u0098\u009C(\u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x0600006A RID: 106 RVA: 0x0000A0C4 File Offset: 0x000082C4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0091\u0088\u0098\u0093\u008D\u009D\u009E\u0090\u0087\u0093(bool \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.AA\u008A\u009A\u0099\u0097\u0095\u009C\u0088\u0089\u009C.AA\u009C\u0090\u0091\u008E\u0099\u0098\u0090\u0088\u0086(\u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600006B RID: 107 RVA: 0x0000A128 File Offset: 0x00008328
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0099\u0093\u0099\u009B\u0087\u0088\u0092\u008B\u0099\u0087(double \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094.AA\u0095\u0098\u009D\u0088\u0087\u0088\u0092\u0087\u009A(\u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600006C RID: 108 RVA: 0x0000A18C File Offset: 0x0000838C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009B\u0090\u0093\u009C\u008D\u008E\u0099\u0090\u0089\u0097(int \u0020, bool \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 0:
					goto IL_00F6;
				case 1:
					goto IL_0137;
				case 2:
					return;
				case 3:
					break;
				case 4:
					if (!\u0020)
					{
						num2 = 3;
						continue;
					}
					goto IL_0137;
				case 5:
					return;
				case 6:
					this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Items[\u0020].EnsureVisible();
					num2 = 7;
					continue;
				case 7:
					this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Focus();
					num2 = 5;
					continue;
				default:
					goto IL_00F6;
				}
				IL_0068:
				MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1734807256 ^ -1844189989 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4) + this.A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088.Text.Trim() + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-252024401 ^ -80003742 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1063499328 ^ -1059953493 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1 == 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_00F6:
				this.A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093.Items[\u0020].Selected = true;
				num2 = 6;
				continue;
				IL_0137:
				if (\u0020 < 0)
				{
					goto IL_0068;
				}
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d != 0)
				{
					num2 = 0;
				}
			}
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000A31C File Offset: 0x0000851C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0094\u008E\u008B\u008F\u008D\u008F\u0087\u008B\u0089\u009E(int \u0020, bool \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_01A0;
				case 2:
					goto IL_009E;
				case 3:
					if (!\u0020)
					{
						num2 = 2;
						continue;
					}
					goto IL_01A0;
				case 4:
					this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Focus();
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8838d4ed8f054abebce2c8db8270b0ca == 0)
					{
						num2 = 7;
						continue;
					}
					continue;
				case 5:
					this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Items[\u0020].EnsureVisible();
					num2 = 4;
					continue;
				case 6:
					goto IL_009E;
				case 7:
					return;
				case 8:
					return;
				}
				IL_0047:
				this.A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E.Items[\u0020].Selected = true;
				num2 = 5;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1 != 0)
				{
					num2 = 5;
					continue;
				}
				continue;
				IL_009E:
				MessageBox.Show(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(708720596 ^ 1544786413 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427) + this.A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B.Text.Trim() + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(561493477 ^ 1139034446 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1109220480 << 2) ^ 273098351 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850), MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				num2 = 8;
				continue;
				IL_01A0:
				if (\u0020 >= 0)
				{
					goto IL_0047;
				}
				num2 = 6;
			}
		}

		// Token: 0x0600006E RID: 110 RVA: 0x0000A4DC File Offset: 0x000086DC
		[CompilerGenerated]
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0091\u009C\u0090\u0086\u009E\u0094\u008E\u0094\u008B\u008E([Nullable(2)] object s, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093.PerformClick();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600006F RID: 111 RVA: 0x0000A540 File Offset: 0x00008740
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0090\u0089\u009C\u0088\u0096\u008D\u009E\u0094\u0086\u0098()
		{
			return AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.A\u0086\u009D\u0089\u0090\u009E\u0094\u008F\u008B\u0094\u0094 == null;
		}

		// Token: 0x06000070 RID: 112 RVA: 0x0000A554 File Offset: 0x00008754
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096 AA\u0086\u009E\u0095\u0089\u0087\u009D\u009A\u0086\u0098()
		{
			return AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096.A\u0086\u009D\u0089\u0090\u009E\u0094\u008F\u008B\u0094\u0094;
		}

		// Token: 0x06000071 RID: 113 RVA: 0x0000A564 File Offset: 0x00008764
		static AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000019 RID: 25
		[Nullable(1)]
		private readonly A\u0099\u008A\u0095\u008F\u0095\u0094\u0090\u009E\u009E\u0093 A\u009D\u0095\u0091\u009A\u008C\u0092\u0098\u008B\u008A\u0094;

		// Token: 0x0400001A RID: 26
		[Nullable(1)]
		private readonly AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099 A\u008A\u008E\u0095\u009A\u0087\u009B\u0099\u0092\u008A\u0091;

		// Token: 0x0400001B RID: 27
		[Nullable(1)]
		private readonly AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099 AA\u008B\u0094\u0086\u0087\u0098\u008C\u0086\u0092\u0097;

		// Token: 0x0400001C RID: 28
		[Nullable(1)]
		private readonly AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094 A\u009A\u0086\u0087\u0092\u0093\u0095\u009B\u008B\u0092\u0086;

		// Token: 0x0400001D RID: 29
		[Nullable(1)]
		private readonly A\u008B\u009A\u0099\u009B\u009C\u0097\u0093\u009E\u0090\u008B A\u008E\u0091\u0094\u0090\u008B\u0096\u008B\u0094\u0095\u008A;

		// Token: 0x0400001E RID: 30
		[Nullable(1)]
		private readonly A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B AA\u008A\u009A\u0099\u0097\u0095\u009C\u0088\u0089\u009C;

		// Token: 0x0400001F RID: 31
		private long A\u0089\u009D\u0086\u008B\u009A\u0088\u008D\u009E\u0088\u009C;

		// Token: 0x04000020 RID: 32
		private bool AA\u009A\u0097\u0092\u0094\u0095\u0090\u0090\u008D\u008E;

		// Token: 0x04000022 RID: 34
		private object A\u009B\u0092\u008B\u008F\u0092\u0092\u0093\u0092\u0092\u0093;

		// Token: 0x04000023 RID: 35
		private object A\u008D\u0093\u008C\u008D\u008E\u0095\u0087\u0094\u0086\u0095;

		// Token: 0x04000024 RID: 36
		private object A\u0090\u0086\u008C\u008F\u0090\u009A\u009B\u0094\u0091\u008E;

		// Token: 0x04000025 RID: 37
		private object A\u008D\u0096\u009D\u0094\u008C\u0096\u009C\u0092\u009E\u0093;

		// Token: 0x04000026 RID: 38
		private object A\u009D\u0096\u0089\u008D\u008D\u0093\u009B\u0094\u0091\u0089;

		// Token: 0x04000027 RID: 39
		private object A\u0088\u0093\u008B\u008B\u0096\u0086\u008C\u0094\u0095\u009C;

		// Token: 0x04000028 RID: 40
		private object A\u0094\u0095\u009D\u009C\u008B\u009E\u0093\u0090\u008D\u0092;

		// Token: 0x04000029 RID: 41
		private object A\u0087\u0094\u008E\u008C\u0098\u009C\u009D\u008B\u008C\u0088;

		// Token: 0x0400002A RID: 42
		private object A\u0094\u0093\u0093\u0088\u009D\u0088\u008B\u009E\u008C\u0095;

		// Token: 0x0400002B RID: 43
		private object A\u009E\u0098\u0098\u0095\u008A\u009C\u0092\u0090\u0086\u009E;

		// Token: 0x0400002C RID: 44
		private object A\u0095\u009D\u0090\u008C\u009C\u0092\u0097\u0092\u0092\u0091;

		// Token: 0x0400002D RID: 45
		private object A\u008E\u008D\u0093\u009D\u0093\u008F\u009E\u0094\u0097\u009E;

		// Token: 0x0400002E RID: 46
		private object A\u008A\u008F\u0088\u008E\u0086\u009B\u0092\u0090\u0094\u008B;

		// Token: 0x0400002F RID: 47
		private object A\u008C\u0089\u0099\u0087\u0096\u0097\u0098\u009E\u0095\u0095;

		// Token: 0x04000030 RID: 48
		private object A\u0089\u008A\u009C\u0093\u0096\u0095\u009D\u0094\u008A\u008A;

		// Token: 0x04000031 RID: 49
		private object A\u0092\u0089\u008F\u0087\u009D\u0096\u009E\u0092\u0090\u0095;

		// Token: 0x04000032 RID: 50
		private object A\u0094\u0088\u0093\u0094\u008F\u008B\u009D\u0092\u0090\u008A;

		// Token: 0x04000033 RID: 51
		private object A\u008B\u008E\u009D\u0097\u008E\u0098\u009A\u0090\u009C\u008F;

		// Token: 0x04000034 RID: 52
		private object A\u0094\u0086\u0094\u0097\u0099\u0086\u0088\u0094\u0095\u008C;

		// Token: 0x04000035 RID: 53
		private object AA\u0087\u009D\u008E\u0099\u0090\u0092\u008E\u009B\u0091;

		// Token: 0x04000036 RID: 54
		private object A\u0090\u008D\u0093\u0095\u0096\u0094\u0086\u0094\u0090\u009C;

		// Token: 0x04000037 RID: 55
		private object A\u0094\u0095\u0086\u0098\u009E\u0086\u008E\u009E\u008A\u009D;

		// Token: 0x04000038 RID: 56
		private object A\u008F\u0088\u0099\u009E\u009D\u0095\u0089\u0090\u0097\u0090;

		// Token: 0x04000039 RID: 57
		private object AA\u0095\u008B\u0086\u008A\u009C\u0099\u009B\u0097\u009E;

		// Token: 0x0400003A RID: 58
		private object A\u0093\u0087\u0099\u009C\u0097\u008E\u009E\u0094\u0092\u009C;

		// Token: 0x0400003B RID: 59
		private object A\u008D\u008F\u009C\u009E\u008A\u0090\u0095\u0094\u008C\u0094;

		// Token: 0x0400003C RID: 60
		private object A\u0090\u009E\u009A\u0093\u008F\u0089\u0090\u0090\u0098\u0092;

		// Token: 0x0400003D RID: 61
		private object A\u0091\u0089\u008C\u009C\u008D\u0099\u0096\u0094\u009D\u0091;

		// Token: 0x0400003E RID: 62
		private object A\u0099\u008B\u0090\u009C\u009D\u0093\u0088\u0094\u009A\u0086;

		// Token: 0x0400003F RID: 63
		private object AA\u008C\u008C\u0095\u008E\u0087\u0090\u0099\u0087\u009E;

		// Token: 0x04000040 RID: 64
		private object A\u008F\u0092\u009D\u0098\u009A\u0096\u0097\u0090\u0093\u0092;

		// Token: 0x04000041 RID: 65
		private object A\u008D\u0086\u0094\u0086\u0093\u008C\u0090\u0092\u008C\u0086;

		// Token: 0x04000042 RID: 66
		private object A\u0088\u009A\u0090\u009B\u0089\u0088\u009D\u008B\u0088\u009B;

		// Token: 0x04000043 RID: 67
		private object A\u0092\u0088\u0090\u0089\u0087\u009E\u009E\u008B\u009B\u0089;

		// Token: 0x04000044 RID: 68
		private object A\u008A\u009B\u008C\u0089\u0093\u008E\u008D\u009E\u0086\u008C;

		// Token: 0x04000045 RID: 69
		private object A\u009A\u008B\u0088\u009B\u0094\u008B\u008B\u008B\u0094\u008D;

		// Token: 0x04000046 RID: 70
		private object AA\u0099\u0087\u008A\u008A\u0087\u0092\u0090\u009C\u0096;

		// Token: 0x04000047 RID: 71
		private static object A\u0086\u009D\u0089\u0090\u009E\u0094\u008F\u008B\u0094\u0094;
	}
}
