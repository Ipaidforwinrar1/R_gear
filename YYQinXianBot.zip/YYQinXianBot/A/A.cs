﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200003F RID: 63
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060001B5 RID: 437 RVA: 0x000101BC File Offset: 0x0000E3BC
		// (set) Token: 0x060001B6 RID: 438 RVA: 0x000101CC File Offset: 0x0000E3CC
		[JsonPropertyName("id")]
		public int AA\u009A\u0095\u0088\u0097\u0086\u0089\u0092\u0097\u009E
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0090\u0099\u009E\u0090\u009D\u0094\u009C\u0092\u008A\u0095;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0090\u0099\u009E\u0090\u009D\u0094\u009C\u0092\u008A\u0095 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e != 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060001B7 RID: 439 RVA: 0x0001022C File Offset: 0x0000E42C
		// (set) Token: 0x060001B8 RID: 440 RVA: 0x0001023C File Offset: 0x0000E43C
		[JsonPropertyName("name")]
		public string AA\u009A\u009B\u0097\u0096\u0097\u0088\u0090\u0099\u0098
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0095\u008F\u0094\u008F\u008F\u009B\u008D\u009E\u0091\u009C;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0095\u008F\u0094\u008F\u008F\u009B\u008D\u009E\u0091\u009C = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed == 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x0001029C File Offset: 0x0000E49C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0095\u008F\u0094\u008F\u008F\u009B\u008D\u009E\u0091\u009C = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001BA RID: 442 RVA: 0x00010310 File Offset: 0x0000E510
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009D\u0099\u0090\u0097\u008B\u009D\u0098\u009E\u0090\u0087()
		{
			return A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099.A\u008A\u008C\u0088\u0093\u0097\u0087\u0089\u0094\u009B\u0097 == null;
		}

		// Token: 0x060001BB RID: 443 RVA: 0x00010324 File Offset: 0x0000E524
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099 A\u0086\u0094\u009E\u0095\u0098\u0088\u0089\u0092\u0092\u009C()
		{
			return A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099.A\u008A\u008C\u0088\u0093\u0097\u0087\u0089\u0094\u009B\u0097;
		}

		// Token: 0x060001BC RID: 444 RVA: 0x00010334 File Offset: 0x0000E534
		static A\u008B\u0097\u0099\u0098\u0098\u0094\u0097\u009E\u0091\u0099()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000145 RID: 325
		[CompilerGenerated]
		private int A\u0090\u0099\u009E\u0090\u009D\u0094\u009C\u0092\u008A\u0095;

		// Token: 0x04000146 RID: 326
		[CompilerGenerated]
		private string A\u0095\u008F\u0094\u008F\u008F\u009B\u008D\u009E\u0091\u009C;

		// Token: 0x04000147 RID: 327
		internal static object A\u008A\u008C\u0088\u0093\u0097\u0087\u0089\u0094\u009B\u0097;
	}
}
