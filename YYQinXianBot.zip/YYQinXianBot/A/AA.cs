﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000032 RID: 50
	[NullableContext(1)]
	[Nullable(0)]
	public class AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094
	{
		// Token: 0x06000156 RID: 342 RVA: 0x0000DBB4 File Offset: 0x0000BDB4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 1;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb != 0)
			{
				num = 1;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					this.A\u0098\u0095\u0096\u008E\u0090\u0099\u0094\u008B\u008F\u009C = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1241912462 ^ 192537914 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75));
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d == 0)
					{
						num = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000157 RID: 343 RVA: 0x0000DC6C File Offset: 0x0000BE6C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task A\u009E\u0087\u009E\u0095\u008C\u008C\u008C\u0090\u009E\u0095(ListView \u0020)
		{
			int num = 4;
			int num2 = num;
			AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094.<LoadBuiltInMusicAsync>d__2 <LoadBuiltInMusicAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<LoadBuiltInMusicAsync>d__.<>t__builder.Start<AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094.<LoadBuiltInMusicAsync>d__2>(ref <LoadBuiltInMusicAsync>d__);
					num2 = 2;
					continue;
				case 2:
					goto IL_0076;
				case 3:
					<LoadBuiltInMusicAsync>d__.listView = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_28ad7821f34743c6aa9e64279b477f26 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 4:
					<LoadBuiltInMusicAsync>d__.<>t__builder = AsyncTaskMethodBuilder.Create();
					num2 = 3;
					continue;
				}
				<LoadBuiltInMusicAsync>d__.<>1__state = -1;
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b == 0)
				{
					num2 = 1;
				}
			}
			IL_0076:
			return <LoadBuiltInMusicAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000158 RID: 344 RVA: 0x0000DD38 File Offset: 0x0000BF38
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0095\u009D\u008E\u0095\u0089\u009E\u0099\u0094\u009B\u0092(ListView \u0020)
		{
			int num = 12;
			int num2 = num;
			for (;;)
			{
				int num3;
				string[] array;
				string text;
				switch (num2)
				{
				case 0:
					goto IL_0205;
				case 1:
					return;
				case 2:
					break;
				case 3:
					num3 = 0;
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 == 0)
					{
						num2 = 10;
						continue;
					}
					continue;
				case 4:
					goto IL_028A;
				case 5:
					return;
				case 6:
				{
					string[] files = Directory.GetFiles(this.A\u0098\u0095\u0096\u008E\u0090\u0099\u0094\u008B\u008F\u009C, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-149166022 >> 3) ^ -214265161 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c));
					int num4 = 1;
					array = files;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 == 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				}
				case 7:
					goto IL_022A;
				case 8:
					goto IL_034E;
				case 9:
					try
					{
						string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(text);
						int num5 = 6;
						for (;;)
						{
							int num4;
							switch (num5)
							{
							case 1:
							{
								ListViewItem listViewItem;
								listViewItem.SubItems.Add(fileNameWithoutExtension);
								num5 = 3;
								continue;
							}
							case 2:
								goto IL_01BF;
							case 3:
							{
								ListViewItem listViewItem;
								A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089 a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u;
								listViewItem.Tag = a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u;
								num5 = 4;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a != 0)
								{
									num5 = 1;
									continue;
								}
								continue;
							}
							case 4:
							{
								ListViewItem listViewItem;
								\u0020.Items.Add(listViewItem);
								num5 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_732282d3a2ef416a9e85867f5ef3f928 != 0)
								{
									num5 = 0;
									continue;
								}
								continue;
							}
							case 5:
							{
								A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089 a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u2 = new A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089();
								a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u2.A\u009C\u009E\u008F\u0093\u0095\u008A\u0092\u0090\u0099\u0095(num4);
								a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u2.A\u0089\u008A\u009C\u0086\u0087\u0088\u009B\u0092\u009D\u0094(fileNameWithoutExtension);
								string text2;
								a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u2.AAA\u0093\u009B\u0088\u0096\u0089\u0099\u009A\u0092(text2);
								A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089 a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u = a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u2;
								num5 = 7;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 != 0)
								{
									num5 = 5;
									continue;
								}
								continue;
							}
							case 6:
							{
								string text2 = File.ReadAllText(text);
								num5 = 5;
								continue;
							}
							case 7:
							{
								ListViewItem listViewItem = new ListViewItem(num4.ToString());
								num5 = 1;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0 == 0)
								{
									num5 = 0;
									continue;
								}
								continue;
							}
							}
							num4++;
							num5 = 2;
						}
						IL_01BF:
						goto IL_028A;
					}
					catch
					{
						int num6 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b == 0)
						{
							num6 = 0;
						}
						switch (num6)
						{
						default:
							goto IL_028A;
						}
					}
					goto IL_0205;
				case 10:
					break;
				case 11:
					if (Directory.Exists(this.A\u0098\u0095\u0096\u008E\u0090\u0099\u0094\u008B\u008F\u009C))
					{
						num2 = 6;
						continue;
					}
					goto IL_034E;
				case 12:
					\u0020.Items.Clear();
					num2 = 11;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33 == 0)
					{
						num2 = 11;
						continue;
					}
					continue;
				default:
					goto IL_0205;
				}
				if (num3 >= array.Length)
				{
					break;
				}
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3f1903d0114e4a7ea4b860c994faf9cc != 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_022A:
				text = array[num3];
				num2 = 9;
				continue;
				IL_0205:
				goto IL_022A;
				IL_028A:
				num3++;
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4b72a14166d4402292c229b4ea32f24b == 0)
				{
					num2 = 2;
					continue;
				}
				continue;
				IL_034E:
				Directory.CreateDirectory(this.A\u0098\u0095\u0096\u008E\u0090\u0099\u0094\u008B\u008F\u009C);
				num2 = 5;
			}
		}

		// Token: 0x06000159 RID: 345 RVA: 0x0000E0C4 File Offset: 0x0000C2C4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u009E\u0089\u008E\u0086\u0099\u0088\u008E\u008B\u0098\u0099()
		{
			return this.A\u0098\u0095\u0096\u008E\u0090\u0099\u0094\u008B\u008F\u009C;
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0000E0D4 File Offset: 0x0000C2D4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0094\u0086\u008B\u0098\u0086\u0089\u0096\u0090\u008A\u008D(ListView \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0095\u009D\u008E\u0095\u0089\u009E\u0099\u0094\u009B\u0092(\u0020);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x0600015B RID: 347 RVA: 0x0000E134 File Offset: 0x0000C334
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008B\u0088\u0090\u0092\u008A\u0094\u0088\u0092\u0092\u0097()
		{
			return AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094.A\u0087\u0087\u0092\u008D\u0087\u0086\u009A\u0094\u0093\u009A == null;
		}

		// Token: 0x0600015C RID: 348 RVA: 0x0000E148 File Offset: 0x0000C348
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094 A\u009A\u0089\u0099\u008A\u0089\u009D\u0095\u008B\u0089\u008D()
		{
			return AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094.A\u0087\u0087\u0092\u008D\u0087\u0086\u009A\u0094\u0093\u009A;
		}

		// Token: 0x0600015D RID: 349 RVA: 0x0000E158 File Offset: 0x0000C358
		static AA\u0097\u0098\u0099\u0094\u0092\u009A\u0089\u0096\u0094()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000120 RID: 288
		private readonly object A\u0098\u0095\u0096\u008E\u0090\u0099\u0094\u008B\u008F\u009C;

		// Token: 0x04000121 RID: 289
		internal static object A\u0087\u0087\u0092\u008D\u0087\u0086\u009A\u0094\u0093\u009A;
	}
}
