﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200005D RID: 93
	public partial class A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E : Form
	{
		// Token: 0x060002C9 RID: 713 RVA: 0x0001777C File Offset: 0x0001597C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 5;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce == 0)
			{
				num = 4;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					return;
				case 2:
					this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097.TextChanged += this.AA\u0087\u008D\u0097\u0096\u009E\u009A\u009E\u0091\u0093;
					num = 4;
					continue;
				case 3:
					this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097.KeyPress += this.A\u0092\u0087\u009C\u008C\u009D\u008D\u008E\u0094\u0087\u0086;
					num = 6;
					continue;
				case 4:
					this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088.TextChanged += this.AA\u0087\u008D\u0097\u0096\u009E\u009A\u009E\u0091\u0093;
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b == 0)
					{
						num = 0;
						continue;
					}
					continue;
				case 5:
					this.A\u009B\u008A\u008E\u008E\u009C\u008A\u0090\u009E\u0096\u0099();
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 == 0)
					{
						num = 0;
						continue;
					}
					continue;
				case 6:
					this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088.KeyPress += this.A\u0091\u0087\u009B\u0098\u0094\u0098\u0092\u009E\u0099\u0097;
					num = 2;
					continue;
				}
				this.A\u008E\u0086\u0095\u0099\u008F\u009D\u008D\u0092\u0091\u008F();
				num = 3;
			}
		}

		// Token: 0x060002CA RID: 714 RVA: 0x000178C8 File Offset: 0x00015AC8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008E\u0086\u0095\u0099\u008F\u009D\u008D\u0092\u0091\u008F()
		{
			switch (1)
			{
			case 1:
				try
				{
					Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1565911326 ^ 901083983 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292));
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 != 0)
					{
						num = 0;
					}
					for (;;)
					{
						switch (num)
						{
						case 1:
							base.Icon = new Icon(manifestResourceStream);
							num = 2;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 != 0)
							{
								num = 0;
								continue;
							}
							continue;
						case 2:
							goto IL_00DF;
						}
						if (manifestResourceStream == null)
						{
							break;
						}
						num = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 != 0)
						{
							num = 1;
						}
					}
					IL_00DF:;
				}
				catch
				{
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f != 0)
					{
						num2 = 0;
					}
					switch (num2)
					{
					}
				}
				break;
			}
		}

		// Token: 0x060002CB RID: 715 RVA: 0x00017A20 File Offset: 0x00015C20
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0092\u0087\u009C\u008C\u009D\u008D\u008E\u0094\u0087\u0086([Nullable(2)] object sender, KeyPressEventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					return;
				case 2:
					if (char.IsControl(\u0020.KeyChar))
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f531084ae45649978fa1b5ace1a011d5 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					else if (!char.IsLetterOrDigit(\u0020.KeyChar))
					{
						num2 = 3;
						continue;
					}
					break;
				case 3:
					\u0020.Handled = true;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x060002CC RID: 716 RVA: 0x00017AD0 File Offset: 0x00015CD0
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0091\u0087\u009B\u0098\u0094\u0098\u0092\u009E\u0099\u0097([Nullable(2)] object sender, KeyPressEventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (char.IsControl(\u0020.KeyChar))
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					else
					{
						if (char.IsLetterOrDigit(\u0020.KeyChar))
						{
							return;
						}
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					break;
				case 2:
					\u0020.Handled = true;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 3:
					return;
				}
				break;
			}
		}

		// Token: 0x060002CD RID: 717 RVA: 0x00017B98 File Offset: 0x00015D98
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u0087\u008D\u0097\u0096\u009E\u009A\u009E\u0091\u0093([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 6;
			int num2 = num;
			for (;;)
			{
				TextBox textBox;
				string text;
				int selectionStart;
				switch (num2)
				{
				case 0:
					goto IL_0191;
				case 1:
					text = Regex.Replace(textBox.Text, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1565911326 ^ 921856467 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231), "");
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5 != 0)
					{
						num2 = 7;
						continue;
					}
					continue;
				case 2:
					goto IL_01C5;
				case 3:
					return;
				case 4:
					textBox.Text = text;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 5:
					if (textBox == null)
					{
						num2 = 2;
						continue;
					}
					goto IL_0142;
				case 6:
					textBox = sender as TextBox;
					num2 = 5;
					continue;
				case 7:
					if (text != textBox.Text)
					{
						num2 = 3;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590 != 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					}
					break;
				case 8:
					selectionStart = textBox.SelectionStart;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 9:
					goto IL_0142;
				case 10:
					break;
				default:
					goto IL_0191;
				}
				textBox.TextChanged += this.AA\u0087\u008D\u0097\u0096\u009E\u009A\u009E\u0091\u0093;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904 == 0)
				{
					num2 = 2;
					continue;
				}
				continue;
				IL_0142:
				textBox.TextChanged -= this.AA\u0087\u008D\u0097\u0096\u009E\u009A\u009E\u0091\u0093;
				num2 = 8;
				continue;
				IL_0191:
				textBox.SelectionStart = Math.Min(selectionStart, text.Length);
				num2 = 10;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
				{
					num2 = 8;
				}
			}
			return;
			IL_01C5:;
		}

		// Token: 0x060002CE RID: 718 RVA: 0x00017D78 File Offset: 0x00015F78
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void AA\u009E\u009D\u008F\u0091\u0099\u0094\u0087\u008B\u0090([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
				{
					A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E.<btnLogin_Click>d__5 <btnLogin_Click>d__;
					<btnLogin_Click>d__.<>t__builder.Start<A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E.<btnLogin_Click>d__5>(ref <btnLogin_Click>d__);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 == 0)
					{
						num2 = 0;
					}
					break;
				}
				case 2:
				{
					A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E.<btnLogin_Click>d__5 <btnLogin_Click>d__;
					<btnLogin_Click>d__.<>1__state = -1;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf != 0)
					{
						num2 = 1;
					}
					break;
				}
				case 3:
				{
					A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E.<btnLogin_Click>d__5 <btnLogin_Click>d__;
					<btnLogin_Click>d__.<>4__this = this;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb != 0)
					{
						num2 = 2;
					}
					break;
				}
				case 4:
				{
					A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E.<btnLogin_Click>d__5 <btnLogin_Click>d__;
					<btnLogin_Click>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
					num2 = 3;
					break;
				}
				}
			}
		}

		// Token: 0x060002CF RID: 719 RVA: 0x00017E50 File Offset: 0x00016050
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task A\u008C\u0093\u009D\u0097\u009B\u0092\u0097\u0090\u0096\u0095()
		{
			int num = 1;
			int num2 = num;
			object[] array;
			for (;;)
			{
				switch (num2)
				{
				default:
				{
					object[] array2;
					array = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(25, array2, this);
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 == 0)
					{
						num2 = 2;
					}
					break;
				}
				case 1:
				{
					object[] array2 = new object[0];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53 != 0)
					{
						num2 = 0;
					}
					break;
				}
				case 2:
					goto IL_005D;
				}
			}
			IL_005D:
			return (Task)array[0];
		}

		// Token: 0x060002D0 RID: 720 RVA: 0x00017EF0 File Offset: 0x000160F0
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009B\u008F\u0095\u0087\u008D\u009D\u0098\u0092\u008D\u0092([Nullable(2)] object sender, EventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					base.Close();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					base.DialogResult = DialogResult.Cancel;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00018070 File Offset: 0x00016270
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u009B\u008A\u008E\u008E\u009C\u008A\u0090\u009E\u0096\u0099()
		{
			int num = 44;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1648996374 + 313516088) ^ -1446854779 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0ad91a4dc28d4fbfafc627c5cc1773c5);
						num2 = 63;
						continue;
					case 2:
						this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097.TabIndex = 0;
						num2 = 45;
						continue;
					case 3:
						base.MaximizeBox = false;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 4:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-541696120 ^ -104049779 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583), 10f);
						num2 = 25;
						continue;
					case 5:
						this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1612782771 >> 1) ^ -1665124858 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510);
						num2 = 61;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f == 0)
						{
							num2 = 61;
							continue;
						}
						continue;
					case 6:
						base.ResumeLayout(false);
						num2 = 34;
						continue;
					case 7:
						this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088.TabIndex = 1;
						num2 = 59;
						continue;
					case 8:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(649406881 ^ -2075055971 ^ -903720937 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1);
						num2 = 8;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 18;
							continue;
						}
						continue;
					case 9:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.TabIndex = 3;
						num2 = 8;
						continue;
					case 10:
						this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--266838818 ^ 846048898 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0d3e5d57ccad4f0881b6d46a45d950b2);
						num2 = 13;
						continue;
					case 11:
						base.StartPosition = FormStartPosition.CenterParent;
						num2 = 15;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
						{
							num2 = 19;
							continue;
						}
						continue;
					case 12:
						this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097.Location = new Point(80, 22);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 13:
						this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088.Size = new Size(220, 23);
						num2 = 7;
						continue;
					case 14:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1913821498 ^ 2144038010 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c);
						num2 = 41;
						continue;
					case 15:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094 = new Button();
						num2 = 17;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a == 0)
						{
							num2 = 8;
							continue;
						}
						continue;
					case 16:
						this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.TabIndex = 2;
						num2 = 55;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 == 0)
						{
							num2 = 44;
							continue;
						}
						continue;
					case 17:
						goto IL_0A28;
					case 18:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.UseVisualStyleBackColor = true;
						num2 = 48;
						continue;
					case 19:
						this.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-20831348 ^ -196527591 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4);
						num2 = 6;
						continue;
					case 20:
						this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B.Location = new Point(20, 25);
						num2 = 50;
						continue;
					case 21:
						this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B.AutoSize = true;
						num2 = 52;
						continue;
					case 22:
						goto IL_0360;
					case 23:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098.Location = new Point(20, 65);
						num2 = 3;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 == 0)
						{
							num2 = 14;
							continue;
						}
						continue;
					case 24:
						base.Controls.Add(this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094);
						num2 = 32;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 != 0)
						{
							num2 = 7;
							continue;
						}
						continue;
					case 25:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.Location = new Point(200, 110);
						num2 = 20;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 != 0)
						{
							num2 = 31;
							continue;
						}
						continue;
					case 26:
						goto IL_0211;
					case 27:
						this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.Location = new Point(80, 110);
						num2 = 35;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef == 0)
						{
							num2 = 30;
							continue;
						}
						continue;
					case 28:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098 = new Label();
						num2 = 53;
						continue;
					case 29:
						base.Controls.Add(this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B);
						num2 = 6;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6123357505a5405392c0339436988b0a == 0)
						{
							num2 = 57;
							continue;
						}
						continue;
					case 30:
						goto IL_0453;
					case 31:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~-1437012807 ^ 117390222 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf);
						num2 = 62;
						continue;
					case 32:
						base.Controls.Add(this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C);
						num2 = 49;
						continue;
					case 33:
						this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088.Location = new Point(80, 62);
						num2 = 10;
						continue;
					case 34:
						base.PerformLayout();
						num2 = 51;
						continue;
					case 35:
						this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((421324402 >> 1) ^ 498182183 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b);
						num2 = 46;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc == 0)
						{
							num2 = 34;
							continue;
						}
						continue;
					case 36:
						goto IL_0967;
					case 37:
						goto IL_0519;
					case 38:
						base.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-242410958 + -2074834086) ^ 2118573738 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4);
						num2 = 11;
						continue;
					case 39:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1699391948 ^ -1063410865 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1);
						num2 = 36;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b == 0)
						{
							num2 = 26;
							continue;
						}
						continue;
					case 40:
						this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.UseVisualStyleBackColor = true;
						num2 = 30;
						continue;
					case 41:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098.Size = new Size(56, 14);
						num2 = 58;
						continue;
					case 42:
						this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B.Size = new Size(56, 14);
						num2 = 60;
						continue;
					case 43:
						this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088 = new TextBox();
						num2 = 64;
						continue;
					case 44:
						this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097 = new TextBox();
						num2 = 43;
						continue;
					case 45:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098.AutoSize = true;
						num2 = 56;
						continue;
					case 46:
						goto IL_053C;
					case 47:
						base.AutoScaleMode = AutoScaleMode.Font;
						num2 = 22;
						continue;
					case 48:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.Click += this.A\u009B\u008F\u0095\u0087\u008D\u009D\u0098\u0092\u008D\u0092;
						num2 = 37;
						continue;
					case 49:
						base.Controls.Add(this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088);
						num2 = 18;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b72d53da7b174fadb50590dffdef5348 == 0)
						{
							num2 = 26;
							continue;
						}
						continue;
					case 50:
						this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B.Name = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1959070071 >> 2) ^ -2141365435 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_11962280e2d843899a33d16568cb47d0);
						num2 = 42;
						continue;
					case 51:
						return;
					case 52:
						this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1927311401 ^ 424142494 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231), 10f);
						num2 = 20;
						continue;
					case 53:
						base.SuspendLayout();
						num2 = 17;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_86e848c6696044348a77d8429afaaa88 == 0)
						{
							num2 = 21;
							continue;
						}
						continue;
					case 54:
						base.Controls.Add(this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097);
						num2 = 28;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c != 0)
						{
							num2 = 29;
							continue;
						}
						continue;
					case 55:
						this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1186520438 - -1314777313) ^ 1058828101 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3e7119b219884fb89fd2909088fcea1c);
						num2 = 40;
						continue;
					case 56:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-174680055 ^ -226554898 ^ 1843285322 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f), 10f);
						num2 = 23;
						continue;
					case 57:
						base.FormBorderStyle = FormBorderStyle.FixedDialog;
						num2 = 3;
						continue;
					case 58:
						this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098.TabIndex = 1;
						num2 = 39;
						continue;
					case 59:
						this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1551084448 ^ 880897453 ^ 1891671554 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850), 10f);
						num2 = 27;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 60:
						this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B.TabIndex = 0;
						num2 = 3;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 != 0)
						{
							num2 = 5;
							continue;
						}
						continue;
					case 61:
						this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-2096723947 << 2) ^ 577232269 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c2683bac3fa41a8a7728311137af4d6), 10f);
						num2 = 12;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 62:
						this.A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094.Size = new Size(100, 32);
						num2 = 3;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc != 0)
						{
							num2 = 9;
							continue;
						}
						continue;
					case 63:
						this.A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097.Size = new Size(220, 23);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f1766e9180ec40b1bff7882e75721ed2 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 64:
						this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C = new Button();
						num2 = 15;
						continue;
					}
					base.MinimizeBox = false;
					num2 = 38;
				}
				IL_0211:
				base.Controls.Add(this.A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098);
				num = 54;
				continue;
				IL_0360:
				base.ClientSize = new Size(330, 165);
				num = 24;
				continue;
				IL_0453:
				this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.Click += this.AA\u009E\u009D\u008F\u0091\u0099\u0094\u0087\u008B\u0090;
				num = 4;
				continue;
				IL_0519:
				base.AutoScaleDimensions = new SizeF(7f, 17f);
				num = 47;
				continue;
				IL_053C:
				this.A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C.Size = new Size(100, 32);
				num = 16;
				continue;
				IL_0967:
				this.A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088.Font = new Font(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(~435105394 ^ -147912037 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_08992b8dfcb14af69d253831d9a9b85b), 10f);
				num = 33;
				continue;
				IL_0A28:
				this.A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B = new Label();
				num = 28;
			}
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x00018BD4 File Offset: 0x00016DD4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009D\u0090\u009A\u0090\u0091\u008F\u008D\u0090\u008C\u008C()
		{
			return A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E.A\u009B\u0086\u008F\u009E\u0094\u009D\u0086\u0092\u0086\u008B == null;
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x00018BE8 File Offset: 0x00016DE8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E A\u0089\u008F\u0093\u0094\u0099\u0089\u008D\u009E\u0087\u0087()
		{
			return A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E.A\u009B\u0086\u008F\u009E\u0094\u009D\u0086\u0092\u0086\u008B;
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00018BF8 File Offset: 0x00016DF8
		static A\u0088\u008A\u008C\u0089\u0096\u0093\u0098\u0094\u0091\u008E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x040001C1 RID: 449
		private object A\u008D\u009C\u0099\u0092\u008D\u0090\u0099\u009E\u008E\u0097;

		// Token: 0x040001C2 RID: 450
		private object A\u008E\u0088\u0093\u009B\u009A\u0086\u0088\u0092\u0091\u0088;

		// Token: 0x040001C3 RID: 451
		private object A\u0095\u008B\u0087\u009E\u008A\u008D\u0097\u008B\u0090\u008C;

		// Token: 0x040001C4 RID: 452
		private object A\u0094\u0090\u0090\u009E\u008E\u008B\u008A\u0090\u0089\u0094;

		// Token: 0x040001C5 RID: 453
		private object A\u0088\u008C\u0093\u0087\u0099\u0095\u0094\u0092\u0094\u008B;

		// Token: 0x040001C6 RID: 454
		private object A\u0086\u0095\u008E\u008D\u009D\u008F\u009B\u009E\u0096\u0098;

		// Token: 0x040001C7 RID: 455
		internal static object A\u009B\u0086\u008F\u009E\u0094\u009D\u0086\u0092\u0086\u008B;

		// Token: 0x0200005E RID: 94
		[CompilerGenerated]
		private static class <>O
		{
			// Token: 0x060002D6 RID: 726 RVA: 0x00029E8C File Offset: 0x0002808C
			static <>O()
			{
				A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			}

			// Token: 0x040001C8 RID: 456
			public static Func<char, bool> AA\u0087\u0096\u009A\u0091\u0088\u0096\u009C\u0097\u0091;

			// Token: 0x040001C9 RID: 457
			public static Func<char, bool> A\u0086\u008D\u009A\u008F\u009E\u008E\u009E\u008B\u009B\u008F;
		}
	}
}
