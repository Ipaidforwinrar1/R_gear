﻿using System;
using System.Net;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000016 RID: 22
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D
	{
		// Token: 0x060000B5 RID: 181 RVA: 0x0000B238 File Offset: 0x00009438
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D A\u009E\u008D\u008A\u009D\u0086\u0097\u0099\u009E\u008C\u0098()
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					bool flag = false;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 == 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				}
				case 2:
					goto IL_01BF;
				case 3:
					if (A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u0087\u0090\u0098\u0098\u0087\u0090\u0088\u0090\u0089\u0099 != null)
					{
						num2 = 2;
						continue;
					}
					break;
				case 4:
					goto IL_004F;
				case 5:
					goto IL_009D;
				}
				object a_u008C_u0096_u009E_u009A_u0095_u009B_u0091_u008B_u0095_u = A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u008C\u0096\u009E\u009A\u0095\u009B\u0091\u008B\u0095\u0098;
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 == 0)
				{
					num2 = 1;
				}
			}
			IL_004F:
			return A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u0087\u0090\u0098\u0098\u0087\u0090\u0088\u0090\u0089\u0099;
			IL_009D:
			try
			{
				bool flag;
				object a_u008C_u0096_u009E_u009A_u0095_u009B_u0091_u008B_u0095_u;
				Monitor.Enter(a_u008C_u0096_u009E_u009A_u0095_u009B_u0091_u008B_u0095_u, ref flag);
				int num3 = 3;
				for (;;)
				{
					int num4 = num3;
					for (;;)
					{
						switch (num4)
						{
						case 1:
							goto IL_00D3;
						case 3:
							if (A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u0087\u0090\u0098\u0098\u0087\u0090\u0088\u0090\u0089\u0099 == null)
							{
								goto IL_00D3;
							}
							num4 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 == 0)
							{
								num4 = 0;
								continue;
							}
							continue;
						}
						goto Block_7;
					}
					IL_00D3:
					A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u0087\u0090\u0098\u0098\u0087\u0090\u0088\u0090\u0089\u0099 = new A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D();
					num3 = 2;
				}
				Block_7:;
			}
			finally
			{
				bool flag;
				if (flag)
				{
					int num5 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4fd4da50723435eb2ba03ef8cab027d == 0)
					{
						num5 = 1;
					}
					for (;;)
					{
						switch (num5)
						{
						case 1:
						{
							object a_u008C_u0096_u009E_u009A_u0095_u009B_u0091_u008B_u0095_u;
							Monitor.Exit(a_u008C_u0096_u009E_u009A_u0095_u009B_u0091_u008B_u0095_u);
							num5 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 == 0)
							{
								num5 = 0;
								continue;
							}
							continue;
						}
						}
						break;
					}
				}
			}
			IL_01BF:
			goto IL_004F;
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x0000B438 File Offset: 0x00009638
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u0099\u0090\u009D\u008B\u009D\u0098\u0086\u008B\u0097\u009B()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (!string.IsNullOrEmpty(this.AA\u009E\u0093\u0095\u0088\u0098\u0089\u0092\u0088\u0099))
					{
						goto IL_002F;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_002F;
				}
				break;
			}
			return false;
			IL_002F:
			return !string.IsNullOrEmpty(this.A\u0086\u0097\u008C\u0087\u008A\u0096\u0098\u0094\u0095\u0094);
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x0000B4D8 File Offset: 0x000096D8
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u008C\u0096\u009E\u009A\u0095\u009B\u0091\u008B\u0095\u0098 = new object();
					num2 = 5;
					continue;
				case 2:
					A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
					num2 = 6;
					continue;
				case 3:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6fdef4c9fb0147c3b3aa646e625fdd4d != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 4:
					return;
				case 5:
					A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u009A\u008F\u009A\u008A\u0089\u0088\u008C\u008B\u0088\u0094 = new HttpClient(new SocketsHttpHandler
					{
						PooledConnectionLifetime = TimeSpan.FromMinutes(5.0),
						PooledConnectionIdleTimeout = TimeSpan.FromMinutes(2.0),
						MaxConnectionsPerServer = 10,
						AutomaticDecompression = (DecompressionMethods.GZip | DecompressionMethods.Deflate)
					}, false)
					{
						BaseAddress = new Uri(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-281757643 ^ -1837041436 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a)),
						Timeout = TimeSpan.FromSeconds(15.0)
					};
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 6:
					A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u0091\u0093\u008B\u009E\u008C\u009A\u008F\u009E\u0094\u008E = new A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1078991464 ^ -1421932815 ^ 2086054836 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1));
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u009A\u008F\u009A\u008A\u0089\u0088\u008C\u008B\u0088\u0094.DefaultRequestHeaders.Add(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1315084 << 6) ^ -2031240748 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1063499328 ^ -851073374 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c));
				num2 = 4;
			}
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x0000B6A8 File Offset: 0x000098A8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x0000B70C File Offset: 0x0000990C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E>> A\u0089\u009A\u0094\u009E\u008D\u0088\u0093\u008B\u009A\u0087(string \u0020)
		{
			int num = 5;
			int num2 = num;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<InitDeviceAsync>d__14 <InitDeviceAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<InitDeviceAsync>d__.<>1__state = -1;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3e7119b219884fb89fd2909088fcea1c != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 2:
					<InitDeviceAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<InitDeviceAsync>d__14>(ref <InitDeviceAsync>d__);
					num2 = 3;
					continue;
				case 3:
					goto IL_00A1;
				case 4:
					<InitDeviceAsync>d__.<>4__this = this;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 5:
					<InitDeviceAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<AA\u009A\u008E\u0094\u0091\u0091\u0098\u0091\u009D\u008E>>.Create();
					num2 = 4;
					continue;
				}
				<InitDeviceAsync>d__.deviceNo = \u0020;
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 == 0)
				{
					num2 = 1;
				}
			}
			IL_00A1:
			return <InitDeviceAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x0000B804 File Offset: 0x00009A04
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087>> A\u0099\u009A\u009D\u008E\u008F\u0094\u009A\u008B\u0087\u0093(int \u0020 = 1, int \u0020 = 200)
		{
			int num = 6;
			int num2 = num;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<GetInternalMusicListAsync>d__15 <GetInternalMusicListAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<GetInternalMusicListAsync>d__.pageSize = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					<GetInternalMusicListAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<GetInternalMusicListAsync>d__15>(ref <GetInternalMusicListAsync>d__);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b != 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 3:
					goto IL_0109;
				case 4:
					<GetInternalMusicListAsync>d__.page = \u0020;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e8599cb2375542158244c170b37afacc == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 5:
					<GetInternalMusicListAsync>d__.<>4__this = this;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed == 0)
					{
						num2 = 4;
						continue;
					}
					continue;
				case 6:
					<GetInternalMusicListAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u008F\u009D\u0094\u0093\u0091\u0090\u009B\u0094\u0098\u0087>>.Create();
					num2 = 5;
					continue;
				}
				<GetInternalMusicListAsync>d__.<>1__state = -1;
				num2 = 2;
			}
			IL_0109:
			return <GetInternalMusicListAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000BB RID: 187 RVA: 0x0000B928 File Offset: 0x00009B28
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095>> A\u009A\u0091\u0098\u009B\u0098\u008E\u008D\u0092\u009E\u0087(string \u0020, int \u0020)
		{
			int num = 2;
			int num2 = num;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<GuestPlayMusicAsync>d__16 <GuestPlayMusicAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<GuestPlayMusicAsync>d__.<>4__this = this;
					num2 = 6;
					continue;
				case 2:
					<GuestPlayMusicAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095>>.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					<GuestPlayMusicAsync>d__.<>1__state = -1;
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8a7706961f2842d0974d2f2cdf994020 == 0)
					{
						num2 = 5;
						continue;
					}
					continue;
				case 4:
					goto IL_008D;
				case 5:
					<GuestPlayMusicAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<GuestPlayMusicAsync>d__16>(ref <GuestPlayMusicAsync>d__);
					num2 = 4;
					continue;
				case 6:
					<GuestPlayMusicAsync>d__.deviceNo = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				<GuestPlayMusicAsync>d__.musicId = \u0020;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_aeecb0ba81724219b3aab6c572f13b3f != 0)
				{
					num2 = 2;
				}
			}
			IL_008D:
			return <GuestPlayMusicAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000BC RID: 188 RVA: 0x0000BA4C File Offset: 0x00009C4C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095>> A\u0086\u008E\u0093\u008C\u0086\u008D\u0095\u008B\u0086\u009A(string \u0020, string \u0020, string \u0020, int \u0020)
		{
			int num = 3;
			int num2 = num;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<UserPlayMusicAsync>d__17 <UserPlayMusicAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<UserPlayMusicAsync>d__.username = \u0020;
					num2 = 7;
					continue;
				case 2:
					<UserPlayMusicAsync>d__.<>4__this = this;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					<UserPlayMusicAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0086\u009A\u009D\u008B\u0096\u008A\u0090\u0092\u0095\u0095>>.Create();
					num2 = 2;
					continue;
				case 4:
					<UserPlayMusicAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<UserPlayMusicAsync>d__17>(ref <UserPlayMusicAsync>d__);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 5:
					<UserPlayMusicAsync>d__.deviceNo = \u0020;
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 == 0)
					{
						num2 = 6;
						continue;
					}
					continue;
				case 6:
					<UserPlayMusicAsync>d__.musicId = \u0020;
					num2 = 8;
					continue;
				case 7:
					<UserPlayMusicAsync>d__.password = \u0020;
					num2 = 5;
					continue;
				case 8:
					<UserPlayMusicAsync>d__.<>1__state = -1;
					num2 = 4;
					continue;
				}
				break;
			}
			return <UserPlayMusicAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000BD RID: 189 RVA: 0x0000BB88 File Offset: 0x00009D88
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089>> A\u009B\u0091\u009D\u0099\u0094\u008C\u0093\u0094\u009D\u0094(string \u0020, string \u0020, string \u0020)
		{
			int num = 4;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<LoginAsync>d__18 <LoginAsync>d__;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						<LoginAsync>d__.username = \u0020;
						num2 = 6;
						break;
					case 1:
						<LoginAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<LoginAsync>d__18>(ref <LoginAsync>d__);
						num2 = 7;
						break;
					case 2:
						<LoginAsync>d__.<>1__state = -1;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 != 0)
						{
							num2 = 1;
						}
						break;
					case 3:
						<LoginAsync>d__.<>4__this = this;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a73c42054dcb4c649e3326c08dd43fc3 != 0)
						{
							num2 = 0;
						}
						break;
					case 4:
						goto IL_00DE;
					case 5:
						goto IL_00A1;
					case 6:
						<LoginAsync>d__.password = \u0020;
						num2 = 4;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb != 0)
						{
							num2 = 5;
						}
						break;
					case 7:
						goto IL_0094;
					}
				}
				IL_00A1:
				<LoginAsync>d__.deviceNo = \u0020;
				num = 2;
				continue;
				IL_00DE:
				<LoginAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089>>.Create();
				num = 3;
			}
			IL_0094:
			return <LoginAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000BE RID: 190 RVA: 0x0000BCB4 File Offset: 0x00009EB4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088>> A\u008E\u0089\u008D\u0089\u0088\u008F\u008A\u008B\u0093\u0087(string \u0020)
		{
			int num = 2;
			int num2 = num;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<PromptAccountAsync>d__19 <PromptAccountAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<PromptAccountAsync>d__.<>4__this = this;
					num2 = 5;
					continue;
				case 2:
					<PromptAccountAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u008D\u009A\u009E\u008D\u008B\u0095\u0096\u008B\u008D\u0088>>.Create();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					<PromptAccountAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<PromptAccountAsync>d__19>(ref <PromptAccountAsync>d__);
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b == 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 4:
					goto IL_00E1;
				case 5:
					<PromptAccountAsync>d__.deviceNo = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a470257873ee4efe9970265367c819a3 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				<PromptAccountAsync>d__.<>1__state = -1;
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
				{
					num2 = 3;
				}
			}
			IL_00E1:
			return <PromptAccountAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000BF RID: 191 RVA: 0x0000BDC0 File Offset: 0x00009FC0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089>> AA\u0093\u0089\u0094\u0095\u009A\u0088\u009A\u008F\u0086(string \u0020, string \u0020, string \u0020)
		{
			int num = 2;
			int num2 = num;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<RegisterAsync>d__20 <RegisterAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<RegisterAsync>d__.<>4__this = this;
					num2 = 7;
					continue;
				case 2:
					<RegisterAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089>>.Create();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_86e848c6696044348a77d8429afaaa88 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					<RegisterAsync>d__.deviceNo = \u0020;
					num2 = 4;
					continue;
				case 4:
					<RegisterAsync>d__.<>1__state = -1;
					num2 = 6;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 5:
					goto IL_00F8;
				case 6:
					<RegisterAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<RegisterAsync>d__20>(ref <RegisterAsync>d__);
					num2 = 5;
					continue;
				case 7:
					<RegisterAsync>d__.username = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				<RegisterAsync>d__.password = \u0020;
				num2 = 3;
			}
			IL_00F8:
			return <RegisterAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x0000BEE4 File Offset: 0x0000A0E4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D>> A\u008C\u0095\u0088\u008C\u0086\u009A\u009E\u0094\u0099\u0095(string \u0020, string \u0020)
		{
			int num = 1;
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<VerifyCardKeyAsync>d__21 <VerifyCardKeyAsync>d__;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						<VerifyCardKeyAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u008A\u008D\u0088\u0096\u0099\u009B\u0097\u0094\u008F\u008D>>.Create();
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_44c58969999b4bcc8508adab214dff9c != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 2:
						goto IL_006A;
					case 3:
						goto IL_00DE;
					case 4:
						<VerifyCardKeyAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<VerifyCardKeyAsync>d__21>(ref <VerifyCardKeyAsync>d__);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7a2f4939f164474e9670d53835be0850 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 5:
						<VerifyCardKeyAsync>d__.cardNo = \u0020;
						num2 = 3;
						continue;
					case 6:
						goto IL_0089;
					}
					<VerifyCardKeyAsync>d__.<>4__this = this;
					num2 = 5;
				}
				IL_0089:
				<VerifyCardKeyAsync>d__.<>1__state = -1;
				num = 4;
				continue;
				IL_00DE:
				<VerifyCardKeyAsync>d__.username = \u0020;
				num = 6;
			}
			IL_006A:
			return <VerifyCardKeyAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x0000BFE4 File Offset: 0x0000A1E4
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task<AA\u0095\u008D\u008F\u009B\u0098\u0086\u008E\u0088\u0092> AA\u0089\u009A\u0098\u0094\u008E\u0088\u008F\u0093\u0087<AA\u0095\u008D\u008F\u009B\u0098\u0086\u008E\u0088\u0092>(string \u0020, object \u0020) where AA\u0095\u008D\u008F\u009B\u0098\u0086\u008E\u0088\u0092 : class, new()
		{
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<SendEncryptedPostAsync>d__22<AA\u0095\u008D\u008F\u009B\u0098\u0086\u008E\u0088\u0092> <SendEncryptedPostAsync>d__;
			<SendEncryptedPostAsync>d__.<>t__builder = AsyncTaskMethodBuilder<AA\u0095\u008D\u008F\u009B\u0098\u0086\u008E\u0088\u0092>.Create();
			<SendEncryptedPostAsync>d__.<>4__this = this;
			<SendEncryptedPostAsync>d__.endpoint = \u0020;
			<SendEncryptedPostAsync>d__.requestData = \u0020;
			<SendEncryptedPostAsync>d__.<>1__state = -1;
			<SendEncryptedPostAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<SendEncryptedPostAsync>d__22<AA\u0095\u008D\u008F\u009B\u0098\u0086\u008E\u0088\u0092>>(ref <SendEncryptedPostAsync>d__);
			return <SendEncryptedPostAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0000C040 File Offset: 0x0000A240
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static string A\u008D\u0094\u0086\u0094\u0093\u008E\u0088\u0094\u0093\u009B()
		{
			int num = 3;
			int num2 = num;
			string text;
			RandomNumberGenerator randomNumberGenerator;
			byte[] array;
			for (;;)
			{
				switch (num2)
				{
				default:
					goto IL_0033;
				case 1:
					return text;
				case 2:
					randomNumberGenerator = RandomNumberGenerator.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4 != 0)
					{
						num2 = 0;
					}
					break;
				case 3:
					array = new byte[16];
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e290ea0c329f43c690d839db6d947938 != 0)
					{
						num2 = 1;
					}
					break;
				}
			}
			IL_0033:
			try
			{
				randomNumberGenerator.GetBytes(array);
				int num3 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3f1903d0114e4a7ea4b860c994faf9cc == 0)
				{
					num3 = 1;
				}
				for (;;)
				{
					switch (num3)
					{
					case 1:
						text = Convert.ToBase64String(array);
						num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_07eba690fbdf4e9ca7a412347aaa0904 != 0)
						{
							num3 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
			finally
			{
				if (randomNumberGenerator != null)
				{
					int num4 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 != 0)
					{
						num4 = 0;
					}
					for (;;)
					{
						switch (num4)
						{
						default:
							((IDisposable)randomNumberGenerator).Dispose();
							num4 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7374b39cd1dd42699e43c77815e1074b == 0)
							{
								num4 = 1;
							}
							break;
						case 1:
							goto IL_0101;
						}
					}
				}
				IL_0101:;
			}
			return text;
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x0000C1D0 File Offset: 0x0000A3D0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0088\u0086\u008E\u0098\u0091\u0091\u008C\u008B\u0090\u0086>> A\u008C\u0095\u0086\u0095\u0099\u008A\u0087\u0094\u008C\u0090<A\u0088\u0086\u008E\u0098\u0091\u0091\u008C\u008B\u0090\u0086>(Func<Task<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0088\u0086\u008E\u0098\u0091\u0091\u008C\u008B\u0090\u0086>>> \u0020, string \u0020) where A\u0088\u0086\u008E\u0098\u0091\u0091\u008C\u008B\u0090\u0086 : class
		{
			A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<ExecuteApiCallAsync>d__24<A\u0088\u0086\u008E\u0098\u0091\u0091\u008C\u008B\u0090\u0086> <ExecuteApiCallAsync>d__;
			<ExecuteApiCallAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u0088\u0086\u008E\u0098\u0091\u0091\u008C\u008B\u0090\u0086>>.Create();
			<ExecuteApiCallAsync>d__.apiCall = \u0020;
			<ExecuteApiCallAsync>d__.operationName = \u0020;
			<ExecuteApiCallAsync>d__.<>1__state = -1;
			<ExecuteApiCallAsync>d__.<>t__builder.Start<A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.<ExecuteApiCallAsync>d__24<A\u0088\u0086\u008E\u0098\u0091\u0091\u008C\u008B\u0090\u0086>>(ref <ExecuteApiCallAsync>d__);
			return <ExecuteApiCallAsync>d__.<>t__builder.Task;
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x0000C224 File Offset: 0x0000A424
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009B\u0099\u009A\u008D\u0090\u009D\u0090\u008B\u0087\u0086()
		{
			return A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u009D\u0099\u0090\u0097\u008A\u009B\u0090\u008B\u0093\u009B == null;
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x0000C238 File Offset: 0x0000A438
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D AA\u009E\u0093\u0099\u0088\u009E\u008C\u009A\u0089\u0099()
		{
			return A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D.A\u009D\u0099\u0090\u0097\u008A\u009B\u0090\u008B\u0093\u009B;
		}

		// Token: 0x0400007F RID: 127
		private static readonly object A\u0091\u0093\u008B\u009E\u008C\u009A\u008F\u009E\u0094\u008E;

		// Token: 0x04000080 RID: 128
		private static readonly object A\u009A\u008F\u009A\u008A\u0089\u0088\u008C\u008B\u0088\u0094;

		// Token: 0x04000081 RID: 129
		[Nullable(2)]
		private string AA\u009E\u0093\u0095\u0088\u0098\u0089\u0092\u0088\u0099;

		// Token: 0x04000082 RID: 130
		[Nullable(2)]
		private string A\u0086\u0097\u008C\u0087\u008A\u0096\u0098\u0094\u0095\u0094;

		// Token: 0x04000083 RID: 131
		[Nullable(2)]
		private AA\u009B\u008C\u0087\u008F\u009E\u008A\u0093\u0092\u008F A\u0098\u008C\u008D\u0096\u009C\u009E\u008F\u009E\u0087\u008F;

		// Token: 0x04000084 RID: 132
		[Nullable(2)]
		private static A\u0099\u0093\u0091\u008D\u009D\u0093\u009C\u0094\u0093\u009D A\u0087\u0090\u0098\u0098\u0087\u0090\u0088\u0090\u0089\u0099;

		// Token: 0x04000085 RID: 133
		private static readonly object A\u008C\u0096\u009E\u009A\u0095\u009B\u0091\u008B\u0095\u0098;

		// Token: 0x04000086 RID: 134
		internal static object A\u009D\u0099\u0090\u0097\u008A\u009B\u0090\u008B\u0093\u009B;
	}
}
