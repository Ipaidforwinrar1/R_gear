﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000051 RID: 81
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086
	{
		// Token: 0x06000275 RID: 629 RVA: 0x00014F7C File Offset: 0x0001317C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E> A\u009A\u0088\u0090\u009B\u008C\u009A\u0090\u0094\u0097\u008B()
		{
			return this.AA\u0086\u0093\u0091\u008E\u009A\u0097\u009A\u0087\u008F;
		}

		// Token: 0x06000276 RID: 630 RVA: 0x00014F8C File Offset: 0x0001318C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0088\u0094\u0096\u0094\u008C\u0093\u008B\u0094\u008A\u0099(List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E> \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.AA\u0086\u0093\u0091\u008E\u009A\u0097\u009A\u0087\u008F = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000277 RID: 631 RVA: 0x00014FEC File Offset: 0x000131EC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E> A\u009C\u0088\u008B\u008D\u0089\u0096\u0088\u009E\u008F\u0096()
		{
			return this.A\u0086\u008A\u009D\u008F\u009E\u0095\u009B\u0092\u0096\u0088;
		}

		// Token: 0x06000278 RID: 632 RVA: 0x00014FFC File Offset: 0x000131FC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0086\u0099\u008F\u0096\u0086\u0099\u008F\u0092\u009E\u0096(List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E> \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0086\u008A\u009D\u008F\u009E\u0095\u009B\u0092\u0096\u0088 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000279 RID: 633 RVA: 0x0001505C File Offset: 0x0001325C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.AA\u0086\u0093\u0091\u008E\u009A\u0097\u009A\u0087\u008F = new List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E>();
			this.A\u0086\u008A\u009D\u008F\u009E\u0095\u009B\u0092\u0096\u0088 = new List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E>();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_fb7b7adb6e6747ef81ebb3c181669ada != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600027A RID: 634 RVA: 0x000150E0 File Offset: 0x000132E0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0096\u0097\u009D\u008D\u008A\u0099\u008E\u008B\u0094\u009B()
		{
			return A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086.A\u008F\u008B\u008D\u008D\u009E\u009D\u0096\u009E\u008D\u0090 == null;
		}

		// Token: 0x0600027B RID: 635 RVA: 0x000150F4 File Offset: 0x000132F4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086 A\u008E\u0097\u009B\u0086\u0086\u0094\u009E\u0092\u0096\u0092()
		{
			return A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086.A\u008F\u008B\u008D\u008D\u009E\u009D\u0096\u009E\u008D\u0090;
		}

		// Token: 0x0600027C RID: 636 RVA: 0x00015104 File Offset: 0x00013304
		static A\u009E\u0098\u009E\u008C\u0096\u0089\u0092\u008B\u0093\u0086()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400019A RID: 410
		[CompilerGenerated]
		private List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E> AA\u0086\u0093\u0091\u008E\u009A\u0097\u009A\u0087\u008F;

		// Token: 0x0400019B RID: 411
		[CompilerGenerated]
		private List<A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E> A\u0086\u008A\u009D\u008F\u009E\u0095\u009B\u0092\u0096\u0088;

		// Token: 0x0400019C RID: 412
		private static object A\u008F\u008B\u008D\u008D\u009E\u009D\u0096\u009E\u008D\u0090;
	}
}
