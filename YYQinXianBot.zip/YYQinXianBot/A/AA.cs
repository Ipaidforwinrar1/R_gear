﻿using System;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200003C RID: 60
	[Nullable(new byte[] { 0, 1 })]
	public class AA\u0092\u009A\u0092\u0087\u0094\u0088\u0099\u0091\u0087 : A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<object>
	{
		// Token: 0x060001A1 RID: 417 RVA: 0x0000FE2C File Offset: 0x0000E02C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public AA\u0092\u009A\u0092\u0087\u0094\u0088\u0099\u0091\u0087()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001A2 RID: 418 RVA: 0x0000FE90 File Offset: 0x0000E090
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0099\u0099\u0095\u0089\u0095\u0089\u008F\u0094\u0098\u0089()
		{
			return AA\u0092\u009A\u0092\u0087\u0094\u0088\u0099\u0091\u0087.AA\u0087\u008E\u0097\u009E\u0096\u008D\u009A\u0092\u008C == null;
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x0000FEA4 File Offset: 0x0000E0A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u0092\u009A\u0092\u0087\u0094\u0088\u0099\u0091\u0087 A\u0094\u0088\u0095\u0093\u0091\u008D\u008B\u0090\u0094\u009A()
		{
			return AA\u0092\u009A\u0092\u0087\u0094\u0088\u0099\u0091\u0087.AA\u0087\u008E\u0097\u009E\u0096\u008D\u009A\u0092\u008C;
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x0000FEB4 File Offset: 0x0000E0B4
		static AA\u0092\u009A\u0092\u0087\u0094\u0088\u0099\u0091\u0087()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400013E RID: 318
		internal static object AA\u0087\u008E\u0097\u009E\u0096\u008D\u009A\u0092\u008C;
	}
}
