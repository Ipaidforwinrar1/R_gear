﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200004B RID: 75
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092
	{
		// Token: 0x14000002 RID: 2
		// (add) Token: 0x0600022C RID: 556 RVA: 0x00013554 File Offset: 0x00011754
		// (remove) Token: 0x0600022D RID: 557 RVA: 0x00013658 File Offset: 0x00011858
		[Nullable(2)]
		public event Action<int> A\u009E\u0088\u008A\u0088\u008D\u0095\u0098\u0090\u0088\u0092
		{
			[CompilerGenerated]
			[NullableContext(2)]
			[MethodImpl(MethodImplOptions.NoInlining)]
			add
			{
				int num = 3;
				int num2 = num;
				for (;;)
				{
					Action<int> action;
					Action<int> action2;
					switch (num2)
					{
					case 1:
						if (action != action2)
						{
							goto IL_00E9;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 2:
						goto IL_00E9;
					case 3:
						action = this.A\u0092\u008D\u0092\u0095\u0098\u0087\u008F\u0090\u0093\u008A;
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 != 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					case 4:
					{
						Action<int> action3;
						action = Interlocked.CompareExchange<Action<int>>(ref this.A\u0092\u008D\u0092\u0095\u0098\u0087\u008F\u0090\u0093\u008A, action3, action2);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_abe20d072e0047029269598ba2657c84 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					case 5:
					{
						Action<int> action3 = (Action<int>)Delegate.Combine(action2, value);
						num2 = 4;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c5518c15345b4b68b42acb503192f55c != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					}
					}
					break;
					IL_00E9:
					action2 = action;
					num2 = 5;
				}
			}
			[NullableContext(2)]
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			remove
			{
				int num = 5;
				for (;;)
				{
					int num2 = num;
					Action<int> action;
					for (;;)
					{
						Action<int> action2;
						switch (num2)
						{
						default:
							if (action == action2)
							{
								goto Block_1;
							}
							break;
						case 1:
						{
							Action<int> action3 = (Action<int>)Delegate.Remove(action2, value);
							num2 = 2;
							continue;
						}
						case 2:
						{
							Action<int> action3;
							action = Interlocked.CompareExchange<Action<int>>(ref this.A\u0092\u008D\u0092\u0095\u0098\u0087\u008F\u0090\u0093\u008A, action3, action2);
							num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_da43cebebf20410e839dcc1f58bfa330 == 0)
							{
								num2 = 0;
								continue;
							}
							continue;
						}
						case 3:
							return;
						case 4:
							break;
						case 5:
							goto IL_00BF;
						}
						action2 = action;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c != 0)
						{
							num2 = 1;
						}
					}
					Block_1:
					num = 3;
					continue;
					IL_00BF:
					action = this.A\u0092\u008D\u0092\u0095\u0098\u0087\u008F\u0090\u0093\u008A;
					num = 4;
				}
			}
		}

		// Token: 0x0600022E RID: 558 RVA: 0x0001373C File Offset: 0x0001193C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public IntPtr A\u0087\u008A\u0098\u009E\u0089\u008C\u0093\u009E\u009B\u0099()
		{
			return this.A\u008D\u0093\u0098\u0088\u0089\u0095\u0090\u008B\u0098\u0094;
		}

		// Token: 0x0600022F RID: 559 RVA: 0x0001374C File Offset: 0x0001194C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008B\u0086\u008B\u008D\u0087\u0087\u0088\u0094\u009A\u0095(IntPtr \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u008D\u0093\u0098\u0088\u0089\u0095\u0090\u008B\u0098\u0094 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000230 RID: 560 RVA: 0x000137AC File Offset: 0x000119AC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u009B\u008A\u0092\u0090\u0094\u0098\u009D\u009E\u0096\u009B()
		{
			return this.A\u0094\u0097\u008C\u0087\u008C\u008B\u0088\u0092\u008C\u008E;
		}

		// Token: 0x06000231 RID: 561 RVA: 0x000137BC File Offset: 0x000119BC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0088\u0099\u008A\u0099\u009E\u0087\u0094\u009E\u0095\u0094(string \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0094\u0097\u008C\u0087\u008C\u008B\u0088\u0092\u008C\u008E = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000232 RID: 562 RVA: 0x0001381C File Offset: 0x00011A1C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u009B\u0098\u0094\u0091\u008B\u0099\u0093\u0094\u008E\u0088()
		{
			return this.A\u0087\u008A\u0098\u009E\u0089\u008C\u0093\u009E\u009B\u0099() != IntPtr.Zero;
		}

		// Token: 0x06000233 RID: 563 RVA: 0x00013838 File Offset: 0x00011A38
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u009E\u009E\u009D\u0087\u009A\u0089\u009B\u0094\u009D\u0092()
		{
			return this.A\u008E\u0086\u0093\u009B\u0095\u0096\u0096\u008B\u009D\u0095;
		}

		// Token: 0x06000234 RID: 564 RVA: 0x00013848 File Offset: 0x00011A48
		[MethodImpl(MethodImplOptions.NoInlining)]
		public double A\u0093\u009D\u0087\u0089\u009D\u0095\u008C\u008B\u009E\u0098()
		{
			return this.A\u0094\u0095\u009C\u009A\u008D\u008D\u008E\u0090\u008C\u0095;
		}

		// Token: 0x06000235 RID: 565 RVA: 0x00013858 File Offset: 0x00011A58
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0094\u008F\u008E\u008D\u009E\u0099\u009E\u0090\u008C\u0096(double \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0094\u0095\u009C\u009A\u008D\u008D\u008E\u0090\u008C\u0095 = ((\u0020 > 0.0) ? \u0020 : 1.0);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75 != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000236 RID: 566 RVA: 0x000138D4 File Offset: 0x00011AD4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u0090\u009B\u0096\u008D\u0099\u0099\u0097\u0092\u0094\u008E()
		{
			return this.AA\u0090\u0097\u008B\u0087\u008C\u0098\u009C\u009E\u0093;
		}

		// Token: 0x06000237 RID: 567 RVA: 0x000138E4 File Offset: 0x00011AE4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008A\u0087\u009D\u0089\u0087\u009B\u0098\u0090\u0093\u0097(bool \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.AA\u0090\u0097\u008B\u0087\u008C\u0098\u009C\u009E\u0093 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000238 RID: 568 RVA: 0x00013944 File Offset: 0x00011B44
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008E\u0094\u0087\u008B\u0093\u009D\u0092\u0094\u008B\u008C(double \u0020)
		{
			int num = 6;
			for (;;)
			{
				int num2 = num;
				for (;;)
				{
					double num3;
					int num4;
					switch (num2)
					{
					case 0:
						goto IL_00C3;
					case 1:
						break;
					case 2:
						return;
					case 3:
						return;
					case 4:
						this.AA\u008A\u0098\u008B\u0087\u008A\u009C\u0090\u008A\u0097 = num3;
						num2 = 3;
						continue;
					case 5:
						goto IL_009F;
					case 6:
						if (this.A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087 == null)
						{
							goto Block_2;
						}
						break;
					case 7:
						num4 = this.AA\u009D\u0086\u009E\u0096\u0091\u008D\u0091\u0087\u009E(num3);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					default:
						goto IL_00C3;
					}
					if (this.A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087.Count == 0)
					{
						num2 = 2;
						continue;
					}
					num3 = this.A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087.Sum<ValueTuple<char?, double, bool, double>>(new Func<ValueTuple<char?, double, bool, double>, double>(A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092.<>c.A\u0095\u0095\u0089\u0098\u008E\u008C\u009E\u009E\u0099\u009A.A\u0095\u0095\u008C\u0095\u0093\u009A\u0095\u0094\u0094\u0094)) * Math.Clamp(\u0020, 0.0, 1.0);
					num2 = 7;
					continue;
					IL_00C3:
					this.A\u0099\u0086\u008D\u0099\u009B\u0099\u0088\u0092\u009B\u0086 = new int?(num4);
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_187f5dc9d63847ebb305df4c3a07e8c9 == 0)
					{
						num2 = 4;
					}
				}
				Block_2:
				num = 5;
			}
			IL_009F:;
		}

		// Token: 0x06000239 RID: 569 RVA: 0x00013AA8 File Offset: 0x00011CA8
		[MethodImpl(MethodImplOptions.NoInlining)]
		private int AA\u009D\u0086\u009E\u0096\u0091\u008D\u0091\u0087\u009E(double \u0020)
		{
			int num = 6;
			int num3;
			for (;;)
			{
				int num2 = num;
				int num5;
				for (;;)
				{
					int num4;
					switch (num2)
					{
					case 1:
						goto IL_015A;
					case 2:
						goto IL_0053;
					case 3:
						return 0;
					case 4:
						num3 = num4 + 1;
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 5:
						if (this.A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087.Count == 0)
						{
							goto Block_4;
						}
						num3 = 0;
						num2 = 4;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf != 0)
						{
							num2 = 10;
							continue;
						}
						continue;
					case 6:
						if (this.A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087 != null)
						{
							num2 = 5;
							continue;
						}
						return 0;
					case 7:
						if (this.A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087[num4].Item4 < \u0020)
						{
							num2 = 4;
							continue;
						}
						break;
					case 8:
						return num3;
					case 9:
						goto IL_0053;
					case 10:
						goto IL_00DF;
					case 11:
						goto IL_0053;
					}
					num5 = num4;
					num2 = 9;
					continue;
					IL_015A:
					num4 = (num3 + num5) / 2;
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 != 0)
					{
						num2 = 7;
						continue;
					}
					continue;
					IL_0053:
					if (num3 >= num5)
					{
						break;
					}
					goto IL_015A;
				}
				num = 8;
				continue;
				Block_4:
				num = 3;
				continue;
				IL_00DF:
				num5 = this.A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087.Count - 1;
				num = 11;
			}
			return num3;
		}

		// Token: 0x0600023A RID: 570 RVA: 0x00013C5C File Offset: 0x00011E5C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0094\u0095\u009C\u009A\u008D\u008D\u008E\u0090\u008C\u0095 = 1.0;
			this.AA\u0090\u0097\u008B\u0087\u008C\u0098\u009C\u009E\u0093 = true;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510 == 0)
			{
				num = 0;
			}
			for (;;)
			{
				switch (num)
				{
				case 1:
					this.A\u0088\u0099\u008A\u0099\u009E\u0087\u0094\u009E\u0095\u0094(string.Empty);
					num = 2;
					continue;
				case 2:
					return;
				case 3:
					this.A\u008B\u0086\u008B\u008D\u0087\u0087\u0088\u0094\u009A\u0095(IntPtr.Zero);
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 != 0)
					{
						num = 0;
						continue;
					}
					continue;
				}
				this.A\u008C\u008F\u0099\u009B\u008C\u0093\u0091\u0090\u008A\u0097 = new A\u009A\u0097\u0095\u0095\u009A\u0091\u008E\u0090\u009C\u008C();
				num = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b != 0)
				{
					num = 3;
				}
			}
		}

		// Token: 0x0600023B RID: 571 RVA: 0x00013D58 File Offset: 0x00011F58
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u0086\u008F\u0094\u0090\u008E\u009C\u009B\u008B\u0086\u009C(string \u0020)
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0088\u0099\u008A\u0099\u009E\u0087\u0094\u009E\u0095\u0094(\u0020);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_187f5dc9d63847ebb305df4c3a07e8c9 == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 2:
					return true;
				case 3:
					if (this.A\u0087\u008A\u0098\u009E\u0089\u008C\u0093\u009E\u009B\u0099() == IntPtr.Zero)
					{
						return false;
					}
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b72d53da7b174fadb50590dffdef5348 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 4:
					this.A\u008B\u0086\u008B\u008D\u0087\u0087\u0088\u0094\u009A\u0095(this.A\u008C\u008F\u0099\u009B\u008C\u0093\u0091\u0090\u008A\u0097.A\u0088\u008D\u0097\u0099\u0090\u008C\u008A\u0094\u009B\u008E(\u0020));
					num2 = 3;
					continue;
				case 5:
					if (!string.IsNullOrWhiteSpace(\u0020))
					{
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c83fdfd7feb346bcbdc0a4168723b361 != 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					}
					break;
				}
				break;
			}
			return false;
		}

		// Token: 0x0600023C RID: 572 RVA: 0x00013E64 File Offset: 0x00012064
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009D\u008F\u009E\u009D\u0094\u0088\u009C\u008B\u0086\u0099()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0088\u0099\u008A\u0099\u009E\u0087\u0094\u009E\u0095\u0094(string.Empty);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db == 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					this.A\u008B\u0086\u008B\u008D\u0087\u0087\u0088\u0094\u009A\u0095(IntPtr.Zero);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x0600023D RID: 573 RVA: 0x00013EF4 File Offset: 0x000120F4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u0089\u0090\u008F\u009A\u0096\u0090\u009D\u0090\u008C\u008A(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (this.A\u009B\u0098\u0094\u0091\u008B\u0099\u0093\u0094\u008E\u0088())
					{
						goto IL_0057;
					}
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
			return false;
			IL_0057:
			return this.A\u008C\u008F\u0099\u009B\u008C\u0093\u0091\u0090\u008A\u0097.A\u0093\u0095\u0098\u009E\u0092\u0091\u008B\u0090\u0087\u009B(this.A\u0087\u008A\u0098\u009E\u0089\u008C\u0093\u009E\u009B\u0099(), \u0020);
		}

		// Token: 0x0600023E RID: 574 RVA: 0x00013F6C File Offset: 0x0001216C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u008F\u008C\u0099\u0098\u009C\u0097\u009B\u0090\u0090\u0097(char \u0020)
		{
			int num = 1;
			int num2 = num;
			int num3;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					if (!this.A\u009B\u0098\u0094\u0091\u008B\u0099\u0093\u0094\u008E\u0088())
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_995893e15640499db99898ce289aa393 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					else
					{
						num3 = (int)char.ToUpper(\u0020);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf != 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					break;
				case 2:
					goto IL_0082;
				}
				break;
			}
			return false;
			IL_0082:
			return this.A\u008C\u008F\u0099\u009B\u008C\u0093\u0091\u0090\u008A\u0097.A\u0093\u0095\u0098\u009E\u0092\u0091\u008B\u0090\u0087\u009B(this.A\u0087\u008A\u0098\u009E\u0089\u008C\u0093\u009E\u009B\u0099(), num3);
		}

		// Token: 0x0600023F RID: 575 RVA: 0x00014010 File Offset: 0x00012210
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AA\u0089\u0087\u009B\u0089\u0090\u008C\u0095\u0093\u0089()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					this.A\u0096\u0093\u0096\u008C\u0095\u0092\u0096\u009E\u008F\u0092 = new TaskCompletionSource<bool>();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971 != 0)
					{
						num2 = 3;
					}
					break;
				case 1:
					this.A\u008E\u0086\u0093\u009B\u0095\u0096\u0096\u008B\u009D\u0095 = true;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 != 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					if (this.A\u008E\u0086\u0093\u009B\u0095\u0096\u0096\u008B\u009D\u0095)
					{
						return;
					}
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 == 0)
					{
						num2 = 0;
					}
					break;
				case 3:
					return;
				}
			}
		}

		// Token: 0x06000240 RID: 576 RVA: 0x000140CC File Offset: 0x000122CC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AA\u0099\u008C\u009D\u0087\u0099\u008E\u009E\u008D\u008A()
		{
			int num = 5;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 0:
					goto IL_008C;
				case 1:
					break;
				case 2:
					break;
				case 3:
					return;
				case 4:
					this.A\u008E\u0086\u0093\u009B\u0095\u0096\u0096\u008B\u009D\u0095 = false;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 5:
					if (!this.A\u008E\u0086\u0093\u009B\u0095\u0096\u0096\u008B\u009D\u0095)
					{
						return;
					}
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 != 0)
					{
						num2 = 4;
						continue;
					}
					continue;
				default:
					goto IL_008C;
				}
				this.A\u0096\u0093\u0096\u008C\u0095\u0092\u0096\u009E\u008F\u0092 = null;
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad != 0)
				{
					num2 = 3;
					continue;
				}
				continue;
				IL_008C:
				TaskCompletionSource<bool> a_u0096_u0093_u0096_u008C_u0095_u0092_u0096_u009E_u008F_u = this.A\u0096\u0093\u0096\u008C\u0095\u0092\u0096\u009E\u008F\u0092;
				if (a_u0096_u0093_u0096_u008C_u0095_u0092_u0096_u009E_u008F_u == null)
				{
					num2 = 2;
				}
				else
				{
					a_u0096_u0093_u0096_u008C_u0095_u0092_u0096_u009E_u008F_u.SetResult(true);
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 != 0)
					{
						num2 = 1;
					}
				}
			}
		}

		// Token: 0x06000241 RID: 577 RVA: 0x000141CC File Offset: 0x000123CC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009C\u0091\u0097\u0098\u008A\u0099\u008D\u0092\u0096\u0092()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					CancellationTokenSource a_u0095_u008D_u008E_u0088_u0095_u0097_u0095_u0090_u009B_u = this.A\u0095\u008D\u008E\u0088\u0095\u0097\u0095\u0090\u009B\u0087;
					if (a_u0095_u008D_u008E_u0088_u0095_u0097_u0095_u0090_u009B_u != null)
					{
						a_u0095_u008D_u008E_u0088_u0095_u0097_u0095_u0090_u009B_u.Cancel();
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c9177097f6d4245975a6f4f2351fc33 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					else
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_187f5dc9d63847ebb305df4c3a07e8c9 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
				case 2:
					return;
				}
				break;
			}
		}

		// Token: 0x06000242 RID: 578 RVA: 0x00014260 File Offset: 0x00012460
		[MethodImpl(MethodImplOptions.NoInlining)]
		public Task<A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098> AA\u0093\u0086\u008E\u0095\u0097\u008A\u0086\u0097\u009E(string \u0020, [Nullable(2)] string playSign = null)
		{
			int num = 2;
			int num2 = num;
			A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092.<PlayMusicAsync>d__40 <PlayMusicAsync>d__;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					<PlayMusicAsync>d__.<>4__this = this;
					num2 = 4;
					continue;
				case 2:
					<PlayMusicAsync>d__.<>t__builder = AsyncTaskMethodBuilder<A\u0089\u0095\u008F\u0092\u0091\u009C\u0092\u008B\u008A\u0098>.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_732282d3a2ef416a9e85867f5ef3f928 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					goto IL_00DF;
				case 4:
					<PlayMusicAsync>d__.musicSequence = \u0020;
					num2 = 5;
					continue;
				case 5:
					<PlayMusicAsync>d__.playSign = playSign;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_52308d089d9b4f4886d133839f666281 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 6:
					<PlayMusicAsync>d__.<>t__builder.Start<A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092.<PlayMusicAsync>d__40>(ref <PlayMusicAsync>d__);
					num2 = 3;
					continue;
				}
				<PlayMusicAsync>d__.<>1__state = -1;
				num2 = 6;
			}
			IL_00DF:
			return <PlayMusicAsync>d__.<>t__builder.Task;
		}

		// Token: 0x06000243 RID: 579 RVA: 0x00014358 File Offset: 0x00012558
		[MethodImpl(MethodImplOptions.NoInlining)]
		private string A\u008A\u009C\u0091\u009A\u0091\u008D\u0098\u009E\u0099\u009E(string \u0020)
		{
			int num = 6;
			int num2 = num;
			List<string> list;
			for (;;)
			{
				string text2;
				string text;
				string[] array2;
				int num4;
				switch (num2)
				{
				case 1:
					goto IL_0109;
				case 2:
					goto IL_00E9;
				case 4:
				{
					int num3;
					text = text2.Substring(0, num3);
					num2 = 5;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f136acc47f754716b678b3f3e6c42c64 == 0)
					{
						num2 = 7;
						continue;
					}
					continue;
				}
				case 5:
					return \u0020;
				case 6:
				{
					if (string.IsNullOrWhiteSpace(\u0020))
					{
						num2 = 5;
						continue;
					}
					string[] array = \u0020.Split(new char[] { '\r', '\n' }, StringSplitOptions.None);
					list = new List<string>();
					array2 = array;
					num2 = 14;
					continue;
				}
				case 7:
					goto IL_021D;
				case 8:
				{
					int num3;
					if (num3 >= 0)
					{
						num2 = 3;
						continue;
					}
					goto IL_01F5;
				}
				case 9:
					goto IL_021D;
				case 10:
					goto IL_01F5;
				case 11:
				{
					int num3 = text2.IndexOf(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-452330619 - -634177689) ^ 1036373329 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f80759bf0d24441d86de0e3fda73c330));
					num2 = 16;
					continue;
				}
				case 12:
					goto IL_0109;
				case 13:
					goto IL_008B;
				case 14:
					num4 = 0;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 15:
					goto IL_0130;
				case 16:
				{
					int num3;
					if (num3 >= 0)
					{
						num2 = 4;
						continue;
					}
					goto IL_00E9;
				}
				}
				num4++;
				num2 = 12;
				continue;
				IL_00E9:
				text = text2;
				num2 = 9;
				continue;
				IL_0109:
				if (num4 >= array2.Length)
				{
					num2 = 13;
					continue;
				}
				IL_0130:
				text2 = array2[num4];
				num2 = 11;
				continue;
				IL_01F5:
				list.Add(text);
				num2 = 0;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_be5da1cd750e495490bb42f04b10e65d != 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_021D:
				if (!string.IsNullOrWhiteSpace(text))
				{
					goto IL_01F5;
				}
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b85ea2e7d9514d96855b12200976c01b != 0)
				{
					num2 = 8;
				}
			}
			IL_008B:
			return string.Join(Environment.NewLine, list);
		}

		// Token: 0x06000244 RID: 580 RVA: 0x000145AC File Offset: 0x000127AC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool AA\u0089\u0093\u0095\u0097\u009C\u008C\u008D\u0098\u0087()
		{
			return A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092.A\u0088\u008B\u009E\u008C\u008D\u0089\u009A\u009E\u009E\u0094 == null;
		}

		// Token: 0x06000245 RID: 581 RVA: 0x000145C0 File Offset: 0x000127C0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092 A\u009B\u0088\u0090\u008C\u008E\u0090\u0087\u0090\u0095\u0092()
		{
			return A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092.A\u0088\u008B\u009E\u008C\u008D\u0089\u009A\u009E\u009E\u0094;
		}

		// Token: 0x06000246 RID: 582 RVA: 0x000145D0 File Offset: 0x000127D0
		static A\u008D\u008D\u0094\u0096\u0091\u0089\u008B\u009E\u008A\u0092()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400016D RID: 365
		private object A\u008C\u008F\u0099\u009B\u008C\u0093\u0091\u0090\u008A\u0097;

		// Token: 0x0400016E RID: 366
		[Nullable(2)]
		private TaskCompletionSource<bool> A\u0096\u0093\u0096\u008C\u0095\u0092\u0096\u009E\u008F\u0092;

		// Token: 0x0400016F RID: 367
		private bool A\u008E\u0086\u0093\u009B\u0095\u0096\u0096\u008B\u009D\u0095;

		// Token: 0x04000170 RID: 368
		[Nullable(2)]
		private CancellationTokenSource A\u0095\u008D\u008E\u0088\u0095\u0097\u0095\u0090\u009B\u0087;

		// Token: 0x04000171 RID: 369
		private double A\u0094\u0095\u009C\u009A\u008D\u008D\u008E\u0090\u008C\u0095;

		// Token: 0x04000172 RID: 370
		private bool AA\u0090\u0097\u008B\u0087\u008C\u0098\u009C\u009E\u0093;

		// Token: 0x04000173 RID: 371
		private int? A\u0099\u0086\u008D\u0099\u009B\u0099\u0088\u0092\u009B\u0086;

		// Token: 0x04000174 RID: 372
		private double AA\u008A\u0098\u008B\u0087\u008A\u009C\u0090\u008A\u0097;

		// Token: 0x04000175 RID: 373
		[Nullable(new byte[] { 2, 0 })]
		private List<ValueTuple<char?, double, bool, double>> A\u0087\u0091\u0094\u0089\u008F\u0098\u0092\u009E\u0089\u0087;

		// Token: 0x04000176 RID: 374
		[CompilerGenerated]
		[Nullable(2)]
		private Action<int> A\u0092\u008D\u0092\u0095\u0098\u0087\u008F\u0090\u0093\u008A;

		// Token: 0x04000177 RID: 375
		[CompilerGenerated]
		private IntPtr A\u008D\u0093\u0098\u0088\u0089\u0095\u0090\u008B\u0098\u0094;

		// Token: 0x04000178 RID: 376
		[CompilerGenerated]
		private string A\u0094\u0097\u008C\u0087\u008C\u008B\u0088\u0092\u008C\u008E;

		// Token: 0x04000179 RID: 377
		private static object A\u0088\u008B\u009E\u008C\u008D\u0089\u009A\u009E\u009E\u0094;
	}
}
