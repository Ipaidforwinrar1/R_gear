﻿namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000009 RID: 9
	public partial class AA\u008B\u0087\u0099\u009E\u008C\u0086\u0097\u008D\u0096 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000067 RID: 103 RVA: 0x00006184 File Offset: 0x00004384
		[global::System.Runtime.CompilerServices.MethodImpl(global::System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
		protected override void Dispose(bool \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_003F;
				case 2:
					if (\u0020)
					{
						goto IL_00BD;
					}
					num2 = 1;
					if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c706b3fe493b4ff4b5fae9040cf0ef62 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					goto IL_003F;
				case 4:
					goto IL_003F;
				case 5:
					goto IL_00BD;
				case 6:
					goto IL_00D3;
				}
				break;
				IL_003F:
				base.Dispose(\u0020);
				num2 = 0;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 != 0)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_00BD:
				if (this.AA\u009B\u009A\u0098\u0088\u008D\u0088\u008C\u008B\u0087 == null)
				{
					num2 = 4;
					continue;
				}
				IL_00D3:
				((global::System.IDisposable)this.AA\u009B\u009A\u0098\u0088\u008D\u0088\u008C\u008B\u0087).Dispose();
				num2 = 3;
				if (global::<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094 == 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x04000021 RID: 33
		private object AA\u009B\u009A\u0098\u0088\u008D\u0088\u008C\u008B\u0087;
	}
}
