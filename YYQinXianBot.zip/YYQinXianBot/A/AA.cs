﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000034 RID: 52
	[Nullable(0)]
	[NullableContext(2)]
	public class AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099
	{
		// Token: 0x06000163 RID: 355 RVA: 0x0000E160 File Offset: 0x0000C360
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008B\u008E\u0095\u009A\u0090\u0088\u0086\u0094\u008F\u009A(Action<int, bool> \u0020)
		{
			int num = 4;
			for (;;)
			{
				int num2 = num;
				Action<int, bool> action;
				Action<int, bool> action2;
				Action<int, bool> action3;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						goto IL_009E;
					case 2:
						if (action != action2)
						{
							goto IL_003B;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e4d680ac36814dd8aef53aa8836fd257 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 3:
						goto IL_003B;
					case 4:
						action = this.A\u008C\u0097\u008A\u0087\u0098\u008C\u008B\u009E\u0096\u0098;
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e93134abf3fa4d7fa1b6f86fd7d5b5db != 0)
						{
							num2 = 3;
							continue;
						}
						continue;
					case 5:
						action3 = (Action<int, bool>)Delegate.Combine(action2, \u0020);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					return;
					IL_003B:
					action2 = action;
					num2 = 5;
				}
				IL_009E:
				action = Interlocked.CompareExchange<Action<int, bool>>(ref this.A\u008C\u0097\u008A\u0087\u0098\u008C\u008B\u009E\u0096\u0098, action3, action2);
				num = 2;
			}
		}

		// Token: 0x06000164 RID: 356 RVA: 0x0000E254 File Offset: 0x0000C454
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009C\u0091\u0093\u0089\u0098\u009C\u0095\u009E\u008E\u009C(Action<int, bool> \u0020)
		{
			int num = 3;
			for (;;)
			{
				int num2 = num;
				Action<int, bool> action3;
				for (;;)
				{
					Action<int, bool> action2;
					switch (num2)
					{
					default:
					{
						Action<int, bool> action = (Action<int, bool>)Delegate.Remove(action2, \u0020);
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 != 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					}
					case 1:
						if (action3 == action2)
						{
							num2 = 5;
							continue;
						}
						break;
					case 2:
						break;
					case 3:
						goto IL_00D0;
					case 4:
					{
						Action<int, bool> action;
						action3 = Interlocked.CompareExchange<Action<int, bool>>(ref this.A\u008C\u0097\u008A\u0087\u0098\u008C\u008B\u009E\u0096\u0098, action, action2);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bdb81ac0568b460cba7d8f0f1b954590 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					case 5:
						return;
					}
					action2 = action3;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_fb7b7adb6e6747ef81ebb3c181669ada == 0)
					{
						num2 = 0;
					}
				}
				IL_00D0:
				action3 = this.A\u008C\u0097\u008A\u0087\u0098\u008C\u008B\u009E\u0096\u0098;
				num = 2;
			}
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000E348 File Offset: 0x0000C548
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int A\u008D\u0092\u0096\u0090\u0088\u0092\u0093\u0094\u0091\u008B(string \u0020, ListView.ListViewItemCollection \u0020)
		{
			int num = 23;
			int num3;
			for (;;)
			{
				int num2 = num;
				bool flag;
				int count;
				int num6;
				for (;;)
				{
					A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089 a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u;
					int num4;
					int num5;
					switch (num2)
					{
					case 0:
						goto IL_023D;
					case 1:
						goto IL_0123;
					case 2:
						this.AA\u0094\u0097\u0094\u0099\u0092\u008F\u0093\u0086\u008A = \u0020;
						num2 = 18;
						continue;
					case 3:
						goto IL_0299;
					case 4:
						return -1;
					case 5:
						return -1;
					case 6:
						flag = true;
						num2 = 10;
						continue;
					case 7:
						a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u = \u0020[num3].Tag as A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089;
						num2 = 20;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f == 0)
						{
							num2 = 19;
							continue;
						}
						continue;
					case 8:
						flag = false;
						num2 = 16;
						continue;
					case 9:
						goto IL_0167;
					case 10:
					{
						Action<int, bool> a_u008C_u0097_u008A_u0087_u0098_u008C_u008B_u009E_u0096_u = this.A\u008C\u0097\u008A\u0087\u0098\u008C\u008B\u009E\u0096\u0098;
						if (a_u008C_u0097_u008A_u0087_u0098_u008C_u008B_u009E_u0096_u == null)
						{
							num2 = 27;
							continue;
						}
						a_u008C_u0097_u008A_u0087_u0098_u008C_u008B_u009E_u0096_u(num3, true);
						num2 = 14;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b != 0)
						{
							num2 = 5;
							continue;
						}
						continue;
					}
					case 11:
					{
						Action<int, bool> a_u008C_u0097_u008A_u0087_u0098_u008C_u008B_u009E_u0096_u2 = this.A\u008C\u0097\u008A\u0087\u0098\u008C\u008B\u009E\u0096\u0098;
						if (a_u008C_u0097_u008A_u0087_u0098_u008C_u008B_u009E_u0096_u2 == null)
						{
							num2 = 15;
							continue;
						}
						a_u008C_u0097_u008A_u0087_u0098_u008C_u008B_u009E_u0096_u2(-1, false);
						num2 = 14;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 == 0)
						{
							num2 = 21;
							continue;
						}
						continue;
					}
					case 12:
						goto IL_0299;
					case 13:
						if (a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u.A\u008F\u0096\u008F\u008C\u0095\u0087\u008C\u0090\u008F\u0099().Contains(\u0020, StringComparison.OrdinalIgnoreCase))
						{
							goto IL_026D;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d375a57ab5714e038011351b58752657 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 14:
						return num3;
					case 15:
						goto IL_037E;
					case 16:
						num4 = 0;
						num2 = 12;
						continue;
					case 17:
						goto IL_01C7;
					case 18:
						break;
					case 19:
						goto IL_026D;
					case 20:
						if (a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u != null)
						{
							num2 = 13;
							continue;
						}
						goto IL_02D1;
					case 21:
						return -1;
					case 22:
						if (!(\u0020 != this.AA\u0094\u0097\u0094\u0099\u0092\u008F\u0093\u0086\u008A))
						{
							num2 = 24;
							continue;
						}
						goto IL_0123;
					case 23:
						if (!string.IsNullOrWhiteSpace(\u0020))
						{
							num2 = 22;
							continue;
						}
						return -1;
					case 24:
						break;
					case 25:
						goto IL_0167;
					case 26:
						this.A\u0095\u0096\u0096\u008E\u008D\u0096\u0091\u0094\u008F\u0093 = -1;
						num2 = 11;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d1106d82c6b04def9a99ca31aaab510f == 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					case 27:
						goto IL_0336;
					case 28:
						goto IL_01A1;
					case 29:
						goto IL_00E2;
					case 30:
						if (num5.ToString().Contains(\u0020))
						{
							goto Block_9;
						}
						goto IL_02D1;
					default:
						goto IL_023D;
					}
					count = \u0020.Count;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292 != 0)
					{
						num2 = 17;
						continue;
					}
					continue;
					IL_0123:
					this.A\u0095\u0096\u0096\u008E\u008D\u0096\u0091\u0094\u008F\u0093 = -1;
					num2 = 2;
					continue;
					IL_0167:
					num3 = (num6 + num4) % count;
					num2 = 7;
					continue;
					IL_023D:
					num5 = a_u008F_u008D_u0097_u0093_u008B_u0090_u0086_u008B_u008D_u.AA\u0092\u009A\u0090\u008B\u009D\u0089\u0086\u009B\u009E();
					num2 = 30;
					continue;
					IL_026D:
					this.A\u0095\u0096\u0096\u008E\u008D\u0096\u0091\u0094\u008F\u0093 = num3;
					num2 = 6;
					continue;
					IL_0299:
					if (num4 < count)
					{
						num2 = 25;
						continue;
					}
					goto IL_01A1;
					IL_02D1:
					num4++;
					num2 = 3;
				}
				IL_00E2:
				num6 = (this.A\u0095\u0096\u0096\u008E\u008D\u0096\u0091\u0094\u008F\u0093 + 1) % count;
				num = 8;
				continue;
				IL_01A1:
				if (!flag)
				{
					num = 26;
					continue;
				}
				return -1;
				IL_01C7:
				if (count != 0)
				{
					num = 29;
					continue;
				}
				break;
				Block_9:
				num = 19;
			}
			return -1;
			IL_0336:
			return num3;
			IL_037E:
			return -1;
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0000E700 File Offset: 0x0000C900
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009A\u008E\u0095\u009E\u008D\u009C\u0099\u0094\u0086\u009C()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0095\u0096\u0096\u008E\u008D\u0096\u0091\u0094\u008F\u0093 = -1;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				}
				this.AA\u0094\u0097\u0094\u0099\u0092\u008F\u0093\u0086\u008A = string.Empty;
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_74e8e2b7236a42b8a041a2fdb7c3d76f == 0)
				{
					num2 = 1;
				}
			}
		}

		// Token: 0x06000167 RID: 359 RVA: 0x0000E78C File Offset: 0x0000C98C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0095\u0096\u0096\u008E\u008D\u0096\u0091\u0094\u008F\u0093 = -1;
			this.AA\u0094\u0097\u0094\u0099\u0092\u008F\u0093\u0086\u008A = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6ab7b845bbe34f4080aea5a4b4c62bc1 != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000E80C File Offset: 0x0000CA0C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008C\u0088\u0091\u008F\u0096\u0086\u0086\u0090\u0097\u0093()
		{
			return AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099.A\u009B\u0095\u008D\u009A\u008C\u0090\u0089\u009E\u009E\u0097 == null;
		}

		// Token: 0x06000169 RID: 361 RVA: 0x0000E820 File Offset: 0x0000CA20
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099 A\u009D\u008C\u009A\u0090\u0086\u008A\u009A\u0090\u0086\u0088()
		{
			return AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099.A\u009B\u0095\u008D\u009A\u008C\u0090\u0089\u009E\u009E\u0097;
		}

		// Token: 0x0600016A RID: 362 RVA: 0x0000E830 File Offset: 0x0000CA30
		static AA\u0097\u008D\u0097\u0087\u009B\u0090\u009A\u0090\u0099()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000127 RID: 295
		private int A\u0095\u0096\u0096\u008E\u008D\u0096\u0091\u0094\u008F\u0093;

		// Token: 0x04000128 RID: 296
		[Nullable(1)]
		private string AA\u0094\u0097\u0094\u0099\u0092\u008F\u0093\u0086\u008A;

		// Token: 0x04000129 RID: 297
		[CompilerGenerated]
		private Action<int, bool> A\u008C\u0097\u008A\u0087\u0098\u008C\u008B\u009E\u0096\u0098;

		// Token: 0x0400012A RID: 298
		internal static object A\u009B\u0095\u008D\u009A\u008C\u0090\u0089\u009E\u009E\u0097;
	}
}
