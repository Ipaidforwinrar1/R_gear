﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000030 RID: 48
	[NullableContext(2)]
	[Nullable(0)]
	public class A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B
	{
		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000143 RID: 323 RVA: 0x0000C248 File Offset: 0x0000A448
		[Nullable(1)]
		public static A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B A\u0090\u009A\u0094\u009C\u009E\u0093\u008D\u0090\u0091\u0086
		{
			[NullableContext(1)]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				int num = 4;
				int num2 = num;
				for (;;)
				{
					object a_u009B_u0095_u0087_u008E_u008B_u0098_u009B_u009E_u0087_u;
					bool flag;
					switch (num2)
					{
					case 1:
						goto IL_01AA;
					case 2:
						try
						{
							Monitor.Enter(a_u009B_u0095_u0087_u008E_u008B_u0098_u009B_u009E_u0087_u, ref flag);
							int num3 = 2;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cdb1a8831edc4441a68ba2f3ff3702c4 == 0)
							{
								num3 = 0;
							}
							for (;;)
							{
								switch (num3)
								{
								case 1:
									goto IL_00D6;
								case 2:
									if (A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0099\u009C\u0091\u008A\u0092\u0093\u0089\u0092\u009D\u009D != null)
									{
										goto IL_00D6;
									}
									num3 = 0;
									if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c == 0)
									{
										num3 = 0;
										continue;
									}
									continue;
								}
								A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0099\u009C\u0091\u008A\u0092\u0093\u0089\u0092\u009D\u009D = new A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B();
								num3 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
								{
									num3 = 1;
								}
							}
							IL_00D6:
							goto IL_003B;
						}
						finally
						{
							if (flag)
							{
								goto IL_011B;
							}
							int num4 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_bcfa91d5e4c9439fa56d5117666088b4 != 0)
							{
								num4 = 1;
							}
							IL_0105:
							switch (num4)
							{
							case 2:
								IL_011B:
								Monitor.Exit(a_u009B_u0095_u0087_u008E_u008B_u0098_u009B_u009E_u0087_u);
								num4 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a38905b424c9477eb3c3d2ef4ad1502c != 0)
								{
									num4 = 0;
									goto IL_0105;
								}
								goto IL_0105;
							}
						}
						break;
					case 3:
						goto IL_01D0;
					case 4:
						if (A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0099\u009C\u0091\u008A\u0092\u0093\u0089\u0092\u009D\u009D != null)
						{
							num2 = 3;
							continue;
						}
						goto IL_01AA;
					case 5:
						goto IL_003B;
					}
					flag = false;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c83fdfd7feb346bcbdc0a4168723b361 != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
					IL_01AA:
					a_u009B_u0095_u0087_u008E_u008B_u0098_u009B_u009E_u0087_u = A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u009B\u0095\u0087\u008E\u008B\u0098\u009B\u009E\u0087\u0086;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed != 0)
					{
						num2 = 0;
					}
				}
				IL_003B:
				return A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0099\u009C\u0091\u008A\u0092\u0093\u0089\u0092\u009D\u009D;
				IL_01D0:
				goto IL_003B;
			}
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0000C458 File Offset: 0x0000A658
		[MethodImpl(MethodImplOptions.NoInlining)]
		private A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0000C4BC File Offset: 0x0000A6BC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public bool A\u009B\u009C\u0097\u009D\u008F\u0090\u0090\u009E\u0098\u008A()
		{
			return this.A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D != null;
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0000C4D0 File Offset: 0x0000A6D0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u0087\u008C\u0092\u0092\u008C\u0089\u0096\u008B\u0092\u0096()
		{
			return this.A\u0089\u009B\u0092\u0086\u008C\u008F\u0091\u0090\u008A\u0095;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0000C4E0 File Offset: 0x0000A6E0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string AA\u008D\u009A\u008D\u0095\u009B\u009D\u0091\u0086\u0098()
		{
			return this.A\u008A\u0096\u0096\u0097\u009B\u0086\u0087\u008B\u0088\u0096;
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0000C4F0 File Offset: 0x0000A6F0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089 A\u0090\u008B\u008E\u0090\u0087\u0097\u008F\u009E\u0087\u008F()
		{
			return this.A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D;
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000C500 File Offset: 0x0000A700
		[NullableContext(1)]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0087\u0087\u0098\u0096\u009B\u009D\u008A\u0090\u0091\u008D(string \u0020, string \u0020, A\u0090\u0097\u0092\u0094\u009C\u0099\u008D\u0094\u0089\u0089 \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					this.A\u008A\u0096\u0096\u0097\u009B\u0086\u0087\u008B\u0088\u0096 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ee067a24329c4886bdd15d0a629cd9a9 == 0)
					{
						num2 = 3;
					}
					break;
				case 1:
					this.A\u0089\u009B\u0092\u0086\u008C\u008F\u0091\u0090\u008A\u0095 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_22c090f1cce64234b3842cd138fe56f3 == 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					return;
				case 3:
					this.A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D = \u0020;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad == 0)
					{
						num2 = 1;
					}
					break;
				}
			}
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0000C5B4 File Offset: 0x0000A7B4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0086\u0098\u0095\u0099\u0087\u008A\u0089\u0092\u0099\u0091(int \u0020)
		{
			int num = 4;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					long num3;
					this.A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D.AA\u009D\u008E\u0098\u0099\u009E\u0092\u008F\u009D\u0087 = Math.Max(num3, this.A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D.AA\u009D\u008E\u0098\u0099\u009E\u0092\u008F\u009D\u0087) + (long)\u0020 * 86400L;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b2d055de0c54ba08a92e6c6cd750833 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 2:
					goto IL_00AA;
				case 3:
				{
					DateTimeOffset utcNow = DateTimeOffset.UtcNow;
					num2 = 6;
					continue;
				}
				case 4:
					if (this.A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D == null)
					{
						goto IL_00AA;
					}
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_167081a03738463b981911dfdcf8b1a1 != 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				case 5:
					return;
				case 6:
				{
					DateTimeOffset utcNow;
					long num3 = utcNow.ToUnixTimeSeconds();
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c5518c15345b4b68b42acb503192f55c != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				}
				this.A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D.AA\u0095\u008E\u0093\u0088\u008C\u0090\u0090\u0098\u008E = 1;
				num2 = 5;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b2d055de0c54ba08a92e6c6cd750833 != 0)
				{
					num2 = 4;
				}
			}
			return;
			IL_00AA:
			throw new InvalidOperationException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-214453972 ^ -11646669 ^ 692311342 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce));
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0000C720 File Offset: 0x0000A920
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				case 3:
					A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u009B\u0095\u0087\u008E\u008B\u0098\u009B\u009E\u0087\u0086 = new object();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				}
				A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
				num2 = 3;
			}
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0000C7BC File Offset: 0x0000A9BC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0086\u0092\u0089\u008E\u0099\u0098\u009A\u0094\u0094\u0086()
		{
			return A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0087\u0086\u008E\u009B\u009A\u008C\u0097\u009E\u008D\u0097 == null;
		}

		// Token: 0x0600014D RID: 333 RVA: 0x0000C7D0 File Offset: 0x0000A9D0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B A\u0087\u0098\u0087\u009B\u008C\u008D\u0090\u0090\u009E\u0089()
		{
			return A\u0097\u009C\u008E\u0096\u0091\u0086\u0093\u0090\u0090\u008B.A\u0087\u0086\u008E\u009B\u009A\u008C\u0097\u009E\u008D\u0097;
		}

		// Token: 0x04000118 RID: 280
		private static object A\u0099\u009C\u0091\u008A\u0092\u0093\u0089\u0092\u009D\u009D;

		// Token: 0x04000119 RID: 281
		[Nullable(1)]
		private static readonly object A\u009B\u0095\u0087\u008E\u008B\u0098\u009B\u009E\u0087\u0086;

		// Token: 0x0400011A RID: 282
		private object A\u0089\u009B\u0092\u0086\u008C\u008F\u0091\u0090\u008A\u0095;

		// Token: 0x0400011B RID: 283
		private object A\u008A\u0096\u0096\u0097\u009B\u0086\u0087\u008B\u0088\u0096;

		// Token: 0x0400011C RID: 284
		private object A\u008C\u0093\u0086\u0097\u009E\u008F\u0099\u008B\u0099\u008D;

		// Token: 0x0400011D RID: 285
		private static object A\u0087\u0086\u008E\u009B\u009A\u008C\u0097\u009E\u008D\u0097;
	}
}
