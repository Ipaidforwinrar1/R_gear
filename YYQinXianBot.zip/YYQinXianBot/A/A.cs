﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000037 RID: 55
	[NullableContext(1)]
	[Nullable(0)]
	public static class A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088
	{
		// Token: 0x06000178 RID: 376 RVA: 0x0000F298 File Offset: 0x0000D498
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static void AA\u008F\u0098\u0099\u008B\u008F\u0094\u009E\u0091\u0088(object \u0020, object \u0020)
		{
			switch (1)
			{
			case 1:
				try
				{
					object obj = \u0020 + A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1373637206 >> 5) ^ 374549173 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad) + \u0020;
					string text = A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0098\u008C\u008B\u009B\u0099\u009D\u008A\u0095\u008B.Substring(0, 16);
					string text2 = A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094.A\u008E\u009B\u0097\u008A\u0098\u0091\u0090\u0094\u0093\u009C(obj, text);
					int num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_622ea7c76806473a96d520a96eb5e231 == 0)
					{
						num = 0;
					}
					for (;;)
					{
						switch (num)
						{
						case 1:
							File.WriteAllText(A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099, text2);
							num = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b == 0)
							{
								num = 0;
								continue;
							}
							continue;
						}
						break;
					}
				}
				catch
				{
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d == 0)
					{
						num2 = 0;
					}
					switch (num2)
					{
					}
				}
				break;
			}
		}

		// Token: 0x06000179 RID: 377 RVA: 0x0000F3DC File Offset: 0x0000D5DC
		[MethodImpl(MethodImplOptions.NoInlining)]
		[return: Nullable(new byte[] { 0, 2, 2 })]
		public static ValueTuple<string, string> A\u0092\u0098\u009E\u0086\u0092\u0090\u008D\u0094\u0095\u0093()
		{
			ValueTuple<string, string> valueTuple;
			switch (1)
			{
			case 1:
				try
				{
					if (!File.Exists(A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099))
					{
						goto IL_00BE;
					}
					int num = 2;
					for (;;)
					{
						IL_0049:
						string[] array;
						switch (num)
						{
						case 1:
							goto IL_00FA;
						case 2:
							goto IL_006F;
						case 3:
							if (array.Length != 2)
							{
								num = 6;
								continue;
							}
							valueTuple = new ValueTuple<string, string>(array[0], array[1]);
							num = 4;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 != 0)
							{
								num = 3;
								continue;
							}
							continue;
						case 4:
							goto IL_0191;
						case 5:
							goto IL_006F;
						case 6:
							goto IL_011E;
						}
						break;
						IL_006F:
						object obj = File.ReadAllText(A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099).Trim();
						string text = A\u008C\u0089\u0096\u009B\u0086\u0095\u0092\u0090\u0090\u0093.AA\u0098\u008C\u008B\u009B\u0099\u009D\u008A\u0095\u008B.Substring(0, 16);
						array = A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094.A\u009B\u0091\u0099\u0096\u0096\u009C\u0096\u0092\u009D\u009C(obj, text).Split(':', 2, StringSplitOptions.None);
						num = 3;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f != 0)
						{
							num = 1;
						}
					}
					goto IL_00BE;
					IL_00FA:
					break;
					IL_011E:
					throw new FormatException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1876083551 ^ 118787584 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_382d10fefc4a4c79816fcf22096882d1));
					IL_0191:
					break;
					IL_00BE:
					valueTuple = new ValueTuple<string, string>(null, null);
					num = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_86e848c6696044348a77d8429afaaa88 == 0)
					{
						num = 1;
						goto IL_0049;
					}
					goto IL_0049;
				}
				catch
				{
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c == 0)
					{
						num2 = 1;
					}
					for (;;)
					{
						switch (num2)
						{
						case 1:
							A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0097\u0086\u0098\u0097\u0088\u009A\u008F\u008B\u009A\u009A();
							num2 = 2;
							continue;
						case 2:
							valueTuple = new ValueTuple<string, string>(null, null);
							num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 != 0)
							{
								num2 = 0;
								continue;
							}
							continue;
						}
						break;
					}
				}
				break;
			}
			return valueTuple;
		}

		// Token: 0x0600017A RID: 378 RVA: 0x0000F634 File Offset: 0x0000D834
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static void A\u0097\u0086\u0098\u0097\u0088\u009A\u008F\u008B\u009A\u009A()
		{
			switch (1)
			{
			case 1:
				try
				{
					if (File.Exists(A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099))
					{
						goto IL_0075;
					}
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f == 0)
					{
						num = 0;
					}
					IL_005F:
					switch (num)
					{
					case 1:
						IL_0075:
						File.Delete(A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099);
						num = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f == 0)
						{
							num = 2;
							goto IL_005F;
						}
						goto IL_005F;
					}
				}
				catch
				{
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a342f3298a39451892d5aac144479c75 != 0)
					{
						num2 = 0;
					}
					switch (num2)
					{
					}
				}
				break;
			}
		}

		// Token: 0x0600017B RID: 379 RVA: 0x0000F770 File Offset: 0x0000D970
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static bool A\u0094\u0089\u009E\u0098\u0099\u008C\u0096\u008B\u0090\u0099()
		{
			return File.Exists(A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099);
		}

		// Token: 0x0600017C RID: 380 RVA: 0x0000F784 File Offset: 0x0000D984
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e910a69b81de45f2940131c6edb340c2 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1482712261 ^ 611738139 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3aa5662495c6439da596902a17e1ae33));
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					return;
				}
				A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 == 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x0600017D RID: 381 RVA: 0x0000F858 File Offset: 0x0000DA58
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0099\u0096\u008E\u0089\u009A\u009B\u0091\u0094\u009B\u0087()
		{
			return A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0093\u0095\u009B\u009B\u008F\u0091\u0086\u0094\u009A\u008A == null;
		}

		// Token: 0x0600017E RID: 382 RVA: 0x0000F86C File Offset: 0x0000DA6C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088 AA\u0087\u009E\u0094\u0096\u008A\u008E\u0090\u008C\u008E()
		{
			return A\u008A\u008B\u008D\u009A\u0087\u0097\u009D\u0094\u008B\u0088.A\u0093\u0095\u009B\u009B\u008F\u0091\u0086\u0094\u009A\u008A;
		}

		// Token: 0x04000130 RID: 304
		private static readonly object A\u0089\u0094\u009B\u009D\u0087\u009E\u0091\u009E\u0099\u0099;

		// Token: 0x04000131 RID: 305
		private static object A\u0093\u0095\u009B\u009B\u008F\u0091\u0086\u0094\u009A\u008A;
	}
}
