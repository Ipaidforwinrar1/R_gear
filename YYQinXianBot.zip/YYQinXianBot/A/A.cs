﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000044 RID: 68
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u0097\u0095\u0093\u0092\u0099\u009B\u009B\u009E\u009A\u0089<[Nullable(2)] A\u0091\u008D\u008F\u008B\u008C\u0099\u0097\u0094\u0099\u0088>
	{
		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060001DD RID: 477 RVA: 0x0001094C File Offset: 0x0000EB4C
		// (set) Token: 0x060001DE RID: 478 RVA: 0x0001095C File Offset: 0x0000EB5C
		[JsonPropertyName("timestamp")]
		public long A\u0089\u0089\u0086\u0090\u009E\u0096\u0090\u0090\u008C\u0098
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0087\u009C\u009D\u0091\u0090\u008D\u0094\u0090\u009C\u009A;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0087\u009C\u009D\u0091\u0090\u008D\u0094\u0090\u009C\u009A = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060001DF RID: 479 RVA: 0x000109BC File Offset: 0x0000EBBC
		// (set) Token: 0x060001E0 RID: 480 RVA: 0x000109CC File Offset: 0x0000EBCC
		[JsonPropertyName("nonce")]
		public string A\u008E\u0091\u0099\u008C\u0098\u0095\u008A\u008B\u0096\u008F
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u008C\u0092\u008D\u0096\u0096\u0093\u008E\u0094\u0092\u008D;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u008C\u0092\u008D\u0096\u0096\u0093\u008E\u0094\u0092\u008D = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c39cb8e78fa412ba973477767f4d094 == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060001E1 RID: 481 RVA: 0x00010A2C File Offset: 0x0000EC2C
		// (set) Token: 0x060001E2 RID: 482 RVA: 0x00010A3C File Offset: 0x0000EC3C
		[JsonPropertyName("data")]
		public A\u0091\u008D\u008F\u008B\u008C\u0099\u0097\u0094\u0099\u0088 A\u0089\u0095\u009C\u009A\u0089\u008D\u0092\u0094\u0098\u0094
		{
			[MethodImpl(MethodImplOptions.NoInlining)]
			get;
			[MethodImpl(MethodImplOptions.NoInlining)]
			set;
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x00010A4C File Offset: 0x0000EC4C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0097\u0095\u0093\u0092\u0099\u009B\u009B\u009E\u009A\u0089()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u008C\u0092\u008D\u0096\u0096\u0093\u008E\u0094\u0092\u008D = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_84da5965a68844438b1a549d826fac7a != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x00010AC0 File Offset: 0x0000ECC0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool AA\u0095\u0096\u0099\u0094\u008B\u0091\u0094\u009C\u008C()
		{
			return A\u0097\u0095\u0093\u0092\u0099\u009B\u009B\u009E\u009A\u0089<A\u0091\u008D\u008F\u008B\u008C\u0099\u0097\u0094\u0099\u0088>.A\u009E\u0094\u0090\u009D\u008A\u008D\u0097\u0094\u0089\u009D == null;
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x00010AD4 File Offset: 0x0000ECD4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object AA\u0098\u009A\u0088\u009A\u009D\u0093\u0097\u009D\u0099()
		{
			return A\u0097\u0095\u0093\u0092\u0099\u009B\u009B\u009E\u009A\u0089<A\u0091\u008D\u008F\u008B\u008C\u0099\u0097\u0094\u0099\u0088>.A\u009E\u0094\u0090\u009D\u008A\u008D\u0097\u0094\u0089\u009D;
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x00010AE4 File Offset: 0x0000ECE4
		static A\u0097\u0095\u0093\u0092\u0099\u009B\u009B\u009E\u009A\u0089()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000154 RID: 340
		[CompilerGenerated]
		private long A\u0087\u009C\u009D\u0091\u0090\u008D\u0094\u0090\u009C\u009A;

		// Token: 0x04000155 RID: 341
		[CompilerGenerated]
		private string A\u008C\u0092\u008D\u0096\u0096\u0093\u008E\u0094\u0092\u008D;

		// Token: 0x04000156 RID: 342
		[CompilerGenerated]
		private A\u0091\u008D\u008F\u008B\u008C\u0099\u0097\u0094\u0099\u0088 A\u009E\u0096\u0094\u0097\u0095\u008B\u008F\u008B\u0097\u008E;

		// Token: 0x04000157 RID: 343
		private static object A\u009E\u0094\u0090\u009D\u008A\u008D\u0097\u0094\u0089\u009D;
	}
}
