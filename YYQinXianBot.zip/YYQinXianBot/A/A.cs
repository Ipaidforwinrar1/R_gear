﻿using System;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200003A RID: 58
	[NullableContext(1)]
	public interface A\u008B\u0091\u0087\u008A\u009C\u009D\u008E\u0090\u008F\u009B
	{
		// Token: 0x0600018F RID: 399
		int a1\u008D\u000D\u000A\u009Bmu\u009Bq5m();

		// Token: 0x06000190 RID: 400
		string f\u0095\u0095\u000D\u000A\u009Bn0y\u009802();

		// Token: 0x06000191 RID: 401
		long E\u0093\u0093\u000D\u000A\u009Bowy\u0089\u0087\u0087();

		// Token: 0x06000192 RID: 402
		string l\u008E\u0086\u000D\u000A\u009Bp8ax\u009Ax();
	}
}
