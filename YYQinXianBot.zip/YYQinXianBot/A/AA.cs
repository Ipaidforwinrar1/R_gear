﻿using System;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000036 RID: 54
	[Nullable(0)]
	[NullableContext(1)]
	public static class AA\u0089\u008C\u0095\u0097\u0092\u0094\u008D\u0095\u0097
	{
		// Token: 0x06000173 RID: 371 RVA: 0x0000ECE0 File Offset: 0x0000CEE0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u0091\u0090\u008B\u008F\u009E\u008D\u008C\u0094\u0096\u0092()
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					goto IL_0055;
				case 2:
				{
					RandomNumberGenerator randomNumberGenerator = RandomNumberGenerator.Create();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				}
				break;
			}
			string text;
			return text;
			IL_0055:
			try
			{
				byte[] array = new byte[32];
				int num3 = 2;
				int num4 = num3;
				for (;;)
				{
					switch (num4)
					{
					case 1:
						text = Convert.ToBase64String(array);
						num4 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1803988e08d94458a1484838316ae19f == 0)
						{
							num4 = 0;
							continue;
						}
						continue;
					case 2:
					{
						RandomNumberGenerator randomNumberGenerator;
						randomNumberGenerator.GetBytes(array);
						num4 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8dc5d10e77244a8e9604eb3c3cdc8971 != 0)
						{
							num4 = 1;
							continue;
						}
						continue;
					}
					}
					break;
				}
			}
			finally
			{
				RandomNumberGenerator randomNumberGenerator;
				if (randomNumberGenerator != null)
				{
					int num5 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_b8dd0272817d4ee09eb670a93868b3ef != 0)
					{
						num5 = 0;
					}
					for (;;)
					{
						switch (num5)
						{
						default:
							((IDisposable)randomNumberGenerator).Dispose();
							num5 = 1;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_4792882b11f1461bbd77b2206a4b5583 == 0)
							{
								num5 = 1;
							}
							break;
						case 1:
							goto IL_013E;
						}
					}
				}
				IL_013E:;
			}
			return text;
		}

		// Token: 0x06000174 RID: 372 RVA: 0x0000EE60 File Offset: 0x0000D060
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u009D\u009C\u0086\u008D\u008D\u009E\u0087\u008B\u0088\u0091(object \u0020, object \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					num2 = 4;
					continue;
				case 2:
					if (string.IsNullOrEmpty(\u0020))
					{
						goto IL_003F;
					}
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					goto IL_0391;
				case 4:
					try
					{
						byte[] array = Convert.FromBase64String(\u0020.Replace(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(141962467 ^ 497455498 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c83fdfd7feb346bcbdc0a4168723b361), "").Replace(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1536669816 ^ -353260358 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb), "").Replace(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1959070071 >> 2) ^ -166553749 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad), "")
							.Replace(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(--1451827733 ^ 993722060 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754), "")
							.Trim());
						int num3 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 == 0)
						{
							num3 = 1;
						}
						RSA rsa;
						for (;;)
						{
							switch (num3)
							{
							case 1:
								rsa = RSA.Create();
								num3 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_81c95615ba8542caa2cd904fc96bdf5c == 0)
								{
									num3 = 0;
									continue;
								}
								continue;
							}
							break;
						}
						try
						{
							int num4;
							rsa.ImportSubjectPublicKeyInfo(array, out num4);
							int num5 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce != 0)
							{
								num5 = 0;
							}
							string text;
							for (;;)
							{
								byte[] bytes;
								switch (num5)
								{
								case 1:
									text = Convert.ToBase64String(rsa.Encrypt(bytes, RSAEncryptionPadding.Pkcs1));
									num5 = 2;
									continue;
								case 2:
									goto IL_02B2;
								}
								bytes = Encoding.UTF8.GetBytes(\u0020);
								num5 = 0;
								if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 == 0)
								{
									num5 = 1;
								}
							}
							IL_02B2:
							return text;
						}
						finally
						{
							if (rsa != null)
							{
								goto IL_02F7;
							}
							int num6 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 == 0)
							{
								num6 = 1;
							}
							IL_02E1:
							switch (num6)
							{
							default:
								IL_02F7:
								((IDisposable)rsa).Dispose();
								num6 = 2;
								goto IL_02E1;
							case 1:
								break;
							case 2:
								break;
							}
						}
					}
					catch (Exception ex)
					{
						int num7 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd == 0)
						{
							num7 = 0;
						}
						switch (num7)
						{
						default:
							throw new InvalidOperationException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-55930691 ^ -826668725 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_03d60c6a09754e3e82db491095d4955d), ex);
						}
					}
					goto IL_0391;
				case 5:
					goto IL_003F;
				case 6:
				{
					string text;
					return text;
				}
				}
				break;
				IL_0391:
				if (string.IsNullOrEmpty(\u0020))
				{
					break;
				}
				num2 = 2;
			}
			goto IL_00AA;
			IL_003F:
			throw new ArgumentException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1699391948 ^ -150565929 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-364525890 ^ -1670879713 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427));
			IL_00AA:
			throw new ArgumentException(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1927311401 ^ 1715231600 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_66b143f977b0493ba8057bf1d89e49ad), A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1609698565 >> 2) ^ 1928111879 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_90673161207945fc8c997b096847d363));
		}

		// Token: 0x06000175 RID: 373 RVA: 0x0000F26C File Offset: 0x0000D46C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0098\u0095\u0091\u0096\u0088\u008C\u009E\u009E\u0099\u0095()
		{
			return AA\u0089\u008C\u0095\u0097\u0092\u0094\u008D\u0095\u0097.A\u008D\u0086\u0086\u0086\u008E\u008E\u0096\u0092\u0086\u0089 == null;
		}

		// Token: 0x06000176 RID: 374 RVA: 0x0000F280 File Offset: 0x0000D480
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static AA\u0089\u008C\u0095\u0097\u0092\u0094\u008D\u0095\u0097 A\u0093\u0086\u0089\u0087\u009B\u008D\u0092\u0094\u0087\u0093()
		{
			return AA\u0089\u008C\u0095\u0097\u0092\u0094\u008D\u0095\u0097.A\u008D\u0086\u0086\u0086\u008E\u008E\u0096\u0092\u0086\u0089;
		}

		// Token: 0x06000177 RID: 375 RVA: 0x0000F290 File Offset: 0x0000D490
		static AA\u0089\u008C\u0095\u0097\u0092\u0094\u008D\u0095\u0097()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400012F RID: 303
		internal static object A\u008D\u0086\u0086\u0086\u008E\u008E\u0096\u0092\u0086\u0089;
	}
}
