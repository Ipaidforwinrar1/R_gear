﻿using System;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000052 RID: 82
	public class A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E
	{
		// Token: 0x0600027D RID: 637 RVA: 0x0001510C File Offset: 0x0001330C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u009E\u0093\u0091\u008A\u0098\u0087\u0097\u0094\u0096\u0090 A\u008D\u008A\u0094\u0095\u0087\u008C\u0095\u0094\u0095\u008C()
		{
			return this.A\u0093\u0096\u008C\u0092\u009D\u0091\u009C\u0092\u009E\u008E;
		}

		// Token: 0x0600027E RID: 638 RVA: 0x0001511C File Offset: 0x0001331C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008C\u009A\u0093\u009B\u008D\u0090\u009B\u0092\u008C\u0094(A\u009E\u0093\u0091\u008A\u0098\u0087\u0097\u0094\u0096\u0090 \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0093\u0096\u008C\u0092\u009D\u0091\u009C\u0092\u009E\u008E = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d375a57ab5714e038011351b58752657 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x0600027F RID: 639 RVA: 0x0001517C File Offset: 0x0001337C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public char AA\u009C\u009D\u008F\u008B\u008F\u0086\u0087\u0087\u0087()
		{
			return this.A\u009D\u008A\u008B\u0099\u008A\u008B\u0092\u009E\u0086\u009A;
		}

		// Token: 0x06000280 RID: 640 RVA: 0x0001518C File Offset: 0x0001338C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0093\u0090\u008A\u0093\u009C\u0094\u0097\u0094\u0099\u0097(char \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u009D\u008A\u008B\u0099\u008A\u008B\u0092\u009E\u0086\u009A = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8a7706961f2842d0974d2f2cdf994020 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x06000281 RID: 641 RVA: 0x000151EC File Offset: 0x000133EC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public double A\u0095\u0095\u009D\u0089\u0089\u0092\u0098\u009E\u0092\u0091()
		{
			return this.A\u0087\u0099\u0096\u0087\u009A\u0086\u009D\u0090\u009A\u0088;
		}

		// Token: 0x06000282 RID: 642 RVA: 0x000151FC File Offset: 0x000133FC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0089\u008F\u009C\u009E\u0095\u009C\u0090\u008B\u0098\u008B(double \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0087\u0099\u0096\u0087\u009A\u0086\u009D\u0090\u009A\u0088 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_920a4bea3a494b318935361960b3a6ed == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x06000283 RID: 643 RVA: 0x0001525C File Offset: 0x0001345C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8a7706961f2842d0974d2f2cdf994020 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x06000284 RID: 644 RVA: 0x000152C0 File Offset: 0x000134C0
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0094\u009E\u008A\u0095\u008B\u0097\u0086\u0092\u008B\u0091()
		{
			return A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E.AA\u0094\u0098\u008D\u0092\u009C\u0097\u0098\u009B\u009A == null;
		}

		// Token: 0x06000285 RID: 645 RVA: 0x000152D4 File Offset: 0x000134D4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E A\u009D\u0096\u009B\u008E\u008F\u0087\u0093\u0092\u0099\u009A()
		{
			return A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E.AA\u0094\u0098\u008D\u0092\u009C\u0097\u0098\u009B\u009A;
		}

		// Token: 0x06000286 RID: 646 RVA: 0x000152E4 File Offset: 0x000134E4
		static A\u0095\u008D\u0092\u0087\u008A\u009D\u0093\u0090\u0098\u008E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x0400019D RID: 413
		[CompilerGenerated]
		private A\u009E\u0093\u0091\u008A\u0098\u0087\u0097\u0094\u0096\u0090 A\u0093\u0096\u008C\u0092\u009D\u0091\u009C\u0092\u009E\u008E;

		// Token: 0x0400019E RID: 414
		[CompilerGenerated]
		private char A\u009D\u008A\u008B\u0099\u008A\u008B\u0092\u009E\u0086\u009A;

		// Token: 0x0400019F RID: 415
		[CompilerGenerated]
		private double A\u0087\u0099\u0096\u0087\u009A\u0086\u009D\u0090\u009A\u0088;

		// Token: 0x040001A0 RID: 416
		internal static object AA\u0094\u0098\u008D\u0092\u009C\u0097\u0098\u009B\u009A;
	}
}
