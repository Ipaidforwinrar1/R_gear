﻿using System;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000045 RID: 69
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089
	{
		// Token: 0x060001E7 RID: 487 RVA: 0x00010AEC File Offset: 0x0000ECEC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public int AA\u0092\u009A\u0090\u008B\u009D\u0089\u0086\u009B\u009E()
		{
			return this.A\u0097\u0096\u008F\u0097\u009D\u0097\u008F\u0090\u0099\u008F;
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x00010AFC File Offset: 0x0000ECFC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u009C\u009E\u008F\u0093\u0095\u008A\u0092\u0090\u0099\u0095(int \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u0097\u0096\u008F\u0097\u009D\u0097\u008F\u0090\u0099\u008F = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_278e1e36c9644b209011aa0d1a2f6ef6 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x00010B5C File Offset: 0x0000ED5C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u008F\u0096\u008F\u008C\u0095\u0087\u008C\u0090\u008F\u0099()
		{
			return this.A\u009B\u009B\u0096\u008C\u0090\u008E\u008D\u008B\u0092\u008E;
		}

		// Token: 0x060001EA RID: 490 RVA: 0x00010B6C File Offset: 0x0000ED6C
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u0089\u008A\u009C\u0086\u0087\u0088\u009B\u0092\u009D\u0094(string \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u009B\u009B\u0096\u008C\u0090\u008E\u008D\u008B\u0092\u008E = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d != 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x060001EB RID: 491 RVA: 0x00010BCC File Offset: 0x0000EDCC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u0093\u0092\u009E\u008F\u008F\u0096\u008F\u0094\u008C\u0092()
		{
			return this.AA\u0096\u008C\u008C\u0097\u0092\u008A\u0086\u008E\u0087;
		}

		// Token: 0x060001EC RID: 492 RVA: 0x00010BDC File Offset: 0x0000EDDC
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AAA\u0093\u009B\u0088\u0096\u0089\u0099\u009A\u0092(string \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.AA\u0096\u008C\u008C\u0097\u0092\u008A\u0086\u008E\u0087 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a92c90848a014df384ec9c975a65e62a == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x060001ED RID: 493 RVA: 0x00010C3C File Offset: 0x0000EE3C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public string A\u0088\u0099\u0097\u009C\u008D\u008E\u0096\u0092\u0096\u0086()
		{
			string text;
			switch (1)
			{
			case 1:
				try
				{
					text = A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094.A\u009B\u0091\u0099\u0096\u0096\u009C\u0096\u0092\u009D\u009C(this.A\u0093\u0092\u009E\u008F\u008F\u0096\u008F\u0094\u008C\u0092(), null);
					int num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c != 0)
					{
						num = 0;
					}
					switch (num)
					{
					}
				}
				catch
				{
					int num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d93d7c9b9a374fd99941c9395358400a != 0)
					{
						num2 = 1;
					}
					for (;;)
					{
						switch (num2)
						{
						case 1:
							text = this.A\u0093\u0092\u009E\u008F\u008F\u0096\u008F\u0094\u008C\u0092();
							num2 = 0;
							if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9045a27d79f243e6b13dacc2b07bc481 != 0)
							{
								num2 = 0;
								continue;
							}
							continue;
						}
						break;
					}
				}
				break;
			}
			return text;
		}

		// Token: 0x060001EE RID: 494 RVA: 0x00010D4C File Offset: 0x0000EF4C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public override string ToString()
		{
			int num = 1;
			int num2 = num;
			DefaultInterpolatedStringHandler defaultInterpolatedStringHandler;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(2, 2);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-2096723947 << 2) ^ 70739862 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e));
					num2 = 3;
					continue;
				case 3:
					defaultInterpolatedStringHandler.AppendFormatted(this.A\u008F\u0096\u008F\u008C\u0095\u0087\u008C\u0090\u008F\u0099());
					num2 = 4;
					continue;
				case 4:
					goto IL_0069;
				}
				defaultInterpolatedStringHandler.AppendFormatted<int>(this.AA\u0092\u009A\u0090\u008B\u009D\u0089\u0086\u009B\u009E());
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d == 0)
				{
					num2 = 2;
				}
			}
			IL_0069:
			return defaultInterpolatedStringHandler.ToStringAndClear();
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00010E34 File Offset: 0x0000F034
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u009B\u009B\u0096\u008C\u0090\u008E\u008D\u008B\u0092\u008E = string.Empty;
			this.AA\u0096\u008C\u008C\u0097\u0092\u008A\u0086\u008E\u0087 = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8303e4c6935047879936422b129218be == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x00010EB8 File Offset: 0x0000F0B8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0095\u009D\u008E\u0096\u0088\u0099\u009C\u008B\u0090\u0092()
		{
			return A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089.A\u0092\u0089\u0089\u008F\u0093\u0093\u0098\u0092\u008F\u0093 == null;
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x00010ECC File Offset: 0x0000F0CC
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089 AA\u008F\u008C\u0099\u0096\u0088\u008A\u008A\u008B\u0086()
		{
			return A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089.A\u0092\u0089\u0089\u008F\u0093\u0093\u0098\u0092\u008F\u0093;
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x00010EDC File Offset: 0x0000F0DC
		static A\u008F\u008D\u0097\u0093\u008B\u0090\u0086\u008B\u008D\u0089()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000158 RID: 344
		[CompilerGenerated]
		private int A\u0097\u0096\u008F\u0097\u009D\u0097\u008F\u0090\u0099\u008F;

		// Token: 0x04000159 RID: 345
		[CompilerGenerated]
		private string A\u009B\u009B\u0096\u008C\u0090\u008E\u008D\u008B\u0092\u008E;

		// Token: 0x0400015A RID: 346
		[CompilerGenerated]
		private string AA\u0096\u008C\u008C\u0097\u0092\u008A\u0086\u008E\u0087;

		// Token: 0x0400015B RID: 347
		internal static object A\u0092\u0089\u0089\u008F\u0093\u0093\u0098\u0092\u008F\u0093;
	}
}
