﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000048 RID: 72
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A
	{
		// Token: 0x06000204 RID: 516 RVA: 0x000117EC File Offset: 0x0000F9EC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] A\u0089\u0087\u0086\u008B\u008E\u0099\u009B\u0090\u0099\u0090(object \u0020)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(5, array, null);
					num2 = 3;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_5ddb277eb30a483ead398b1695e56f5b == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 3:
					goto IL_008C;
				}
				array[0] = \u0020;
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8c924468ee9547ed99cf8509f39ab8ad == 0)
				{
					num2 = 1;
				}
			}
			IL_008C:
			return (byte[])array2[0];
		}

		// Token: 0x06000205 RID: 517 RVA: 0x000118BC File Offset: 0x0000FABC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] A\u008F\u0097\u0091\u0087\u0098\u008F\u008C\u008B\u008D\u008E(object \u0020)
		{
			int num = 3;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					goto IL_0074;
				case 2:
					array[0] = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					array = new object[1];
					num2 = 2;
					continue;
				}
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(6, array, null);
				num2 = 1;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b != 0)
				{
					num2 = 0;
				}
			}
			IL_0074:
			return (byte[])array2[0];
		}

		// Token: 0x06000206 RID: 518 RVA: 0x00011974 File Offset: 0x0000FB74
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] AA\u0087\u0093\u008B\u0097\u0090\u008C\u009C\u0095\u008F(object \u0020)
		{
			int num = 3;
			int num2 = num;
			object[] array;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					object[] array2;
					array = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(7, array2, null);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_6a1032b9337c4c8e9aa4deb73c96a427 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 2:
				{
					object[] array2;
					array2[0] = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				case 3:
				{
					object[] array2 = new object[1];
					num2 = 2;
					continue;
				}
				}
				break;
			}
			return (byte[])array[0];
		}

		// Token: 0x06000207 RID: 519 RVA: 0x00011A2C File Offset: 0x0000FC2C
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] A\u0087\u009D\u0099\u0096\u009C\u008C\u008D\u0092\u008F\u0092(object \u0020)
		{
			int num = 2;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					object[] array;
					array[0] = \u0020;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1d35cedc33144a818d13d3e4a8659fe9 == 0)
					{
						num2 = 3;
						continue;
					}
					continue;
				}
				case 2:
				{
					object[] array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_57de3c904ab143e3b1043ba047f687ca != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				case 3:
				{
					object[] array;
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(8, array, null);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2c9177097f6d4245975a6f4f2351fc33 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				}
				break;
			}
			return (byte[])array2[0];
		}

		// Token: 0x06000208 RID: 520 RVA: 0x00011AFC File Offset: 0x0000FCFC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static byte[] A\u009D\u0089\u008F\u008E\u009C\u0097\u0099\u0094\u009B\u009E(object \u0020)
		{
			int num = 3;
			int num2 = num;
			object[] array;
			for (;;)
			{
				switch (num2)
				{
				default:
					goto IL_0033;
				case 1:
				{
					object[] array2;
					array = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(9, array2, null);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c6b856dbddf14282afbbb88f4b71059a == 0)
					{
						num2 = 0;
					}
					break;
				}
				case 2:
				{
					object[] array2;
					array2[0] = \u0020;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0691267dca54481597a4b1f14f90aa9d == 0)
					{
						num2 = 1;
					}
					break;
				}
				case 3:
				{
					object[] array2 = new object[1];
					num2 = 2;
					break;
				}
				}
			}
			IL_0033:
			return (byte[])array[0];
		}

		// Token: 0x06000209 RID: 521 RVA: 0x00011BB4 File Offset: 0x0000FDB4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static byte[] AA\u0093\u009A\u0086\u0087\u0092\u009A\u0090\u0099\u008B(object \u0020, object \u0020)
		{
			int num = 2;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array[0] = \u0020;
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_ca4cfff71871411997ee2c1fb2f8f95e == 0)
					{
						num2 = 4;
						continue;
					}
					continue;
				case 2:
					array = new object[2];
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 3:
					goto IL_0062;
				case 4:
					array[1] = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_c5518c15345b4b68b42acb503192f55c != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(10, array, null);
				num2 = 3;
			}
			IL_0062:
			return (byte[])array2[0];
		}

		// Token: 0x0600020A RID: 522 RVA: 0x00011C9C File Offset: 0x0000FE9C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static byte[] A\u0096\u0090\u008C\u008B\u0096\u008E\u0089\u0090\u0092\u0093(object \u0020, object \u0020)
		{
			int num = 2;
			object[] array2;
			for (;;)
			{
				int num2 = num;
				object[] array;
				for (;;)
				{
					switch (num2)
					{
					default:
						goto IL_0037;
					case 1:
						array[0] = \u0020;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e != 0)
						{
							num2 = 0;
						}
						break;
					case 2:
						array = new object[2];
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_91ebce23836241af8cb3ecaf6a70057f != 0)
						{
							num2 = 1;
						}
						break;
					case 3:
						goto IL_00B1;
					case 4:
						goto IL_0051;
					}
				}
				IL_0037:
				array[1] = \u0020;
				num = 3;
				continue;
				IL_00B1:
				array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(11, array, null);
				num = 4;
			}
			IL_0051:
			return (byte[])array2[0];
		}

		// Token: 0x0600020B RID: 523 RVA: 0x00011D78 File Offset: 0x0000FF78
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u0098\u0092\u008E\u008C\u0098\u0095\u0093\u009E\u009C\u0090(object \u0020, object \u0020)
		{
			object bytes = Encoding.UTF8.GetBytes(\u0020);
			byte[] bytes2 = Encoding.UTF8.GetBytes(\u0020);
			return Convert.ToBase64String(A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A.AA\u0093\u009A\u0086\u0087\u0092\u009A\u0090\u0099\u008B(bytes, bytes2));
		}

		// Token: 0x0600020C RID: 524 RVA: 0x00011DB0 File Offset: 0x0000FFB0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u008E\u008B\u009B\u009C\u0089\u008B\u008B\u0090\u0092\u0086(object \u0020, object \u0020)
		{
			int num = 1;
			int num2 = num;
			byte[] array;
			for (;;)
			{
				switch (num2)
				{
				default:
					goto IL_002B;
				case 1:
				{
					object obj = Convert.FromBase64String(\u0020);
					byte[] bytes = Encoding.UTF8.GetBytes(\u0020);
					array = A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A.A\u0096\u0090\u008C\u008B\u0096\u008E\u0089\u0090\u0092\u0093(obj, bytes);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 == 0)
					{
						num2 = 0;
					}
					break;
				}
				}
			}
			IL_002B:
			return Encoding.UTF8.GetString(array);
		}

		// Token: 0x0600020D RID: 525 RVA: 0x00011E30 File Offset: 0x00010030
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600020E RID: 526 RVA: 0x00011E94 File Offset: 0x00010094
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool AA\u0093\u0097\u0098\u0093\u0092\u0096\u008E\u0096\u008B()
		{
			return A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A.A\u009A\u008F\u009B\u0096\u009B\u0096\u009B\u0092\u0094\u0099 == null;
		}

		// Token: 0x0600020F RID: 527 RVA: 0x00011EA8 File Offset: 0x000100A8
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A AA\u0087\u0088\u008B\u0095\u008C\u0099\u008F\u009B\u0097()
		{
			return A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A.A\u009A\u008F\u009B\u0096\u009B\u0096\u009B\u0092\u0094\u0099;
		}

		// Token: 0x06000210 RID: 528 RVA: 0x00011EB8 File Offset: 0x000100B8
		static A\u0096\u008E\u0095\u0089\u0098\u009E\u009A\u0092\u0089\u008A()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000162 RID: 354
		internal static object A\u009A\u008F\u009B\u0096\u009B\u0096\u009B\u0092\u0094\u0099;
	}
}
