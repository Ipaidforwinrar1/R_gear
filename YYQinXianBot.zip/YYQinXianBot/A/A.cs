﻿using System;
using System.Runtime.CompilerServices;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000054 RID: 84
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094
	{
		// Token: 0x06000287 RID: 647 RVA: 0x000152EC File Offset: 0x000134EC
		[MethodImpl(MethodImplOptions.NoInlining)]
		private static string A\u0091\u008C\u008B\u0097\u009D\u0090\u0094\u009E\u008E\u0096(object \u0020)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				switch (num2)
				{
				default:
				{
					object[] array;
					array[0] = \u0020;
					num2 = 3;
					break;
				}
				case 1:
				{
					object[] array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3f1903d0114e4a7ea4b860c994faf9cc == 0)
					{
						num2 = 0;
					}
					break;
				}
				case 2:
					goto IL_0049;
				case 3:
				{
					object[] array;
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(19, array, null);
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 == 0)
					{
						num2 = 0;
					}
					break;
				}
				}
			}
			IL_0049:
			return (string)array2[0];
		}

		// Token: 0x06000288 RID: 648 RVA: 0x000153A4 File Offset: 0x000135A4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u008E\u009B\u0097\u008A\u0098\u0091\u0090\u0094\u0093\u009C(object \u0020, [Nullable(2)] string key = null)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				switch (num2)
				{
				default:
				{
					object[] array;
					array[0] = \u0020;
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 == 0)
					{
						num2 = 1;
					}
					break;
				}
				case 1:
				{
					object[] array = new object[2];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8f31c15439234923b14fd39c83cec21f != 0)
					{
						num2 = 0;
					}
					break;
				}
				case 2:
					goto IL_0078;
				case 3:
				{
					object[] array;
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(20, array, null);
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c != 0)
					{
						num2 = 2;
					}
					break;
				}
				case 4:
				{
					object[] array;
					array[1] = key;
					num2 = 3;
					break;
				}
				}
			}
			IL_0078:
			return (string)array2[0];
		}

		// Token: 0x06000289 RID: 649 RVA: 0x0001548C File Offset: 0x0001368C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u009B\u0091\u0099\u0096\u0096\u009C\u0096\u0092\u009D\u009C(object \u0020, [Nullable(2)] string key = null)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[2];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(21, array, null);
					num2 = 4;
					continue;
				case 3:
					array[1] = key;
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_cfd07f15044a43fbbfaf4b9aecbd2fd6 != 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 4:
					goto IL_0091;
				}
				array[0] = \u0020;
				num2 = 3;
			}
			IL_0091:
			return (string)array2[0];
		}

		// Token: 0x0600028A RID: 650 RVA: 0x00015560 File Offset: 0x00013760
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string A\u009D\u0088\u008D\u0090\u0091\u0099\u0096\u0094\u0089\u009D(object \u0020)
		{
			int num = 1;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				object[] array;
				switch (num2)
				{
				case 1:
					array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					goto IL_0033;
				case 3:
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(22, array, null);
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_1211ee101e804cb6846c860fe2402754 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				array[0] = \u0020;
				num2 = 3;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 == 0)
				{
					num2 = 3;
				}
			}
			IL_0033:
			return (string)array2[0];
		}

		// Token: 0x0600028B RID: 651 RVA: 0x00015630 File Offset: 0x00013830
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static string AA\u008E\u0098\u0089\u008D\u009A\u008F\u0099\u0095\u0086(object \u0020)
		{
			int num = 2;
			int num2 = num;
			object[] array2;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					object[] array;
					array[0] = \u0020;
					num2 = 3;
					continue;
				}
				case 2:
				{
					object[] array = new object[1];
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 != 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				case 3:
				{
					object[] array;
					array2 = AA\u008C\u0088\u008A\u0087\u008B\u0091\u0087\u008E\u009C.A\u0098\u008C\u009E\u0098\u009A\u009A\u0094\u0094\u0089\u009D(23, array, null);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				}
				break;
			}
			return (string)array2[0];
		}

		// Token: 0x0600028C RID: 652 RVA: 0x000156E8 File Offset: 0x000138E8
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_fb7b7adb6e6747ef81ebb3c181669ada == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600028D RID: 653 RVA: 0x0001574C File Offset: 0x0001394C
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 == 0)
					{
						num2 = 3;
					}
					break;
				case 1:
					A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e == 0)
					{
						num2 = 0;
					}
					break;
				case 2:
					return;
				case 3:
					A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094.AA\u008A\u008D\u0086\u0092\u009B\u0093\u0092\u008C\u0089 = new A\u0086\u0086\u0099\u0096\u0097\u008F\u0091\u0094\u0097\u0087(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(649406881 ^ -2075055971 ^ -482767121 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0fa968d1b98f47aa9358e00f884ca05b));
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f != 0)
					{
						num2 = 2;
					}
					break;
				}
			}
		}

		// Token: 0x0600028E RID: 654 RVA: 0x0001581C File Offset: 0x00013A1C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009C\u0099\u0097\u0088\u0086\u0095\u0093\u0092\u0098\u0099()
		{
			return A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094.AAA\u008A\u0087\u009C\u008D\u0087\u0098\u0091\u009A == null;
		}

		// Token: 0x0600028F RID: 655 RVA: 0x00015830 File Offset: 0x00013A30
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094 A\u0098\u0086\u0095\u008C\u0090\u008D\u008F\u009E\u0096\u0086()
		{
			return A\u008B\u0089\u0096\u0087\u009C\u009D\u008E\u008B\u0086\u0094.AAA\u008A\u0087\u009C\u008D\u0087\u0098\u0091\u009A;
		}

		// Token: 0x040001A2 RID: 418
		private static readonly object AA\u008A\u008D\u0086\u0092\u009B\u0093\u0092\u008C\u0089;

		// Token: 0x040001A3 RID: 419
		internal static object AAA\u008A\u0087\u009C\u008D\u0087\u0098\u0091\u009A;
	}
}
