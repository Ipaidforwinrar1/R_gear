﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200003B RID: 59
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<[Nullable(2)] A\u009B\u0096\u0087\u0095\u009B\u0092\u0087\u0090\u0093\u0099> : A\u008B\u0091\u0087\u008A\u009C\u009D\u008E\u0090\u008F\u009B
	{
		// Token: 0x17000017 RID: 23
		// (get) Token: 0x06000193 RID: 403 RVA: 0x0000FB9C File Offset: 0x0000DD9C
		// (set) Token: 0x06000194 RID: 404 RVA: 0x0000FBAC File Offset: 0x0000DDAC
		[JsonPropertyName("code")]
		public int Code
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0090\u009C\u0094\u0093\u0099\u0086\u0090\u009E\u0095\u008F;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u0090\u009C\u0094\u0093\u0099\u0086\u0090\u009E\u0095\u008F = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000195 RID: 405 RVA: 0x0000FC0C File Offset: 0x0000DE0C
		// (set) Token: 0x06000196 RID: 406 RVA: 0x0000FC1C File Offset: 0x0000DE1C
		[Nullable(2)]
		[JsonPropertyName("data")]
		public A\u009B\u0096\u0087\u0095\u009B\u0092\u0087\u0090\u0093\u0099 A\u0087\u0088\u009E\u0086\u009D\u009E\u0095\u009E\u009D\u0092
		{
			[NullableContext(2)]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get;
			[NullableContext(2)]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set;
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000197 RID: 407 RVA: 0x0000FC2C File Offset: 0x0000DE2C
		// (set) Token: 0x06000198 RID: 408 RVA: 0x0000FC3C File Offset: 0x0000DE3C
		[JsonPropertyName("message")]
		public string Message
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u009D\u008C\u008B\u0091\u009E\u009B\u008A\u0092\u0097\u0096;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u009D\u008C\u008B\u0091\u009E\u009B\u008A\u0092\u0097\u0096 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_113c357a79e64b4185d20e116a9eaadd != 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000199 RID: 409 RVA: 0x0000FC9C File Offset: 0x0000DE9C
		// (set) Token: 0x0600019A RID: 410 RVA: 0x0000FCAC File Offset: 0x0000DEAC
		[JsonPropertyName("timestamp")]
		public long Timestamp
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0092\u0098\u009B\u009E\u0090\u008B\u009A\u009E\u009B\u008F;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0092\u0098\u009B\u009E\u0090\u008B\u009A\u009E\u009B\u008F = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e != 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600019B RID: 411 RVA: 0x0000FD0C File Offset: 0x0000DF0C
		// (set) Token: 0x0600019C RID: 412 RVA: 0x0000FD1C File Offset: 0x0000DF1C
		[JsonPropertyName("nonce")]
		public string Nonce
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u008E\u0099\u009A\u0096\u0087\u0088\u009C\u0090\u0088\u008D;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u008E\u0099\u009A\u0096\u0087\u0088\u009C\u0090\u0088\u008D = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1e92022cc04264952d19efe296f52f == 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x0600019D RID: 413 RVA: 0x0000FD7C File Offset: 0x0000DF7C
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u009D\u008C\u008B\u0091\u009E\u009B\u008A\u0092\u0097\u0096 = string.Empty;
			this.A\u008E\u0099\u009A\u0096\u0087\u0088\u009C\u0090\u0088\u008D = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_fb7b7adb6e6747ef81ebb3c181669ada != 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600019E RID: 414 RVA: 0x0000FE00 File Offset: 0x0000E000
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u008B\u008C\u0090\u0094\u008D\u008D\u0090\u0090\u0095\u008A()
		{
			return A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u009B\u0096\u0087\u0095\u009B\u0092\u0087\u0090\u0093\u0099>.A\u008B\u0086\u008F\u008F\u0094\u009E\u0094\u009E\u0091\u009C == null;
		}

		// Token: 0x0600019F RID: 415 RVA: 0x0000FE14 File Offset: 0x0000E014
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static object A\u0092\u0091\u009C\u0099\u008C\u009E\u0090\u008B\u009E\u0086()
		{
			return A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093<A\u009B\u0096\u0087\u0095\u009B\u0092\u0087\u0090\u0093\u0099>.A\u008B\u0086\u008F\u008F\u0094\u009E\u0094\u009E\u0091\u009C;
		}

		// Token: 0x060001A0 RID: 416 RVA: 0x0000FE24 File Offset: 0x0000E024
		static A\u0090\u0096\u008C\u008D\u009C\u0098\u008D\u0090\u0092\u0093()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000138 RID: 312
		[CompilerGenerated]
		private int A\u0090\u009C\u0094\u0093\u0099\u0086\u0090\u009E\u0095\u008F;

		// Token: 0x04000139 RID: 313
		[Nullable(2)]
		[CompilerGenerated]
		private A\u009B\u0096\u0087\u0095\u009B\u0092\u0087\u0090\u0093\u0099 A\u009D\u0099\u0091\u009D\u0098\u0093\u008A\u009E\u0096\u0097;

		// Token: 0x0400013A RID: 314
		[CompilerGenerated]
		private string A\u009D\u008C\u008B\u0091\u009E\u009B\u008A\u0092\u0097\u0096;

		// Token: 0x0400013B RID: 315
		[CompilerGenerated]
		private long A\u0092\u0098\u009B\u009E\u0090\u008B\u009A\u009E\u009B\u008F;

		// Token: 0x0400013C RID: 316
		[CompilerGenerated]
		private string A\u008E\u0099\u009A\u0096\u0087\u0088\u009C\u0090\u0088\u008D;

		// Token: 0x0400013D RID: 317
		private static object A\u008B\u0086\u008F\u008F\u0094\u009E\u0094\u009E\u0091\u009C;
	}
}
