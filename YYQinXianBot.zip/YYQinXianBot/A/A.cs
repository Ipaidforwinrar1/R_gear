﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Threading;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x0200007E RID: 126
	[Obfuscation(Feature = "EZNRMERM", Exclude = false, StripAfterObfuscation = false)]
	internal class A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B : ResourceManager
	{
		// Token: 0x06000422 RID: 1058 RVA: 0x00039A58 File Offset: 0x00037C58
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B(string \u0020, Assembly \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0094\u009E\u0096\u0096\u008B\u008C\u008C\u0090\u008F\u009E = new Hashtable();
			base..ctor(\u0020, \u0020);
			int num = 0;
			if (!true)
			{
				num = 0;
			}
			switch (num)
			{
			case 0:
				goto IL_0065;
			case 1:
				break;
			default:
				goto IL_0065;
			}
			return;
			IL_0065:
			try
			{
				this.AA\u0095\u009D\u008F\u0092\u0086\u0088\u008B\u0086\u0097 = \u0020.GetType(\u0020);
				int num2 = 0;
				if (!true)
				{
					num2 = 0;
				}
				switch (num2)
				{
				default:
					return;
				}
			}
			catch
			{
				int num3 = 0;
				if (!true)
				{
					num3 = 0;
				}
				switch (num3)
				{
				default:
					return;
				}
			}
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x00039B58 File Offset: 0x00037D58
		[MethodImpl(MethodImplOptions.NoInlining)]
		static A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
			int num = 12;
			for (;;)
			{
				int num2 = num;
				BinaryReader binaryReader;
				Stream manifestResourceStream;
				string text2;
				for (;;)
				{
					int num3;
					byte[] array;
					switch (num2)
					{
					default:
						A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u0092\u009A\u0095\u0090\u0093\u008D\u0091\u009E\u0093\u008A = new Dictionary<string, Assembly>();
						num2 = 4;
						continue;
					case 1:
						binaryReader.Close();
						num2 = 9;
						continue;
					case 2:
						if (manifestResourceStream != null)
						{
							goto IL_0072;
						}
						num2 = 0;
						if (!false)
						{
							num2 = 5;
							continue;
						}
						continue;
					case 3:
						num3 = 0;
						num2 = 8;
						if (false)
						{
							num2 = 6;
							continue;
						}
						continue;
					case 4:
						goto IL_0129;
					case 5:
						return;
					case 6:
						binaryReader.BaseStream.Position = 0L;
						num2 = 7;
						if (false)
						{
							num2 = 7;
							continue;
						}
						continue;
					case 7:
						goto IL_02B7;
					case 8:
						break;
					case 9:
						try
						{
							Assembly assembly = Assembly.Load(array);
							int num4 = 0;
							if (!false)
							{
								num4 = 0;
							}
							for (;;)
							{
								int num5;
								string text;
								switch (num4)
								{
								case 1:
									num5 = 0;
									num4 = 2;
									if (!false)
									{
										num4 = 6;
										continue;
									}
									continue;
								case 2:
									A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u0092\u009A\u0095\u0090\u0093\u008D\u0091\u009E\u0093\u008A[text] = assembly;
									num4 = 5;
									if (false)
									{
										num4 = 4;
										continue;
									}
									continue;
								case 3:
									goto IL_0221;
								case 4:
									goto IL_0251;
								case 5:
									num5++;
									num4 = 0;
									if (!false)
									{
										num4 = 3;
										continue;
									}
									continue;
								case 6:
									goto IL_0221;
								case 7:
									goto IL_026E;
								}
								string[] manifestResourceNames = assembly.GetManifestResourceNames();
								num4 = 0;
								if (true)
								{
									num4 = 1;
									continue;
								}
								continue;
								IL_0221:
								if (num5 >= manifestResourceNames.Length)
								{
									num4 = 7;
									continue;
								}
								IL_0251:
								text = manifestResourceNames[num5];
								num4 = 0;
								if (!false)
								{
									num4 = 2;
								}
							}
							IL_026E:
							break;
						}
						catch
						{
							int num6 = 0;
							if (true)
							{
								num6 = 0;
							}
							switch (num6)
							{
							default:
								goto IL_0089;
							}
						}
						goto IL_02B7;
					case 10:
						num3++;
						num2 = 2;
						continue;
					case 11:
						A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
						num2 = 0;
						if (!false)
						{
							num2 = 0;
							continue;
						}
						continue;
					case 12:
						A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
						num2 = 11;
						continue;
					case 13:
						binaryReader.Read(array, 0, array.Length);
						num2 = 1;
						if (false)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 14:
						return;
					}
					IL_0089:
					manifestResourceStream = typeof(A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B).Assembly.GetManifestResourceStream(text2 + num3.ToString());
					num2 = 10;
					continue;
					IL_02B7:
					array = new byte[manifestResourceStream.Length];
					num2 = 13;
				}
				IL_0072:
				binaryReader = new BinaryReader(manifestResourceStream);
				num = 6;
				continue;
				IL_0129:
				text2 = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((1373637206 >> 5) ^ 257343660 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e0f2761790ba43c49baa366df52b462c);
				num = 3;
			}
		}

		// Token: 0x06000424 RID: 1060 RVA: 0x00039EA8 File Offset: 0x000380A8
		[MethodImpl(MethodImplOptions.NoInlining)]
		protected override ResourceSet InternalGetResourceSet(CultureInfo \u0020, bool \u0020, bool \u0020)
		{
			int num = 3;
			int num2 = num;
			ResourceSet resourceSet;
			for (;;)
			{
				string text;
				Assembly assembly;
				Stream stream;
				switch (num2)
				{
				case 0:
					goto IL_0210;
				case 1:
					goto IL_03B6;
				case 2:
					if (resourceSet != null)
					{
						num2 = 13;
						continue;
					}
					goto IL_0590;
				case 3:
					resourceSet = this.A\u0094\u009E\u0096\u0096\u008B\u008C\u008C\u0090\u008F\u009E[\u0020] as ResourceSet;
					num2 = 2;
					continue;
				case 4:
					goto IL_01BF;
				case 5:
					goto IL_029F;
				case 6:
					A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u0092\u009A\u0095\u0090\u0093\u008D\u0091\u009E\u0093\u008A.TryGetValue(text, out assembly);
					num2 = 11;
					continue;
				case 7:
					stream = this.MainAssembly.GetManifestResourceStream(text);
					num2 = 26;
					if (!A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F())
					{
						num2 = 6;
						continue;
					}
					continue;
				case 8:
					goto IL_0395;
				case 9:
					goto IL_0590;
				case 10:
					goto IL_03B6;
				case 11:
					if (assembly != null)
					{
						goto IL_028A;
					}
					num2 = 5;
					if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F())
					{
						num2 = 31;
						continue;
					}
					continue;
				case 12:
					return resourceSet;
				case 13:
					goto IL_03D7;
				case 14:
					break;
				case 15:
					goto IL_023C;
				case 16:
				{
					bool flag = false;
					num2 = 29;
					continue;
				}
				case 17:
					if (stream != null)
					{
						num2 = 10;
						continue;
					}
					goto IL_036A;
				case 18:
					goto IL_029F;
				case 19:
					goto IL_0347;
				case 20:
					goto IL_036A;
				case 21:
					goto IL_0307;
				case 22:
					goto IL_055C;
				case 23:
					goto IL_0347;
				case 24:
				{
					Hashtable a_u0094_u009E_u0096_u0096_u008B_u008C_u008C_u0090_u008F_u009E = this.A\u0094\u009E\u0096\u0096\u008B\u008C\u008C\u0090\u008F\u009E;
					num2 = 6;
					if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() == null)
					{
						num2 = 16;
						continue;
					}
					continue;
				}
				case 25:
					goto IL_028A;
				case 26:
					if (stream == null)
					{
						goto IL_031C;
					}
					num2 = 1;
					if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() == null)
					{
						num2 = 5;
						continue;
					}
					continue;
				case 27:
					stream = assembly.GetManifestResourceStream(this.AA\u0095\u009D\u008F\u0092\u0086\u0088\u008B\u0086\u0097, text);
					num2 = 1;
					if (!A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F())
					{
						num2 = 0;
						continue;
					}
					continue;
				case 28:
					goto IL_031C;
				case 29:
					try
					{
						bool flag;
						Hashtable a_u0094_u009E_u0096_u0096_u008B_u008C_u008C_u0090_u008F_u009E;
						Monitor.Enter(a_u0094_u009E_u0096_u0096_u008B_u008C_u008C_u0090_u008F_u009E, ref flag);
						int num3 = 6;
						if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() != null)
						{
							num3 = 6;
						}
						for (;;)
						{
							switch (num3)
							{
							case 0:
								goto IL_04D3;
							case 1:
							{
								ResourceSet resourceSet2;
								resourceSet = resourceSet2;
								num3 = 3;
								continue;
							}
							case 2:
							{
								ResourceSet resourceSet2;
								if (object.Equals(resourceSet2, resourceSet))
								{
									goto IL_04F4;
								}
								num3 = 0;
								if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() == null)
								{
									num3 = 0;
									continue;
								}
								continue;
							}
							case 3:
								goto IL_0448;
							case 4:
								goto IL_04F4;
							case 5:
							{
								ResourceSet resourceSet2;
								if (resourceSet2 != null)
								{
									num3 = 2;
									continue;
								}
								break;
							}
							case 6:
							{
								ResourceSet resourceSet2 = this.A\u0094\u009E\u0096\u0096\u008B\u008C\u008C\u0090\u008F\u009E[\u0020] as ResourceSet;
								num3 = 5;
								continue;
							}
							case 7:
								break;
							default:
								goto IL_04D3;
							}
							this.A\u0094\u009E\u0096\u0096\u008B\u008C\u008C\u0090\u008F\u009E.Add(\u0020, resourceSet);
							num3 = 4;
							continue;
							IL_04D3:
							resourceSet.Dispose();
							num3 = 1;
							if (!A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F())
							{
								num3 = 1;
							}
						}
						IL_0448:
						IL_04F4:
						return resourceSet;
					}
					finally
					{
						bool flag;
						if (flag)
						{
							int num4 = 0;
							if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() == null)
							{
								num4 = 0;
							}
							for (;;)
							{
								switch (num4)
								{
								default:
								{
									Hashtable a_u0094_u009E_u0096_u0096_u008B_u008C_u008C_u0090_u008F_u009E;
									Monitor.Exit(a_u0094_u009E_u0096_u0096_u008B_u008C_u008C_u0090_u008F_u009E);
									num4 = 1;
									if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() != null)
									{
										num4 = 0;
									}
									break;
								}
								case 1:
									goto IL_0551;
								}
							}
						}
						IL_0551:;
					}
					goto IL_055C;
				case 30:
					this.A\u0088\u0093\u0086\u009B\u0092\u0088\u008B\u0090\u0086\u0096 = ResourceManager.GetNeutralResourcesLanguage(this.MainAssembly);
					num2 = 1;
					if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() == null)
					{
						num2 = 4;
						continue;
					}
					continue;
				case 31:
					goto IL_03B6;
				case 32:
					goto IL_029F;
				case 33:
					goto IL_0307;
				default:
					goto IL_0210;
				}
				IL_00AB:
				resourceSet = new ResourceSet(stream);
				num2 = 24;
				continue;
				IL_01BF:
				if (!this.A\u0088\u0093\u0086\u009B\u0092\u0088\u008B\u0090\u0086\u0096.Equals(\u0020))
				{
					num2 = 23;
					continue;
				}
				goto IL_0395;
				IL_055C:
				if (this.A\u0088\u0093\u0086\u009B\u0092\u0088\u008B\u0090\u0086\u0096 != null)
				{
					goto IL_01BF;
				}
				num2 = 30;
				if (!A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F())
				{
					num2 = 22;
					continue;
				}
				continue;
				IL_0210:
				assembly = null;
				num2 = 6;
				continue;
				IL_023C:
				stream = this.MainAssembly.GetManifestResourceStream(this.AA\u0095\u009D\u008F\u0092\u0086\u0088\u008B\u0086\u0097, text);
				num2 = 32;
				if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() != null)
				{
					num2 = 12;
					continue;
				}
				continue;
				IL_031C:
				if (this.AA\u0095\u009D\u008F\u0092\u0086\u0088\u008B\u0086\u0097 != null)
				{
					goto IL_023C;
				}
				num2 = 18;
				if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() != null)
				{
					num2 = 17;
					continue;
				}
				continue;
				IL_028A:
				stream = assembly.GetManifestResourceStream(text);
				num2 = 17;
				continue;
				IL_029F:
				if (stream != null)
				{
					goto IL_03B6;
				}
				num2 = 0;
				if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() != null)
				{
					num2 = 0;
					continue;
				}
				continue;
				IL_0307:
				resourceSet = base.InternalGetResourceSet(\u0020, \u0020, \u0020);
				num2 = 12;
				continue;
				IL_0347:
				text = this.GetResourceFileName(\u0020);
				num2 = 4;
				if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() == null)
				{
					num2 = 7;
					continue;
				}
				continue;
				IL_036A:
				if (!(this.AA\u0095\u009D\u008F\u0092\u0086\u0088\u008B\u0086\u0097 != null))
				{
					goto IL_03B6;
				}
				num2 = 27;
				if (!A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F())
				{
					num2 = 4;
					continue;
				}
				continue;
				IL_0395:
				\u0020 = CultureInfo.InvariantCulture;
				num2 = 19;
				if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A() != null)
				{
					num2 = 7;
					continue;
				}
				continue;
				IL_0590:
				text = null;
				num2 = 22;
				continue;
				IL_03B6:
				if (stream != null)
				{
					goto IL_00AB;
				}
				num2 = 25;
				if (A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F())
				{
					num2 = 33;
				}
			}
			return resourceSet;
			IL_03D7:
			return resourceSet;
		}

		// Token: 0x06000425 RID: 1061 RVA: 0x0003A470 File Offset: 0x00038670
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009D\u0089\u0095\u0098\u0093\u009A\u008B\u009E\u009A\u008F()
		{
			return A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u0094\u008B\u0088\u0092\u009D\u0096\u0086\u0094\u009D\u008A == null;
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x0003A484 File Offset: 0x00038684
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B AAAA\u008D\u0091\u0094\u008A\u009E\u0089\u008A()
		{
			return A\u008E\u0098\u0090\u0098\u008C\u0087\u0094\u0090\u009B\u008B.A\u0094\u008B\u0088\u0092\u009D\u0096\u0086\u0094\u009D\u008A;
		}

		// Token: 0x04000241 RID: 577
		private object A\u0088\u0093\u0086\u009B\u0092\u0088\u008B\u0090\u0086\u0096;

		// Token: 0x04000242 RID: 578
		private Type AA\u0095\u009D\u008F\u0092\u0086\u0088\u008B\u0086\u0097;

		// Token: 0x04000243 RID: 579
		private object A\u0094\u009E\u0096\u0096\u008B\u008C\u008C\u0090\u008F\u009E;

		// Token: 0x04000244 RID: 580
		private static Dictionary<string, Assembly> A\u0092\u009A\u0095\u0090\u0093\u008D\u0091\u009E\u0093\u008A;

		// Token: 0x04000245 RID: 581
		private static object A\u0094\u008B\u0088\u0092\u009D\u0096\u0086\u0094\u009D\u008A;
	}
}
