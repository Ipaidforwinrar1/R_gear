﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Windows.Forms;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000014 RID: 20
	[NullableContext(1)]
	[Nullable(0)]
	public class A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x060000A3 RID: 163 RVA: 0x0000A8BC File Offset: 0x00008ABC
		// (remove) Token: 0x060000A4 RID: 164 RVA: 0x0000A9AC File Offset: 0x00008BAC
		[Nullable(2)]
		public event Action<double> A\u008E\u008E\u008F\u0094\u0090\u008B\u0094\u008B\u0094\u0096
		{
			[CompilerGenerated]
			[NullableContext(2)]
			[MethodImpl(MethodImplOptions.NoInlining)]
			add
			{
				int num = 2;
				int num2 = num;
				for (;;)
				{
					Action<double> action;
					Action<double> action2;
					Action<double> action3;
					switch (num2)
					{
					case 0:
						goto IL_00A1;
					case 1:
						break;
					case 2:
						action = this.A\u0098\u009A\u009C\u0089\u009E\u0086\u0099\u0090\u009B\u0089;
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2b8d2e58ea3547aba9e10495226c7200 == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 3:
						return;
					case 4:
						if (action == action2)
						{
							num2 = 3;
							continue;
						}
						break;
					case 5:
						action = Interlocked.CompareExchange<Action<double>>(ref this.A\u0098\u009A\u009C\u0089\u009E\u0086\u0099\u0090\u009B\u0089, action3, action2);
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889 != 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					default:
						goto IL_00A1;
					}
					action2 = action;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9c57da0077774a5ab62d456636f39b0d == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
					IL_00A1:
					action3 = (Action<double>)Delegate.Combine(action2, value);
					num2 = 5;
				}
			}
			[CompilerGenerated]
			[NullableContext(2)]
			[MethodImpl(MethodImplOptions.NoInlining)]
			remove
			{
				int num = 3;
				int num2 = num;
				for (;;)
				{
					Action<double> action2;
					Action<double> action3;
					switch (num2)
					{
					case 1:
					{
						Action<double> action = (Action<double>)Delegate.Remove(action2, value);
						num2 = 4;
						continue;
					}
					case 2:
						goto IL_00AD;
					case 3:
						action3 = this.A\u0098\u009A\u009C\u0089\u009E\u0086\u0099\u0090\u009B\u0089;
						num2 = 2;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 != 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					case 4:
					{
						Action<double> action;
						action3 = Interlocked.CompareExchange<Action<double>>(ref this.A\u0098\u009A\u009C\u0089\u009E\u0086\u0099\u0090\u009B\u0089, action, action2);
						num2 = 5;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf == 0)
						{
							num2 = 2;
							continue;
						}
						continue;
					}
					case 5:
						if (action3 != action2)
						{
							goto IL_00AD;
						}
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_39f0dd17e1924a2ead84728abfdc4d53 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
					IL_00AD:
					action2 = action3;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d384574c295648b99063c9621455396b != 0)
					{
						num2 = 0;
					}
				}
			}
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x0000AAB0 File Offset: 0x00008CB0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B(ProgressBar \u0020, GroupBox \u0020)
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0f1eaad0426f410480f9464ebfdfb292 != 0)
			{
				num = 1;
			}
			for (;;)
			{
				switch (num)
				{
				default:
					return;
				case 1:
					this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E = \u0020;
					num = 4;
					break;
				case 2:
					this.A\u0088\u0096\u0090\u009A\u0098\u008F\u0089\u009E\u0094\u008A();
					num = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a38905b424c9477eb3c3d2ef4ad1502c == 0)
					{
						num = 0;
					}
					break;
				case 3:
					this.A\u008A\u0086\u008B\u0098\u0091\u008A\u0095\u008B\u0095\u0093 = new ToolTip
					{
						AutoPopDelay = 5000,
						InitialDelay = 200,
						ReshowDelay = 100
					};
					num = 2;
					break;
				case 4:
					this.A\u0087\u0086\u008F\u008D\u008B\u008D\u009D\u0090\u008C\u0089 = \u0020;
					num = 3;
					break;
				}
			}
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x0000ABA0 File Offset: 0x00008DA0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0088\u0096\u0090\u009A\u0098\u008F\u0089\u009E\u0094\u008A()
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.MouseLeave += this.A\u008A\u008B\u0090\u009E\u0095\u0095\u0099\u0090\u009E\u0087;
					num2 = 4;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				case 2:
					this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.MouseMove += this.A\u008F\u0097\u0091\u0092\u008F\u0092\u0087\u0094\u0092\u0093;
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_50aea8df650d401a83a4c5c6f9214e66 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 3:
					this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.Cursor = Cursors.Hand;
					num2 = 2;
					continue;
				case 4:
					this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.MouseClick += this.A\u0087\u008A\u0090\u009C\u0092\u0093\u0096\u0092\u0086\u009C;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0c7792b0f47f430398f1eb6883c7c6ce == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				break;
			}
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x0000ACA0 File Offset: 0x00008EA0
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u0087\u008A\u0090\u009C\u0092\u0093\u0096\u0092\u0086\u009C([Nullable(2)] object sender, MouseEventArgs \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					return;
				case 2:
					return;
				case 3:
					if (!this.A\u0089\u0089\u008F\u008B\u009D\u0086\u0088\u008B\u0086\u008D)
					{
						num2 = 2;
					}
					else
					{
						double num3 = (double)\u0020.X / (double)this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.Width;
						num2 = 4;
					}
					break;
				case 4:
				{
					Action<double> a_u0098_u009A_u009C_u0089_u009E_u0086_u0099_u0090_u009B_u = this.A\u0098\u009A\u009C\u0089\u009E\u0086\u0099\u0090\u009B\u0089;
					if (a_u0098_u009A_u009C_u0089_u009E_u0086_u0099_u0090_u009B_u == null)
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a776256cdd4f4cb79343bb3efb41eb83 == 0)
						{
							num2 = 1;
						}
					}
					else
					{
						double num3;
						a_u0098_u009A_u009C_u0089_u009E_u0086_u0099_u0090_u009B_u(num3);
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_0407aeff566943d9b679ed2e59d9eb33 != 0)
						{
							num2 = 0;
						}
					}
					break;
				}
				}
			}
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x0000AD70 File Offset: 0x00008F70
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AA\u009C\u0090\u0091\u008E\u0099\u0098\u0090\u0088\u0086(bool \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u0089\u0089\u008F\u008B\u009D\u0086\u0088\u008B\u0086\u008D = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9a45e63718d44f17be2c7b1f9c466e55 == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x0000ADD0 File Offset: 0x00008FD0
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void AA\u008F\u009B\u0094\u008F\u0094\u0098\u0091\u0098\u009C(int \u0020)
		{
			int num = 3;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.Invoke(new Action(CS$<>8__locals1.A\u0094\u0094\u008A\u009E\u008B\u0097\u009E\u008B\u008F\u0090));
					num2 = 6;
					continue;
				case 2:
					CS$<>8__locals1.A\u0093\u0098\u0086\u008A\u0093\u009C\u009D\u008B\u0089\u0099 = this;
					num2 = 5;
					continue;
				case 3:
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8303e4c6935047879936422b129218be == 0)
					{
						num2 = 2;
						continue;
					}
					continue;
				case 4:
					return;
				case 5:
					CS$<>8__locals1.A\u0090\u0095\u008A\u0096\u009A\u008E\u0097\u009E\u0098\u0086 = \u0020;
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 6:
					return;
				case 7:
				{
					Control a_u0087_u0086_u008F_u008D_u008B_u008D_u009D_u0090_u008C_u = this.A\u0087\u0086\u008F\u008D\u008B\u008D\u009D\u0090\u008C\u0089;
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(4, 1);
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(1800344929 ^ 331599483 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_d6dfa1019c974a87b6fd082f4590f889));
					defaultInterpolatedStringHandler.AppendFormatted<int>(CS$<>8__locals1.A\u0090\u0095\u008A\u0096\u009A\u008E\u0097\u009E\u0098\u0086);
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-238694913 ^ -1084480671 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_7f18858cee4a4e83bd2b5dc21c4aabcb));
					a_u0087_u0086_u008F_u008D_u008B_u008D_u009D_u0090_u008C_u.Text = defaultInterpolatedStringHandler.ToStringAndClear();
					num2 = 4;
					continue;
				}
				}
				if (this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.InvokeRequired)
				{
					num2 = 1;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f6deb97ac827458ea2e5dd63e8f576e7 != 0)
					{
						num2 = 0;
					}
				}
				else
				{
					this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.Value = CS$<>8__locals1.A\u0090\u0095\u008A\u0096\u009A\u008E\u0097\u009E\u0098\u0086;
					num2 = 7;
				}
			}
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0000AF64 File Offset: 0x00009164
		[MethodImpl(MethodImplOptions.NoInlining)]
		public void A\u008D\u009E\u008A\u008E\u008C\u0088\u008E\u0090\u008D\u008E()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					this.AA\u008F\u009B\u0094\u008F\u0094\u0098\u0091\u0098\u009C(0);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_df7f2652d91543f5a2da72e8224abd5c != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				}
				this.A\u0087\u0086\u008F\u008D\u008B\u008D\u009D\u0090\u008C\u0089.Text = A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-275825843 ^ 302041667 ^ -1455597701 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a1ea44f33dbd4ce1b900784f2b402a6c);
				num2 = 2;
				if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_98785a773c4445c7ad1ec6cfc103cff4 == 0)
				{
					num2 = 2;
				}
			}
		}

		// Token: 0x060000AB RID: 171 RVA: 0x0000B014 File Offset: 0x00009214
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008F\u0097\u0091\u0092\u008F\u0092\u0087\u0094\u0092\u0093([Nullable(2)] object s, MouseEventArgs \u0020)
		{
			int num = 2;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
				{
					int num3 = (int)(Math.Clamp((double)\u0020.X / (double)this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E.Width, 0.0, 1.0) * 100.0);
					num2 = 3;
					continue;
				}
				case 2:
					if (this.A\u0089\u0089\u008F\u008B\u009D\u0086\u0088\u008B\u0086\u008D)
					{
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_8e72010bdd124c1883da7268d3caf07f == 0)
						{
							num2 = 1;
							continue;
						}
						continue;
					}
					else
					{
						this.A\u008A\u0086\u008B\u0098\u0091\u008A\u0095\u008B\u0095\u0093.SetToolTip(this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E, A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(247185273 ^ 1575194209 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a6c6c5320a2641eaba91f3a9b5d804bf));
						num2 = 1;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2785f46fba6b48baa1bee272289076d2 == 0)
						{
							num2 = 4;
							continue;
						}
						continue;
					}
					break;
				case 3:
				{
					ToolTip a_u008A_u0086_u008B_u0098_u0091_u008A_u0095_u008B_u0095_u = this.A\u008A\u0086\u008B\u0098\u0091\u008A\u0095\u008B\u0095\u0093;
					Control a_u008A_u0097_u0091_u0098_u0087_u008B_u0099_u008B_u0089_u008E = this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E;
					DefaultInterpolatedStringHandler defaultInterpolatedStringHandler = new DefaultInterpolatedStringHandler(7, 1);
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F((-1925285482 + 96378623) ^ -597076151 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_3ad8ad14358d4be09704fcb5b2bbba8b));
					int num3;
					defaultInterpolatedStringHandler.AppendFormatted<int>(num3);
					defaultInterpolatedStringHandler.AppendLiteral(A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u0094\u008B\u0096\u008E\u009B\u009B\u0097\u0090\u0094\u008F(-1480444969 ^ -755500071 ^ <Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_a8c98d5ff1a34d9284610bfefa88b283));
					a_u008A_u0086_u008B_u0098_u0091_u008A_u0095_u008B_u0095_u.SetToolTip(a_u008A_u0097_u0091_u0098_u0087_u008B_u0099_u008B_u0089_u008E, defaultInterpolatedStringHandler.ToStringAndClear());
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_20a385b13e244889ad68bdb099acf5ed == 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				}
				case 4:
					return;
				}
				break;
			}
		}

		// Token: 0x060000AC RID: 172 RVA: 0x0000B1A4 File Offset: 0x000093A4
		[CompilerGenerated]
		[MethodImpl(MethodImplOptions.NoInlining)]
		private void A\u008A\u008B\u0090\u009E\u0095\u0095\u0099\u0090\u009E\u0087([Nullable(2)] object s, EventArgs \u0020)
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				default:
					return;
				case 1:
					this.A\u008A\u0086\u008B\u0098\u0091\u008A\u0095\u008B\u0095\u0093.Hide(this.A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E);
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_70c02fc372194e58990f59ebe25c102c == 0)
					{
						num2 = 0;
					}
					break;
				}
			}
		}

		// Token: 0x060000AD RID: 173 RVA: 0x0000B20C File Offset: 0x0000940C
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u009D\u0093\u009E\u0090\u008F\u008C\u0086\u009E\u0096\u0086()
		{
			return A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B.A\u008B\u0094\u0099\u009A\u008B\u008A\u009B\u009E\u0099\u009B == null;
		}

		// Token: 0x060000AE RID: 174 RVA: 0x0000B220 File Offset: 0x00009420
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B A\u0095\u0090\u0086\u0086\u008D\u0090\u008F\u0090\u0093\u008D()
		{
			return A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B.A\u008B\u0094\u0099\u009A\u008B\u008A\u009B\u009E\u0099\u009B;
		}

		// Token: 0x060000AF RID: 175 RVA: 0x0000B230 File Offset: 0x00009430
		static A\u008C\u0087\u0094\u008D\u0092\u009D\u009E\u0090\u009C\u008B()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000076 RID: 118
		private readonly object A\u008A\u0097\u0091\u0098\u0087\u008B\u0099\u008B\u0089\u008E;

		// Token: 0x04000077 RID: 119
		private readonly object A\u0087\u0086\u008F\u008D\u008B\u008D\u009D\u0090\u008C\u0089;

		// Token: 0x04000078 RID: 120
		private readonly object A\u008A\u0086\u008B\u0098\u0091\u008A\u0095\u008B\u0095\u0093;

		// Token: 0x04000079 RID: 121
		private bool A\u0089\u0089\u008F\u008B\u009D\u0086\u0088\u008B\u0086\u008D;

		// Token: 0x0400007A RID: 122
		[Nullable(2)]
		[CompilerGenerated]
		private Action<double> A\u0098\u009A\u009C\u0089\u009E\u0086\u0099\u0090\u009B\u0089;

		// Token: 0x0400007B RID: 123
		internal static object A\u008B\u0094\u0099\u009A\u008B\u008A\u009B\u009E\u0099\u009B;
	}
}
