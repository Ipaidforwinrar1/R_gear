﻿using System;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095
{
	// Token: 0x02000039 RID: 57
	[Nullable(0)]
	[NullableContext(1)]
	public class A\u0090\u0088\u0088\u008F\u008D\u0089\u0087\u0090\u0087\u009E
	{
		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000187 RID: 391 RVA: 0x0000FA0C File Offset: 0x0000DC0C
		// (set) Token: 0x06000188 RID: 392 RVA: 0x0000FA1C File Offset: 0x0000DC1C
		[JsonPropertyName("ciphertext")]
		public string AA\u009D\u0086\u009D\u0099\u0088\u008A\u0087\u0099\u0087
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u0086\u0095\u008F\u0093\u0089\u0088\u008F\u0090\u008F\u009B;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					default:
						return;
					case 1:
						this.A\u0086\u0095\u008F\u0093\u0089\u0088\u008F\u0090\u008F\u009B = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_e31f4c5097f542c7a0f5c42de7a2553e != 0)
						{
							num2 = 0;
						}
						break;
					}
				}
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x06000189 RID: 393 RVA: 0x0000FA7C File Offset: 0x0000DC7C
		// (set) Token: 0x0600018A RID: 394 RVA: 0x0000FA8C File Offset: 0x0000DC8C
		[JsonPropertyName("sign")]
		public string A\u0095\u0091\u0093\u0095\u0094\u0088\u008C\u0090\u008A\u009E
		{
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			get
			{
				return this.A\u009A\u0098\u0088\u0098\u009B\u0094\u009C\u008B\u009A\u0088;
			}
			[CompilerGenerated]
			[MethodImpl(MethodImplOptions.NoInlining)]
			set
			{
				int num = 1;
				int num2 = num;
				for (;;)
				{
					switch (num2)
					{
					case 1:
						this.A\u009A\u0098\u0088\u0098\u009B\u0094\u009C\u008B\u009A\u0088 = value;
						num2 = 0;
						if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_2816f050e66e4575956b273a95ff5b19 != 0)
						{
							num2 = 0;
							continue;
						}
						continue;
					}
					break;
				}
			}
		}

		// Token: 0x0600018B RID: 395 RVA: 0x0000FAEC File Offset: 0x0000DCEC
		[MethodImpl(MethodImplOptions.NoInlining)]
		public A\u0090\u0088\u0088\u008F\u008D\u0089\u0087\u0090\u0087\u009E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u008F\u008A\u0087\u0096\u008C\u008E\u0099\u0092\u008A\u0098();
			A\u008D\u0094\u009E\u0098\u0096\u0092\u0094\u009E\u008D\u0091.A\u008B\u0089\u008E\u009E\u008F\u008F\u0087\u008B\u008E\u0094();
			this.A\u0086\u0095\u008F\u0093\u0089\u0088\u008F\u0090\u008F\u009B = string.Empty;
			this.A\u009A\u0098\u0088\u0098\u009B\u0094\u009C\u008B\u009A\u0088 = string.Empty;
			base..ctor();
			int num = 0;
			if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_935f791759da446480bc2f4b4a29d940 == 0)
			{
				num = 0;
			}
			switch (num)
			{
			default:
				return;
			}
		}

		// Token: 0x0600018C RID: 396 RVA: 0x0000FB70 File Offset: 0x0000DD70
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0094\u0099\u0098\u008C\u009B\u0091\u0099\u0094\u0087\u0091()
		{
			return A\u0090\u0088\u0088\u008F\u008D\u0089\u0087\u0090\u0087\u009E.A\u0086\u0096\u009A\u0096\u0091\u0095\u008F\u008B\u0096\u008C == null;
		}

		// Token: 0x0600018D RID: 397 RVA: 0x0000FB84 File Offset: 0x0000DD84
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static A\u0090\u0088\u0088\u008F\u008D\u0089\u0087\u0090\u0087\u009E A\u0092\u008E\u0097\u0091\u008A\u0090\u008E\u008B\u009D\u0090()
		{
			return A\u0090\u0088\u0088\u008F\u008D\u0089\u0087\u0090\u0087\u009E.A\u0086\u0096\u009A\u0096\u0091\u0095\u008F\u008B\u0096\u008C;
		}

		// Token: 0x0600018E RID: 398 RVA: 0x0000FB94 File Offset: 0x0000DD94
		static A\u0090\u0088\u0088\u008F\u008D\u0089\u0087\u0090\u0087\u009E()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000135 RID: 309
		[CompilerGenerated]
		private string A\u0086\u0095\u008F\u0093\u0089\u0088\u008F\u0090\u008F\u009B;

		// Token: 0x04000136 RID: 310
		[CompilerGenerated]
		private string A\u009A\u0098\u0088\u0098\u009B\u0094\u009C\u008B\u009A\u0088;

		// Token: 0x04000137 RID: 311
		internal static object A\u0086\u0096\u009A\u0096\u0091\u0095\u008F\u008B\u0096\u008C;
	}
}
