﻿using System;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using A\u008D\u0098\u0087\u0091\u008A\u008E\u0087\u009E\u0087\u0095;

namespace YYQinXianBot
{
	// Token: 0x02000013 RID: 19
	[CompilerGenerated]
	internal static class ApplicationConfiguration
	{
		// Token: 0x0600009F RID: 159 RVA: 0x0000A7F4 File Offset: 0x000089F4
		[MethodImpl(MethodImplOptions.NoInlining)]
		public static void Initialize()
		{
			int num = 1;
			int num2 = num;
			for (;;)
			{
				switch (num2)
				{
				case 1:
					Application.EnableVisualStyles();
					num2 = 0;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_9b354cb2927d4917aafec5a348022c53 != 0)
					{
						num2 = 0;
						continue;
					}
					continue;
				case 2:
					return;
				case 3:
					Application.SetHighDpiMode(HighDpiMode.DpiUnaware);
					num2 = 2;
					if (<Module>{8416050b-06f5-485a-a4bc-ee5e26ce9679}.m_4b10203f98bc47dcb6a03d95b609faf1.m_f46e6cf5ed8741ec9c0a87df272a6510 == 0)
					{
						num2 = 1;
						continue;
					}
					continue;
				}
				Application.SetCompatibleTextRenderingDefault(false);
				num2 = 3;
			}
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x0000A890 File Offset: 0x00008A90
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static bool A\u0094\u0088\u008E\u008A\u0090\u0094\u0097\u008B\u009B\u0099()
		{
			return ApplicationConfiguration.AA\u0090\u0087\u0087\u0089\u0099\u0094\u009A\u0094\u0093 == null;
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x0000A8A4 File Offset: 0x00008AA4
		[MethodImpl(MethodImplOptions.NoInlining)]
		internal static ApplicationConfiguration A\u0090\u009D\u008D\u008C\u0091\u0091\u0097\u008B\u009B\u008F()
		{
			return ApplicationConfiguration.AA\u0090\u0087\u0087\u0089\u0099\u0094\u009A\u0094\u0093;
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x0000A8B4 File Offset: 0x00008AB4
		static ApplicationConfiguration()
		{
			A\u0094\u0093\u008D\u0093\u009D\u0087\u0091\u008B\u009C\u0089.A\u009A\u008A\u0098\u0091\u0093\u009A\u0088\u009E\u0087\u008A();
		}

		// Token: 0x04000075 RID: 117
		private static ApplicationConfiguration AA\u0090\u0087\u0087\u0089\u0099\u0094\u009A\u0094\u0093;
	}
}
